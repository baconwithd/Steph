import java.nio.file.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public final class FixConsumables implements Opcodes {
 public static byte[] fix(byte[] b){ClassNode n=new ClassNode();new ClassReader(b).accept(n,0);int changed=0;
  for(MethodNode m:n.methods)if(m.name.equals("isLooping")&&m.desc.equals("()Z")){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.instructions.add(new InsnNode(ICONST_0));m.instructions.add(new InsnNode(IRETURN));changed++;}
  if(changed!=1)throw new IllegalStateException("Unexpected sound API");ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);return w.toByteArray();}
 public static void main(String[] a)throws Exception{int changes=0;try(ZipFile z=new ZipFile(a[0]);ZipOutputStream o=new ZipOutputStream(Files.newOutputStream(Path.of(a[1])))){
  var en=z.entries();while(en.hasMoreElements()){var e=en.nextElement();if(e.isDirectory())continue;byte[] d=z.getInputStream(e).readAllBytes();String name=e.getName();
   if(name.equals("ichttt/mods/firstaid/client/HealingSoundController$ItemUseSound.class")){d=fix(d);changes++;}
   if(name.equals("assets/firstaid/models/item/dirty_cloth.json")){d="{\"parent\":\"minecraft:item/generated\",\"textures\":{\"layer0\":\"firstaid:item/dirty_cloth\"}}\n".getBytes(java.nio.charset.StandardCharsets.UTF_8);changes++;}
   if(name.equals("META-INF/neoforge.mods.toml")){d=new String(d,java.nio.charset.StandardCharsets.UTF_8).replace("zomboid-v3.4.1-hud-fix","zomboid-v3.4.2-sound-cloth").getBytes(java.nio.charset.StandardCharsets.UTF_8);changes++;}
   o.putNextEntry(new ZipEntry(name));o.write(d);o.closeEntry();
  }o.putNextEntry(new ZipEntry("assets/firstaid/textures/item/dirty_cloth.png"));o.write(Files.readAllBytes(Path.of(a[2])));o.closeEntry();}
  if(changes!=3)throw new IllegalStateException("Unexpected jar "+changes);System.out.println("Patched sound, dirty cloth model and version; added texture.");}
}
