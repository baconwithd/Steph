import java.nio.file.*;import java.util.zip.*;import java.util.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public final class FixFirstAid implements Opcodes{
 public static byte[] fix(byte[] bytes){
  ClassNode n=new ClassNode();new ClassReader(bytes).accept(n,0);String owner=n.name,helper="sanitizeHealingPrompt";
  if(n.methods.stream().anyMatch(m->m.name.equals(helper)))throw new IllegalArgumentException("Already fixed");
  String pending=n.fields.stream().filter(f->f.name.equals("pendingHealingSelection")).findFirst().orElseThrow().desc;
  String prompt=n.fields.stream().filter(f->f.name.equals("interactionPrompt")).findFirst().orElseThrow().desc;
  String promptOwner=prompt.substring(1,prompt.length()-1),type="L"+owner+"$InteractionType;";
  MethodNode guard=new MethodNode(ACC_PRIVATE|ACC_STATIC,helper,"()V",null,null);LabelNode done=new LabelNode();
  guard.instructions.add(new FieldInsnNode(GETSTATIC,owner,"pendingHealingSelection",pending));guard.instructions.add(new JumpInsnNode(IFNONNULL,done));
  guard.instructions.add(new FieldInsnNode(GETSTATIC,owner,"interactionPrompt",prompt));guard.instructions.add(new JumpInsnNode(IFNULL,done));
  guard.instructions.add(new FieldInsnNode(GETSTATIC,owner,"interactionPrompt",prompt));guard.instructions.add(new MethodInsnNode(INVOKEVIRTUAL,promptOwner,"type","()"+type,false));
  guard.instructions.add(new FieldInsnNode(GETSTATIC,owner+"$InteractionType","HEAL_SELF",type));guard.instructions.add(new JumpInsnNode(IF_ACMPNE,done));
  guard.instructions.add(new MethodInsnNode(INVOKESTATIC,owner,"resetInteractionPromptState","()V",false));
  guard.instructions.add(done);guard.instructions.add(new FrameNode(F_SAME,0,null,0,null));guard.instructions.add(new InsnNode(RETURN));guard.maxStack=2;guard.maxLocals=0;
  Set<String> getters=Set.of("hasInteractionPrompt","getInteractionPromptTitle","getInteractionPromptDetail","getInteractionPromptProgressText","getInteractionHoldProgress","getInteractionHoldSeconds","getInteractionHoldDurationSeconds","isHealingInteractionPrompt","isRescueInteractionPrompt","isSelfDefibInteractionPrompt","isExecutionInteractionPrompt");
  int count=0;
  for(MethodNode m:n.methods){
   if(getters.contains(m.name)){m.instructions.insert(new MethodInsnNode(INVOKESTATIC,owner,helper,"()V",false));count++;}
   if(m.name.equals("clearPendingHealingSelection")&&m.desc.equals("()V"))for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==RETURN)m.instructions.insertBefore(i,new MethodInsnNode(INVOKESTATIC,owner,helper,"()V",false));
  }
  if(count!=11)throw new IllegalArgumentException("Unexpected HUD API: "+count);
  n.methods.add(guard);ClassWriter out=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(out);return out.toByteArray();
 }
 public static void main(String[] a)throws Exception{
  try(ZipFile z=new ZipFile(a[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(a[1])))){
   var entries=z.entries();while(entries.hasMoreElements()){
    ZipEntry e=entries.nextElement();if(e.isDirectory())continue;byte[] data=z.getInputStream(e).readAllBytes();
    if(e.getName().equals("ichttt/mods/firstaid/client/ClientEventHandler.class"))data=fix(data);
    if(e.getName().equals("META-INF/neoforge.mods.toml"))data=new String(data,java.nio.charset.StandardCharsets.UTF_8).replace("zomboid-v3.4-cloth-hordes","zomboid-v3.4.1-hud-fix").getBytes(java.nio.charset.StandardCharsets.UTF_8);
    out.putNextEntry(new ZipEntry(e.getName()));out.write(data);out.closeEntry();
   }
  }
 }
}
