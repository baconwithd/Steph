import java.net.*;import java.nio.file.*;import java.lang.reflect.*;
public class NullSelectionTest {
 static int checks;static void check(boolean b,String text){checks++;if(!b)throw new AssertionError(text);}
 static String name="ichttt.mods.firstaid.client.ClientEventHandler";
 static Class<?> load(boolean fixed)throws Exception{
  byte[] original=Files.readAllBytes(Path.of("work/firstaidfix/fixture/"+name.replace('.','/')+".class"));byte[] bytes=fixed?FixFirstAid.fix(original):original;
  URLClassLoader loader=new URLClassLoader(new URL[]{Path.of("work/firstaidfix/fixture").toUri().toURL()},null){@Override protected Class<?> findClass(String n)throws ClassNotFoundException{if(n.equals(name))return defineClass(n,bytes,0,bytes.length);return super.findClass(n);}};return loader.loadClass(name);
 }
 static void state(Class<?> c,String type,boolean selected)throws Exception{c.getMethod("setState",String.class,boolean.class).invoke(null,type,selected);}
 static Object call(Class<?> c,String method)throws Exception{return c.getMethod(method).invoke(null);}
 public static void main(String[] args)throws Exception{
  Class<?> before=load(false);state(before,"HEAL_SELF",false);boolean reproduced=false;try{call(before,"getInteractionPromptDetail");}catch(InvocationTargetException e){reproduced=e.getCause() instanceof NullPointerException;}check(reproduced,"Original cancellation state reproduces reported NPE");
  Class<?> after=load(true);state(after,"HEAL_SELF",false);check(call(after,"getInteractionPromptDetail").equals(""),"Stale healing prompt cleared instead of dereferencing null");check(after.getField("resets").getInt(null)==1,"Hold/sound reset happens once");check(!(Boolean)call(after,"hasInteractionPrompt"),"Invalid prompt cannot render again");check((Float)call(after,"getInteractionHoldDurationSeconds")==0,"Invalid duration is zero");
  state(after,"HEAL_SELF",true);check(call(after,"getInteractionPromptDetail").equals("LEFT_ARM"),"Valid healing selected part retained");check(after.getField("resets").getInt(null)==0,"Valid treatment not canceled");call(after,"clearPendingHealingSelection");check(!(Boolean)call(after,"hasInteractionPrompt"),"Canceling treatment clears prompt immediately");
  for(String type:new String[]{"USE_MEDICINE_SELF","SELF_DEFIB","RESCUE","EXECUTE","INVALID_ITEM"}){state(after,type,false);check(call(after,"getInteractionPromptDetail").equals(type),"Unrelated action kept: "+type);call(after,"clearPendingHealingSelection");check((Boolean)call(after,"hasInteractionPrompt"),"Clearing pending heal keeps "+type);check(after.getField("resets").getInt(null)==0,"No unrelated hold reset: "+type);}
  state(after,null,false);check(call(after,"getInteractionPromptDetail").equals(""),"Absent prompt remains safe");
  System.out.println(checks+" cancellation/HUD regressions passed (original NPE reproduced)");
 }
}
