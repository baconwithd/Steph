package ichttt.mods.firstaid.client;
public class ClientEventHandler {
 private static InteractionPrompt interactionPrompt;private static PendingHealingSelection pendingHealingSelection;public static int resets;
 public enum InteractionType {HEAL_SELF,USE_MEDICINE_SELF,SELF_DEFIB,RESCUE,EXECUTE,INVALID_ITEM}
 private record InteractionPrompt(InteractionType type){}
 private record PendingHealingSelection(String part){}
 public static void setState(String type,boolean selected){interactionPrompt=type==null?null:new InteractionPrompt(InteractionType.valueOf(type));pendingHealingSelection=selected?new PendingHealingSelection("LEFT_ARM"):null;resets=0;}
 private static void resetInteractionPromptState(){resets++;interactionPrompt=null;}
 public static void clearPendingHealingSelection(){pendingHealingSelection=null;}
 public static boolean hasInteractionPrompt(){return interactionPrompt!=null;}
 public static String getInteractionPromptDetail(){if(interactionPrompt==null)return "";return interactionPrompt.type()==InteractionType.HEAL_SELF?pendingHealingSelection.part():interactionPrompt.type().name();}
 public static String getInteractionPromptTitle(){return getInteractionPromptDetail();}
 public static String getInteractionPromptProgressText(float tick){return getInteractionPromptDetail();}
 public static float getInteractionHoldProgress(float tick){return interactionPrompt==null?0:1;}
 public static float getInteractionHoldSeconds(float tick){return interactionPrompt==null?0:1;}
 public static float getInteractionHoldDurationSeconds(){return interactionPrompt==null?0:1;}
 public static boolean isHealingInteractionPrompt(){return interactionPrompt!=null&&interactionPrompt.type()==InteractionType.HEAL_SELF;}
 public static boolean isRescueInteractionPrompt(){return interactionPrompt!=null&&interactionPrompt.type()==InteractionType.RESCUE;}
 public static boolean isSelfDefibInteractionPrompt(){return interactionPrompt!=null&&interactionPrompt.type()==InteractionType.SELF_DEFIB;}
 public static boolean isExecutionInteractionPrompt(){return interactionPrompt!=null&&interactionPrompt.type()==InteractionType.EXECUTE;}
}
