import java.nio.file.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public final class FixCriticalCare implements Opcodes {
 static final String HELPER="ichttt/mods/firstaid/survival/CriticalCare";
 static byte[] patch(byte[] b,boolean part){ClassNode n=new ClassNode();new ClassReader(b).accept(n,0);int changes=0;
 for(MethodNode m:n.methods){
  if(part&&m.name.equals("damage")&&m.desc.equals("(FLnet/minecraft/world/entity/player/Player;ZF)F")){
   InsnList pre=new InsnList();pre.add(new VarInsnNode(ALOAD,0));pre.add(new VarInsnNode(FLOAD,1));pre.add(new MethodInsnNode(INVOKESTATIC,HELPER,"damage","(Lichttt/mods/firstaid/api/damagesystem/AbstractDamageablePart;F)F",false));pre.add(new VarInsnNode(FSTORE,1));m.instructions.insert(pre);changes++;}
  if(!part&&m.name.equals("v34NativeRecord"))for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode call){
   if(call.owner.equals("ichttt/mods/firstaid/compat/lrtactical/TreatmentV33")&&call.name.equals("recordBite")){call.owner=HELPER;call.name="bite";changes++;}
   if(call.owner.equals("ichttt/mods/firstaid/survival/ClinicalState$Wound")&&call.name.equals("cut")){
    AbstractInsnNode prev=i.getPrevious();while(prev!=null&&!(prev instanceof MethodInsnNode c&&c.name.equals("ordinal")&&c.owner.endsWith("EnumPlayerPart")))prev=prev.getPrevious();
    if(prev==null||!(prev.getPrevious() instanceof VarInsnNode load)||load.getOpcode()!=ALOAD)throw new IllegalStateException("Missing cut part local");
    InsnList args=new InsnList();args.add(new VarInsnNode(ALOAD,load.var));args.add(new VarInsnNode(ALOAD,1));m.instructions.insertBefore(i,args);
    call.setOpcode(INVOKESTATIC);call.owner=HELPER;call.name="cut";call.desc="(Lichttt/mods/firstaid/survival/ClinicalState$Wound;Lichttt/mods/firstaid/api/enums/EnumPlayerPart;Lnet/minecraft/world/entity/player/Player;)V";changes++;
   }
  }
 }
 if(changes!=(part?1:2))throw new IllegalStateException("Unexpected patch sites: "+n.name+" "+changes);
 ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);return w.toByteArray();}
 static byte[] bleeding(byte[] b){ClassNode n=new ClassNode();new ClassReader(b).accept(n,0);int changes=0;
  for(MethodNode m:n.methods)if(m.name.equals("onDamage"))for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.owner.equals("ichttt/mods/firstaid/fracture/Bleeding")&&call.name.equals("start")){call.owner=HELPER;call.name="bleed";changes++;}
  if(changes!=1)throw new IllegalStateException("Unexpected bleed sites "+changes);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);return w.toByteArray();
 }
 public static void main(String[] a)throws Exception{try(ZipFile z=new ZipFile(a[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(a[1])))){
  var it=z.entries();while(it.hasMoreElements()){var e=it.nextElement();if(e.isDirectory())continue;String name=e.getName();byte[] b=z.getInputStream(e).readAllBytes();
   if(name.equals("ichttt/mods/firstaid/common/damagesystem/DamageablePart.class"))b=patch(b,true);
   if(name.equals("ichttt/mods/firstaid/survival/ClinicalHooks.class"))b=patch(b,false);
   if(name.equals("ichttt/mods/firstaid/fracture/Bleeding.class"))b=bleeding(b);
   if(name.equals("META-INF/neoforge.mods.toml"))b=new String(b,java.nio.charset.StandardCharsets.UTF_8).replace("zomboid-v3.4.2-sound-cloth","zomboid-v3.4.3-critical-care").getBytes(java.nio.charset.StandardCharsets.UTF_8);
   out.putNextEntry(new ZipEntry(name));out.write(b);out.closeEntry();
  }
  out.putNextEntry(new ZipEntry(HELPER+".class"));out.write(Files.readAllBytes(Path.of(a[2])));out.closeEntry();
 }System.out.println("Patched critical damage, cut and bite recording; preserved remaining jar.");}
}
