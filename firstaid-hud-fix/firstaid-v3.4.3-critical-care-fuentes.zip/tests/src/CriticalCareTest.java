import ichttt.mods.firstaid.survival.*;import ichttt.mods.firstaid.api.enums.*;import ichttt.mods.firstaid.api.damagesystem.*;import ichttt.mods.firstaid.compat.lrtactical.*;import net.minecraft.world.entity.player.Player;
public class CriticalCareTest{static int checks;static void ok(boolean b){checks++;if(!b)throw new AssertionError("check "+checks);}public static void main(String[] args){
 Player player=new Player();
 for(var p:EnumPlayerPart.values()){var part=new AbstractDamageablePart(p,10);ok(CriticalCare.damage(part,6)==(CriticalCare.critical(p)?3:6));}
 player.roll=.2f;var w=new ClinicalState.Wound();w.treatments=3;CriticalCare.cut(w,EnumPlayerPart.HEAD,player);ok(!w.cut&&w.treatments==3);
 player.roll=.1999f;CriticalCare.cut(w,EnumPlayerPart.HEAD,player);ok(w.cut);player.roll=.9f;CriticalCare.cut(w,EnumPlayerPart.HEAD,player);ok(w.cut&&w.treatments==3);
 w=new ClinicalState.Wound();CriticalCare.cut(w,EnumPlayerPart.LEFT_ARM,player);ok(w.cut);
 var before=new AbstractPlayerDamageModel();var current=new AbstractPlayerDamageModel();current.getFromEnum(EnumPlayerPart.HEAD).currentHealth=5;
 CriticalCare.bite(current,player,new Object(),before);ok(TreatmentV33.calls==0);
 player.roll=.1f;CriticalCare.bite(current,player,new Object(),before);ok(TreatmentV33.calls==1);
 player.roll=.9f;current.getFromEnum(EnumPlayerPart.LEFT_LEG).currentHealth=1;CriticalCare.bite(current,player,new Object(),before);ok(TreatmentV33.calls==2);
 current=new AbstractPlayerDamageModel();current.getFromEnum(EnumPlayerPart.BODY).currentHealth=5;CriticalCare.bite(current,player,new Object(),before);ok(TreatmentV33.calls==2);
 var server=new net.minecraft.server.level.ServerPlayer();server.roll=.9f;CriticalCare.bleed(server,EnumPlayerPart.HEAD);ok(ichttt.mods.firstaid.fracture.Bleeding.calls==0);CriticalCare.bleed(server,EnumPlayerPart.LEFT_ARM);ok(ichttt.mods.firstaid.fracture.Bleeding.calls==1);server.roll=.1f;CriticalCare.bleed(server,EnumPlayerPart.BODY);ok(ichttt.mods.firstaid.fracture.Bleeding.calls==2);
 System.out.println("PASS: "+checks+" critical damage/wound thresholds, existing treatments and limb injury checks");}}
