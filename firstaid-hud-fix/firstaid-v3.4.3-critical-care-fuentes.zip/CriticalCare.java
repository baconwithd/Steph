package ichttt.mods.firstaid.survival;
import ichttt.mods.firstaid.api.damagesystem.*;
import ichttt.mods.firstaid.api.enums.EnumPlayerPart;
import ichttt.mods.firstaid.compat.lrtactical.TreatmentV33;
import net.minecraft.world.entity.player.Player;
/** Keeps existing treatments/injuries; gates only newly recorded critical wounds. */
public final class CriticalCare {
 public static boolean critical(EnumPlayerPart p){return p==EnumPlayerPart.HEAD||p==EnumPlayerPart.BODY;}
 public static float damage(AbstractDamageablePart p,float amount){return critical(p.part)?amount*0.5f:amount;}
 public static void cut(ClinicalState.Wound w,EnumPlayerPart p,Player player){if(!critical(p)||player.getRandom().nextFloat()<0.2f)w.cut();}
 public static void bleed(net.minecraft.server.level.ServerPlayer player,EnumPlayerPart p){if(!critical(p)||player.getRandom().nextFloat()<0.2f)ichttt.mods.firstaid.fracture.Bleeding.start(player,p);}
 public static void bite(Object current,Object player,Object source,Object before){
  AbstractPlayerDamageModel now=(AbstractPlayerDamageModel)current,old=(AbstractPlayerDamageModel)before;
  EnumPlayerPart chosen=null;float most=0.0001f;
  for(EnumPlayerPart p:EnumPlayerPart.values()){float lost=old.getFromEnum(p).currentHealth-now.getFromEnum(p).currentHealth;if(lost>most){most=lost;chosen=p;}}
  if(chosen!=null&&critical(chosen)&&((Player)player).getRandom().nextFloat()>=0.2f)return;
  TreatmentV33.recordBite(current,player,source,before);
 }
}
