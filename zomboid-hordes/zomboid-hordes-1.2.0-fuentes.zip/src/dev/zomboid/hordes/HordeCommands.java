package dev.zomboid.hordes;
import com.mojang.brigadier.context.CommandContext;import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.*;import net.minecraft.server.level.ServerPlayer;import net.minecraft.network.chat.Component;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.neoforge.event.RegisterCommandsEvent;
@EventBusSubscriber(modid=ZomboidHordes.ID)
public final class HordeCommands {
 @SubscribeEvent public static void register(RegisterCommandsEvent e){e.getDispatcher().register(Commands.literal("zhorda").requires(s->s.hasPermission(2))
  .then(Commands.literal("noche").executes(c->test(c,1)))
  .then(Commands.literal("ruido").executes(c->test(c,0)))
  .then(Commands.literal("helicoptero").executes(c->test(c,2)))
  .then(Commands.literal("dia").executes(c->test(c,3)))
  .then(Commands.literal("parar").executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();int n=HordeEvents.stopHordes(p);c.getSource().sendSuccess(()->Component.literal("Se cancelaron "+n+" oleadas pendientes cercanas. Los zombis existentes siguen ahí."),false);return n;}))
  .then(Commands.literal("estado").executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();HordeData d=HordeData.get(p.serverLevel());int remaining=d.tickets.stream().mapToInt(t->t.remaining).sum();c.getSource().sendSuccess(()->Component.literal("Oleadas pendientes: "+d.tickets.size()+"; zombis pendientes: "+remaining+". Helicóptero programado: "+(d.helicopterAt>=0?"sí":"no")),false);return d.tickets.size();}))
  .executes(c->{c.getSource().sendSuccess(()->Component.literal("Pruebas: /zhorda noche | ruido | helicoptero | dia. Control: /zhorda estado | parar. Usa supervivencia en el Overworld."),false);return 1;}));}
 private static int test(CommandContext<CommandSourceStack> c,int kind)throws CommandSyntaxException{ServerPlayer p=c.getSource().getPlayerOrException();if(!HordeEvents.testHorde(p,kind)){c.getSource().sendFailure(Component.literal("No se pudo iniciar: necesitas supervivencia, Overworld, dificultad distinta de Pacífico y doMobSpawning=true."));return 0;}c.getSource().sendSuccess(()->Component.literal("Prueba iniciada. Usa /zhorda estado para ver las oleadas. No se cambia la hora del mundo."),false);return 1;}
}
