package dev.zomboid.remains;
public final class WeaponRarityRules {
 public static int tier(double damage,double pistol){if(!Double.isFinite(damage)||damage<=0)return 4;double ratio=damage/Math.max(.1,pistol);return ratio<=1.01?0:ratio<=1.5?1:ratio<=2.2?2:ratio<=3.5?3:4;}
 public static double weight(int quality,int tier,double damage,double pistol){double[][] chance={{85,12,2.5,.45,.05},{55,30,12,2.5,.5},{25,35,28,10,2},{10,20,35,28,7},{5,10,20,35,30}};return chance[QualityRules.clamp(quality)][QualityRules.clamp(tier)]/Math.max(1,Math.pow(damage/Math.max(.1,pistol),1.25));}
 public static double worldChance(int tier){return new double[]{1,.75,.45,.20,.08}[QualityRules.clamp(tier)];}
}
