package dev.zomboid.remains;
import java.util.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
public final class WeaponLoot {
 public static double damage(GunAccess.Profile p){try{Object bullet=p.data().getClass().getMethod("getBulletData").invoke(p.data());return Math.max(.1,((Number)bullet.getClass().getMethod("getDamageAmount").invoke(bullet)).doubleValue());}catch(ReflectiveOperationException|RuntimeException e){return Double.NaN;}}
 public static double baseline()throws ReflectiveOperationException{double pistol=Double.POSITIVE_INFINITY,any=pistol;for(var p:GunAccess.profiles()){double d=damage(p);if(!Double.isFinite(d))continue;any=Math.min(any,d);if(p.tier()==0)pistol=Math.min(pistol,d);}return Double.isFinite(pistol)?pistol:Double.isFinite(any)?any:5;}
 public static GunAccess.Profile choose(int q,RandomSource random)throws ReflectiveOperationException{var all=GunAccess.profiles();double pistol=baseline();List<GunAccess.Profile> valid=new ArrayList<>();List<Double> weights=new ArrayList<>();double total=0;for(var p:all){double damage=damage(p);if(!Double.isFinite(damage))continue;int tier=WeaponRarityRules.tier(damage,pistol);double w=WeaponRarityRules.weight(q,tier,damage,pistol);if(tier==0&&p.tier()==0)w*=3;valid.add(p);weights.add(w);total+=w;}if(valid.isEmpty())return GunAccess.choose(QualityRules.gunTier(q),random);double roll=random.nextDouble()*total;for(int i=0;i<valid.size();i++){roll-=weights.get(i);if(roll<=0)return valid.get(i);}return valid.getLast();}
 public static void decorate(ItemStack gun){var profile=GunAccess.describe(gun);if(profile==null)return;try{int tier=WeaponRarityRules.tier(damage(profile),baseline());String label="Arma "+QualityRules.name(tier)+" · Daño base por disparo: "+String.format(Locale.ROOT,"%.1f",damage(profile));List<Component> lore=new ArrayList<>();var old=gun.get(DataComponents.LORE);if(old!=null)for(Component line:old.lines())if(!line.getString().startsWith("Arma "))lore.add(line);lore.add(Component.literal(label).withStyle(new ChatFormatting[]{ChatFormatting.GRAY,ChatFormatting.GREEN,ChatFormatting.AQUA,ChatFormatting.LIGHT_PURPLE,ChatFormatting.GOLD}[tier]));gun.set(DataComponents.LORE,new ItemLore(lore));}catch(ReflectiveOperationException ignored){}}
 public static ItemStack ammo(ResourceLocation id,int count)throws ReflectiveOperationException{ItemStack s=ZombieRemainsLoot.stack("tacz:ammo",count);if(s.isEmpty())return s;Class<?> api=Class.forName("com.tacz.guns.api.item.IAmmo");Object item=api.getMethod("getIAmmoOrNull",ItemStack.class).invoke(null,s);if(item==null)return ItemStack.EMPTY;api.getMethod("setAmmoId",ItemStack.class,ResourceLocation.class).invoke(item,s,id);return s;}
 public static ResourceLocation ammoId(ItemStack s){try{Class<?> api=Class.forName("com.tacz.guns.api.item.IAmmo");Object item=api.getMethod("getIAmmoOrNull",ItemStack.class).invoke(null,s);return item==null?null:(ResourceLocation)api.getMethod("getAmmoId",ItemStack.class).invoke(item,s);}catch(ReflectiveOperationException ignored){return null;}}
 private static boolean checked(ItemStack s){var data=s.get(DataComponents.CUSTOM_DATA);return data!=null&&data.copyTag().getBoolean("zr_weapon_loot_checked");}
 private static void mark(ItemStack s){var data=s.get(DataComponents.CUSTOM_DATA);var tag=data==null?new net.minecraft.nbt.CompoundTag():data.copyTag();tag.putBoolean("zr_weapon_loot_checked",true);s.set(DataComponents.CUSTOM_DATA,net.minecraft.world.item.component.CustomData.of(tag));}
 public static void audit(net.minecraft.world.Container inventory,int q,RandomSource random){
  List<ItemStack> items=new ArrayList<>();for(int i=0;i<inventory.getContainerSize();i++)if(!inventory.getItem(i).isEmpty())items.add(inventory.getItem(i));
  if(items.stream().noneMatch(s->GunAccess.describe(s)!=null))return;
  int size=items.size();supply(items,q,random,false);
  for(int n=size;n<items.size();n++){ItemStack ammo=items.get(n);if(ammoId(ammo)==null)continue;int slot=-1;
   for(int i=0;i<inventory.getContainerSize();i++)if(inventory.getItem(i).isEmpty()){slot=i;break;}
   if(slot<0)for(int i=0;i<inventory.getContainerSize();i++){ItemStack old=inventory.getItem(i);if(GunAccess.describe(old)==null&&ammoId(old)==null){slot=i;break;}}
   if(slot>=0)inventory.setItem(slot,ammo);
   else{for(int i=0;i<inventory.getContainerSize();i++){var gun=GunAccess.describe(inventory.getItem(i));if(gun!=null&&gun.ammo().equals(ammoId(ammo))){inventory.setItem(i,ammo);break;}}}
  }
  for(int i=0;i<inventory.getContainerSize();i++){ItemStack item=inventory.getItem(i);var gun=GunAccess.describe(item);if(gun==null)continue;boolean found=false;for(int j=0;j<inventory.getContainerSize();j++)if(gun.ammo().equals(ammoId(inventory.getItem(j)))&&inventory.getItem(j).getCount()>0){found=true;break;}if(!found)inventory.setItem(i,ItemStack.EMPTY);}
  inventory.setChanged();
 }
 public static void supply(List<ItemStack> items,int q,RandomSource random,boolean world){if(items.stream().noneMatch(s->GunAccess.describe(s)!=null))return;try{
  double baseline=baseline();Map<ResourceLocation,Integer> need=new LinkedHashMap<>();
  for(var it=items.iterator();it.hasNext();){ItemStack s=it.next();var p=GunAccess.describe(s);if(p==null)continue;int tier=WeaponRarityRules.tier(damage(p),baseline);if(world&&!checked(s)&&random.nextDouble()>WeaponRarityRules.worldChance(tier)/Math.max(1,Math.pow(damage(p)/baseline,.35))){it.remove();continue;}decorate(s);mark(s);need.merge(p.ammo(),1,Integer::sum);}
  for(var entry:need.entrySet()){int min=ExtraLootRules.ammoMin(q),max=ExtraLootRules.ammoMax(q);int target=Math.max(15*entry.getValue(),min+random.nextInt(max-min+1));int have=0;for(var s:items)if(entry.getKey().equals(ammoId(s)))have+=s.getCount();int remaining=Math.max(0,target-have);while(remaining>0){int amount=Math.min(64,remaining);ItemStack stack=ammo(entry.getKey(),amount);if(stack.isEmpty())break;items.add(stack);remaining-=amount;}}
 }catch(ReflectiveOperationException|RuntimeException e){org.slf4j.LoggerFactory.getLogger("ZombieRemainsLoot").warn("Unable to pair generated gun with ammo",e);}}
}
