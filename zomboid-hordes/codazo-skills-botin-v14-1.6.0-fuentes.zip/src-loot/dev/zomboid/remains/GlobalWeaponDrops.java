package dev.zomboid.remains;
import java.util.*;import net.minecraft.world.item.ItemStack;import net.minecraft.world.entity.item.ItemEntity;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
@EventBusSubscriber(modid="zombie_remains_loot")
public final class GlobalWeaponDrops {
 @SubscribeEvent(priority=net.neoforged.bus.api.EventPriority.LOWEST) public static void drops(LivingDropsEvent e){if(e.getEntity().level().isClientSide()||e.getEntity() instanceof net.minecraft.world.entity.player.Player||e.getDrops().isEmpty())return;List<ItemStack> items=new ArrayList<>();for(var drop:e.getDrops())items.add(drop.getItem());WeaponLoot.supply(items,0,e.getEntity().getRandom(),true);e.getDrops().clear();for(var item:items)e.getDrops().add(new ItemEntity(e.getEntity().level(),e.getEntity().getX(),e.getEntity().getY(),e.getEntity().getZ(),item));}
 @SubscribeEvent public static void reload(net.neoforged.neoforge.event.OnDatapackSyncEvent e){GunAccess.clearCache();}
}
