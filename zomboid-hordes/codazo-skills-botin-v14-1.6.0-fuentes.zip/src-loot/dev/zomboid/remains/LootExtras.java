package dev.zomboid.remains;
import java.util.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.*;
public final class LootExtras {
 static void priority(ZombieRemainsLoot.Corpse c,ItemStack item){
  if(item.isEmpty())return;
  for(int i=0;i<c.inventory.getContainerSize();i++)if(c.inventory.getItem(i).isEmpty()){ZombieRemainsLoot.add(c,item);return;}
  // Full high-quality inventories reserve room by replacing a low-value utility item.
  for(int i=0;i<c.inventory.getContainerSize();i++){ItemStack old=c.inventory.getItem(i);String path=BuiltInRegistries.ITEM.getKey(old.getItem()).getPath();
   if(!(old.getItem() instanceof ArmorItem)&&!(old.getItem() instanceof TieredItem)&&!path.contains("backpack")&&!path.equals("ammo")&&GunAccess.describe(old)==null){c.inventory.setItem(i,item);return;}
  }
 }
 static void populate(ZombieRemainsLoot.Corpse c,ServerLevel level,boolean bandit,boolean mutant,Mob mob){
  int q=QualityRules.clamp(c.quality);
  for(int i=0;i<c.inventory.getContainerSize();i++){var id=BuiltInRegistries.ITEM.getKey(c.inventory.getItem(i).getItem());if(id.getNamespace().equals("tacz")&&id.getPath().equals("ammo"))c.inventory.setItem(i,ItemStack.EMPTY);}
  if(level.random.nextDouble()<ExtraLootRules.backpackChance(q,bandit,mutant)){ItemStack bag=ZombieRemainsLoot.stack(ExtraLootRules.backpack(q),1);if(bag.isEmpty())bag=ZombieRemainsLoot.stack("sophisticatedbackpacks:backpack",1);priority(c,bag);}
  if(level.random.nextDouble()<ExtraLootRules.militaryChance(q,bandit,mutant)){
   List<ItemStack> armor=new ArrayList<>();for(Item item:BuiltInRegistries.ITEM){var id=BuiltInRegistries.ITEM.getKey(item);if(id.getNamespace().equals("fracturepoint")&&item instanceof ArmorItem)armor.add(new ItemStack(item));}
   if(!armor.isEmpty()){ItemStack gear=armor.get(level.random.nextInt(armor.size()));if(gear.isDamageableItem())gear.setDamageValue((int)(gear.getMaxDamage()*(q>=3?.05:.25+level.random.nextDouble()*.35)));priority(c,gear);}
  }
  // Supply every caliber after all weapon rolls, including actual bandit/mutant equipment.
  List<ItemStack> bundle=new ArrayList<>();for(int i=0;i<c.inventory.getContainerSize();i++)if(!c.inventory.getItem(i).isEmpty())bundle.add(c.inventory.getItem(i));
  boolean hasGun=bundle.stream().anyMatch(s->GunAccess.describe(s)!=null);
  if(hasGun){WeaponLoot.supply(bundle,q,level.random,false);for(ItemStack s:bundle)if(WeaponLoot.ammoId(s)!=null)priority(c,s);}
  else try{var p=WeaponLoot.choose(q,level.random);if(p!=null)ZombieRemainsLoot.addAmmo(c,p.ammo(),ExtraLootRules.ammoMin(q)+level.random.nextInt(ExtraLootRules.ammoMax(q)-ExtraLootRules.ammoMin(q)+1));}catch(ReflectiveOperationException ignored){}
  WeaponLoot.audit(c.inventory,q,level.random);
 }
}
