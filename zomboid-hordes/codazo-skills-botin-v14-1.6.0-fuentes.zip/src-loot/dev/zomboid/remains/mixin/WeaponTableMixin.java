package dev.zomboid.remains.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
import net.minecraft.world.level.storage.loot.*;
@Mixin(LootTable.class)
public abstract class WeaponTableMixin {
 @Inject(method="getRandomItems(Lnet/minecraft/world/level/storage/loot/LootContext;)Lit/unimi/dsi/fastutil/objects/ObjectArrayList;",at=@At("RETURN"))
 private void loot$ammo(LootContext context,CallbackInfoReturnable<java.util.List<net.minecraft.world.item.ItemStack>> cir){dev.zomboid.remains.WeaponLoot.supply(cir.getReturnValue(),0,context.getRandom(),true);}
 @Inject(method="fill",at=@At("RETURN"))
 private void loot$check(net.minecraft.world.Container inventory,LootParams params,long seed,CallbackInfo ci){dev.zomboid.remains.WeaponLoot.audit(inventory,0,params.getLevel().random);}
}
