import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public final class Bindings23Test {
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Binding "+n);}
 static ClassNode cls(ZipFile z,String name)throws Exception{ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name)).readAllBytes()).accept(c,0);return c;}
 static MethodNode m(ClassNode c,String name){return c.methods.stream().filter(x->x.name.equals(name)).findFirst().orElseThrow();}
 static boolean call(MethodNode m,String name){for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals(name))return true;return false;}
 public static void main(String[] a)throws Exception{try(var skill=new ZipFile(a[0]);var loot=new ZipFile(a[1]);var melee=new ZipFile(a[2]);var mc=new ZipFile(a[3]);var lr=new ZipFile(a[4])){
  var registry=cls(skill,"dev/survivorcreator/skills/Skills.class");ok(call(m(registry,"<clinit>"),"prune"));ok(call(m(registry,"grant"),"enqueueRange"));ok(call(m(registry,"addXp"),"scale"));
  var active=m(cls(skill,"dev/survivorcreator/skills/ActiveSkills.class"),"<clinit>");java.util.Set<String> ids=new java.util.HashSet<>();for(var i:active.instructions.toArray())if(i instanceof LdcInsnNode x&&x.cst instanceof String s)ids.add(s);ok(ids.size()==18);for(String s:new String[]{"aiming","reloading","axe","long_blade","short_blade","long_blunt","short_blunt","spear","maintenance"})ok(ids.contains(s));
  var durability=cls(mc,"net/minecraft/world/item/ItemStack.class");ok(durability.methods.stream().anyMatch(x->x.name.equals("hurtAndBreak")&&x.desc.equals("(ILnet/minecraft/server/level/ServerLevel;Lnet/minecraft/server/level/ServerPlayer;Ljava/util/function/Consumer;)V")));
  var table=cls(mc,"net/minecraft/world/level/storage/loot/LootTable.class");ok(table.methods.stream().anyMatch(x->x.name.equals("getRandomItems")&&x.desc.equals("(Lnet/minecraft/world/level/storage/loot/LootContext;)Lit/unimi/dsi/fastutil/objects/ObjectArrayList;")));ok(m(table,"fill").desc.equals("(Lnet/minecraft/world/Container;Lnet/minecraft/world/level/storage/loot/LootParams;J)V"));
  var mixin=cls(loot,"dev/zomboid/remains/mixin/WeaponTableMixin.class");ok(call(m(mixin,"loot$ammo"),"supply"));ok(call(m(mixin,"loot$check"),"audit"));
  ok(call(m(cls(loot,"dev/zomboid/remains/QualityLoot.class"),"populate"),"choose"));ok(call(m(cls(loot,"dev/zomboid/remains/LootExtras.class"),"populate"),"audit"));
  var shove=m(cls(melee,"dev/zomboidmelee/combat/ShoveCombat.class"),"push");ok(call(shove,"hurt"));boolean two=false,marked=false;for(var i:shove.instructions.toArray()){if(i instanceof InsnNode x&&x.getOpcode()==Opcodes.FCONST_2)two=true;if(i instanceof LdcInsnNode x&&"zpush_active".equals(x.cst))marked=true;}ok(two&&marked);ok(call(shove,"remove"));
  var hand=m(cls(melee,"dev/zomboidmelee/mixin/VanillaPushPoseMixin.class"),"zpush$stock");ok(call(hand,"renderProxy")&&call(hand,"cancel"));ok(!call(hand,"pose"));
  ok(call(m(cls(melee,"dev/zomboidmelee/client/NativeBatRenderer.class"),"getTextureLocation"),"texture"));
  var renderer=cls(lr,"me/xjqsh/lrtactical/client/renderer/item/MeleeItemRenderer.class");ok(renderer.methods.stream().anyMatch(x->x.name.equals("initContext")&&x.desc.equals("(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/player/Player;F)Lme/xjqsh/lrtactical/api/animation/MeleeAnimationStateContext;")));
  String skillsConfig=new String(skill.getInputStream(skill.getEntry("survivorcreator-combat14.mixins.json")).readAllBytes());ok(skillsConfig.contains("MaintenanceSkillMixin")&&skillsConfig.contains("ReloadSkillMixin")&&skillsConfig.contains("CombatSkillsPanelMixin"));
 }System.out.println("PASS: "+n+" active skill registration/queued XP, exact MC/LR targets, loot/ammo auditing, fixed shove damage and proxy rendering/texture bindings");}
}
