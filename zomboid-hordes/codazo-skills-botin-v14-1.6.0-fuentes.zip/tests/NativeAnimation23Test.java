import com.tacz.guns.api.TimelessAPI;import dev.zomboidmelee.combat.NativeStockAnimation;
public final class NativeAnimation23Test {
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Native/proxy "+n);}
 public static void main(String[] args){
  ok(NativeStockAnimation.play(null));ok("bayonet_stock".equals(TimelessAPI.machine.trigger));ok(!NativeStockAnimation.usesProxy());
  ok(NativeStockAnimation.play(null));ok(TimelessAPI.machine.controller.registered==1);
  TimelessAPI.gun=false;TimelessAPI.machine=new TimelessAPI.Machine();ok(NativeStockAnimation.play(null));ok(!NativeStockAnimation.usesProxy());ok(TimelessAPI.machine.controller.runs==1);
  net.neoforged.neoforge.client.extensions.common.IClientItemExtensions.Flag.proxy=true;TimelessAPI.machine=new TimelessAPI.Machine();TimelessAPI.machine.context=null;
  ok(NativeStockAnimation.play(null));ok(NativeStockAnimation.usesProxy());ok(TimelessAPI.machine.initialized==1&&TimelessAPI.machine.updates==1);ok(dev.zomboidmelee.client.NativeBatRenderer.contexts==1);ok(TimelessAPI.machine.controller.runs==1);ok("melee_stock".equals(TimelessAPI.machine.controller.name));
  ok(NativeStockAnimation.renderProxy(null,null,null,null,null,0,0));ok(dev.zomboidmelee.client.NativeBatRenderer.renders==1);
  ok(NativeStockAnimation.play(null));ok(TimelessAPI.machine.initialized==1&&TimelessAPI.machine.controller.registered==1&&TimelessAPI.machine.controller.runs==2);
  System.out.println("PASS: "+n+" mocked native gun/known melee, unknown-item/bare-hand proxy initialization and render checks");
 }
}
