package net.minecraft.util;public interface RandomSource {double nextDouble();int nextInt(int bound);}
