package net.minecraft.world.item.component;public record ItemLore(java.util.List<net.minecraft.network.chat.Component> lines) {}
