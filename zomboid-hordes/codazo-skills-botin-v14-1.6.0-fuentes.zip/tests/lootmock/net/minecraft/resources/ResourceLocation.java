package net.minecraft.resources;public record ResourceLocation(String value) {public String toString(){return value;}}
