package net.minecraft;public enum ChatFormatting {GRAY,GREEN,AQUA,LIGHT_PURPLE,GOLD}
