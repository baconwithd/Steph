package dev.zomboid.remains;
import net.minecraft.resources.ResourceLocation;import net.minecraft.world.item.ItemStack;
public class GunAccess {
 public record Profile(ResourceLocation id,ResourceLocation ammo,int capacity,int tier,Object data){}
 public record Bullet(double amount){public double getDamageAmount(){return amount;}}
 public record Data(Bullet bullet){public Bullet getBulletData(){return bullet;}}
 public static final java.util.List<Profile> ALL=new java.util.ArrayList<>();
 public static java.util.List<Profile> profiles(){return ALL;}
 public static Profile describe(ItemStack item){return item.profile;}
 public static Profile choose(int tier,net.minecraft.util.RandomSource random){return ALL.getFirst();}
}
