import java.util.*;import dev.zomboid.remains.*;import net.minecraft.world.item.ItemStack;import net.minecraft.resources.ResourceLocation;
public class Ammo23Test {
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Ammo/rarity "+n);}
 static class R implements net.minecraft.util.RandomSource{Random r=new Random(1);public double nextDouble(){return r.nextDouble();}public int nextInt(int b){return r.nextInt(b);}}
 static class Box implements net.minecraft.world.Container{ItemStack[] stacks;Box(ItemStack...s){stacks=s;}public int getContainerSize(){return stacks.length;}public ItemStack getItem(int i){return stacks[i];}public void setItem(int i,ItemStack s){stacks[i]=s;}public void setChanged(){}}
 static ItemStack gun(GunAccess.Profile p){ItemStack s=new ItemStack(1);s.profile=p;return s;}
 static int ammo(List<ItemStack> list,ResourceLocation id){return list.stream().filter(s->id.equals(WeaponLoot.ammoId(s))).mapToInt(ItemStack::getCount).sum();}
 static void paired(List<ItemStack> list){for(var s:list)if(s.profile!=null)ok(ammo(list,s.profile.ammo())>=15);}
 public static void main(String[] a)throws Exception{
  var A=new ResourceLocation("tacz:9mm");var B=new ResourceLocation("tacz:556");double[] damage={4,6,8.8,14,24};
  for(int i=0;i<5;i++)GunAccess.ALL.add(new GunAccess.Profile(new ResourceLocation("gun:"+i),i==0?A:B,30,i==0?0:3,new GunAccess.Data(new GunAccess.Bullet(damage[i]))));
  R r=new R();var list=new ArrayList<ItemStack>(List.of(gun(GunAccess.ALL.get(0)),gun(GunAccess.ALL.get(2))));WeaponLoot.supply(list,0,r,false);paired(list);ok(ammo(list,A)>=15&&ammo(list,B)>=15);
  var same=new ArrayList<ItemStack>(List.of(gun(GunAccess.ALL.get(0)),gun(GunAccess.ALL.get(0))));WeaponLoot.supply(same,0,r,false);ok(ammo(same,A)>=30);ok(same.stream().filter(s->s.profile!=null).count()==2);
  var world=new ArrayList<ItemStack>(List.of(gun(GunAccess.ALL.get(4))));WeaponLoot.supply(world,4,new net.minecraft.util.RandomSource(){public double nextDouble(){return 0;}public int nextInt(int b){return 0;}},true);ok(world.getFirst().profile!=null);paired(world);int size=world.size();WeaponLoot.supply(world,4,new net.minecraft.util.RandomSource(){public double nextDouble(){return .999;}public int nextInt(int b){return 0;}},true);ok(world.size()==size&&world.getFirst().profile!=null);
  ItemStack lore=world.getFirst();ok(lore.get(net.minecraft.core.component.DataComponents.LORE).lines().getFirst().getString().contains("legendario"));WeaponLoot.decorate(lore);ok(lore.get(net.minecraft.core.component.DataComponents.LORE).lines().size()==1);
  Box full=new Box(gun(GunAccess.ALL.get(0)),gun(GunAccess.ALL.get(3)),new ItemStack(1),new ItemStack(1));WeaponLoot.audit(full,3,r);paired(Arrays.asList(full.stacks));
  Box allGuns=new Box(gun(GunAccess.ALL.get(0)),gun(GunAccess.ALL.get(0)));WeaponLoot.audit(allGuns,0,r);paired(Arrays.asList(allGuns.stacks));
  double meanLow=0,meanHigh=0;for(int i=0;i<5000;i++){meanLow+=WeaponLoot.damage(WeaponLoot.choose(0,r));meanHigh+=WeaponLoot.damage(WeaponLoot.choose(4,r));}ok(meanHigh>meanLow*1.5);
  System.out.println("PASS: "+n+" multi-caliber pairing, shared-caliber quantity, world reroll protection, lore, full-inventory audit and quality-weighted selection checks");
 }
}
