package dev.zomboidmelee.client;
public class NativeBatRenderer {
 public static int renders,contexts;
 public com.tacz.guns.api.TimelessAPI.Machine getStateMachine(net.minecraft.world.item.ItemStack s){return com.tacz.guns.api.TimelessAPI.machine;}
 public com.tacz.guns.api.TimelessAPI.Context initContext(net.minecraft.world.item.ItemStack s,net.minecraft.world.entity.player.Player p,float partial){contexts++;return new com.tacz.guns.api.TimelessAPI.Context();}
 public void renderFirstPerson(net.minecraft.client.player.LocalPlayer p,net.minecraft.world.item.ItemStack s,net.minecraft.world.item.ItemDisplayContext mode,com.mojang.blaze3d.vertex.PoseStack pose,net.minecraft.client.renderer.MultiBufferSource buffers,int light,float partial){renders++;}
}
