package com.tacz.guns.api.client.animation;
public class ObjectAnimation {public final String name;public ObjectAnimation(String n){name=n;}public ObjectAnimation(ObjectAnimation o){name=o.name;}public enum PlayType{PLAY_ONCE_STOP}}
