package com.tacz.guns.api;
import com.tacz.guns.api.client.animation.ObjectAnimation;
public class TimelessAPI {
 public static boolean gun=true;public static Machine machine=new Machine();
 public static java.util.Optional<Display> getGunDisplay(net.minecraft.world.item.ItemStack s){return gun?java.util.Optional.of(new Display()):java.util.Optional.empty();}
 public static class Display{public Machine getAnimationStateMachine(){return machine;}}
 public static class Controller{public int registered,runs,track;public String name;public ObjectAnimation prototype;public boolean blend=true;
  public void providePrototypeIfAbsent(String n,java.util.function.Supplier<ObjectAnimation> s){registered++;if(prototype==null)prototype=s.get();}
  public void setBlending(int t,boolean b){blend=b;}
  public void runAnimation(int t,String n,ObjectAnimation.PlayType p,float fade){if(p!=ObjectAnimation.PlayType.PLAY_ONCE_STOP||fade!=.2f)throw new AssertionError();runs++;track=t;name=n;}
 }
 public static class Context extends com.tacz.guns.api.client.animation.statemachine.AnimationStateContext{public int getTrack(int row,int slot){if(row!=0||slot!=1)throw new AssertionError();return 1;}}
 public static class Machine{public Object context=new Context();public int initialized,updates;public Object getContext(){return context;}public void setContext(com.tacz.guns.api.client.animation.statemachine.AnimationStateContext c){context=c;}public void initialize(){initialized++;}public void update(){updates++;}public Controller controller=new Controller();public String trigger;public Controller getAnimationController(){return controller;}public void trigger(String s){trigger=s;}public void processContextIfExist(java.util.function.Consumer<Object> c){if(context!=null)c.accept(context);}}
}
