package com.tacz.guns.client.resource;
public class InternalAssetLoader {public static java.util.List<com.tacz.guns.api.client.animation.ObjectAnimation> getDefaultRifleAnimations(){return java.util.List.of(new com.tacz.guns.api.client.animation.ObjectAnimation("melee_stock"));}}
