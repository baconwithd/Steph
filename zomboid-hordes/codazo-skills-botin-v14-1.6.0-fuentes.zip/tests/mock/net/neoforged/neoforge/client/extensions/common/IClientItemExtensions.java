package net.neoforged.neoforge.client.extensions.common;
public interface IClientItemExtensions {
 class Flag{public static boolean proxy;}
 class NoStateRenderer {}
 static IClientItemExtensions of(net.minecraft.world.item.ItemStack s){return new Extension();}
 Object getCustomRenderer();
 class Extension implements IClientItemExtensions {public Object getCustomRenderer(){return Flag.proxy?new NoStateRenderer():new Renderer();}}
 class Renderer {public com.tacz.guns.api.TimelessAPI.Machine getStateMachine(net.minecraft.world.item.ItemStack s){return com.tacz.guns.api.TimelessAPI.machine;}}
}
