package net.minecraft.world.item;public enum ItemDisplayContext {FIRST_PERSON_RIGHT_HAND,FIRST_PERSON_LEFT_HAND}
