import dev.survivorcreator.skills.CombatSkillRules;import dev.zomboid.remains.*;import dev.zomboidmelee.combat.CombatRules;
public class Rules23Test {
 static int checks;static void ok(boolean b){checks++;if(!b)throw new AssertionError("Rules "+checks);}
 public static void main(String[] args){
  ok(CombatRules.inCone(1.5,1));ok(!CombatRules.inCone(1.5001,1));ok(CombatRules.SHOVE_COOLDOWN==15&&CombatRules.STUN==15);
  for(int i=0;i<=10;i++){ok(CombatSkillRules.spread(i)==1-.04*i);ok(CombatSkillRules.reloadTime(i)==1-.03*i);ok(CombatSkillRules.damage(i)==1+.04f*i);ok(CombatSkillRules.crit(i)==.015*i);ok(CombatSkillRules.preserve(i)==.04*i);}
  int previous=-1;for(double d=1;d<=100;d+=.25){int tier=WeaponRarityRules.tier(d,5);ok(tier>=previous);previous=tier;}
  ok(WeaponRarityRules.tier(5,5)==0);ok(WeaponRarityRules.tier(8,5)==2);ok(WeaponRarityRules.tier(30,5)==4);
  double low=WeaponRarityRules.weight(0,4,30,5)/WeaponRarityRules.weight(0,0,5,5),high=WeaponRarityRules.weight(4,4,30,5)/WeaponRarityRules.weight(4,0,5,5);ok(high>low*100);
  for(int q=0;q<=4;q++)for(int tier=0;tier<=4;tier++)ok(WeaponRarityRules.weight(q,tier,15,5)<WeaponRarityRules.weight(q,tier,10,5));
  System.out.println("PASS: "+checks+" shove reach/cooldown/stun, skill caps, monotonic damage rarity and quality loot weighting checks");
 }
}
