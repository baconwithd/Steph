package org.spongepowered.asm.mixin.injection;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) @java.lang.annotation.Target({java.lang.annotation.ElementType.METHOD,java.lang.annotation.ElementType.ANNOTATION_TYPE})
public @interface At {String value();int ordinal() default -1;String target() default "";boolean remap() default true;}
