from pathlib import Path
import subprocess,zipfile,json,shutil,argparse
r=Path(__file__).resolve().parent;ws=r.parent.parent
mc=ws/'attachments/1338682b-fcc2-4d11-9002-1714ece5faed/client-1.21.1-20240808.144430-srg.jar'
neo=ws/'attachments/31294bde-ea70-4506-8023-e3eaaf3a59ac/neoforge-21.1.255-universal.jar'
lr=ws/'attachments/c534c9db-a999-45a6-9229-53729c01cad1/LesRaisins-Tactical-Equipements-1.21.1-0.4.3-zomboid-jsononly-safe.jar'
survivor=ws/'attachments/af3807a7-05d6-4857-bdd5-1b31c1ecef0d/survivorcreator-neoforge-1.21.1-1.0.8-zomboid-v13-active-skills.jar'
loot=ws/'attachments/0e2f8be2-00cb-4e95-acfb-19b284f277db/zombie-remains-loot-1.5.0-neoforge-1.21.1.jar'
melee=ws/'attachments/68cc6356-3492-4772-b637-f669135e9686/zomboid-global-melee-animations-2.0.0-native-bat.jar'
weight=ws/'outputs/eZWeight-neoforge-1.21.1-1.8.4-stamina-v9-combat.jar'
parser=argparse.ArgumentParser()
for option,default in [('minecraft',mc),('neoforge',neo),('lrtactical',lr),('survivor',survivor),('loot',loot),('melee',melee),('weight',weight),('libs',ws/'work/lib'),('out-dir',ws/'outputs')]:parser.add_argument('--'+option,default=str(default))
a=parser.parse_args();mc=Path(a.minecraft);neo=Path(a.neoforge);lr=Path(a.lrtactical);survivor=Path(a.survivor);loot=Path(a.loot);melee=Path(a.melee);weight=Path(a.weight)
libs=list(Path(a.libs).glob('*.jar'));ecj=Path(a.libs)/'ecj.jar';out=Path(a.out_dir);out.mkdir(parents=True,exist_ok=True)
for kind,base,prefix,name in [('skills',survivor,'dev/survivorcreator','survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v14-combat-skills.jar'),('loot',loot,'dev/zomboid/remains','zombie-remains-loot-1.6.0-neoforge-1.21.1.jar'),('melee',melee,'dev/zomboidmelee','zomboid-global-melee-animations-2.3.0-elbow-range.jar')]:
 classes=r/('classes-'+kind)
 if classes.exists():shutil.rmtree(classes)
 classes.mkdir()
 cp=':'.join(map(str,[mc,neo,lr,survivor,loot,melee,weight]+libs))
 sources=list((r/('src-'+kind)).rglob('*.java'))
 subprocess.run(['java','-jar',str(ecj),'-21','-proc:none','-warn:none','-cp',cp,'-sourcepath',str(r/('src-'+kind))+':'+str(r/'stubs'),'-d',str(classes)]+list(map(str,sources)),check=True)
 if kind=='melee':
  tool=r/'proxy-tool';tool.mkdir(exist_ok=True)
  toolcp=':'.join(map(str,libs));subprocess.run(['java','-jar',str(ecj),'-21','-proc:none','-warn:none','-cp',toolcp,'-d',str(tool),str(r/'PatchProxyRenderer.java')],check=True)
  proxyPath=classes/'dev/zomboidmelee/client/NativeBatRenderer.class';proxyPath.parent.mkdir(parents=True,exist_ok=True)
  with zipfile.ZipFile(base) as original:proxyPath.write_bytes(original.read('dev/zomboidmelee/client/NativeBatRenderer.class'))
  subprocess.run(['java','-cp',str(tool)+':'+toolcp,'PatchProxyRenderer',str(proxyPath),str(proxyPath)],check=True)
 overrides={p.relative_to(classes).as_posix():p.read_bytes() for p in (classes/prefix).rglob('*.class')}
 with zipfile.ZipFile(base) as z:
  toml=z.read('META-INF/neoforge.mods.toml').decode()
  if kind=='skills':
   toml=toml.replace('version = "1.0.8"','version = "1.0.9"')+'\n[[mixins]]\nconfig="survivorcreator-combat14.mixins.json"\n'
   overrides['survivorcreator-combat14.mixins.json']=json.dumps({'required':True,'minVersion':'0.8','package':'dev.survivorcreator.mixin','compatibilityLevel':'JAVA_21','mixins':['CombatSkillsInitMixin','ReloadSkillMixin','AimingSkillMixin','MaintenanceSkillMixin'],'client':['CombatSkillsPanelMixin','CombatSkillsNameMixin'],'injectors':{'defaultRequire':1}},indent=2).encode()
   for locale in ['es_es','en_us']:
    path='assets/survivorcreator/lang/'+locale+'.json'
    lang=json.loads(z.read(path)) if path in z.namelist() else {}
    lang.update({'skill.survivorcreator.'+k:v for k,v in {'aiming':'Puntería','reloading':'Recarga','axe':'Hachas','long_blade':'Hojas largas','short_blade':'Hojas cortas','long_blunt':'Contundentes largos','short_blunt':'Contundentes cortos','spear':'Lanzas','maintenance':'Mantenimiento'}.items()})
    overrides[path]=json.dumps(lang,ensure_ascii=False,indent=2).encode()
  elif kind=='loot':
   toml=toml.replace('1.5.0','1.6.0')+'\n[[mixins]]\nconfig="zombie-remains-weapons.mixins.json"\n'
   overrides['zombie-remains-weapons.mixins.json']=json.dumps({'required':True,'minVersion':'0.8','package':'dev.zomboid.remains.mixin','compatibilityLevel':'JAVA_21','mixins':['WeaponTableMixin'],'injectors':{'defaultRequire':1}},indent=2).encode()
  else:
   toml=toml.replace('version="2.0.0"','version="2.3.0"')+'\n[[dependencies.zomboid_global_melee]]\nmodId="ezweight"\ntype="required"\nversionRange="[1.8.4-stamina-v9]"\nordering="AFTER"\nside="BOTH"\n'
   d=json.loads(z.read('zomboid_global_melee.mixins.json'));d['mixins']+=['MeleeTimingMixin','MeleeStaminaMixin','VanillaCombatMixin','ShoveStunMixin'];d['client']+=['NativePushKeyMixin','MeleePushPoseMixin','VanillaPushPoseMixin','GunPushPoseMixin'];overrides['zomboid_global_melee.mixins.json']=json.dumps(d,indent=2).encode()
  overrides['META-INF/neoforge.mods.toml']=toml.encode()
  if 'META-INF/MANIFEST.MF' in z.namelist():
   manifest=z.read('META-INF/MANIFEST.MF').decode()
   if kind=='loot':manifest=manifest.replace('Implementation-Version: 1.5.0','Implementation-Version: 1.6.0')
   overrides['META-INF/MANIFEST.MF']=manifest.encode()
  with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED) as result:
   for n in z.namelist():
    if n not in overrides:result.writestr(n,z.read(n))
   for n,b in overrides.items():result.writestr(n,b)
 print('Built',name)
