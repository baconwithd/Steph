package dev.zomboidmelee;
@net.neoforged.fml.common.Mod("zomboid_global_melee")
public final class ZomboidGlobalMelee {
 public ZomboidGlobalMelee(){dev.zomboidmelee.combat.GunShoveCompat.install();System.out.println("[ZomboidMelee] 2.1.0: universal shove, stamina, normal -25% cooldown and heavy +50% damage");}
}
