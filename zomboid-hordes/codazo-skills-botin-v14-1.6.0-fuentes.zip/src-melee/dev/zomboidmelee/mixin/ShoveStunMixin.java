package dev.zomboidmelee.mixin;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(Mob.class)
public abstract class ShoveStunMixin {
 @ModifyVariable(method="setSpeed(F)V",at=@At("HEAD"),argsOnly=true)
 private float zpush$pause(float speed){Mob z=(Mob)(Object)this;return !z.level().isClientSide()&&dev.zomboidmelee.combat.ShoveCombat.stunned(z)?0:speed;}
}
