package dev.zomboidmelee.mixin;
import com.armilp.ezweight.stamina.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(Player.class)
public abstract class VanillaCombatMixin {
 @Inject(method="getCurrentItemAttackStrengthDelay()F",at=@At("RETURN"),cancellable=true)
 private void zpush$faster(CallbackInfoReturnable<Float> cir){cir.setReturnValue(cir.getReturnValue()*.75f);}
 @Inject(method="attack(Lnet/minecraft/world/entity/Entity;)V",at=@At("HEAD"),cancellable=true)
 private void zpush$vanillaAttack(Entity target,CallbackInfo ci){Player p=(Player)(Object)this;if(me.xjqsh.lrtactical.api.item.IMeleeWeapon.of(p.getMainHandItem())==null&&!StaminaCommon.consume(p,StaminaRules.NORMAL))ci.cancel();}
}
