package dev.zomboidmelee.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemInHandRenderer.class)
public abstract class VanillaPushPoseMixin {
 @Inject(method="renderArmWithItem",at=@At("HEAD"),cancellable=true)
 private void zpush$stock(AbstractClientPlayer player,float partial,float pitch,InteractionHand hand,float swing,ItemStack item,float equip,PoseStack pose,MultiBufferSource buffers,int light,CallbackInfo ci){
  if(!(player instanceof LocalPlayer p)||dev.zomboidmelee.combat.PushClient.wave(p,partial)<=0||!dev.zomboidmelee.combat.NativeStockAnimation.usesProxy())return;
  if(hand==InteractionHand.OFF_HAND){ci.cancel();return;}
  ItemDisplayContext mode=p.getMainArm()==net.minecraft.world.entity.HumanoidArm.RIGHT?ItemDisplayContext.FIRST_PERSON_RIGHT_HAND:ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
  if(dev.zomboidmelee.combat.NativeStockAnimation.renderProxy(p,item,mode,pose,buffers,light,partial))ci.cancel();
 }
}
