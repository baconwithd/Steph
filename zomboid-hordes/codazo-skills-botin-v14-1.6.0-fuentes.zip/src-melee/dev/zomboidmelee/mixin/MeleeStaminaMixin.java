package dev.zomboidmelee.mixin;
import com.armilp.ezweight.stamina.*;
import me.xjqsh.lrtactical.api.melee.MeleeAction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="me.xjqsh.lrtactical.capability.CombatProperties",remap=false)
public abstract class MeleeStaminaMixin {
 @Shadow @Final private Player entity;
 @Inject(method="preAttack(Lme/xjqsh/lrtactical/api/melee/MeleeAction;ILnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)Z",at=@At("HEAD"),cancellable=true,remap=false)
 private void zpush$check(MeleeAction action,int combo,Vec3 origin,Vec3 direction,CallbackInfoReturnable<Boolean> cir){if(!StaminaCommon.canSpend(entity,action==MeleeAction.RIGHT?StaminaRules.HEAVY:StaminaRules.NORMAL))cir.setReturnValue(false);}
 @Inject(method="preAttack(Lme/xjqsh/lrtactical/api/melee/MeleeAction;ILnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)Z",at=@At("RETURN"),remap=false)
 private void zpush$pay(MeleeAction action,int combo,Vec3 origin,Vec3 direction,CallbackInfoReturnable<Boolean> cir){if(cir.getReturnValue())StaminaCommon.consume(entity,action==MeleeAction.RIGHT?StaminaRules.HEAVY:StaminaRules.NORMAL);}
}
