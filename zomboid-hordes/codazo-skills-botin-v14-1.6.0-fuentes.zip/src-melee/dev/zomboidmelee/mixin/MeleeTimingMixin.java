package dev.zomboidmelee.mixin;
import me.xjqsh.lrtactical.api.melee.MeleeAction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="me.xjqsh.lrtactical.item.MeleeItem",remap=false)
public abstract class MeleeTimingMixin {
 @Inject(method="getAttackCoolDown",at=@At("RETURN"),cancellable=true,remap=false)
 private void zpush$cooldown(ItemStack stack,MeleeAction action,int combo,CallbackInfoReturnable<Integer> cir){cir.setReturnValue(dev.zomboidmelee.combat.CombatRules.cooldown(cir.getReturnValue(),action==MeleeAction.RIGHT));}
 @Inject(method="getAttackDelay",at=@At("RETURN"),cancellable=true,remap=false)
 private void zpush$delay(Player p,ItemStack stack,MeleeAction action,int combo,CallbackInfoReturnable<Integer> cir){cir.setReturnValue(dev.zomboidmelee.combat.CombatRules.delay(cir.getReturnValue(),action==MeleeAction.RIGHT));}
 @ModifyVariable(method="attack(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lme/xjqsh/lrtactical/api/melee/MeleeAction;Ljava/util/List;I)V",at=@At("STORE"),ordinal=0,remap=false)
 private float zpush$heavyDamage(float base,Player p,ItemStack stack,MeleeAction action,java.util.List<net.minecraft.world.entity.Entity> targets,int combo){return dev.zomboidmelee.combat.CombatRules.damage(base,action==MeleeAction.RIGHT);}
}

