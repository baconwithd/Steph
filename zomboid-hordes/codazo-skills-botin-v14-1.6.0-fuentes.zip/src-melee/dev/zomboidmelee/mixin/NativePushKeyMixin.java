package dev.zomboidmelee.mixin;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Pseudo @Mixin(targets="com.tacz.guns.client.input.MeleeKey",remap=false)
public abstract class NativePushKeyMixin {
 @Inject(method="doMeleeLogic()V",at=@At("HEAD"),cancellable=true,remap=false,require=0)
 private static void zpush$native(CallbackInfo ci){dev.zomboidmelee.combat.PushClient.request();ci.cancel();}
 @Inject(method="onMeleeKeyPress(Lnet/neoforged/neoforge/client/event/InputEvent$Key;)V",at=@At("HEAD"),cancellable=true,remap=false,require=0)
 private static void zpush$key(net.neoforged.neoforge.client.event.InputEvent.Key e,CallbackInfo ci){dev.zomboidmelee.combat.PushClient.pressed(e);ci.cancel();}
 @Inject(method="onMeleeMousePress(Lnet/neoforged/neoforge/client/event/InputEvent$MouseButton$Post;)V",at=@At("HEAD"),cancellable=true,remap=false,require=0)
 private static void zpush$mouse(net.neoforged.neoforge.client.event.InputEvent.MouseButton.Post e,CallbackInfo ci){dev.zomboidmelee.combat.PushClient.mouse(e);ci.cancel();}
}
