package dev.zomboidmelee.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.item.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="me.xjqsh.lrtactical.client.renderer.item.MeleeItemRenderer",remap=false)
public abstract class MeleePushPoseMixin {
 @Unique private static final ThreadLocal<java.util.ArrayDeque<Boolean>> zpush$poses=ThreadLocal.withInitial(java.util.ArrayDeque::new);
 @Inject(method="renderFirstPerson",at=@At("HEAD"),remap=false)
 private void zpush$forward(LocalPlayer player,ItemStack stack,ItemDisplayContext mode,PoseStack pose,MultiBufferSource buffers,int light,float partial,CallbackInfo ci){float w=dev.zomboidmelee.combat.PushClient.wave(player,partial);boolean active=w>0&&dev.zomboidmelee.combat.PushClient.needsPose()&&!dev.zomboidmelee.combat.NativeStockAnimation.usesProxy();zpush$poses.get().push(active);if(active){pose.pushPose();dev.zomboidmelee.combat.PushClient.pose(player,partial,pose);}}
 @Inject(method="renderFirstPerson",at=@At("RETURN"),remap=false)
 private void zpush$restore(LocalPlayer player,ItemStack stack,ItemDisplayContext mode,PoseStack pose,MultiBufferSource buffers,int light,float partial,CallbackInfo ci){if(zpush$poses.get().pop())pose.popPose();}
}
