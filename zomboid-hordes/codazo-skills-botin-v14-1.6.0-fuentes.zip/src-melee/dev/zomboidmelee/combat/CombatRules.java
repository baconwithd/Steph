package dev.zomboidmelee.combat;
public final class CombatRules {
 public static int cooldown(int old,boolean heavy){return Math.max(1,(int)Math.ceil(old*(heavy?1.0:.75)));}
 public static int delay(int old,boolean heavy){return Math.max(0,(int)Math.ceil(old*(heavy?1.0:.75)));}
 public static float damage(float original,boolean heavy){return original*(heavy?1.5f:1f);}
 public static final int SHOVE_COOLDOWN=15,STUN=15;
 public static boolean inCone(double distance,double dot){return distance<=1.5&&dot>=.70;}
}
