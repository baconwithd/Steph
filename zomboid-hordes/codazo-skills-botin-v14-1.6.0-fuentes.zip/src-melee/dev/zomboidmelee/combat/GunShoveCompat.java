package dev.zomboidmelee.combat;
import java.lang.reflect.*;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.EventPriority;
/** Also handles gun-melee packets, so old/native TaCZ input cannot cause a second damaging hit. */
public final class GunShoveCompat {
 public static void install(){
  try{Class<?> event=Class.forName("com.tacz.guns.api.event.common.GunMeleeEvent");Object bus=Class.forName("net.neoforged.neoforge.common.NeoForge").getField("EVENT_BUS").get(null);
   Consumer<Object> listener=e->{try{Object shooter=e.getClass().getMethod("getShooter").invoke(e);if(shooter instanceof ServerPlayer p){e.getClass().getMethod("setCanceled",boolean.class).invoke(e,true);ShoveCombat.push(p);}}catch(ReflectiveOperationException error){System.err.println("[ZomboidMelee] Native gun shove event failed: "+error);}};
   for(Method m:bus.getClass().getMethods())if(m.getName().equals("addListener")&&m.getParameterCount()==4&&m.getParameterTypes()[2]==Class.class){m.invoke(bus,EventPriority.HIGHEST,false,event,listener);System.out.println("[ZomboidMelee] TaCZ gun melee routed to one server shove");return;}
   System.err.println("[ZomboidMelee] No compatible NeoForge gun-melee listener registration");
  }catch(ReflectiveOperationException error){System.err.println("[ZomboidMelee] TaCZ server shove hook unavailable: "+error);}
 }
}
