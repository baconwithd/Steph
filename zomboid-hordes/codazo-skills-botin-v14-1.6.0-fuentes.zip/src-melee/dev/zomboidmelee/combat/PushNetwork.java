package dev.zomboidmelee.combat;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="zomboid_global_melee",bus=EventBusSubscriber.Bus.MOD)
public final class PushNetwork {
 public record Push() implements CustomPacketPayload {
  public static final Type<Push> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("zomboid_global_melee","shove"));
  public static final StreamCodec<RegistryFriendlyByteBuf,Push> CODEC=StreamCodec.of((b,p)->{},b->new Push());
  public Type<? extends CustomPacketPayload> type(){return TYPE;}
 }
 @SubscribeEvent public static void register(RegisterPayloadHandlersEvent e){e.registrar("21").playToServer(Push.TYPE,Push.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer sp)ShoveCombat.push(sp);}));}
}
