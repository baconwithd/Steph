package dev.zomboidmelee.combat;
/** Root motion from TaCZ rifle_default melee_stock; Bedrock units, degrees, seconds. */
public final class StockMotion {
 public static final double LENGTH=0.7083;
 public record Frame(double x,double y,double z,float rx,float ry,float rz){}
 private static final double[][] P={{0.0,0,0,0,1},{0.0208,0,0,0.175,0},{0.0625,0,0,1,0},{0.0833,3.6,1.3,-6.1,1},{0.125,4.275,1.4,-7,0},{0.1667,4,1.3,-7.1,0},{0.25,4,1.3,-7.1,0},{0.2917,4,1.3,-7.1,0},{0.4375,0.1,-0.4,-1.5,1},{0.5208,-0.15,0,-0.325,1},{0.5625,0.025,-0.075,0.25,1},{0.6042,-0.025,0,0,1},{0.6667,0.025,0,0,1},{0.7083,0,0,0,1}};
 private static final double[][] R={{0.0,0,0,0,1},{0.0208,-0.62807,4.95976,-6.02537,1},{0.0625,-23.00731,-18.15747,53.72531,1},{0.0833,-142.03231,4.99253,72.92531,1},{0.125,-141.98231,-0.90747,76.72531,0},{0.1667,-144.60731,-1.15747,76.72531,0},{0.25,-144.60731,-1.15747,76.72531,0},{0.2917,-134.00445,-1.25948,63.82049,0},{0.4375,-21.22399,-4.89941,18.91483,1},{0.5208,1.375,0,1,0},{0.5625,-0.175,0.75,0.5,0},{0.6042,0,-0.25,0.25,1},{0.6667,0,0,0,1},{0.7083,0,0,0,1}};
 private static double sample(double[][] k,double t,int axis){
  int i=0;while(i+1<k.length&&k[i+1][0]<=t)i++;if(i+1==k.length)return k[i][axis];
  double f=Math.max(0,Math.min(1,(t-k[i][0])/(k[i+1][0]-k[i][0]))),a=k[i][axis],b=k[i+1][axis];
  if(k[i][4]==0&&k[i+1][4]==0)return a+(b-a)*f;
  double prev=k[Math.max(0,i-1)][axis],next=k[Math.min(k.length-1,i+2)][axis];
  return .5*((2*a)+(-prev+b)*f+(2*prev-5*a+4*b-next)*f*f+(-prev+3*a-3*b+next)*f*f*f);
 }
 public static Frame at(double seconds){if(!Double.isFinite(seconds)||seconds<=0||seconds>=LENGTH)return new Frame(0,0,0,0,0,0);return new Frame(-sample(P,seconds,1)/16,-sample(P,seconds,2)/16,sample(P,seconds,3)/16,(float)-sample(R,seconds,1),(float)-sample(R,seconds,2),(float)sample(R,seconds,3));}
}
