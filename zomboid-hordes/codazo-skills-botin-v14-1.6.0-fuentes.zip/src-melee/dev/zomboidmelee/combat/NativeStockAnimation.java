package dev.zomboidmelee.combat;
import net.minecraft.world.item.ItemStack;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;
public final class NativeStockAnimation {
 private static final Set<Object> PROVIDED=Collections.newSetFromMap(new WeakHashMap<>());
 private static boolean warned,lastProxy;private static Object proxy;
 public static boolean usesProxy(){return lastProxy;}
 public static Object proxy()throws ReflectiveOperationException {if(proxy==null)proxy=Class.forName("dev.zomboidmelee.client.NativeBatRenderer").getConstructor().newInstance();return proxy;}
 public static boolean renderProxy(net.minecraft.client.player.LocalPlayer player,ItemStack stack,net.minecraft.world.item.ItemDisplayContext mode,com.mojang.blaze3d.vertex.PoseStack pose,net.minecraft.client.renderer.MultiBufferSource buffers,int light,float partial){
  try{Object r=proxy();r.getClass().getMethod("renderFirstPerson",net.minecraft.client.player.LocalPlayer.class,ItemStack.class,net.minecraft.world.item.ItemDisplayContext.class,com.mojang.blaze3d.vertex.PoseStack.class,net.minecraft.client.renderer.MultiBufferSource.class,int.class,float.class).invoke(r,player,stack,mode,pose,buffers,light,partial);return true;}catch(ReflectiveOperationException|RuntimeException e){warn(e);return false;}
 }

 public static boolean play(ItemStack stack){
  lastProxy=false;try{
   Object display=((Optional<?>)Class.forName("com.tacz.guns.api.TimelessAPI").getMethod("getGunDisplay",ItemStack.class).invoke(null,stack)).orElse(null);
   boolean gun=display!=null;Object machine,meleeRenderer=null;
   if(gun)machine=display.getClass().getMethod("getAnimationStateMachine").invoke(display);
   else{
    Object extension=Class.forName("net.neoforged.neoforge.client.extensions.common.IClientItemExtensions").getMethod("of",ItemStack.class).invoke(null,stack);
    Object renderer=Class.forName("net.neoforged.neoforge.client.extensions.common.IClientItemExtensions").getMethod("getCustomRenderer").invoke(extension);
    // Use the public interface method even when the extension implementation is anonymous.
    try{machine=renderer.getClass().getMethod("getStateMachine",ItemStack.class).invoke(renderer,stack);}
    catch(NoSuchMethodException missing){renderer=proxy();lastProxy=true;machine=renderer.getClass().getMethod("getStateMachine",ItemStack.class).invoke(renderer,stack);}
    meleeRenderer=renderer;
   }
   if(machine==null)return false;
   if(!gun&&machine.getClass().getMethod("getContext").invoke(machine)==null){
    Object player=net.minecraft.client.Minecraft.getInstance().player;if(player==null)return false;
    Object context=meleeRenderer.getClass().getMethod("initContext",ItemStack.class,net.minecraft.world.entity.player.Player.class,float.class).invoke(meleeRenderer,stack,player,0f);
    machine.getClass().getMethod("setContext",Class.forName("com.tacz.guns.api.client.animation.statemachine.AnimationStateContext")).invoke(machine,context);
    machine.getClass().getMethod("initialize").invoke(machine);machine.getClass().getMethod("update").invoke(machine);
   }
   Object controller=machine.getClass().getMethod("getAnimationController").invoke(machine);
   if(!PROVIDED.contains(controller)){
    var animations=(List<?>)Class.forName("com.tacz.guns.client.resource.InternalAssetLoader").getMethod("getDefaultRifleAnimations").invoke(null);
    Object stock=null;for(Object a:animations)if("melee_stock".equals(a.getClass().getField("name").get(a))){stock=a;break;}
    if(stock==null)return false;
    Object original=stock;Constructor<?> copy=stock.getClass().getConstructor(stock.getClass());
    Supplier<Object> supplier=()->{try{return copy.newInstance(original);}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}};
    controller.getClass().getMethod("providePrototypeIfAbsent",String.class,Supplier.class).invoke(controller,"melee_stock",supplier);PROVIDED.add(controller);
   }
   if(gun){machine.getClass().getMethod("trigger",String.class).invoke(machine,"bayonet_stock");return true;}
   boolean[] played={false};Object animationController=controller;
   Consumer<Object> run=context->{try{
    int track=((Number)context.getClass().getMethod("getTrack",int.class,int.class).invoke(context,0,1)).intValue();
    Class<?> playType=Class.forName("com.tacz.guns.api.client.animation.ObjectAnimation$PlayType");
    @SuppressWarnings({"rawtypes","unchecked"}) Object once=Enum.valueOf((Class)playType,"PLAY_ONCE_STOP");
    animationController.getClass().getMethod("setBlending",int.class,boolean.class).invoke(animationController,track,false);
    animationController.getClass().getMethod("runAnimation",int.class,String.class,playType,float.class).invoke(animationController,track,"melee_stock",once,.2f);played[0]=true;
   }catch(ReflectiveOperationException|RuntimeException e){warn(e);}};
   machine.getClass().getMethod("processContextIfExist",Consumer.class).invoke(machine,run);return played[0];
  }catch(NoSuchMethodException e){return false;}catch(ReflectiveOperationException|RuntimeException e){warn(e);return false;}
 }
 private static void warn(Exception e){if(!warned){warned=true;org.slf4j.LoggerFactory.getLogger("ZomboidMelee").warn("Native stock animation unavailable; using shared rifle stock motion",e);}}
}
