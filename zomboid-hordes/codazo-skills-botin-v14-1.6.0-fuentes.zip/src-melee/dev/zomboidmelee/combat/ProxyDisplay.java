package dev.zomboidmelee.combat;
public final class ProxyDisplay {
 public static net.minecraft.resources.ResourceLocation texture(){try{Object id=Class.forName("dev.zomboidmelee.BridgeWeapon").getField("DISPLAY").get(null);Object display=((java.util.Optional<?>)Class.forName("me.xjqsh.lrtactical.api.LrTacticalAPI").getMethod("getMeleeDisplay",net.minecraft.resources.ResourceLocation.class).invoke(null,id)).orElse(null);if(display!=null)return (net.minecraft.resources.ResourceLocation)display.getClass().getMethod("getTexture").invoke(display);}catch(ReflectiveOperationException ignored){}return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("minecraft","textures/misc/white.png");}
}
