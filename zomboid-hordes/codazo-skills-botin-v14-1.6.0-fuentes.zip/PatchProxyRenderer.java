import java.nio.file.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public final class PatchProxyRenderer implements Opcodes {
 public static void main(String[] args)throws Exception{ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(c,0);if(c.methods.stream().anyMatch(m->m.name.equals("getTextureLocation")))throw new AssertionError("Existing texture override needs review");
 MethodNode m=new MethodNode(ACC_PUBLIC,"getTextureLocation","(Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/resources/ResourceLocation;",null,null);m.instructions.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboidmelee/combat/ProxyDisplay","texture","()Lnet/minecraft/resources/ResourceLocation;",false));m.instructions.add(new InsnNode(ARETURN));c.methods.add(m);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(Path.of(args[1]),w.toByteArray());}
}
