package dev.survivorcreator.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Pseudo @Mixin(targets="ichttt.mods.firstaid.client.gui.SkillsPanel",remap=false)
public abstract class CombatSkillsPanelMixin {
 @Inject(method="group",at=@At("HEAD"),cancellable=true,require=0,remap=false) private static void skill$group(String id,CallbackInfoReturnable<String> cir){if(id.equals("aiming")||id.equals("reloading"))cir.setReturnValue("Combate · Armas de fuego");else if(dev.survivorcreator.skills.CombatSkillRules.name(id)!=null)cir.setReturnValue("Combate · Melee");}
 @Inject(method="benefits",at=@At("HEAD"),cancellable=true,require=0,remap=false) private static void skill$benefits(String id,int level,CallbackInfoReturnable<java.util.List<String>> cir){String s=dev.survivorcreator.skills.CombatSkillRules.benefit(id,level);if(s!=null)cir.setReturnValue(java.util.List.of(s));}
}
