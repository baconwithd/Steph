package dev.survivorcreator.mixin;
import net.minecraft.world.item.*;import net.minecraft.server.level.*;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;
@Mixin(ItemStack.class)
public abstract class MaintenanceSkillMixin {
 @ModifyVariable(method="hurtAndBreak(ILnet/minecraft/server/level/ServerLevel;Lnet/minecraft/server/level/ServerPlayer;Ljava/util/function/Consumer;)V",at=@At("HEAD"),argsOnly=true,ordinal=0)
 private int skill$durability(int amount,int original,ServerLevel level,ServerPlayer player,java.util.function.Consumer<Item> broken){return dev.survivorcreator.skills.CombatSkills.durability((ItemStack)(Object)this,amount,player);}
}
