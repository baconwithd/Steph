package dev.survivorcreator.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;
@Pseudo @Mixin(targets="com.tacz.guns.entity.EntityKineticBullet",remap=false)
public abstract class AimingSkillMixin {
 @ModifyVariable(method="shoot(DDFLorg/joml/Vector2d;)V",at=@At("HEAD"),argsOnly=true,ordinal=0,remap=false,require=0)
 private org.joml.Vector2d skill$spread(org.joml.Vector2d spread){if((Object)this instanceof net.minecraft.world.entity.projectile.Projectile bullet&&bullet.getOwner() instanceof net.minecraft.server.level.ServerPlayer p)return new org.joml.Vector2d(spread).mul(dev.survivorcreator.skills.CombatSkillRules.spread(dev.survivorcreator.skills.ActiveSkills.level(p,"aiming")));return spread;}
}
