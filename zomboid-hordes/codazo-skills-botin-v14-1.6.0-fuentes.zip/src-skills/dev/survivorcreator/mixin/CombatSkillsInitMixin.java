package dev.survivorcreator.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(targets="dev.survivorcreator.skills.Skills",remap=false)
public abstract class CombatSkillsInitMixin {
 @Inject(method="init",at=@At("RETURN"),remap=false) private static void skill$init(CallbackInfo ci){dev.survivorcreator.skills.CombatSkills.init();}
}
