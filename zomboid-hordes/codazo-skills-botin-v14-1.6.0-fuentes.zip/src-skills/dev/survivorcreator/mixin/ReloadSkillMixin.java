package dev.survivorcreator.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Pseudo @Mixin(targets="com.tacz.guns.entity.shooter.LivingEntityReload",remap=false)
public abstract class ReloadSkillMixin {
 @Inject(method="tickReloadState",at=@At("HEAD"),remap=false,require=0) private void skill$advance(CallbackInfoReturnable<Object> cir){dev.survivorcreator.skills.ReloadSkills.advance(this);}
 @Inject(method="tickReloadState",at=@At("RETURN"),remap=false,require=0) private void skill$finished(CallbackInfoReturnable<Object> cir){dev.survivorcreator.skills.ReloadSkills.finished(this,cir.getReturnValue());}
}
