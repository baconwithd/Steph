package dev.survivorcreator.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Pseudo @Mixin(targets="ichttt.mods.firstaid.client.gui.SurvivorSkillsView",remap=false)
public abstract class CombatSkillsNameMixin {
 @Inject(method="name",at=@At("HEAD"),cancellable=true,require=0,remap=false) private static void skill$name(String id,CallbackInfoReturnable<String> cir){String n=dev.survivorcreator.skills.CombatSkillRules.name(id);if(n!=null)cir.setReturnValue(n);}
}
