package dev.survivorcreator.skills;
import java.lang.reflect.*;import java.util.*;
import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.item.ItemStack;
public final class ReloadSkills {
 private record State(long wall,ItemStack item,int ammo,ServerPlayer player){}
 private static final Map<Object,State> ACTIVE=new WeakHashMap<>();private static boolean warned;
 private static Object field(Object o,String name)throws ReflectiveOperationException{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
 private static int ammo(ItemStack s)throws ReflectiveOperationException{Class<?> api=Class.forName("com.tacz.guns.api.item.IGun");Object gun=api.getMethod("getIGunOrNull",ItemStack.class).invoke(null,s);return gun==null?-1:((Number)api.getMethod("getCurrentAmmoCount",ItemStack.class).invoke(gun,s)).intValue();}
 public static void advance(Object reloader){try{
  if(!(field(reloader,"shooter") instanceof ServerPlayer p))return;Object data=field(reloader,"data");Field time=data.getClass().getField("reloadTimestamp");long timestamp=time.getLong(data);Object state=data.getClass().getField("reloadStateType").get(data);
  if(timestamp<0||!Boolean.TRUE.equals(state.getClass().getMethod("isReloading").invoke(state))){ACTIVE.remove(reloader);return;}
  long now=System.currentTimeMillis();State old=ACTIVE.get(reloader);if(old==null){ACTIVE.put(reloader,new State(now,p.getMainHandItem(),ammo(p.getMainHandItem()),p));return;}
  if(old.item()!=p.getMainHandItem()){ACTIVE.remove(reloader);return;}
  long delta=Math.max(0,Math.min(250,now-old.wall()));double extra=1/CombatSkillRules.reloadTime(ActiveSkills.level(p,"reloading"))-1;
  if(extra>0)time.setLong(data,timestamp-(long)(delta*extra));ACTIVE.put(reloader,new State(now,old.item(),old.ammo(),p));
 }catch(ReflectiveOperationException|RuntimeException e){warn(e);}}
 public static void finished(Object reloader,Object result){try{State s=ACTIVE.get(reloader);if(s==null||result==null)return;Object state=result.getClass().getMethod("getStateType").invoke(result);if(Boolean.TRUE.equals(state.getClass().getMethod("isReloading").invoke(state)))return;ACTIVE.remove(reloader);if(!s.player().isCreative()&&!s.player().isSpectator()&&s.item()==s.player().getMainHandItem()&&ammo(s.item())>s.ammo()){Skill skill=Skills.get("reloading");if(skill!=null)Skills.addXp(s.player(),skill,2);}}catch(ReflectiveOperationException|RuntimeException e){warn(e);}}
 private static void warn(Exception e){if(!warned){warned=true;org.slf4j.LoggerFactory.getLogger("SurvivorCombat").warn("TaCZ reload skill hook unavailable",e);}}
}
