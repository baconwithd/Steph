package dev.survivorcreator.skills;
public final class CombatSkillRules {
 public static int level(int n){return Math.max(0,Math.min(10,n));}
 public static double spread(int n){return 1-.04*level(n);}
 public static double reloadTime(int n){return 1-.03*level(n);}
 public static float damage(int n){return 1+.04f*level(n);}
 public static double crit(int n){return .015*level(n);}
 public static double preserve(int n){return .04*level(n);}
 public static String name(String id){return switch(id){case "aiming"->"Puntería";case "reloading"->"Recarga";case "axe"->"Hachas";case "long_blade"->"Hojas largas";case "short_blade"->"Hojas cortas";case "long_blunt"->"Contundentes largos";case "short_blunt"->"Contundentes cortos";case "spear"->"Lanzas";case "maintenance"->"Mantenimiento";default->null;};}
 public static String benefit(String id,int n){n=level(n);return switch(id){case "aiming"->"Dispersión −"+(n*4)+"%";case "reloading"->"Tiempo de recarga −"+(n*3)+"%";case "maintenance"->"Desgaste evitado: "+(n*4)+"% por punto";case "axe","long_blade","short_blade","long_blunt","short_blunt","spear"->"Daño +"+(n*4)+"%; crítico +"+(n*1.5)+"%";default->null;};}
}
