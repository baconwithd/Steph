package dev.survivorcreator.skills;
import java.lang.reflect.*;import java.util.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.damagesource.DamageTypes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
@EventBusSubscriber(modid="survivorcreator")
public final class CombatSkills {
 private static final Map<ServerPlayer,Integer> LAST_SHOT=new WeakHashMap<>();
 public static int level(Player p,String id){if(p instanceof ServerPlayer s)return ActiveSkills.level(s,id);try{var root=com.google.gson.JsonParser.parseString(SkillSnapshot.json()).getAsJsonObject();if(!p.getUUID().toString().equals(root.get("player").getAsString()))return 0;for(var e:root.getAsJsonArray("rows")){var row=e.getAsJsonObject();if(row.get("id").getAsString().equals(id))return row.get("level").getAsInt();}}catch(RuntimeException ignored){}return 0;}
 public static String weapon(ItemStack stack){if(stack.isEmpty())return null;String path=BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
  if(stack.getItem() instanceof AxeItem||path.endsWith("_axe")||path.equals("axe"))return "axe";
  if(path.contains("spear")||path.contains("pike")||path.contains("trident"))return "spear";
  if(path.contains("knife")||path.contains("dagger")||path.contains("karambit")||path.contains("cleaver"))return "short_blade";
  if(stack.getItem() instanceof SwordItem||path.contains("katana")||path.contains("machete")||path.contains("sword"))return "long_blade";
  if((path.contains("baseball")||path.endsWith("_bat")||path.equals("bat"))||path.contains("crowbar")||path.contains("staff")||path.contains("club"))return "long_blunt";
  if(path.contains("hammer")||path.contains("pipe")||path.contains("wrench")||path.contains("skillet")||path.contains("pan"))return "short_blunt";
  return null;
 }
 public static boolean nativeMelee(ItemStack item){try{return Class.forName("me.xjqsh.lrtactical.api.item.IMeleeWeapon").getMethod("of",ItemStack.class).invoke(null,item)!=null;}catch(ReflectiveOperationException ignored){return false;}}
 public static void init(){try{Class<?> event=Class.forName("com.tacz.guns.api.event.common.EntityHurtByGunEvent$Post");Object bus=Class.forName("net.neoforged.neoforge.common.NeoForge").getField("EVENT_BUS").get(null);java.util.function.Consumer<Object> listener=CombatSkills::hitByGun;for(var m:bus.getClass().getMethods())if(m.getName().equals("addListener")&&m.getParameterCount()==4&&m.getParameterTypes()[2]==Class.class){m.invoke(bus,net.neoforged.bus.api.EventPriority.LOWEST,false,event,listener);break;}}catch(ReflectiveOperationException|LinkageError ignored){}}
 public static boolean shove(Player p){return ((net.neoforged.neoforge.common.extensions.IEntityExtension)(Object)p).getPersistentData().getBoolean("zpush_active");}
 private static void xp(ServerPlayer p,String id,double amount){if(p.isCreative()||p.isSpectator())return;Skill s=Skills.get(id);if(s!=null)Skills.addXp(p,s,amount);}
 @SubscribeEvent public static void hit(LivingDamageEvent.Post e){if(e.getNewDamage()<=0||!(e.getSource().getEntity() instanceof ServerPlayer p)||e.getSource().getDirectEntity()!=p||!e.getSource().is(DamageTypes.PLAYER_ATTACK)||shove(p))return;String id=weapon(p.getMainHandItem());if(id!=null){xp(p,id,1);if(p.getMainHandItem().isDamageableItem())xp(p,"maintenance",.6);}}
 @SubscribeEvent public static void damage(LivingDamageEvent.Pre e){if(!(e.getSource().getEntity() instanceof ServerPlayer p)||e.getSource().getDirectEntity()!=p||!e.getSource().is(DamageTypes.PLAYER_ATTACK)||shove(p))return;String id=weapon(p.getMainHandItem());if(id==null)return;float amount=e.getNewDamage()*CombatSkillRules.damage(level(p,id));if(nativeMelee(p.getMainHandItem())&&p.getRandom().nextDouble()<CombatSkillRules.crit(level(p,id))){amount*=1.5f;DamagePopups.meleeCritical(p,e.getEntity());}e.setNewDamage(amount);}
 @SubscribeEvent public static void crit(CriticalHitEvent e){if(e.getEntity() instanceof ServerPlayer p&&!shove(p)&&!nativeMelee(p.getMainHandItem())&&!e.isCriticalHit()){String id=weapon(p.getMainHandItem());if(id!=null&&p.getRandom().nextDouble()<CombatSkillRules.crit(level(p,id))){e.setCriticalHit(true);e.setDamageMultiplier(1.5f);}}}
 @SubscribeEvent public static void bullet(EntityJoinLevelEvent e){if(e.getLevel().isClientSide()||!(e.getEntity() instanceof Projectile bullet)||!(bullet.getOwner() instanceof ServerPlayer p)||!BuiltInRegistries.ENTITY_TYPE.getKey(bullet.getType()).getNamespace().equals("tacz"))return;Integer last=LAST_SHOT.put(p,p.tickCount);if(last==null||last!=p.tickCount)xp(p,"aiming",.3);}
 public static void hitByGun(Object event){try{Object a=event.getClass().getMethod("getAttacker").invoke(event);if(a instanceof ServerPlayer p&&event.getClass().getMethod("getHurtEntity").invoke(event) instanceof net.minecraft.world.entity.LivingEntity)xp(p,"aiming",1);}catch(ReflectiveOperationException ignored){}}
 public static int durability(ItemStack item,int amount,ServerPlayer p){if(p==null||amount<=0||weapon(item)==null)return amount;double chance=CombatSkillRules.preserve(level(p,"maintenance"));int used=0;for(int i=0;i<amount;i++)if(p.getRandom().nextDouble()>=chance)used++;return used;}
}
