#!/usr/bin/env python3
"""Offline build. Requires Java 21, ECJ and the exact supplied Minecraft/NeoForge/SoundAttract jars."""
import argparse,pathlib,subprocess,zipfile
p=argparse.ArgumentParser()
for name in ['mc','neoforge','sound','ecj','libs']:p.add_argument('--'+name,required=True)
p.add_argument('--out',default='zomboid-hordes-1.2.0-neoforge-1.21.1.jar')
a=p.parse_args();root=pathlib.Path(__file__).resolve().parent;classes=root/'build'/'classes';classes.mkdir(parents=True,exist_ok=True)
libs=list(pathlib.Path(a.libs).glob('*.jar'));cp=':'.join([a.mc,a.neoforge,a.sound]+[str(x) for x in libs])
subprocess.run(['java','-jar',a.ecj,'-21','-proc:none','-cp',cp,'-sourcepath',str(root/'src')+':'+str(root/'stubs'),'-d',str(classes)]+[str(x) for x in (root/'src').rglob('*.java')],check=True)
with zipfile.ZipFile(a.out,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted((classes/'dev').rglob('*.class')):z.write(f,f.relative_to(classes).as_posix())
 for f in sorted((root/'resources').rglob('*')):
  if f.is_file():z.write(f,f.relative_to(root/'resources').as_posix())
print('Built',a.out)
