import dev.zomboid.hordes.HordeConfig;import java.nio.file.*;
public class Config16Test {
 public static void main(String[] a)throws Exception{
  Path p=Path.of("config/zomboid-hordes.json");Files.createDirectories(p.getParent());
  Files.writeString(p,"{\"balanceVersion\":6,\"helicopterZombies\":480,\"helicopterExtraPerPlayer\":120,\"helicopterMaximum\":800,\"helicopterChance\":0.23,\"nightZombies\":65,\"noiseHordeChance\":0.12,\"daySpeed\":0.03}");
  HordeConfig c=HordeConfig.load();if(c.balanceVersion!=7||c.helicopterZombies!=90||c.helicopterExtraPerPlayer!=20||c.helicopterMaximum!=150||c.helicopterInitial!=18||c.helicopterActiveLimit!=24||c.helicopterWaveSize!=4||c.helicopterWaveIntervalTicks!=100)throw new AssertionError("Migration");
  if(c.helicopterChance!=.23||c.nightZombies!=65||c.noiseHordeChance!=.12||c.daySpeed!=.03)throw new AssertionError("Unrelated settings changed");
  Files.writeString(p,Files.readString(p).replace("\"helicopterZombies\": 90","\"helicopterZombies\": 60"));if(HordeConfig.load().helicopterZombies!=60)throw new AssertionError("User customization overwritten");
  System.out.println("PASS: helicopter-only migration and preservation of later custom settings");
 }
}
