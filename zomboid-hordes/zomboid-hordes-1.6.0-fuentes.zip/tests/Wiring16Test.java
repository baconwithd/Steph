import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Wiring16Test {
 static int count;static void ok(boolean b){count++;if(!b)throw new AssertionError("Wiring "+count);}
 static ClassNode read(ZipFile z,String p)throws Exception{ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(p)).readAllBytes()).accept(c,0);return c;}
 static boolean call(ClassNode c,String method,String owner,String name){for(var m:c.methods)if(m.name.equals(method))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.owner.equals(owner)&&x.name.equals(name))return true;return false;}
 public static void main(String[] a)throws Exception{
  try(ZipFile z=new ZipFile(a[0]);ZipFile mc=new ZipFile(a[1])){
   String path="dev/zomboid/hordes/";var h=read(z,path+"HordeEvents.class");ok(call(h,"waves",path+"IndividualRules","quota"));ok(call(h,"killed",path+"IndividualRules","reward"));ok(call(h,"alert",path+"ZombieIndividual","hear"));ok(call(h,"zombieTick",path+"ZombieIndividual","sees"));
   var saved=read(z,path+"HordeData.class");boolean credits=false,id=false;for(var m:saved.methods)if(m.name.equals("save"))for(var i:m.instructions.toArray())if(i instanceof LdcInsnNode n){if(n.cst.equals("credits"))credits=true;if(n.cst.equals("id"))id=true;}ok(credits&&id);
   var mix=read(z,path+"mixin/SunProtectionMixin.class");ok(call(mix,"zomboid$individualGoals",path+"ZombieIndividual","individualGoals"));ok(mix.invisibleAnnotations.stream().anyMatch(x->x.desc.endsWith("/Mixin;")));ok(read(mc,"net/minecraft/world/entity/Mob.class").methods.stream().anyMatch(m->m.name.equals("serverAiStep")&&m.desc.equals("()V")));
   ok(call(read(z,path+"ZombieIndividual.class"),"target",path+"ZombieIndividual","sees"));
  }
  System.out.println("PASS: "+count+" kill credits, saved ticket state, individual hearing/targets and native AI hook checks");
 }
}
