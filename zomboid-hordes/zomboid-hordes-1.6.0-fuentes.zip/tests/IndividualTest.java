import dev.zomboid.hordes.IndividualRules;
public class IndividualTest {
 static int checks;static void ok(boolean b){checks++;if(!b)throw new AssertionError("Check "+checks);}
 public static void main(String[] a){
  int pending=90,credits=18,alive=0,spawned=0;
  for(int i=0;i<20;i++){int q=IndividualRules.quota(4,pending,credits,alive,24);alive+=q;spawned+=q;credits-=q;pending-=q;}
  ok(spawned==18&&alive==18&&pending==72&&credits==0);
  ok(IndividualRules.quota(4,pending,credits,0,24)==0); // unloading/moving away grants no replacement
  alive--;credits=IndividualRules.reward(credits,pending);int q=IndividualRules.quota(4,pending,credits,alive,24);ok(q==1);alive+=q;spawned+=q;pending-=q;credits-=q;
  ok(alive==18&&spawned==19&&pending==71);
  for(int i=0;i<200&&pending>0;i++){alive--;credits=IndividualRules.reward(credits,pending);q=IndividualRules.quota(4,pending,credits,alive,24);alive+=q;spawned+=q;pending-=q;credits-=q;ok(alive<=24&&spawned<=90&&pending>=0&&credits>=0);}
  ok(spawned==90);ok(IndividualRules.quota(4,10,10,24,24)==0);ok(IndividualRules.reward(10,0)==0);ok(IndividualRules.initial(18,2)==22);ok(IndividualRules.activeLimit(24,2)==30);ok(IndividualRules.activeLimit(24,20)==42);
  ok(IndividualRules.type(.34)==0&&IndividualRules.type(.35)==1&&IndividualRules.type(.8)==2);
  for(int kind=0;kind<3;kind++){
   ok(IndividualRules.vision(kind,true)<IndividualRules.vision(kind,false));ok(IndividualRules.chance(kind,6,100)==1);ok(IndividualRules.chance(kind,101,100)==0);
   ok(IndividualRules.chance(kind,30,100)>IndividualRules.chance(kind,80,100));ok(IndividualRules.hearing(kind,0)>0);
  }
  ok(IndividualRules.delay(0,0)>IndividualRules.delay(2,0));ok(IndividualRules.hearing(0,.5)<IndividualRules.hearing(2,.5));
  System.out.println("PASS: "+checks+" personality, stealth and kill-driven reinforcement checks");
 }
}
