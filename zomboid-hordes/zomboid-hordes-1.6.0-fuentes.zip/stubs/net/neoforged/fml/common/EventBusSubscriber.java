package net.neoforged.fml.common;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
public @interface EventBusSubscriber { String modid(); net.neoforged.api.distmarker.Dist[] value() default {net.neoforged.api.distmarker.Dist.CLIENT,net.neoforged.api.distmarker.Dist.DEDICATED_SERVER}; }
