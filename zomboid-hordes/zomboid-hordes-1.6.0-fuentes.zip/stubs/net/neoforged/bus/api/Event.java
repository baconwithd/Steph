package net.neoforged.bus.api;
public class Event { public boolean isCanceled(){return false;} public void setCanceled(boolean b){} }
