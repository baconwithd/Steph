package com.mojang.brigadier;
public class CommandDispatcher<S>{public com.mojang.brigadier.tree.LiteralCommandNode<S> register(com.mojang.brigadier.builder.LiteralArgumentBuilder<S> c){return null;}}
