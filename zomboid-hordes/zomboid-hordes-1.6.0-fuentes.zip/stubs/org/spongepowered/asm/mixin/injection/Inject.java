package org.spongepowered.asm.mixin.injection;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) @java.lang.annotation.Target(java.lang.annotation.ElementType.METHOD)
public @interface Inject {String[] method();At[] at();boolean cancellable() default false;int require() default -1;boolean remap() default true;}
