package org.spongepowered.asm.mixin;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.CLASS) @java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
public @interface Pseudo {}
