package org.spongepowered.asm.mixin;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) @java.lang.annotation.Target({java.lang.annotation.ElementType.FIELD,java.lang.annotation.ElementType.METHOD})
public @interface Shadow {String prefix() default "shadow$";boolean remap() default true;String[] aliases() default {};}
