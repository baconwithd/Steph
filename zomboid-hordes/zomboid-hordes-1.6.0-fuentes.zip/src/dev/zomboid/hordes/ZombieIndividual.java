package dev.zomboid.hordes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.common.extensions.IEntityExtension;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
@EventBusSubscriber(modid=ZomboidHordes.ID)
public final class ZombieIndividual {
 public static void individualGoals(net.minecraft.world.entity.ai.goal.GoalSelector selector){
  for(var wrapped:java.util.Set.copyOf(selector.getAvailableGoals())){
   String name=wrapped.getGoal().getClass().getName();
   if(name.startsWith("com.example.soundattract.ai.")&&java.util.Set.of("AttractionGoal","LeaderAttractionGoal","FollowLeaderGoal","FollowerEdgeRelayGoal").contains(wrapped.getGoal().getClass().getSimpleName()))selector.removeGoal(wrapped.getGoal());
  }
 }
 static CompoundTag data(Zombie z){return ((IEntityExtension)(Object)z).getPersistentData();}
 public static CompoundTag profile(Zombie z){CompoundTag t=data(z);if(!t.getBoolean("zi_initialized")){t.putBoolean("zi_initialized",true);int kind=IndividualRules.type(z.getRandom().nextDouble());t.putInt("zi_type",kind);double hearing=IndividualRules.hearing(kind,z.getRandom().nextDouble());if(z.getRandom().nextDouble()<.12)hearing*=.30;t.putDouble("zi_hearing",hearing);t.putInt("zi_delay",IndividualRules.delay(kind,z.getRandom().nextInt()));}return t;}
 public static boolean sees(Zombie z,Player p){CompoundTag t=profile(z);long now=z.level().getGameTime();
  if(t.hasUUID("zi_angry")&&t.getUUID("zi_angry").equals(p.getUUID())&&t.getLong("zi_anger_until")>now)return z.distanceToSqr(p)<64*64;
  if(z.distanceToSqr(p)<=4*4&&z.hasLineOfSight(p))return rememberSight(t,p,now);
  double range=IndividualRules.vision(t.getInt("zi_type"),p.isCrouching());
  boolean known=t.hasUUID("zi_seen")&&t.getUUID("zi_seen").equals(p.getUUID());
  if(known&&t.getLong("zi_seen_until")>now){if(z.hasLineOfSight(p)&&z.distanceToSqr(p)<range*range*2.25)return rememberSight(t,p,now);return z.distanceToSqr(p)<48*48;}
  if(!z.hasLineOfSight(p)||z.distanceToSqr(p)>range*range)return false;
  if(!t.hasUUID("zi_pending")||!t.getUUID("zi_pending").equals(p.getUUID())||now-t.getLong("zi_pending_last")>100){t.putUUID("zi_pending",p.getUUID());t.putLong("zi_notice_at",now+t.getInt("zi_delay"));}
  t.putLong("zi_pending_last",now);if(now<t.getLong("zi_notice_at"))return false;return rememberSight(t,p,now);
 }
 private static boolean rememberSight(CompoundTag t,Player p,long now){t.putUUID("zi_seen",p.getUUID());t.putLong("zi_seen_until",now+160);return true;}
 public static boolean hear(Zombie z,BlockPos pos,ServerPlayer p,double radius,long until,boolean heli){CompoundTag t=profile(z);long now=z.level().getGameTime();
  if(t.getLong("zi_hearing_next")>now)return false;t.putLong("zi_hearing_next",now+40+t.getInt("zi_delay"));
  double distance=Math.sqrt(z.blockPosition().distSqr(pos)),range=radius*t.getDouble("zi_hearing");
  if(z.getRandom().nextDouble()>=IndividualRules.chance(t.getInt("zi_type"),distance,range))return false;
  int error=t.getInt("zi_type")==0?8:t.getInt("zi_type")==1?4:1;BlockPos memory=pos.offset(z.getRandom().nextInt(error*2+1)-error,0,z.getRandom().nextInt(error*2+1)-error);
  t.putLong("zh_pos",memory.asLong());t.putLong("zh_until",Math.min(until,now+(t.getInt("zi_type")==0?300:600)));t.putUUID("zh_player",p.getUUID());t.putBoolean("zh_heli",heli);return true;
 }
 @SubscribeEvent(priority=EventPriority.LOWEST) public static void target(LivingChangeTargetEvent e){if(e.getEntity() instanceof Zombie z&&!z.level().isClientSide()&&e.getNewAboutToBeSetTarget() instanceof Player p&&!sees(z,p))e.setNewAboutToBeSetTarget(null);}
 @SubscribeEvent public static void hurt(LivingDamageEvent.Post e){if(e.getEntity() instanceof Zombie z&&!z.level().isClientSide()&&e.getNewDamage()>0&&e.getSource().getEntity() instanceof Player p){var t=profile(z);t.putUUID("zi_angry",p.getUUID());t.putLong("zi_anger_until",z.level().getGameTime()+200);z.setTarget(p);}}
}
