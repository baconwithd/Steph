package dev.zomboid.hordes;
import java.util.*;
/** Stable batches remain valid when chunk/block callbacks change the live index. */
public final class RestockBatch<T> {
 private final ArrayDeque<T> pending=new ArrayDeque<>();
 public List<T> next(Set<T> live,int budget){
  if(pending.isEmpty())pending.addAll(live);
  List<T> result=new ArrayList<>();
  for(int i=0;i<budget&&!pending.isEmpty();i++){T value=pending.removeFirst();if(live.contains(value))result.add(value);}
  return result;
 }
}
