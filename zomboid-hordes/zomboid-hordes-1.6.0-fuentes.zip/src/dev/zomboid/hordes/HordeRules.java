package dev.zomboid.hordes;
/** Pure rules shared by runtime and offline tests. Time values are Minecraft ticks. */
public final class HordeRules {
 public static boolean night(long time){long t=Math.floorMod(time,24000L);return t>=13000&&t<23000;}
 public static boolean newDay(long time,long lastDay){return Math.floorDiv(time,24000L)>lastDay;}
 public static boolean helicopter(double random,double chance){return random<chance;}
 public static long schedule(long time,int randomOffset){long day=Math.floorDiv(time,24000L);long candidate=day*24000L+1000+randomOffset;return Math.max(time,Math.min(day*24000L+23999,Math.max(time+20,candidate)));}
 public static int budget(int base,int players,int perExtra,int maximum){return Math.min(maximum,base+Math.max(0,players-1)*perExtra);}
 public static double hearing(double original){return Math.max(8,Math.min(192,original*1.5));}
 public static boolean quietGun(double original){return original<64;}
 private HordeRules(){}
}
