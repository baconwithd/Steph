package dev.zomboid.hordes.mixin;
import dev.zomboid.hordes.LootRestock;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.storage.loot.LootTable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(RandomizableContainerBlockEntity.class)
public abstract class LootTableMemoryMixin {
 @Inject(method="setLootTable(Lnet/minecraft/resources/ResourceKey;)V",at=@At("HEAD"))
 private void zomboid$rememberTable(ResourceKey<LootTable> next,CallbackInfo ci){
  var self=(RandomizableContainerBlockEntity)(Object)this;
  LootRestock.remember(self,next!=null?next:self.getLootTable());
 }
}
