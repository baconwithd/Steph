package dev.zomboid.hordes.mixin;
import net.minecraft.world.entity.PathfinderMob;import net.minecraft.world.entity.monster.Zombie;import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MeleeAttackGoal.class)
public abstract class ZombieAttackCooldownMixin {
 @Shadow @Final protected PathfinderMob mob;
 @Shadow private int ticksUntilNextAttack;
 @Inject(method="resetAttackCooldown()V",at=@At("HEAD"),cancellable=true)
 private void zomboid$noBiteCooldown(CallbackInfo ci){if(mob instanceof Zombie){ticksUntilNextAttack=0;ci.cancel();}}
}
