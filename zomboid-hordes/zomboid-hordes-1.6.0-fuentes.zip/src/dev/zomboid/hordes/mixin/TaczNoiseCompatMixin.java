package dev.zomboid.hordes.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import dev.zomboid.hordes.TaczNoiseBridge;
/** Counts actual server shots, not the lifetime of a remembered gun sound. */
@Pseudo @Mixin(targets="com.example.soundattract.integration.tacz.TaczIntegration",remap=false)
public abstract class TaczNoiseCompatMixin {
 @Inject(method="onGunShoot",at=@At("TAIL"),remap=false)
 private static void zomboid$recordShot(@Coerce Object event,CallbackInfo ci){TaczNoiseBridge.shot(event);}
}
