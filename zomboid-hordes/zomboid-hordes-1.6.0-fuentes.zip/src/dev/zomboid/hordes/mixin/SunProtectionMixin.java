package dev.zomboid.hordes.mixin;
import net.minecraft.world.entity.Mob;import net.minecraft.world.entity.monster.Zombie;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.Unique;import org.spongepowered.asm.mixin.Shadow;import org.spongepowered.asm.mixin.Final;import net.minecraft.world.entity.ai.goal.GoalSelector;import dev.zomboid.hordes.InvestigateNoiseGoal;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Mob.class)
public abstract class SunProtectionMixin {
 @Shadow @Final protected GoalSelector goalSelector;
 @Unique private boolean zomboid_individualGoals;
 @Inject(method="serverAiStep",at=@At("HEAD")) private void zomboid$individualGoals(CallbackInfo ci){if(!zomboid_individualGoals&&(Object)this instanceof Zombie){zomboid_individualGoals=true;dev.zomboid.hordes.ZombieIndividual.individualGoals(goalSelector);}}

 @Inject(method="<init>",at=@At("RETURN"))
 private void zomboid$installInvestigation(CallbackInfo ci){if((Object)this instanceof Zombie z){goalSelector.addGoal(1,new InvestigateNoiseGoal(z));goalSelector.addGoal(1,new dev.zomboid.hordes.IndividualIdleGoal(z));}}
 @Inject(method="isSunBurnTick()Z",at=@At("HEAD"),cancellable=true)
 private void zomboid$noSunBurn(CallbackInfoReturnable<Boolean> cir){if((Object)this instanceof Zombie)cir.setReturnValue(false);}
}
