package dev.zomboid.hordes.mixin;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.monster.Zombie;import dev.zomboid.hordes.ZombieCombat;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Mob.class)
public abstract class ZombieBiteMixin {
 @Inject(method="doHurtTarget(Lnet/minecraft/world/entity/Entity;)Z",at=@At("HEAD"),cancellable=true)
 private void zomboid$windUpBite(Entity target,CallbackInfoReturnable<Boolean> ci){if((Object)this instanceof Zombie z&&!ZombieCombat.allowAttack(z,target))ci.setReturnValue(false);}
}
