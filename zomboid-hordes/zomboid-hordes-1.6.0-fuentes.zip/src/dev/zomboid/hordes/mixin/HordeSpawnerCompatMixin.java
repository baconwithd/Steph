package dev.zomboid.hordes.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Keeps Horde Hoard's combat AI but uses one persistent scheduler for automatic hordes. */
@Pseudo @Mixin(targets="com.warwa.hordehoard.procedures.HordeSpawnerProcedure",remap=false)
public abstract class HordeSpawnerCompatMixin {
 @Inject(method="onServerTick",at=@At("HEAD"),cancellable=true,remap=false)
 private static void zomboid$replaceRandomHorde(CallbackInfo ci){ci.cancel();}
}
