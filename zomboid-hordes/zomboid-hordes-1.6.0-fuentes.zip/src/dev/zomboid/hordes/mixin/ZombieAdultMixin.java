package dev.zomboid.hordes.mixin;
import net.minecraft.world.entity.monster.Zombie;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Zombie.class)
public abstract class ZombieAdultMixin {
 @Inject(method="setBaby(Z)V",at=@At("HEAD"),cancellable=true)
 private void zomboid$alwaysAdult(boolean baby,CallbackInfo ci){if(baby){((Zombie)(Object)this).setBaby(false);ci.cancel();}}
}
