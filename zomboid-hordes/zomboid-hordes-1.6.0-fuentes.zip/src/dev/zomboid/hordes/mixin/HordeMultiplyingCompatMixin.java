package dev.zomboid.hordes.mixin;
import net.minecraft.world.level.*;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** Prevents recursive grave reinforcement spawning from bypassing event limits. */
@Pseudo @Mixin(targets="com.warwa.hordehoard.config.HordeHoardConfig",remap=false)
public abstract class HordeMultiplyingCompatMixin {
 @Inject(method="isFeatureOn",at=@At("HEAD"),cancellable=true,remap=false)
 private static void zomboid$boundedReinforcements(LevelAccessor level,GameRules.Key<GameRules.BooleanValue> rule,boolean masterSwitch,CallbackInfoReturnable<Boolean> cir){if(rule.getId().equals("horde_multiplying"))cir.setReturnValue(false);}
}
