package dev.zomboid.hordes.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Replaces the full-health freeze/slowness with this addon's bounded attribute changes. */
@Pseudo @Mixin(targets="net.mcreator.weakerdayzombieneoforge.procedures.WeakerdayzombieprocedureProcedure",remap=false)
public abstract class WeakerDayCompatMixin {
 @Inject(method="execute(Lnet/neoforged/bus/api/Event;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/entity/Entity;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void zomboid$replaceDayEffects(CallbackInfo ci){ci.cancel();}
}
