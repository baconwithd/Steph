package dev.zomboid.hordes;
/** Pure balance rules for stable zombie personalities and helicopter pacing. */
public final class IndividualRules {
 public static int type(double roll){return roll<.35?0:roll<.80?1:2;}
 public static double vision(int type,boolean crouch){return (type==0?14:type==1?24:36)*(crouch?.45:1);}
 public static int delay(int type,int roll){return type==0?20+Math.floorMod(roll,41):type==1?6+Math.floorMod(roll,19):Math.floorMod(roll,7);}
 public static double hearing(int type,double roll){return (type==0?.40:type==1?.75:1.05)+Math.max(0,Math.min(1,roll))*.20;}
 public static double chance(int type,double distance,double radius){if(distance<=6)return 1;if(distance>radius)return 0;return Math.max(.05,(type==0?.38:type==1?.72:.95)*(1-.45*distance/Math.max(1,radius)));}
 public static int initial(int base,int players){return Math.min(30,base+Math.max(0,players-1)*4);}
 public static int activeLimit(int base,int players){return Math.min(42,base+Math.max(0,players-1)*6);}
 public static int quota(int wave,int pending,int credits,int nearby,int limit){return Math.max(0,Math.min(Math.min(wave,pending),Math.min(Math.max(0,credits),Math.max(0,limit-nearby))));}
 public static int reward(int credits,int pending){return Math.min(Math.max(0,pending),Math.max(0,credits)+1);}
}
