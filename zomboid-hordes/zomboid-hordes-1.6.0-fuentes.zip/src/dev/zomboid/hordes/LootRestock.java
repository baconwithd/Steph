package dev.zomboid.hordes;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.storage.loot.LootTable;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.extensions.IBlockEntityExtension;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
/** Original table survives vanilla's first unpack. No inventory is ever cleared. */
@EventBusSubscriber(modid=ZomboidHordes.ID)
public final class LootRestock {
 private static final String TABLE="zh_original_loot_table",NIGHT="zh_loot_roll_night";
 private static final Map<ServerLevel,LinkedHashSet<BlockPos>> watched=new IdentityHashMap<>();
 private static final Map<ServerLevel,RestockBatch<BlockPos>> cursors=new IdentityHashMap<>();
 private static boolean supported(BlockEntity be){return be instanceof ChestBlockEntity||be instanceof BarrelBlockEntity;}
 private static CompoundTag data(BlockEntity be){return ((IBlockEntityExtension)(Object)be).getPersistentData();}
 private static void watch(ServerLevel level,BlockPos pos){watched.computeIfAbsent(level,x->new LinkedHashSet<>()).add(pos.immutable());}
 public static void remember(RandomizableContainerBlockEntity be,ResourceKey<LootTable> table){
  if(table==null||!supported(be)||!(be.getLevel() instanceof ServerLevel level))return;
  CompoundTag tag=data(be);
  if(!tag.getString(TABLE).equals(table.location().toString())){
   tag.putString(TABLE,table.location().toString());
   tag.putLong(NIGHT,Math.floorDiv(level.getDayTime(),24000L)-(HordeRules.night(level.getDayTime())?0:1));be.setChanged();
  }
  watch(level,be.getBlockPos());
 }
 @SubscribeEvent public static void loaded(ChunkEvent.Load e){if(e.getLevel() instanceof ServerLevel level&&e.getChunk() instanceof LevelChunk chunk){
  level.getServer().execute(()->{if(!level.hasChunkAt(chunk.getPos().getWorldPosition()))return;
   for(BlockEntity be:chunk.getBlockEntities().values())if(supported(be)&&be instanceof RandomizableContainerBlockEntity c){
    if(c.getLootTable()!=null)remember(c,c.getLootTable());else if(data(c).contains(TABLE))watch(level,c.getBlockPos());
   }
  });
 }}
 @SubscribeEvent public static void unloaded(ChunkEvent.Unload e){if(e.getLevel() instanceof ServerLevel level){var pos=e.getChunk().getPos();level.getServer().execute(()->{var set=watched.get(level);if(set!=null)set.removeIf(p->(p.getX()>>4)==pos.x&&(p.getZ()>>4)==pos.z);});}}
 @SubscribeEvent public static void stop(ServerStoppedEvent e){watched.clear();cursors.clear();}
 private static boolean emptyClosed(ServerLevel level,RandomizableContainerBlockEntity c){
  if(c.getLootTable()!=null)return false;
  if(c instanceof ChestBlockEntity){if(ChestBlockEntity.getOpenCount(level,c.getBlockPos())>0)return false;}
  if(c instanceof BarrelBlockEntity&&c.getBlockState().getValue(BarrelBlock.OPEN))return false;
  return c.isEmpty();
 }
 private static boolean eligible(ServerLevel level,RandomizableContainerBlockEntity c){
  if(!emptyClosed(level,c))return false;
  if(c instanceof ChestBlockEntity&&c.getBlockState().getValue(ChestBlock.TYPE)!=ChestType.SINGLE){
   BlockPos other=c.getBlockPos().relative(ChestBlock.getConnectedDirection(c.getBlockState()));
   if(!level.hasChunkAt(other)||!(level.getBlockEntity(other) instanceof ChestBlockEntity partner)||!emptyClosed(level,partner))return false;
  }
  return true;
 }
 public static String debug(net.minecraft.server.level.ServerPlayer player,boolean refill){
  var hit=player.pick(6.0,0.0f,false);
  if(!(hit instanceof net.minecraft.world.phys.BlockHitResult blockHit))return "Mira un cofre o barril a menos de 6 bloques.";
  ServerLevel level=player.serverLevel();
  if(!(level.getBlockEntity(blockHit.getBlockPos()) instanceof RandomizableContainerBlockEntity c)||!supported(c))return "El bloque no es un cofre o barril compatible.";
  if(c.getLootTable()!=null)remember(c,c.getLootTable());
  String table=data(c).getString(TABLE);
  if(table.isEmpty())return "Sin tabla de loot conocida. Si se abrió antes de instalar esta versión, vanilla ya borró su tabla. No se rellenará un cofre de almacenamiento.";
  if(!refill)return "Tabla: "+table+"; pendiente de abrir: "+(c.getLootTable()!=null)+"; elegible (vacío/cerrado): "+eligible(level,c)+"; última noche revisada: "+data(c).getLong(NIGHT)+"; probabilidad: "+(int)(ZomboidHordes.CONFIG.chestRestockChance*100)+"%.";
  if(!eligible(level,c))return "No se rellenó: está abierto, contiene objetos o ya tiene loot pendiente. Comprueba también la otra mitad si es doble.";
  ResourceLocation id=ResourceLocation.tryParse(table);if(id==null)return "Identificador de tabla inválido.";
  ResourceKey<LootTable> key=ResourceKey.create(Registries.LOOT_TABLE,id);
  if(level.getServer().reloadableRegistries().getLootTable(key)==LootTable.EMPTY)return "La tabla ya no existe o está vacía. Comprueba los datapacks con /datapack list.";
  c.setLootTableSeed(level.random.nextLong());c.setLootTable(key);c.setChanged();
  data(c).putLong(NIGHT,Math.floorDiv(level.getDayTime(),24000L));
  return "Prueba realizada al 100%: loot preparado con "+table+". Abre el cofre para generarlo. No se cambió el horario ni la probabilidad normal.";
 }
 @SubscribeEvent public static void tick(LevelTickEvent.Post e){
  if(!(e.getLevel() instanceof ServerLevel level)||!level.dimensionType().hasSkyLight()||level.getGameTime()%20!=0||!HordeRules.night(level.getDayTime()))return;
  var set=watched.get(level);if(set==null||set.isEmpty())return;
  var batch=cursors.computeIfAbsent(level,x->new RestockBatch<>());
  long night=Math.floorDiv(level.getDayTime(),24000L);
  for(BlockPos pos:batch.next(set,128)){
   if(!set.contains(pos))continue;
   if(!level.hasChunkAt(pos)){set.remove(pos);continue;}
   if(!(level.getBlockEntity(pos) instanceof RandomizableContainerBlockEntity c)||!supported(c)||!data(c).contains(TABLE)){set.remove(pos);continue;}
   CompoundTag tag=data(c);if(tag.getLong(NIGHT)>=night)continue;
   tag.putLong(NIGHT,night);c.setChanged();
   if(!eligible(level,c)||level.random.nextDouble()>=ZomboidHordes.CONFIG.chestRestockChance)continue;
   ResourceLocation id=ResourceLocation.tryParse(tag.getString(TABLE));if(id==null)continue;
   ResourceKey<LootTable> key=ResourceKey.create(Registries.LOOT_TABLE,id);
   if(level.getServer().reloadableRegistries().getLootTable(key)==LootTable.EMPTY)continue;
   c.setLootTableSeed(level.random.nextLong());c.setLootTable(key);c.setChanged();
  }
 }
}
