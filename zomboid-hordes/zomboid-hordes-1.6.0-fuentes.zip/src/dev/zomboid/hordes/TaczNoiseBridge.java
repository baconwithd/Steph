package dev.zomboid.hordes;
import java.lang.reflect.Method;import net.minecraft.server.level.ServerPlayer;
/** Uses SoundAttract's own muzzle/gun calculation, without shipping TACZ classes. */
public final class TaczNoiseBridge {
 private static Method shooter,gun,range;private static boolean broken;
 public static void shot(Object event){if(broken)return;try{
  if(shooter==null){shooter=event.getClass().getMethod("getShooter");gun=event.getClass().getMethod("getGunItemStack");Class<?> c=Class.forName("com.example.soundattract.integration.tacz.TaczIntegration");range=c.getDeclaredMethod("calculateShootRangeWeight",net.minecraft.world.item.ItemStack.class);range.setAccessible(true);}
  Object p=shooter.invoke(event);if(p instanceof ServerPlayer player){double[] values=(double[])range.invoke(null,gun.invoke(event));HordeEvents.recordGunShot(player,values[0]);}
 }catch(ReflectiveOperationException|LinkageError e){broken=true;System.err.println("[zomboid_hordes] TACZ shot bridge unavailable: "+e);}}
 public static void clear(){shooter=null;gun=null;range=null;broken=false;}
 private TaczNoiseBridge(){}
}
