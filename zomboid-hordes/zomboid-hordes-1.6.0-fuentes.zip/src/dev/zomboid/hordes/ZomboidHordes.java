package dev.zomboid.hordes;
import net.neoforged.fml.common.Mod;import net.neoforged.bus.api.IEventBus;import net.neoforged.neoforge.registries.*;
import net.minecraft.core.registries.Registries;import net.minecraft.resources.ResourceLocation;import net.minecraft.sounds.SoundEvent;
@Mod(ZomboidHordes.ID)
public final class ZomboidHordes {
 public static final String ID="zomboid_hordes";
 public static final DeferredRegister<SoundEvent> SOUNDS=DeferredRegister.create(Registries.SOUND_EVENT,ID);
 public static final DeferredHolder<SoundEvent,SoundEvent> HELICOPTER=SOUNDS.register("helicopter",()->SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(ID,"helicopter")));
 public static final DeferredHolder<SoundEvent,SoundEvent> HORDE=SOUNDS.register("horde",()->SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(ID,"horde")));
 public static HordeConfig CONFIG;
 public ZomboidHordes(IEventBus bus){CONFIG=HordeConfig.load();SOUNDS.register(bus);}
}
