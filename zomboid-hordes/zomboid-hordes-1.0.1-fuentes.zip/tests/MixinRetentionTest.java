import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** Regression for the user's log: MixinInfo reads @Mixin from invisible annotations. */
public final class MixinRetentionTest {
 static boolean has(List<AnnotationNode> a,String suffix){return a!=null&&a.stream().anyMatch(x->x.desc.equals("Lorg/spongepowered/asm/mixin/"+suffix+";"));}
 public static void main(String[] args)throws Exception{int classes=0,injections=0;try(ZipFile z=new ZipFile(args[0])){var it=z.entries();while(it.hasMoreElements()){var e=it.nextElement();if(!e.getName().startsWith("dev/zomboid/hordes/mixin/")||!e.getName().endsWith(".class"))continue;ClassNode n=new ClassNode();new ClassReader(z.getInputStream(e).readAllBytes()).accept(n,0);
  if(!has(n.invisibleAnnotations,"Mixin")||has(n.visibleAnnotations,"Mixin"))throw new AssertionError("Missing loader-visible CLASS-retained @Mixin: "+n.name);
  if(n.name.endsWith("CompatMixin")&&!has(n.invisibleAnnotations,"Pseudo"))throw new AssertionError("Missing optional target marker");
  for(var m:n.methods)if(m.name.startsWith("zomboid$")){if(!has(m.visibleAnnotations,"injection/Inject"))throw new AssertionError("Missing runtime @Inject "+m.name);injections++;}
  for(var f:n.fields)if(f.name.equals("goalSelector"))if(!has(f.visibleAnnotations,"Shadow")||!has(f.visibleAnnotations,"Final"))throw new AssertionError("Missing shadow metadata");
  if(n.name.endsWith("TaczNoiseCompatMixin")){var m=n.methods.stream().filter(x->x.name.equals("zomboid$recordShot")).findFirst().orElseThrow();if(m.invisibleParameterAnnotations==null||!has(m.invisibleParameterAnnotations[0],"injection/Coerce"))throw new AssertionError("Missing coercion annotation");}
  classes++;
 }}if(classes!=5||injections!=6)throw new AssertionError("Missing registered mixins");System.out.println("PASS: all 5 mixins and 6 injection annotations use the retention expected by the loader");}
}
