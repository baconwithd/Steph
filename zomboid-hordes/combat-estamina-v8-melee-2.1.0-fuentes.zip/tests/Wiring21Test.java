import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Wiring21Test {
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Wiring "+n);}
 static ClassNode cls(ZipFile z,String name)throws Exception{ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name)).readAllBytes()).accept(c,0);return c;}
 static boolean signature(ClassNode c,String name,String desc){return c.methods.stream().anyMatch(m->m.name.equals(name)&&m.desc.equals(desc));}
 static int call(ClassNode c,String name,String target){int n=0;for(var m:c.methods)if(m.name.equals(name))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals(target))n++;return n;}
 public static void main(String[] a)throws Exception{
  try(var weight=new ZipFile(a[0]);var melee=new ZipFile(a[1]);var lr=new ZipFile(a[2]);var mc=new ZipFile(a[3])){
   String w="com/armilp/ezweight/stamina/",p="dev/zomboidmelee/";
   var stamina=cls(weight,w+"StaminaCommon.class");ok(stamina.visibleAnnotations.stream().anyMatch(x->x.desc.endsWith("/EventBusSubscriber;")));ok(stamina.methods.stream().filter(m->m.name.equals("onPlayerTick")).anyMatch(m->m.visibleAnnotations!=null));ok(call(stamina,"onPlayerTick","tick")==1);ok(call(stamina,"onPlayerTick","send")==1);
   var hud=cls(weight,w+"StaminaHudOverlay.class");ok(hud.visibleAnnotations.stream().anyMatch(x->x.desc.endsWith("/EventBusSubscriber;")));ok(call(hud,"onRender","getStaminaPercent")==1);
   ok(signature(cls(mc,"net/minecraft/world/entity/LivingEntity.class"),"setSprinting","(Z)V"));ok(signature(cls(mc,"net/minecraft/world/entity/LivingEntity.class"),"jumpFromGround","()V"));ok(signature(cls(mc,"net/minecraft/world/entity/player/Player.class"),"getCurrentItemAttackStrengthDelay","()F"));
   var item=cls(lr,"me/xjqsh/lrtactical/item/MeleeItem.class");ok(signature(item,"getAttackCoolDown","(Lnet/minecraft/world/item/ItemStack;Lme/xjqsh/lrtactical/api/melee/MeleeAction;I)I"));
   ok(signature(item,"attack","(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lme/xjqsh/lrtactical/api/melee/MeleeAction;Ljava/util/List;I)V"));
   int stores=0;for(var m:item.methods)if(m.name.equals("attack"))for(var i:m.instructions.toArray())if(i.getOpcode()==Opcodes.FSTORE)stores++;ok(stores==1);
   ok(signature(cls(lr,"me/xjqsh/lrtactical/capability/CombatProperties.class"),"preAttack","(Lme/xjqsh/lrtactical/api/melee/MeleeAction;ILnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)Z"));
   var push=cls(melee,p+"combat/ShoveCombat.class");ok(call(push,"push","canSpend")==1);ok(call(push,"push","consume")==1);ok(call(push,"push","clip")==1);ok(call(push,"push","knockback")==1);ok(call(push,"stunnedDamage","setCanceled")==1);
   ok(push.methods.stream().filter(m->m.name.equals("stunnedDamage")).flatMap(m->m.visibleAnnotations.stream()).anyMatch(x->x.values!=null&&x.values.stream().anyMatch(v->v instanceof String[] a2&&java.util.Arrays.asList(a2).contains("HIGHEST"))));
   ok(call(cls(melee,p+"mixin/NativePushKeyMixin.class"),"zpush$native","cancel")==1);ok(call(cls(melee,p+"mixin/MeleeStaminaMixin.class"),"zpush$pay","consume")==1);
   ok(call(cls(melee,p+"mixin/MeleeTimingMixin.class"),"zpush$heavyDamage","damage")==1);
   ok(call(cls(melee,p+"ZomboidGlobalMelee.class"),"<init>","install")==1);
   ok(cls(melee,p+"mixin/MeleePushPoseMixin.class").methods.stream().anyMatch(m->m.name.equals("zpush$restore")));
   String config=new String(weight.getInputStream(weight.getEntry("ezweight_stamina.mixins.json")).readAllBytes());ok(config.contains("ExhaustionMixin"));
  }System.out.println("PASS: "+n+" registered stamina/HUD, exact supplied LR/Minecraft targets, one float damage local, server shove validation and combat costs");
 }
}
