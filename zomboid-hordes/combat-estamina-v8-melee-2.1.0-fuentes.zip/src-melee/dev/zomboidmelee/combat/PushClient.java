package dev.zomboidmelee.combat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import com.armilp.ezweight.stamina.*;
@EventBusSubscriber(modid="zomboid_global_melee",value=Dist.CLIENT)
public final class PushClient {
 private static int last=-100;private static net.minecraft.client.player.LocalPlayer owner;private static KeyMapping nativeKey;
 private static boolean usable(){var m=Minecraft.getInstance();return m.player!=null&&m.player.isAlive()&&!m.player.isSpectator()&&m.screen==null&&m.gameMode!=null;}
 public static KeyMapping key(){if(nativeKey==null)try{nativeKey=(KeyMapping)Class.forName("com.tacz.guns.client.input.MeleeKey").getField("MELEE_KEY").get(null);}catch(ReflectiveOperationException ignored){}return nativeKey;}
 public static boolean request(){
  if(!usable())return false;var p=Minecraft.getInstance().player;if(p!=owner){owner=p;last=-100;}
  if(p.tickCount-last<CombatRules.SHOVE_COOLDOWN||!StaminaCommon.canSpend(p,StaminaRules.SHOVE))return false;
  last=p.tickCount;PacketDistributor.sendToServer(new PushNetwork.Push());p.swing(net.minecraft.world.InteractionHand.MAIN_HAND);gunAnimation(p.getMainHandItem());return true;
 }
 public static float wave(net.minecraft.client.player.LocalPlayer p,float partial){if(p!=owner)return 0;double age=p.tickCount-last+partial;return age>0&&age<10?(float)Math.sin(age*Math.PI/10):0;}
 private static void gunAnimation(net.minecraft.world.item.ItemStack stack){
  try{Object optional=Class.forName("com.tacz.guns.api.TimelessAPI").getMethod("getGunDisplay",net.minecraft.world.item.ItemStack.class).invoke(null,stack);Object display=((java.util.Optional<?>)optional).orElse(null);if(display==null)return;Object machine=display.getClass().getMethod("getAnimationStateMachine").invoke(display);if(machine!=null)machine.getClass().getMethod("trigger",String.class).invoke(machine,"bayonet_push");}
  catch(ReflectiveOperationException|RuntimeException ignored){/* Packs without a native push animation still use the normal hand swing. */}
 }
 @SubscribeEvent(priority=EventPriority.HIGHEST) public static void pressed(InputEvent.Key e){if(e.getAction()==1&&(key()!=null?key().matches(e.getKey(),e.getScanCode()):e.getKey()==86))request();}
 @SubscribeEvent(priority=EventPriority.HIGHEST) public static void mouse(InputEvent.MouseButton.Post e){if(e.getAction()==1&&key()!=null&&key().matchesMouse(e.getButton()))request();}
}
