package dev.zomboidmelee.combat;
import java.util.*;
import com.armilp.ezweight.stamina.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.*;
import net.neoforged.neoforge.common.extensions.IEntityExtension;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="zomboid_global_melee")
public final class ShoveCombat {
 private static net.minecraft.nbt.CompoundTag data(Entity e){return ((IEntityExtension)(Object)e).getPersistentData();}
 public static boolean zombie(Entity e){if(!(e instanceof Mob))return false;if(e instanceof net.minecraft.world.entity.monster.Zombie)return true;var id=BuiltInRegistries.ENTITY_TYPE.getKey(e.getType());return id.getPath().contains("zombie")||id.getNamespace().equals("zombie_variants")||id.getNamespace().equals("mutantszombies")&&Set.of("blister_zombie","crawler","spitter","zombie_brute","split_head_zombie","mutant_brute","rotten_mutant").contains(id.getPath());}
 public static boolean stunned(Entity e){return zombie(e)&&data(e).getLong("zpush_until")>e.level().getGameTime();}
 public static boolean push(ServerPlayer p){
  if(!p.isAlive()||p.isSpectator()||p.isSleeping()||p.isPassenger())return false;
  long now=p.level().getGameTime();var t=data(p);if(t.getLong("zpush_next")>now||!StaminaCommon.canSpend(p,StaminaRules.SHOVE))return false;
  // All positions, range, obstruction and targets are calculated by the server, never supplied by the client.
  Vec3 eye=p.getEyePosition(),look=p.getLookAngle();List<LivingEntity> targets=new ArrayList<>();
  for(var e:p.serverLevel().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(3),e->e!=p&&e.isAlive()&&!e.isSpectator()&&!(e instanceof net.minecraft.world.entity.decoration.ArmorStand))){
   if(e instanceof Player other&&!p.canHarmPlayer(other))continue;
   Vec3 center=e.getBoundingBox().getCenter(),delta=center.subtract(eye);double distance=delta.length();
   var hit=p.level().clip(new net.minecraft.world.level.ClipContext(eye,center,net.minecraft.world.level.ClipContext.Block.COLLIDER,net.minecraft.world.level.ClipContext.Fluid.NONE,p));
   if(CombatRules.inCone(distance,distance<.01?1:look.dot(delta.scale(1/distance)))&&hit.getType()==HitResult.Type.MISS)targets.add(e);
  }
  if(!StaminaCommon.consume(p,StaminaRules.SHOVE))return false;t.putLong("zpush_next",now+CombatRules.SHOVE_COOLDOWN);
  targets.sort(Comparator.comparingDouble(e->e.distanceToSqr(p)));int n=0;
  for(var e:targets){if(n++>=3)break;double dx=e.getX()-p.getX(),dz=e.getZ()-p.getZ();if(dx*dx+dz*dz<.001){dx=look.x;dz=look.z;}e.knockback(.85,-dx,-dz);e.hurtMarked=true;
   if(zombie(e)){data(e).putLong("zpush_until",now+CombatRules.STUN);((Mob)e).getNavigation().stop();}
  }
  p.swing(net.minecraft.world.InteractionHand.MAIN_HAND,true);
  p.level().playSound(null,p.blockPosition(),net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP,net.minecraft.sounds.SoundSource.PLAYERS,.5f,.85f);
  return true;
 }
 @SubscribeEvent(priority=net.neoforged.bus.api.EventPriority.HIGHEST) public static void stunnedDamage(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent e){if(e.getEntity() instanceof Player&&e.getSource().getEntity()!=null&&stunned(e.getSource().getEntity()))e.setCanceled(true);}
 @SubscribeEvent public static void stunnedTick(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){if(e.getEntity() instanceof Mob z&&!z.level().isClientSide()&&stunned(z))z.getNavigation().stop();}
}
