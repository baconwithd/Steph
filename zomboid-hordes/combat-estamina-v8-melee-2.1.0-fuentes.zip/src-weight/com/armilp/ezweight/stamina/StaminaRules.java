package com.armilp.ezweight.stamina;
public final class StaminaRules {
 public static final double MAX=3000,UNLOCK=600,NORMAL=60,HEAVY=120,SHOVE=45,JUMP=25;
 public static final int REST=40;
 public record State(double energy,boolean locked,int delay){}
 public static State spend(State s,double amount){double v=Math.max(0,s.energy-amount);return new State(v,s.locked||v<=0,REST);}
 public static State tick(State s,boolean sprint,boolean airborne,boolean moving){
  double v=s.energy;boolean locked=s.locked;int delay=s.delay;
  if(v<=0&&!locked){locked=true;delay=REST;}
  if(sprint&&!locked&&v>0){v-=1+(airborne?.25:0);delay=REST;}else if(delay>0)delay--;else v+=moving?2.5:5;
  v=Math.max(0,Math.min(MAX,v));if(v<=0){locked=true;if(s.energy>0)delay=REST;}if(locked&&v>=UNLOCK)locked=false;
  return new State(v,locked,delay);
 }
 public static boolean canSpend(State s,double amount){return !s.locked&&Double.isFinite(amount)&&amount>=0&&s.energy>=amount;}
}
