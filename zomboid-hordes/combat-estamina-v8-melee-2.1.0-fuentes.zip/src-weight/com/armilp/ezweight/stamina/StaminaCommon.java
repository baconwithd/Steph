package com.armilp.ezweight.stamina;
import java.util.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.extensions.IEntityExtension;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
@EventBusSubscriber(modid="ezweight")
public final class StaminaCommon {
 public static final double MAX_STAMINA=StaminaRules.MAX;
 private record Snapshot(StaminaRules.State state,long tick){}
 private static final Map<UUID,Snapshot> CLIENT=new HashMap<>();
 private static net.minecraft.nbt.CompoundTag data(Player p){return ((IEntityExtension)(Object)p).getPersistentData();}
 private static boolean free(Player p){return p==null||p.isCreative()||p.isSpectator();}
 private static StaminaRules.State state(Player p){
  if(p.level().isClientSide()){var c=CLIENT.get(p.getUUID());return c==null?new StaminaRules.State(MAX_STAMINA,false,0):c.state;}
  var t=data(p);double energy=t.contains("ezs_energy")?t.getDouble("ezs_energy"):MAX_STAMINA;if(!Double.isFinite(energy))energy=MAX_STAMINA;
  return new StaminaRules.State(Math.max(0,Math.min(MAX_STAMINA,energy)),t.getBoolean("ezs_locked")||energy<=0,t.getInt("ezs_delay"));
 }
 private static void put(Player p,StaminaRules.State s){if(p.level().isClientSide()){var old=CLIENT.get(p.getUUID());CLIENT.put(p.getUUID(),new Snapshot(s,old==null?Long.MIN_VALUE:old.tick));return;}var t=data(p);t.putDouble("ezs_energy",s.energy());t.putBoolean("ezs_locked",s.locked());t.putInt("ezs_delay",s.delay());}
 public static boolean exhausted(Player p){return !free(p)&&state(p).locked();}
 public static boolean canSpend(Player p,double amount){return free(p)||StaminaRules.canSpend(state(p),amount);}
 public static boolean consume(Player p,double amount){if(free(p))return true;if(!canSpend(p,amount))return false;put(p,StaminaRules.spend(state(p),amount));if(exhausted(p))p.setSprinting(false);if(p instanceof ServerPlayer sp)StaminaNetwork.send(sp);return true;}
 public static double getStaminaPercent(Player p){return free(p)?1:Math.max(0,Math.min(1,state(p).energy()/MAX_STAMINA));}
 public static void accept(UUID id,double energy,boolean locked,int delay,long tick){var old=CLIENT.get(id);if(old!=null&&tick<old.tick)return;CLIENT.put(id,new Snapshot(new StaminaRules.State(Math.max(0,Math.min(MAX_STAMINA,energy)),locked,delay),tick));}
 public static void clearClient(){CLIENT.clear();}
 @SubscribeEvent public static void onPlayerTick(PlayerTickEvent.Post e){
  Player p=e.getEntity();if(free(p)||!p.isAlive())return;
  if(p.level().isClientSide()){if(exhausted(p)){p.setSprinting(false);p.setJumping(false);}return;}
  var t=data(p);double dx=p.getX()-t.getDouble("ezs_prev_x"),dz=p.getZ()-t.getDouble("ezs_prev_z");boolean moving=t.contains("ezs_prev_x")&&dx*dx+dz*dz>.0025&&dx*dx+dz*dz<4;
  t.putDouble("ezs_prev_x",p.getX());t.putDouble("ezs_prev_z",p.getZ());
  var old=state(p);boolean draining=p.isSprinting()&&moving&&!p.isPassenger()&&!p.getAbilities().flying;
  var updated=StaminaRules.tick(old,draining,!p.onGround(),moving);put(p,updated);
  if(updated.locked()){p.setSprinting(false);p.setJumping(false);}
  if(p instanceof ServerPlayer sp&&(p.tickCount%5==0||old.locked()!=updated.locked()))StaminaNetwork.send(sp);
 }
 @SubscribeEvent public static void respawn(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerRespawnEvent e){if(!e.isEndConquered()){put(e.getEntity(),new StaminaRules.State(MAX_STAMINA,false,0));if(e.getEntity() instanceof ServerPlayer sp)StaminaNetwork.send(sp);}}
 @SubscribeEvent public static void logout(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent e){CLIENT.remove(e.getEntity().getUUID());}
}
