package com.armilp.ezweight.stamina.mixin;
import com.armilp.ezweight.stamina.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntity.class)
public abstract class ExhaustionMixin {
 @Inject(method="setSprinting(Z)V",at=@At("HEAD"),cancellable=true)
 private void ezs$sprint(boolean sprint,CallbackInfo ci){if(sprint&&(Object)this instanceof Player p&&StaminaCommon.exhausted(p)){p.setSprinting(false);ci.cancel();}}
 @Inject(method="jumpFromGround()V",at=@At("HEAD"),cancellable=true)
 private void ezs$jump(CallbackInfo ci){if((Object)this instanceof Player p&&!StaminaCommon.consume(p,StaminaRules.JUMP)){p.setJumping(false);ci.cancel();}}
}
