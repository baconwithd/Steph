package com.armilp.ezweight.stamina;

import com.armilp.ezweight.stamina.StaminaCommon;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

@net.neoforged.fml.common.EventBusSubscriber(modid="ezweight",value=net.neoforged.api.distmarker.Dist.CLIENT)
public class StaminaHudOverlay {
    private static final ResourceLocation ICON = ResourceLocation.fromNamespaceAndPath((String)"ezweight", (String)"textures/gui/stamina_icon.png");
    private static final int ICON_SIZE = 9;
    private static final int ICON_STEP = 8;

    @net.neoforged.bus.api.SubscribeEvent
    public static void onRender(RenderGuiEvent.Post post) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft == null || minecraft.player == null || minecraft.options != null && minecraft.options.hideGui) {
            return;
        }
        GuiGraphics guiGraphics = post.getGuiGraphics();
        if (guiGraphics == null) {
            return;
        }
        double d = StaminaCommon.getStaminaPercent((Player)minecraft.player);
        int n = (int)Math.ceil(d * 10.0);
        int n2 = guiGraphics.guiWidth() / 2 + 108;
        int n3 = guiGraphics.guiHeight() - 84;
        RenderSystem.setShaderTexture((int)0, (ResourceLocation)ICON);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        for (int i = 0; i < 10; ++i) {
            int n4 = n3 + i * 8;
            if (i < n) {
                if(StaminaCommon.exhausted((Player)minecraft.player))RenderSystem.setShaderColor(1.0f,.25f,.25f,1.0f);else RenderSystem.setShaderColor(1.0f,1.0f,1.0f,1.0f);
            } else {
                RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)0.22f);
            }
            guiGraphics.blit(ICON, n2, n4, 0.0f, 0.0f, 9, 9, 9, 9);
        }
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }
    @net.neoforged.bus.api.SubscribeEvent
    public static void disconnected(net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut e){StaminaCommon.clearClient();}
}


