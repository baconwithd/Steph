package com.armilp.ezweight.stamina;
import java.util.UUID;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="ezweight",bus=EventBusSubscriber.Bus.MOD)
public final class StaminaNetwork {
 public record Update(UUID player,double energy,boolean locked,int delay,long tick) implements CustomPacketPayload {
  public static final Type<Update> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("ezweight","stamina_v8"));
  public static final StreamCodec<RegistryFriendlyByteBuf,Update> CODEC=StreamCodec.of((b,p)->{b.writeUUID(p.player);b.writeDouble(p.energy);b.writeBoolean(p.locked);b.writeVarInt(p.delay);b.writeLong(p.tick);},b->new Update(b.readUUID(),b.readDouble(),b.readBoolean(),b.readVarInt(),b.readLong()));
  public Type<? extends CustomPacketPayload> type(){return TYPE;}
 }
 @SubscribeEvent public static void register(RegisterPayloadHandlersEvent e){e.registrar("8").playToClient(Update.TYPE,Update.CODEC,(p,c)->c.enqueueWork(()->StaminaCommon.accept(p.player,p.energy,p.locked,p.delay,p.tick)));}
 public static void send(ServerPlayer p){var t=((net.neoforged.neoforge.common.extensions.IEntityExtension)(Object)p).getPersistentData();PacketDistributor.sendToPlayer(p,new Update(p.getUUID(),t.contains("ezs_energy")?t.getDouble("ezs_energy"):StaminaRules.MAX,t.getBoolean("ezs_locked"),t.getInt("ezs_delay"),p.level().getGameTime()));}
}
