package dev.zomboid.remains;
public final class BanditSettings{
 public boolean enabled=true,softMode=false;
 public int spawnIntervalTicks=600;
 public double spawnChance=.25;
 public int minimumSpawnDistance=32,maximumSpawnDistance=64;
 public int alertRadius=32,memoryTicks=400;
 public double zombieFractureChance=.03,banditFractureChance=.80;
 public String[] materials={"fracturepoint:raw_fiber","fracturepoint:resin","fracturepoint:steel_blend","fracturepoint:steel_plate","fracturepoint:kevlar_fiber","fracturepoint:woven_kevlar"};
 public void validate(){
  if(spawnIntervalTicks<100||minimumSpawnDistance<24||maximumSpawnDistance<minimumSpawnDistance||maximumSpawnDistance>96||alertRadius<8||alertRadius>64||memoryTicks<40)throw new IllegalArgumentException("Invalid bandit distance/timing settings");
  for(double chance:new double[]{spawnChance,zombieFractureChance,banditFractureChance})if(!Double.isFinite(chance)||chance<0||chance>1)throw new IllegalArgumentException("Bandit probabilities must be between 0 and 1");
  if(materials==null)throw new IllegalArgumentException("Bandit materials cannot be null");
 }
}
