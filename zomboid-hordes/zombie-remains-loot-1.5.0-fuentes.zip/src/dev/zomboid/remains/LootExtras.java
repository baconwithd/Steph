package dev.zomboid.remains;
import java.util.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.*;
public final class LootExtras {
 static void priority(ZombieRemainsLoot.Corpse c,ItemStack item){
  if(item.isEmpty())return;
  for(int i=0;i<c.inventory.getContainerSize();i++)if(c.inventory.getItem(i).isEmpty()){ZombieRemainsLoot.add(c,item);return;}
  // Full high-quality inventories reserve room by replacing a low-value utility item.
  for(int i=0;i<c.inventory.getContainerSize();i++){ItemStack old=c.inventory.getItem(i);String path=BuiltInRegistries.ITEM.getKey(old.getItem()).getPath();
   if(!(old.getItem() instanceof ArmorItem)&&!(old.getItem() instanceof TieredItem)&&!path.contains("backpack")&&!path.equals("ammo")&&GunAccess.describe(old)==null){c.inventory.setItem(i,item);return;}
  }
 }
 static void populate(ZombieRemainsLoot.Corpse c,ServerLevel level,boolean bandit,boolean mutant,Mob mob){
  int q=QualityRules.clamp(c.quality);
  for(int i=0;i<c.inventory.getContainerSize();i++){var id=BuiltInRegistries.ITEM.getKey(c.inventory.getItem(i).getItem());if(id.getNamespace().equals("tacz")&&id.getPath().equals("ammo"))c.inventory.setItem(i,ItemStack.EMPTY);}
  if(level.random.nextDouble()<ExtraLootRules.backpackChance(q,bandit,mutant)){ItemStack bag=ZombieRemainsLoot.stack(ExtraLootRules.backpack(q),1);if(bag.isEmpty())bag=ZombieRemainsLoot.stack("sophisticatedbackpacks:backpack",1);priority(c,bag);}
  if(level.random.nextDouble()<ExtraLootRules.militaryChance(q,bandit,mutant)){
   List<ItemStack> armor=new ArrayList<>();for(Item item:BuiltInRegistries.ITEM){var id=BuiltInRegistries.ITEM.getKey(item);if(id.getNamespace().equals("fracturepoint")&&item instanceof ArmorItem)armor.add(new ItemStack(item));}
   if(!armor.isEmpty()){ItemStack gear=armor.get(level.random.nextInt(armor.size()));if(gear.isDamageableItem())gear.setDamageValue((int)(gear.getMaxDamage()*(q>=3?.05:.25+level.random.nextDouble()*.35)));priority(c,gear);}
  }
  // Select one caliber once per corpse, after all mutant/bandit rolls; never exceed two stacks.
  try{
   GunAccess.Profile gun=bandit?GunAccess.describe(mob.getMainHandItem()):null;
   if(gun==null)for(int i=0;i<c.inventory.getContainerSize();i++){gun=GunAccess.describe(c.inventory.getItem(i));if(gun!=null)break;}
   if(gun==null)gun=GunAccess.choose(QualityRules.gunTier(q),level.random);
   if(gun!=null){int min=ExtraLootRules.ammoMin(q),max=ExtraLootRules.ammoMax(q);ZombieRemainsLoot.addAmmo(c,gun.ammo(),min+level.random.nextInt(max-min+1));}
  }catch(ReflectiveOperationException|RuntimeException error){/* Optional gun packs may not have loaded any valid gun/ammunition indexes. */}
 }
}
