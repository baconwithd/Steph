package dev.zomboid.remains;
public final class QualityRules {
 public static int roll(double r,boolean bandit){double[] limits=bandit?new double[]{.25,.60,.85,.97}:new double[]{.55,.80,.94,.99};for(int i=0;i<4;i++)if(r<limits[i])return i;return 4;}
 public static int clamp(int q){return Math.max(0,Math.min(4,q));}
 public static String name(int q){return new String[]{"común","poco común","raro","épico","legendario"}[clamp(q)];}
 public static int gunTier(int q){return Math.min(3,clamp(q));}
 public static double gunChance(int q){return new double[]{.12,.25,.45,.70,1.0}[clamp(q)];}
 public static String[] minerals(int q){return switch(clamp(q)){case 0->new String[]{"minecraft:coal","minecraft:raw_copper"};case 1->new String[]{"minecraft:iron_ingot","minecraft:lapis_lazuli"};case 2->new String[]{"minecraft:gold_ingot","minecraft:redstone","minecraft:diamond"};case 3->new String[]{"minecraft:diamond","minecraft:emerald","minecraft:ancient_debris"};default->new String[]{"minecraft:diamond","minecraft:netherite_scrap","minecraft:netherite_ingot"};};}
}
