package dev.zomboid.remains;
import java.lang.reflect.*;
import java.util.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.slf4j.LoggerFactory;
@EventBusSubscriber(modid=ZombieRemainsLoot.ID)
public final class CorpseIntegration {
 private static boolean warned;
 private static boolean corpse(Entity target){return target.getClass().getName().equals("de.maxhenkel.corpse.entities.CorpseEntity");}
 static Object call(Object target,String method)throws ReflectiveOperationException{return target.getClass().getMethod(method).invoke(target);}
 static Object config(String name)throws ReflectiveOperationException{
  Object serverConfig=Class.forName("de.maxhenkel.corpse.Main").getField("SERVER_CONFIG").get(null);
  Object value=serverConfig.getClass().getField(name).get(serverConfig);
  return value.getClass().getMethod("get").invoke(value);
 }
 static boolean allowed(Entity target,Player player)throws ReflectiveOperationException{
  if(!player.mayBuild()||player.distanceToSqr(target)>36)return false;
  if(!Boolean.TRUE.equals(config("onlyOwnerAccess")))return true;
  if(player instanceof ServerPlayer serverPlayer&&player.hasPermissions(serverPlayer.server.getOperatorUserPermissionLevel()))return true;
  Optional<?> owner=(Optional<?>)call(target,"getCorpseUUID");
  return owner.isEmpty()||owner.get().equals(player.getUUID())||Boolean.TRUE.equals(config("skeletonAccess"))&&Boolean.TRUE.equals(call(target,"isSkeleton"));
 }
 static boolean action(Entity target,Player player,InteractionHand hand,boolean attack){
  if(!corpse(target)||target.isRemoved()||hand!=InteractionHand.MAIN_HAND)return false;
  try{
   boolean bones=Boolean.TRUE.equals(call(target,"isSkeleton"));
   boolean blade=!attack&&ZombieRemainsLoot.blade(player.getItemInHand(hand));
   if(!attack&&!bones&&!blade)return false;
   if(!(target.level() instanceof ServerLevel level))return true;
   if(!allowed(target,player))return true;
   ZombieRemainsLoot.CorpseData store=ZombieRemainsLoot.data(level);
   Skin progress=store.entityCuts.computeIfAbsent(target.getUUID(),id->new Skin());
   if(bones){
    closeMenus(level,target);
    ZombieRemainsLoot.spit(level,target.getX(),target.getY()+.2,target.getZ(),new ItemStack(Items.BONE,2+level.random.nextInt(3)));
    store.entityCuts.remove(target.getUUID());store.setDirty();
    // CorpseEntity.remove natively drops its inventory. Do not drop its items again.
    target.discard();return true;
   }
   if(!blade){
    closeMenus(level,target);
    ItemStack flesh=ZombieRemainsLoot.stack(ZombieRemainsLoot.settings.freshMeatItem,1+level.random.nextInt(2));
    if(flesh.isEmpty())flesh=new ItemStack(Items.ROTTEN_FLESH);
    ZombieRemainsLoot.spit(level,target.getX(),target.getY()+.2,target.getZ(),flesh);
    store.entityCuts.remove(target.getUUID());store.setDirty();target.discard();return true;
   }
   if(!RemainsRules.harvestReady(progress.lastHarvest,level.getGameTime()))return true;
   // Verify the conversion API before producing loot, so an incompatible Corpse version cannot give infinite meat.
   Field age=target.getClass().getDeclaredField("age");age.setAccessible(true);
   Field emptyAge=target.getClass().getDeclaredField("emptyAge");emptyAge.setAccessible(true);
   Method setSkeleton=target.getClass().getMethod("setIsSkeleton",boolean.class);
   int skeletonTime=((Number)config("corpseSkeletonTime")).intValue();
   if(progress.cuts>=ZombieRemainsLoot.settings.skinningCuts){
    age.setInt(target,Math.max(age.getInt(target),skeletonTime));emptyAge.setInt(target,-1);setSkeleton.invoke(target,true);return true;
   }
   progress.lastHarvest=level.getGameTime();progress.cuts++;store.setDirty();
   ItemStack flesh=ZombieRemainsLoot.stack(ZombieRemainsLoot.settings.freshMeatItem,1);
   if(flesh.isEmpty())flesh=new ItemStack(Items.ROTTEN_FLESH);
   ZombieRemainsLoot.spit(level,target.getX(),target.getY()+.2,target.getZ(),flesh);
   if(progress.cuts>=ZombieRemainsLoot.settings.skinningCuts){
    age.setInt(target,Math.max(age.getInt(target),skeletonTime));emptyAge.setInt(target,-1);setSkeleton.invoke(target,true);
   }else{
    // Strip only the displayed armor. The player's actual inventory remains in Death for the eventual drop.
    applyDisplay(target,progress.cuts);
   }
   store.setDirty();
   player.displayClientMessage(Component.literal("Despellejado: "+progress.cuts+"/"+ZombieRemainsLoot.settings.skinningCuts),true);
   if(!player.isCreative())player.getMainHandItem().hurtAndBreak(1,player,EquipmentSlot.MAINHAND);
   return true;
  }catch(ReflectiveOperationException|RuntimeException error){
   if(!warned){warned=true;LoggerFactory.getLogger(ZombieRemainsLoot.ID).error("Corpse skinning integration unavailable",error);}
   return false;
  }
 }
 static void applyDisplay(Entity target,int cuts)throws ReflectiveOperationException{
  @SuppressWarnings("unchecked") NonNullList<ItemStack> current=(NonNullList<ItemStack>)call(target,"getEquipment");
  NonNullList<ItemStack> display=NonNullList.withSize(current.size(),ItemStack.EMPTY);
  for(int i=0;i<current.size();i++)display.set(i,current.get(i).copy());
  for(EquipmentSlot slot:new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST}){
   if(slot.ordinal()<display.size()&&(cuts>=2||slot==EquipmentSlot.HEAD))display.set(slot.ordinal(),ItemStack.EMPTY);
  }
  target.getClass().getMethod("setEquipment",NonNullList.class).invoke(target,display);
 }
 @SubscribeEvent
 public static void join(EntityJoinLevelEvent event){
  Entity target=event.getEntity();
  if(!corpse(target)||!(event.getLevel() instanceof ServerLevel level))return;
  ZombieRemainsLoot.CorpseData store=ZombieRemainsLoot.data(level);
  Skin skin=store.entityCuts.computeIfAbsent(target.getUUID(),id->new Skin());
  if(!skin.randomized)try{
   Object death=call(target,"getDeath");
   for(String pool:new String[]{"getMainInventory","getAdditionalItems"}){
    @SuppressWarnings("unchecked") java.util.List<ItemStack> items=(java.util.List<ItemStack>)call(death,pool);java.util.Collections.shuffle(items);
   }
   skin.randomized=true;store.setDirty();
  }catch(ReflectiveOperationException|RuntimeException error){LoggerFactory.getLogger(ZombieRemainsLoot.ID).warn("Cannot shuffle Corpse inventory",error);}
  if(skin==null||skin.cuts<=0)return;
  try{
   if(skin.cuts>=ZombieRemainsLoot.settings.skinningCuts){
    target.getClass().getMethod("setIsSkeleton",boolean.class).invoke(target,true);
   }else applyDisplay(target,skin.cuts);
  }catch(ReflectiveOperationException error){LoggerFactory.getLogger(ZombieRemainsLoot.ID).warn("Cannot restore corpse skinning display",error);}
 }
 @SubscribeEvent
 public static void leave(EntityLeaveLevelEvent event){
  Entity target=event.getEntity();
  if(!corpse(target)||!(event.getLevel() instanceof ServerLevel level))return;
  Entity.RemovalReason reason=target.getRemovalReason();
  if(reason==Entity.RemovalReason.DISCARDED||reason==Entity.RemovalReason.KILLED){
   ZombieRemainsLoot.CorpseData store=ZombieRemainsLoot.data(level);if(store.entityCuts.remove(target.getUUID())!=null)store.setDirty();
  }
 }
 static void closeMenus(ServerLevel level,Entity corpse){
  for(ServerPlayer player:level.players()){
   try{if(player.containerMenu.getClass().getMethod("getCorpse").invoke(player.containerMenu)==corpse)player.closeContainer();}
   catch(ReflectiveOperationException ignored){}
  }
 }
 @SubscribeEvent(priority=EventPriority.HIGHEST)
 public static void interact(PlayerInteractEvent.EntityInteract event){
  if(action(event.getTarget(),event.getEntity(),event.getHand(),false)){event.setCanceled(true);event.setCancellationResult(InteractionResult.SUCCESS);}
 }
 @SubscribeEvent(priority=EventPriority.HIGHEST)
 public static void interactSpecific(PlayerInteractEvent.EntityInteractSpecific event){
  if(action(event.getTarget(),event.getEntity(),event.getHand(),false)){event.setCanceled(true);event.setCancellationResult(InteractionResult.SUCCESS);}
 }
 @SubscribeEvent(priority=EventPriority.HIGHEST)
 public static void attack(AttackEntityEvent event){
  if(action(event.getTarget(),event.getEntity(),InteractionHand.MAIN_HAND,true))event.setCanceled(true);
 }
 static final class Skin {boolean randomized;int cuts;long lastHarvest=-1;}
}
