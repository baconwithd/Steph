package dev.zomboid.remains;
import java.util.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.*;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
@EventBusSubscriber(modid=ZombieRemainsLoot.ID)
public final class MutantIntegration {
 private static final ResourceLocation HEALTH=ResourceLocation.fromNamespaceAndPath(ZombieRemainsLoot.ID,"mutant_health"),DAMAGE=ResourceLocation.fromNamespaceAndPath(ZombieRemainsLoot.ID,"mutant_damage");
 private static final Map<Entity,Footstep> steps=new WeakHashMap<>();
 public static boolean mutant(Entity e){var id=BuiltInRegistries.ENTITY_TYPE.getKey(e.getType());return MutantRules.supported(id.getNamespace(),id.getPath());}
 @SubscribeEvent public static void join(EntityJoinLevelEvent e){if(e.getLevel().isClientSide()||!(e.getEntity() instanceof LivingEntity mob)||!mutant(mob))return;
  var hp=mob.getAttribute(Attributes.MAX_HEALTH);if(hp!=null&&!hp.hasModifier(HEALTH)){float ratio=mob.getHealth()/Math.max(1f,mob.getMaxHealth());hp.addPermanentModifier(new AttributeModifier(HEALTH,1.0,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));mob.setHealth(mob.getMaxHealth()*ratio);}
  var damage=mob.getAttribute(Attributes.ATTACK_DAMAGE);if(damage!=null&&!damage.hasModifier(DAMAGE))damage.addPermanentModifier(new AttributeModifier(DAMAGE,.35,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
 }
 @SubscribeEvent public static void projectile(LivingIncomingDamageEvent e){Entity attacker=e.getSource().getEntity();if(e.getEntity().level().isClientSide()||attacker==null||!mutant(attacker)||e.getAmount()<=0)return;
  // Melee already uses the enhanced attack attribute; ranged attacks need a separate multiplier.
  if(e.getSource().getDirectEntity()!=attacker)e.setAmount(e.getAmount()*1.35f);
 }
 @SubscribeEvent public static void tick(EntityTickEvent.Post e){Entity mob=e.getEntity();if(!(mob.level() instanceof ServerLevel level)||!mob.isAlive()||!mutant(mob))return;
  Footstep s=steps.get(mob);if(s==null){steps.put(mob,new Footstep(mob.getX(),mob.getZ()));return;}
  double dx=mob.getX()-s.x,dz=mob.getZ()-s.z,d=Math.sqrt(dx*dx+dz*dz);s.x=mob.getX();s.z=mob.getZ();
  if(!mob.onGround()||mob.isPassenger()||mob.isInWater()||d>2){s.distance=0;return;}
  if(d<.005)return;s.distance+=d;
  boolean big=MutantRules.large(BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType()).getPath());
  if(s.distance>=(big?1.0:.7)&&level.getGameTime()-s.last>=6){s.distance=0;s.last=level.getGameTime();
   level.playSound(null,mob.getX(),mob.getY(),mob.getZ(),SoundEvents.IRON_GOLEM_STEP,SoundSource.HOSTILE,big?2.2f:1.6f,big?.60f:.75f);
  }
 }
 @SubscribeEvent public static void stop(ServerStoppedEvent e){steps.clear();}
 private static final class Footstep {double x,z,distance;long last;Footstep(double x,double z){this.x=x;this.z=z;}}
}
