package dev.zomboid.remains;
/** Pure rules shared by placement, migrations, and tests. */
public final class RemainsRules {
 public static final int[] FLOOR={2,3,5,9};
 public static final int[] WALL={1,4,8};
 public static boolean floor(int family){for(int value:FLOOR)if(value==family)return true;return false;}
 public static boolean wall(int family){for(int value:WALL)if(value==family)return true;return false;}
 public static int family(String block){
  if(!block.startsWith("doomsday_decoration:remains_"))return -1;
  String digits=block.substring(block.lastIndexOf('_')+1);
  for(int f=1;f<=10;f++)for(int n=1;n<=3;n++)if(digits.equals(Integer.toString(f).repeat(n)))return f;
  return -1;
 }
 public static String variant(int family,int cuts){return "doomsday_decoration:remains_"+Integer.toString(family).repeat(Math.min(3,Math.max(1,cuts+1)));}
 public static boolean decayed(long born,long now,long ticks){return born>=0&&now>=born&&now-born>=ticks;}
 public static boolean harvestReady(long last,long now){return last<0||now>=last&&now-last>=10;}
 public static boolean bladeName(String id){
  String name=id.toLowerCase(java.util.Locale.ROOT);
  for(String part:new String[]{"sword","knife","cuchillo","dagger","karambit","machete","kukri","blade","cleaver","bayonet"})if(name.contains(part))return true;
  return false;
 }
}
