package dev.zomboid.remains;
import net.minecraft.server.level.ServerLevel;import net.minecraft.world.item.ItemStack;
public final class QualityLoot {
 static void populate(ZombieRemainsLoot.Corpse c,ServerLevel level,boolean bandit){
  int q=QualityRules.clamp(c.quality);var s=ZombieRemainsLoot.settings;
  // Guaranteed category rolls; missing optional items fall back to vanilla.
  for(int i=0;i<2+q;i++)ZombieRemainsLoot.pick(c,level,s.utility,1+level.random.nextInt(3),false);
  String[] clothes=q==0?new String[]{"selfexpression:brown_shirt_chestplate","selfexpression:simple_chestplate","minecraft:leather_chestplate","minecraft:leather_boots"}:q<3?s.clothing:q==4?new String[]{"selfexpression:survivors_armor_chestplate","selfexpression:zombie_survivor_chestplate","selfexpression:stalker_leggings","minecraft:netherite_chestplate","minecraft:netherite_leggings","minecraft:netherite_boots"}:new String[]{"selfexpression:survivors_armor_chestplate","selfexpression:zombie_survivor_chestplate","selfexpression:stalker_leggings","minecraft:diamond_chestplate","minecraft:diamond_boots"};
  for(int i=0;i<1+q/2;i++)pick(c,level,clothes,q,true);
  for(int i=0;i<1+q/2;i++)pick(c,level,q>=3?s.rareMedical:s.medical,q,false);
  pick(c,level,q==0?new String[]{"minecraft:stone_sword","minecraft:stone_axe","lrtactical:baseball_bat"}:q<3?ZombieRemainsLoot.meleePool():q==4?new String[]{"minecraft:netherite_sword","minecraft:netherite_axe"}:new String[]{"minecraft:diamond_sword","minecraft:diamond_axe"},q,true);
  ZombieRemainsLoot.pick(c,level,QualityRules.minerals(q),q==4?1:2+level.random.nextInt(4),false);
  if(q>=3)ZombieRemainsLoot.pick(c,level,QualityRules.minerals(q),1,false);
  if((!bandit&&level.random.nextDouble()<QualityRules.gunChance(q))||(bandit&&q>=3&&level.random.nextDouble()<.65)){
   try{GunAccess.Profile gun=GunAccess.choose(QualityRules.gunTier(q),level.random);if(gun!=null){ZombieRemainsLoot.add(c,GunAccess.create(gun,0));}}
   catch(ReflectiveOperationException|RuntimeException ignored){/* Missing gun pack never blocks other loot. */}
  }
  if(level.random.nextDouble()<(bandit?.8:.10+q*.12))ZombieRemainsLoot.pick(c,level,s.bandits.materials,1+q/2,false);
 }
 static void pick(ZombieRemainsLoot.Corpse c,ServerLevel level,String[] ids,int q,boolean worn){
  java.util.List<ItemStack> choices=new java.util.ArrayList<>();for(String id:ids){ItemStack item=ZombieRemainsLoot.stack(id,1);if(!item.isEmpty())choices.add(item);}
  ItemStack item=choices.isEmpty()?ZombieRemainsLoot.stack(worn?"minecraft:leather_boots":q>=3?"minecraft:golden_apple":"minecraft:bread",1):choices.get(level.random.nextInt(choices.size()));
  if(worn&&item.isDamageableItem())item.setDamageValue((int)(item.getMaxDamage()*(q==0?.70+level.random.nextDouble()*.20:q>=3?level.random.nextDouble()*.15:.20+level.random.nextDouble()*.35)));
  ZombieRemainsLoot.add(c,item);
 }
}
