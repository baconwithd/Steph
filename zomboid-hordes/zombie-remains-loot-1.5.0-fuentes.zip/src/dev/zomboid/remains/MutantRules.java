package dev.zomboid.remains;
import java.util.Set;
public final class MutantRules {
 private static final Set<String> TYPES=Set.of("blister_zombie","crawler","spitter","zombie_brute","split_head_zombie","mutant_brute","rotten_mutant");
 public static boolean supported(String namespace,String path){return namespace.equals("mutantszombies")&&TYPES.contains(path);}
 public static int quality(double r){return r<.10?0:r<.30?1:r<.65?2:r<.90?3:4;}
 public static boolean large(String path){return path.equals("mutant_brute")||path.equals("zombie_brute")||path.equals("spitter");}
}
