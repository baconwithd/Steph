package dev.zomboid.remains;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
public final class SkeletonRemains {
 private static final DeferredRegister<Block> BLOCKS=DeferredRegister.create(Registries.BLOCK,ZombieRemainsLoot.ID);
 public static final DeferredHolder<Block,Block> BONES=BLOCKS.register("skeletal_remains",()->new Block(BlockBehaviour.Properties.of().strength(.4f).sound(SoundType.BONE_BLOCK).noOcclusion().noCollission()){
  @Override public VoxelShape getShape(BlockState state,BlockGetter level,BlockPos pos,CollisionContext context){return Block.box(0,0,0,16,6,16);}
 });
 public static void register(IEventBus bus){BLOCKS.register(bus);}
}
