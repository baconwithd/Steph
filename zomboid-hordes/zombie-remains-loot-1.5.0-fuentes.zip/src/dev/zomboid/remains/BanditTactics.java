package dev.zomboid.remains;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
public final class BanditTactics extends Goal{
 private final Mob mob;private final ServerLevel level;
 private int attackDelay,seenTicks;private long nextPath,nextCover;private UUID previousTarget;
 private BlockPos peek;
 private int pressureIndex=20,firstHit,secondHit;
 public BanditTactics(Mob mob){this.mob=mob;this.level=(ServerLevel)mob.level();setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK,Flag.TARGET));}
 @Override public boolean canUse(){return mob.isAlive();}
 @Override public boolean requiresUpdateEveryTick(){return true;}
 @Override public void stop(){mob.getNavigation().stop();mob.setTarget(null);mob.setAggressive(false);}
 @Override public void tick(){
  long now=level.getGameTime();BanditDirector.State state=BanditDirector.state(mob);
  if(now%200==Math.floorMod(mob.getId(),200)){
   int tier=BanditDirector.localTier(level,mob.position());
   if(tier>state.tier&&mob.getTarget()==null)try{BanditDirector.equip(mob,Math.min(tier,state.tier+1));}catch(Exception e){BanditDirector.problem(e);}
  }
  if(now%10==Math.floorMod(mob.getId(),10))acquire(state,now);
  LivingEntity target=mob.getTarget();
  if(target==null||!target.isAlive()||target instanceof Player p&&(p.isCreative()||p.isSpectator())){
   mob.setTarget(null);mob.setAggressive(false);seenTicks=0;
   if(now>=nextPath){nextPath=now+80;
    if(state.lastKnown!=null&&state.guardUntil>now)move(state.lastKnown,1.0);
    else{
     // Patrol in a loose formation instead of stacking allies at one point.
     double a=mob.getRandom().nextDouble()*Math.PI*2;
     Mob leader=BanditDirector.nearby(mob,32).stream().filter(e->BanditDirector.state(e).group.equals(state.group)).min(Comparator.comparingInt(e->BanditDirector.state(e).role)).orElse(mob);
     Vec3 center=leader==mob?(state.home==null?mob.position():state.home):leader.position();
     BlockPos pos=BlockPos.containing(center).offset((int)(Math.cos(a)*(leader==mob?5:3)),0,(int)(Math.sin(a)*(leader==mob?5:3)));
     if(BanditDirector.safe(level,pos))mob.getNavigation().moveTo(pos.getX()+.5,pos.getY(),pos.getZ()+.5,.7);
    }
   }
   return;
  }
  if(!target.getUUID().equals(previousTarget)){previousTarget=target.getUUID();seenTicks=0;nextPath=0;state.cover=null;peek=null;}
  boolean visible=BanditDirector.visible(mob,target);
  if(visible){
   seenTicks++;state.lastKnown=target.position();state.seenAt=now;
   if(now%40==Math.floorMod(mob.getId(),40))BanditDirector.alert(mob,target,state.lastKnown,now);
  }else seenTicks=0;
  if(now-state.seenAt>BanditDirector.settings().memoryTicks||mob.distanceToSqr(target)>64*64){mob.setTarget(null);mob.getNavigation().stop();return;}
  mob.setAggressive(true);
  Vec3 point=visible?target.position():state.lastKnown;if(point==null)return;
  mob.getLookControl().setLookAt(point.x,point.y+target.getEyeHeight(),point.z,20,20);
  boolean hiddenPhase=false;
  if(state.guardUntil>now){
   if(now>=nextCover){nextCover=now+60;state.cover=cover(point,state);peek=state.cover==null?null:peek(state.cover,point,state);}
   if(state.cover!=null){
    hiddenPhase=(state.guardUntil-now)%80>30;
    BlockPos destination=hiddenPhase||peek==null?state.cover:peek;
    if(now>=nextPath){nextPath=now+15;mob.getNavigation().moveTo(destination.getX()+.5,destination.getY(),destination.getZ()+.5,1.15);}
   }else if(now>=nextPath){nextPath=now+25;retreat(point,4+state.role);hiddenPhase=true;}
  }else if(now>=nextPath){
   nextPath=now+30;Vec3 delta=mob.position().subtract(point);double distance=delta.horizontalDistance();
   if(!visible)move(point,1.0);
   else if(distance<7)retreat(point,4);
   else if(distance>22||state.role>0){
    Vec3 normal=delta.horizontalDistanceSqr()<.01?new Vec3(1,0,0):new Vec3(delta.x,0,delta.z).normalize();
    Vec3 side=new Vec3(-normal.z,0,normal.x).scale(state.role==1?6:state.role==2?-6:0);
    Vec3 flank=point.add(normal.scale(13+state.role*2)).add(side);move(flank,1.0);
   }else mob.getNavigation().stop();
  }
  if(attackDelay>0)attackDelay--;
  int reaction=target instanceof Player?Math.max(15,35-state.tier*4):8;
  if(state.guardUntil>now)reaction=Math.min(reaction,12);
  if(hiddenPhase||!visible||seenTicks<reaction||attackDelay>0||mob.distanceToSqr(target)>40*40||allyInLine(target))return;
  try{
   Vec3 aim;
   boolean pressure=target instanceof Player;
   if(pressure){
    Player player=(Player)target;
    if(pressureIndex>=20){
     pressureIndex=0;firstHit=mob.getRandom().nextInt(20);
     secondHit=mob.getRandom().nextInt(19);if(secondHit>=firstHit)secondHit++;
    }
    boolean hit=BanditRules.pressureHit(pressureIndex,firstHit,secondHit,BanditDirector.settings().softMode);
    boolean arm=hit&&mob.getRandom().nextInt(5)==0;
    // Aim below the head even on deliberate misses. Do not spray vertically toward the eyes.
    Vec3 ground=player.position();
    Vec3 toward=ground.subtract(mob.position());
    Vec3 side=new Vec3(-toward.z,0,toward.x);
    side=side.lengthSqr()<.001?new Vec3(1,0,0):side.normalize();
    double sign=mob.getRandom().nextBoolean()?1:-1;
    double lateral=hit?player.getBbWidth()*(arm?.42:.16):1.8+mob.getRandom().nextDouble()*2+BanditDirector.speed(player)*8;
    aim=ground.add(side.scale(sign*lateral)).add(0,hit?BanditRules.aimHeight(player.getBbHeight(),arm):player.getBbHeight()*.20,0);
   }else aim=target.getEyePosition();
   Vec3 delta=aim.subtract(mob.getEyePosition());
   float yaw=(float)Math.toDegrees(Math.atan2(delta.z,delta.x))-90;
   float pitch=(float)-Math.toDegrees(Math.atan2(delta.y,delta.horizontalDistance()));
   if(!pressure){double spread=BanditRules.spread(false,0,state.tier);yaw+=(mob.getRandom().nextFloat()-.5f)*spread;pitch+=(mob.getRandom().nextFloat()-.5f)*spread*.5;}
   if(GunAccess.fire(mob,pitch,yaw)){if(pressure)pressureIndex++;BanditDirector.dirty(mob);attackDelay=BanditRules.delay(pressure,state.tier);}
   else attackDelay=5;
  }catch(Exception error){attackDelay=100;BanditDirector.problem(error);}
 }
 private void acquire(BanditDirector.State state,long now){
  LivingEntity current=mob.getTarget();
  Zombie threat=level.getEntitiesOfClass(Zombie.class,mob.getBoundingBox().inflate(24),z->z.isAlive()&&BanditDirector.visible(mob,z)).stream().min(Comparator.comparingDouble(z->mob.distanceToSqr(z))).orElse(null);
  if(threat!=null&&mob.distanceToSqr(threat)<8*8){mob.setTarget(threat);state.lastKnown=threat.position();state.seenAt=now;return;}
  if(current!=null&&current.isAlive())return;
  Player player=level.players().stream().filter(p->p.isAlive()&&!p.isCreative()&&!p.isSpectator()&&detect(p)).min(Comparator.comparingDouble(p->mob.distanceToSqr(p))).orElse(null);
  if(player!=null){mob.setTarget(player);state.lastKnown=player.position();state.seenAt=now;BanditDirector.alert(mob,player,state.lastKnown,now);}
  else if(threat!=null){mob.setTarget(threat);state.lastKnown=threat.position();state.seenAt=now;}
 }
 private boolean detect(Player player){
  double radius=BanditRules.detection(player.isCrouching(),player.isSprinting(),player.isInvisible());
  if(mob.distanceToSqr(player)>radius*radius||!BanditDirector.visible(mob,player))return false;
  Vec3 toward=player.position().subtract(mob.position()).normalize();return mob.distanceToSqr(player)<3*3||mob.getLookAngle().dot(toward)>.2;
 }
 private void move(Vec3 point,double speed){BlockPos pos=BlockPos.containing(point);if(level.hasChunkAt(pos)&&level.getWorldBorder().isWithinBounds(pos))mob.getNavigation().moveTo(point.x,point.y,point.z,speed);}
 private void retreat(Vec3 target,double amount){Vec3 dir=mob.position().subtract(target);if(dir.horizontalDistanceSqr()<.01)dir=new Vec3(1,0,0);move(mob.position().add(new Vec3(dir.x,0,dir.z).normalize().scale(amount)),1.15);}
 private BlockPos cover(Vec3 threat,BanditDirector.State state){
  BlockPos best=null;double score=Double.MAX_VALUE;int paths=0;
  search:for(int r:new int[]{3,5,7})for(int a=0;a<12;a++)for(int dy=-1;dy<=1;dy++){
   double angle=a*Math.PI/6;BlockPos pos=mob.blockPosition().offset((int)Math.round(Math.cos(angle)*r),dy,(int)Math.round(Math.sin(angle)*r));
   if(!level.hasChunkAt(pos)||!BanditDirector.safe(level,pos))continue;
   Vec3 eye=Vec3.atBottomCenterOf(pos).add(0,mob.getEyeHeight(),0);
   if(BanditDirector.clear(level,threat.add(0,1.5,0),eye,mob)||eye.distanceToSqr(threat)<16)continue;
   if(++paths>8)break search;
   Path path=mob.getNavigation().createPath(pos,0);if(path==null||!path.canReach())continue;
   double value=mob.distanceToSqr(Vec3.atBottomCenterOf(pos))+.1*eye.distanceToSqr(threat);
   for(Mob ally:BanditDirector.nearby(mob,12))if(ally!=mob&&ally.distanceToSqr(Vec3.atBottomCenterOf(pos))<2)value+=100;
   if(value<score){score=value;best=pos;}
  }
  return best;
 }
 private BlockPos peek(BlockPos cover,Vec3 target,BanditDirector.State state){
  int[] signs=state.role==2?new int[]{-1,1}:new int[]{1,-1};
  for(int sign:signs)for(BlockPos pos:new BlockPos[]{cover.offset(sign,0,0),cover.offset(0,0,sign)}){
   if(!BanditDirector.safe(level,pos)||!BanditDirector.clear(level,Vec3.atBottomCenterOf(pos).add(0,mob.getEyeHeight(),0),target.add(0,1.5,0),mob))continue;
   Path p=mob.getNavigation().createPath(pos,0);if(p!=null&&p.canReach())return pos;
  }return null;
 }
 private boolean allyInLine(LivingEntity target){
  Vec3 start=mob.getEyePosition(),line=target.getEyePosition().subtract(start);double length=line.lengthSqr();
  for(Mob ally:level.getEntitiesOfClass(Mob.class,mob.getBoundingBox().expandTowards(line).inflate(1),e->e!=mob&&BanditDirector.bandit(e))){
   double t=ally.getEyePosition().subtract(start).dot(line)/Math.max(.01,length);
   if(t>0&&t<1&&ally.getEyePosition().distanceToSqr(start.add(line.scale(t)))<.8)return true;
  }return false;
 }
}
