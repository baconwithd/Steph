package dev.zomboid.remains;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
public final class CorpseSounds {
 private static final DeferredRegister<SoundEvent> SOUNDS=DeferredRegister.create(Registries.SOUND_EVENT,ZombieRemainsLoot.ID);
 public static final DeferredHolder<SoundEvent,SoundEvent> BLOOD=SOUNDS.register("blood_splatter",()->SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(ZombieRemainsLoot.ID,"blood_splatter")));
 public static void register(IEventBus bus){SOUNDS.register(bus);}
}
