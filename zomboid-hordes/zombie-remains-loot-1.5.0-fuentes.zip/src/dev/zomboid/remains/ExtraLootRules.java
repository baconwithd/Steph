package dev.zomboid.remains;
public final class ExtraLootRules {
 public static int ammoMin(int q){return new int[]{15,24,36,48,64}[QualityRules.clamp(q)];}
 public static int ammoMax(int q){return new int[]{32,48,64,96,128}[QualityRules.clamp(q)];}
 public static double backpackChance(int q,boolean bandit,boolean mutant){return Math.min(.65,new double[]{.08,.12,.18,.24,.30}[QualityRules.clamp(q)]+(bandit?.15:0)+(mutant?.10:0));}
 public static double militaryChance(int q,boolean bandit,boolean mutant){return Math.min(.30,new double[]{.015,.025,.04,.06,.08}[QualityRules.clamp(q)]+(bandit?.08:0)+(mutant?.03:0));}
 public static String backpack(int q){return "sophisticatedbackpacks:"+new String[]{"backpack","copper_backpack","iron_backpack","gold_backpack","diamond_backpack"}[QualityRules.clamp(q)];}
}
