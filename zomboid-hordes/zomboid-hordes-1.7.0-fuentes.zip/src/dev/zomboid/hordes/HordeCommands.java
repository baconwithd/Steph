package dev.zomboid.hordes;
import com.mojang.brigadier.context.CommandContext;import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.*;import net.minecraft.server.level.ServerPlayer;import net.minecraft.network.chat.Component;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.neoforge.event.RegisterCommandsEvent;
@EventBusSubscriber(modid=ZomboidHordes.ID)
public final class HordeCommands {
 @SubscribeEvent public static void register(RegisterCommandsEvent e){e.getDispatcher().register(Commands.literal("zhorda").requires(s->s.hasPermission(2))
  .then(Commands.literal("loot").then(Commands.literal("estado").executes(c->loot(c,false))).then(Commands.literal("probar").executes(c->loot(c,true))))
  .then(Commands.literal("zombis").executes(HordeCommands::profiles))
  .then(Commands.literal("noche").executes(c->test(c,1)))
  .then(Commands.literal("ruido").executes(c->test(c,0)))
  .then(Commands.literal("helicoptero").executes(c->test(c,2)))
  .then(Commands.literal("dia").executes(c->test(c,3)))
  .then(Commands.literal("parar").executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();int n=HordeEvents.stopHordes(p);c.getSource().sendSuccess(()->Component.literal("Se cancelaron "+n+" oleadas pendientes cercanas. Los zombis existentes siguen ahí."),false);return n;}))
  .then(Commands.literal("estado").executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();HordeData d=HordeData.get(p.serverLevel());int remaining=d.tickets.stream().mapToInt(t->t.remaining).sum();c.getSource().sendSuccess(()->Component.literal("Oleadas pendientes: "+d.tickets.size()+"; zombis pendientes: "+remaining+". Helicóptero programado: "+(d.helicopterAt>=0?"sí":"no")),false);return d.tickets.size();}))
  .executes(c->{c.getSource().sendSuccess(()->Component.literal("Pruebas: /zhorda noche | ruido | helicoptero | dia. Control: /zhorda estado | parar. Loot: /zhorda loot estado | probar (mira un cofre). Usa supervivencia en el Overworld."),false);return 1;}));}
 private static int profiles(CommandContext<CommandSourceStack> c)throws CommandSyntaxException{
  ServerPlayer p=c.getSource().getPlayerOrException();int[] count=new int[4];
  for(var mob:p.serverLevel().getEntitiesOfClass(net.minecraft.world.entity.Mob.class,p.getBoundingBox().inflate(24),ZombieIndividual::supported)){
   count[Math.max(0,Math.min(2,ZombieIndividual.profile(mob).getInt("zi_type")))]++;if(mob.getTarget()==p)count[3]++;
  }
  c.getSource().sendSuccess(()->Component.literal("Zombis a 24 bloques: torpes "+count[0]+", normales "+count[1]+", atentos "+count[2]+"; te persiguen "+count[3]+". Ruido cotidiano: máximo 8 bloques."),false);return count[0]+count[1]+count[2];
 }
 private static int loot(CommandContext<CommandSourceStack> c,boolean refill)throws CommandSyntaxException{String result=LootRestock.debug(c.getSource().getPlayerOrException(),refill);c.getSource().sendSuccess(()->Component.literal(result),false);return 1;}
 private static int test(CommandContext<CommandSourceStack> c,int kind)throws CommandSyntaxException{ServerPlayer p=c.getSource().getPlayerOrException();if(!HordeEvents.testHorde(p,kind)){c.getSource().sendFailure(Component.literal("No se pudo iniciar: necesitas supervivencia, Overworld, dificultad distinta de Pacífico y doMobSpawning=true."));return 0;}c.getSource().sendSuccess(()->Component.literal("Prueba iniciada. Usa /zhorda estado para ver las oleadas. No se cambia la hora del mundo."),false);return 1;}
}
