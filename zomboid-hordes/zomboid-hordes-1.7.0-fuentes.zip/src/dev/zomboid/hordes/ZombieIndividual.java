package dev.zomboid.hordes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.*;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.common.extensions.IEntityExtension;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
@EventBusSubscriber(modid=ZomboidHordes.ID)
public final class ZombieIndividual {
 public static void individualGoals(Mob mob,net.minecraft.world.entity.ai.goal.GoalSelector selector){
  for(var wrapped:java.util.Set.copyOf(selector.getAvailableGoals())){
   String name=wrapped.getGoal().getClass().getName();
   if(profile(mob).getInt("zi_type")==0&&wrapped.getGoal() instanceof net.minecraft.world.entity.ai.goal.LookAtPlayerGoal){selector.removeGoal(wrapped.getGoal());continue;}
   if(name.startsWith("com.example.soundattract.ai.")&&java.util.Set.of("AttractionGoal","LeaderAttractionGoal","FollowLeaderGoal","FollowerEdgeRelayGoal","FollowScentGoal").contains(wrapped.getGoal().getClass().getSimpleName()))selector.removeGoal(wrapped.getGoal());
  }
 }
 public static boolean supported(net.minecraft.world.entity.Entity e){
  if(!(e instanceof Mob))return false;if(e instanceof net.minecraft.world.entity.monster.Zombie)return true;
  var id=net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType());
  return id.getNamespace().equals("zombie_variants")||id.getPath().contains("zombie")||(id.getNamespace().equals("mutantszombies")&&java.util.Set.of("blister_zombie","crawler","spitter","zombie_brute","split_head_zombie","mutant_brute","rotten_mutant").contains(id.getPath()));
 }
 static CompoundTag data(Mob z){return ((IEntityExtension)(Object)z).getPersistentData();}
 public static CompoundTag profile(Mob z){CompoundTag t=data(z);if(t.getInt("zi_profile_version")<2){t.putBoolean("zi_initialized",true);t.putInt("zi_profile_version",2);t.remove("zi_seen");t.remove("zi_pending");int kind=IndividualRules.type(z.getRandom().nextDouble());t.putInt("zi_type",kind);double hearing=IndividualRules.hearing(kind,z.getRandom().nextDouble());if(z.getRandom().nextDouble()<.12)hearing*=.30;t.putDouble("zi_hearing",hearing);t.putInt("zi_delay",IndividualRules.delay(kind,z.getRandom().nextInt()));}return t;}
 public static boolean sees(Mob z,Player p){CompoundTag t=profile(z);long now=z.level().getGameTime();
  if(t.hasUUID("zi_angry")&&t.getUUID("zi_angry").equals(p.getUUID())&&t.getLong("zi_anger_until")>now)return z.distanceToSqr(p)<64*64;
  if(z.distanceToSqr(p)<=1.25*1.25&&z.hasLineOfSight(p))return rememberSight(t,p,now);
  double range=IndividualRules.vision(t.getInt("zi_type"),p.isCrouching());
  boolean known=t.hasUUID("zi_seen")&&t.getUUID("zi_seen").equals(p.getUUID());
  if(known&&t.getLong("zi_seen_until")>now){if(z.hasLineOfSight(p)&&z.distanceToSqr(p)<range*range*2.25)return rememberSight(t,p,now);return z.distanceToSqr(p)<48*48;}
  if(!z.hasLineOfSight(p)||z.distanceToSqr(p)>range*range)return false;
  double dx=p.getX()-z.getX(),dz=p.getZ()-z.getZ(),len=Math.sqrt(dx*dx+dz*dz),yaw=Math.toRadians(z.getYHeadRot());
  double dot=len<.01?1:(-Math.sin(yaw)*dx+Math.cos(yaw)*dz)/len;
  if(!IndividualRules.inView(t.getInt("zi_type"),dot,p.isCrouching()))return false;
  if(!t.hasUUID("zi_pending")||!t.getUUID("zi_pending").equals(p.getUUID())||now-t.getLong("zi_pending_last")>100){t.putUUID("zi_pending",p.getUUID());t.putLong("zi_notice_at",now+t.getInt("zi_delay"));}
  t.putLong("zi_pending_last",now);if(now<t.getLong("zi_notice_at"))return false;return rememberSight(t,p,now);
 }
 private static boolean rememberSight(CompoundTag t,Player p,long now){t.putUUID("zi_seen",p.getUUID());t.putLong("zi_seen_until",now+160);return true;}
 public static boolean hear(Mob z,BlockPos pos,ServerPlayer p,double radius,long until,boolean heli){CompoundTag t=profile(z);long now=z.level().getGameTime();
  if(t.getLong("zi_hearing_next")>now&&radius<=t.getDouble("zi_last_radius")*1.2)return false;t.putDouble("zi_last_radius",radius);t.putLong("zi_hearing_next",now+40+t.getInt("zi_delay"));
  double distance=Math.sqrt(z.blockPosition().distSqr(pos)),range=NoiseRules.heardRadius(radius,t.getDouble("zi_hearing"));
  if(z.getRandom().nextDouble()>=IndividualRules.chance(t.getInt("zi_type"),distance,range))return false;
  int error=radius<=8?(t.getInt("zi_type")==0?2:1):(t.getInt("zi_type")==0?6:t.getInt("zi_type")==1?3:1);BlockPos memory=pos.offset(z.getRandom().nextInt(error*2+1)-error,0,z.getRandom().nextInt(error*2+1)-error);
  t.putLong("zh_pos",memory.asLong());t.putLong("zh_until",Math.min(until,now+(t.getInt("zi_type")==0?300:600)));t.putUUID("zh_player",p.getUUID());t.putBoolean("zh_heli",heli);return true;
 }
 private static final net.minecraft.resources.ResourceLocation HEALTH=net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(ZomboidHordes.ID,"individual_health"),DAMAGE=net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(ZomboidHordes.ID,"individual_damage");
 private static void stats(Mob z,CompoundTag t){
  boolean smart=IndividualRules.smart(t.getInt("zi_type"));
  stat(z,net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH,HEALTH,smart?.25:0);
  stat(z,net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE,DAMAGE,smart?.15:0);
 }
 private static void stat(Mob z,net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> key,net.minecraft.resources.ResourceLocation id,double value){
  var a=z.getAttribute(key);if(a==null)return;var old=a.getModifier(id);if(old!=null&&Math.abs(old.amount()-value)<.0001)return;
  double before=z.getMaxHealth();a.removeModifier(id);if(value>0)a.addPermanentModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(id,value,net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
  if(key==net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH){if(z.getHealth()>=before-.01)z.setHealth(z.getMaxHealth());else if(z.getHealth()>z.getMaxHealth())z.setHealth(z.getMaxHealth());}
 }
 @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){
  if(!(e.getEntity() instanceof Mob z)||!supported(z)||z.level().isClientSide()||!z.isAlive())return;
  var t=profile(z);if((z.tickCount+z.getId())%20==0){stats(z,t);if(z.getTarget() instanceof Player p&&!sees(z,p))z.setTarget(null);}
  if(z.getTarget()==null&&t.getLong("zh_until")<=z.level().getGameTime()&&t.getInt("zi_type")==0){if(z.tickCount%5==0)z.setXRot(38);}
  else if(z.tickCount%5==0&&z.getTarget()==null)z.setXRot(0);
 }
 @SubscribeEvent(priority=EventPriority.LOWEST) public static void target(LivingChangeTargetEvent e){if(e.getEntity() instanceof Mob z&&supported(z)&&!z.level().isClientSide()&&e.getNewAboutToBeSetTarget() instanceof Player p&&!sees(z,p))e.setNewAboutToBeSetTarget(null);}
 @SubscribeEvent public static void hurt(LivingDamageEvent.Post e){if(e.getEntity() instanceof Mob z&&supported(z)&&!z.level().isClientSide()&&e.getNewDamage()>0&&e.getSource().getEntity() instanceof Player p){var t=profile(z);t.putUUID("zi_angry",p.getUUID());t.putLong("zi_anger_until",z.level().getGameTime()+200);z.setTarget(p);}}
}
