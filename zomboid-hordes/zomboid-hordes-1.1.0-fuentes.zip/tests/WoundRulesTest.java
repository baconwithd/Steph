import dev.zomboid.hordes.WoundRules;
public class WoundRulesTest {
 static int count;static void ok(boolean b,String why){count++;if(!b)throw new AssertionError(why);}
 public static void main(String[] args){
  ok(WoundRules.region(.9,0)==WoundRules.HEAD,"head");ok(WoundRules.region(.75,0)==WoundRules.HEAD,"head boundary");ok(WoundRules.region(.2,0)==WoundRules.LEGS,"leg");ok(WoundRules.region(.6,.4)==WoundRules.ARMS,"right arm");ok(WoundRules.region(.6,-.4)==WoundRules.ARMS,"left arm");ok(WoundRules.region(.5,0)==WoundRules.TORSO,"torso");
  ok(WoundRules.damage(WoundRules.HEAD)>WoundRules.damage(WoundRules.TORSO),"head kills faster");ok(WoundRules.biteFailure(0)==0,"healthy jaw");ok(WoundRules.biteFailure(2)>WoundRules.biteFailure(1),"jaw damage accumulates");ok(WoundRules.biteFailure(100)==.9,"jaw chance bounded");
  ok(!WoundRules.ready(119,100,true,true,0),"19 contact ticks cannot bite");ok(WoundRules.ready(120,100,true,true,0),"20 ticks permits bite");ok(!WoundRules.ready(200,100,true,false,0),"leaving range prevents bite");ok(!WoundRules.ready(200,100,false,true,0),"changing target prevents bite");ok(!WoundRules.ready(120,100,true,true,130),"stun prevents bite");ok(!WoundRules.ready(135,130,true,true,130),"fresh timer after stun prevents immediate bite");
  ok(WoundRules.speed(0,1)==0,"healthy speed unchanged");ok(WoundRules.speed(1,1)<WoundRules.speed(0,1),"leg wound slows");ok(WoundRules.speed(1,.3)<WoundRules.speed(1,1),"low health weakens further");ok(WoundRules.strength(1,1)<WoundRules.strength(0,1),"arm wound reduces strength");ok(WoundRules.speed(100,0)==-.65,"speed capped");ok(WoundRules.strength(100,0)==-.7,"damage capped");ok(WoundRules.stun(WoundRules.HEAD)>WoundRules.stun(WoundRules.LEGS),"head stuns longer");
  System.out.println("PASS: "+count+" wound, impact zone, stun and one-second contact checks");
 }
}
