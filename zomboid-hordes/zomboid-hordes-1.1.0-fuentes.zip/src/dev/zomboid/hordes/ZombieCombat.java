package dev.zomboid.hordes;
import java.util.*;import net.minecraft.core.Holder;import net.minecraft.nbt.CompoundTag;import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.player.Player;import net.minecraft.world.entity.monster.Zombie;import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.ai.attributes.*;import net.minecraft.world.damagesource.DamageSource;import net.minecraft.world.phys.*;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.neoforge.event.tick.EntityTickEvent;import net.neoforged.neoforge.event.entity.living.*;import net.neoforged.neoforge.common.extensions.IEntityExtension;
@EventBusSubscriber(modid=ZomboidHordes.ID)
public final class ZombieCombat {
 private static final ResourceLocation WOUND=ResourceLocation.fromNamespaceAndPath(ZomboidHordes.ID,"wounds");
 private static CompoundTag tag(Entity e){return ((IEntityExtension)(Object)e).getPersistentData();}
 private static boolean contact(Zombie z,Entity target){double width=z.getBbWidth()*2;return target!=null&&target.isAlive()&&target.level()==z.level()&&z.distanceToSqr(target)<=width*width+target.getBbWidth()&&z.hasLineOfSight(target);}
 private static void reset(CompoundTag t){t.remove("zc_target");t.remove("zc_since");}
 @SubscribeEvent public static void tick(EntityTickEvent.Post e){if(!(e.getEntity() instanceof Zombie z)||z.level().isClientSide()||!z.isAlive())return;
  if(z.isBaby())z.setBaby(false);long now=z.level().getGameTime();CompoundTag t=tag(z);
  if(t.getLong("zc_stun")>now){z.getNavigation().stop();reset(t);z.setDeltaMovement(z.getDeltaMovement().multiply(.25,1,.25));}
  else {LivingEntity target=z.getTarget();if(target instanceof Player p&&!p.isCreative()&&!p.isSpectator()&&contact(z,p)){
   if(!t.hasUUID("zc_target")||!t.getUUID("zc_target").equals(p.getUUID())){t.putUUID("zc_target",p.getUUID());t.putLong("zc_since",now);}
  }else reset(t);}
  if((z.tickCount+z.getId())%20==0)weaken(z);
 }
 public static boolean allowAttack(Zombie z,Entity target){if(z.level().isClientSide())return true;long now=z.level().getGameTime();CompoundTag t=tag(z);
  if(t.getLong("zc_stun")>now)return false;
  if(target instanceof Player){boolean same=t.hasUUID("zc_target")&&t.getUUID("zc_target").equals(target.getUUID());
   if(!WoundRules.ready(now,t.getLong("zc_since"),same,contact(z,target),t.getLong("zc_stun")))return false;
   t.putLong("zc_since",now);if(z.getRandom().nextDouble()<WoundRules.biteFailure(t.getInt("zc_head")))return false;
  }return true;
 }
 @SubscribeEvent public static void incoming(LivingIncomingDamageEvent e){if(!(e.getEntity() instanceof Zombie z)||z.level().isClientSide()||e.getAmount()<=0||!(e.getSource().getEntity() instanceof LivingEntity))return;
  int part=part(z,e.getSource());boolean gun=(e.getSource().getDirectEntity()!=null&&e.getSource().getDirectEntity().getClass().getName().startsWith("com.tacz."))||e.getSource().getMsgId().toLowerCase(Locale.ROOT).contains("gun")||e.getSource().getMsgId().toLowerCase(Locale.ROOT).contains("bullet");
  if(!gun)e.setAmount((float)(e.getAmount()*WoundRules.damage(part))); // Gun mods retain their own headshot damage.
 }
 @SubscribeEvent public static void damaged(LivingDamageEvent.Post e){if(!(e.getEntity() instanceof Zombie z)||z.level().isClientSide()||!z.isAlive()||e.getNewDamage()<=0)return;
  CompoundTag t=tag(z);if(e.getSource().getEntity() instanceof LivingEntity){int part=part(z,e.getSource());String key=part==WoundRules.HEAD?"zc_head":part==WoundRules.LEGS?"zc_legs":part==WoundRules.ARMS?"zc_arms":"zc_body";t.putInt(key,Math.min(10,t.getInt(key)+1));t.putLong("zc_stun",z.level().getGameTime()+WoundRules.stun(part));reset(t);z.getNavigation().stop();}
  weaken(z);
 }
 private static int part(Zombie z,DamageSource source){AABB box=z.getBoundingBox();Entity direct=source.getDirectEntity();Vec3 point=null;
  if(direct instanceof Projectile){Vec3 velocity=direct.getDeltaMovement();point=box.clip(direct.position().subtract(velocity.scale(2)),direct.position().add(velocity.scale(2))).orElse(null);}
  if(point==null&&source.getEntity() instanceof LivingEntity attacker){Vec3 eye=attacker.getEyePosition();point=box.clip(eye,eye.add(attacker.getLookAngle().scale(attacker.distanceTo(z)+3))).orElse(null);}
  if(point==null)return WoundRules.TORSO;
  double height=(point.y-box.minY)/Math.max(.01,box.getYsize());double yaw=Math.toRadians(z.getYRot());double lateral=((point.x-z.getX())*Math.cos(yaw)+(point.z-z.getZ())*Math.sin(yaw))/Math.max(.01,box.getXsize());return WoundRules.region(height,lateral);
 }
 private static void weaken(Zombie z){CompoundTag t=tag(z);double hp=z.getHealth()/Math.max(1,z.getMaxHealth());modify(z,Attributes.MOVEMENT_SPEED,WoundRules.speed(t.getInt("zc_legs"),hp));modify(z,Attributes.ATTACK_DAMAGE,WoundRules.strength(t.getInt("zc_arms"),hp));}
 private static void modify(Zombie z,Holder<Attribute> key,double amount){AttributeInstance a=z.getAttribute(key);if(a==null)return;AttributeModifier old=a.getModifier(WOUND);if(old!=null&&Math.abs(old.amount()-amount)<.001)return;a.removeModifier(WOUND);if(amount<-.001)a.addTransientModifier(new AttributeModifier(WOUND,amount,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));}
}
