package dev.zomboid.hordes;
public final class WoundRules {
 public static final int HEAD=0,TORSO=1,ARMS=2,LEGS=3;
 public static int region(double height,double lateral){return height>=.75?HEAD:height<.35?LEGS:Math.abs(lateral)>.32?ARMS:TORSO;}
 public static double damage(int region){return region==HEAD?1.5:region==LEGS?.9:1;}
 public static int stun(int region){return region==HEAD?12:region==LEGS?6:8;}
 public static double biteFailure(int headHits){return Math.min(.90,Math.max(0,headHits)*.30);}
 public static double speed(int legs,double health){return -Math.min(.65,Math.max(0,legs)*.12+.20*(1-Math.clamp(health,0,1)));}
 public static double strength(int arms,double health){return -Math.min(.70,Math.max(0,arms)*.10+.30*(1-Math.clamp(health,0,1)));}
 public static boolean ready(long now,long since,boolean sameTarget,boolean contact,long stunnedUntil){return sameTarget&&contact&&now>=stunnedUntil&&now-since>=20;}
 private WoundRules(){}
}
