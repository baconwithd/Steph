import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class CompatibilityCheck {
 static int checks;
 static ClassNode read(String jar,String name)throws Exception{try(ZipFile z=new ZipFile(jar)){ClassNode n=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class")).readAllBytes()).accept(n,0);return n;}}
 static void method(ClassNode c,String name,String desc,boolean isStatic){var m=c.methods.stream().filter(x->x.name.equals(name)&&x.desc.equals(desc)).findFirst().orElseThrow(()->new AssertionError(c.name+" "+name+desc));if(((m.access&Opcodes.ACC_STATIC)!=0)!=isStatic)throw new AssertionError("static mismatch");checks++;}
 public static void main(String[] args)throws Exception{
  String mc=args[0],day=args[1],hoard=args[2],sound=args[3];
  ClassNode mob=read(mc,"net/minecraft/world/entity/Mob");method(mob,"doHurtTarget","(Lnet/minecraft/world/entity/Entity;)Z",false);method(read(mc,"net/minecraft/world/entity/monster/Zombie"),"setBaby","(Z)V",false);method(mob,"isSunBurnTick","()Z",false);method(mob,"<init>","(Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V",false);
  if(mob.fields.stream().noneMatch(f->f.name.equals("goalSelector")&&f.desc.equals("Lnet/minecraft/world/entity/ai/goal/GoalSelector;")))throw new AssertionError("goalSelector missing");checks++;
  method(read(day,"net/mcreator/weakerdayzombieneoforge/procedures/WeakerdayzombieprocedureProcedure"),"execute","(Lnet/neoforged/bus/api/Event;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/entity/Entity;)V",true);
  method(read(hoard,"com/warwa/hordehoard/procedures/HordeSpawnerProcedure"),"onServerTick","(Lnet/minecraft/server/MinecraftServer;)V",true);
  method(read(hoard,"com/warwa/hordehoard/config/HordeHoardConfig"),"isFeatureOn","(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/GameRules$Key;Z)Z",true);
  ClassNode tacz=read(sound,"com/example/soundattract/integration/tacz/TaczIntegration");method(tacz,"onGunShoot","(Lcom/tacz/guns/api/event/common/GunShootEvent;)V",true);method(tacz,"calculateShootRangeWeight","(Lnet/minecraft/world/item/ItemStack;)[D",true);
  ClassNode tracker=read(sound,"com/example/soundattract/tracking/SoundTracker");method(tracker,"getNearbySounds","(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;D)Ljava/util/List;",true);
  ClassNode record=read(sound,"com/example/soundattract/tracking/SoundTracker$SoundRecord");for(String name:List.of("ticksRemaining","range","pos","soundId")){if(record.fields.stream().noneMatch(f->f.name.equals(name)&&(f.access&Opcodes.ACC_PUBLIC)!=0))throw new AssertionError(name);checks++;}
  method(read(mc,"net/minecraft/world/level/block/entity/RandomizableContainerBlockEntity"),"setLootTable","(Lnet/minecraft/resources/ResourceKey;)V",false);
  method(read(mc,"net/minecraft/world/level/block/entity/ChestBlockEntity"),"getOpenCount","(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)I",true);
  method(read(mc,"net/minecraft/world/level/block/ChestBlock"),"getConnectedDirection","(Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/core/Direction;",true);
  method(read(mc,"net/minecraft/world/level/block/entity/RandomizableContainerBlockEntity"),"getLootTable","()Lnet/minecraft/resources/ResourceKey;",false);
  System.out.println("PASS: "+checks+" original-JAR integration and mixin target contracts");
 }
}
