package dev.zomboid.hordes;
import java.util.*;import net.minecraft.core.*;import net.minecraft.nbt.*;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.level.saveddata.SavedData;
public final class HordeData extends SavedData {
 public long lastDay=Long.MIN_VALUE, helicopterAt=-1,lastNight=Long.MIN_VALUE,lastPatrol=0,lastDaySpawn=0;
 public final List<Ticket> tickets=new ArrayList<>();
 public static HordeData get(ServerLevel level){return level.getDataStorage().computeIfAbsent(new SavedData.Factory<>(HordeData::new,HordeData::load,null),"zomboid_hordes");}
 public static HordeData load(CompoundTag tag,HolderLookup.Provider lookup){HordeData d=new HordeData();d.lastDay=tag.contains("day")?tag.getLong("day"):Long.MIN_VALUE;d.helicopterAt=tag.contains("helicopter")?tag.getLong("helicopter"):-1;d.lastNight=tag.contains("night")?tag.getLong("night"):Long.MIN_VALUE;d.lastPatrol=tag.getLong("patrol");d.lastDaySpawn=tag.getLong("daySpawn");
  ListTag list=tag.getList("waves",10);for(int i=0;i<list.size()&&i<16;i++){CompoundTag t=list.getCompound(i);if(!t.hasUUID("player"))continue;Ticket w=new Ticket(t.getUUID("player"),BlockPos.of(t.getLong("pos")),t.getInt("kind"),Math.min(2000,t.getInt("remaining")),t.getLong("created"));w.next=t.getLong("next");if(w.remaining>0)d.tickets.add(w);}return d;}
 @Override public CompoundTag save(CompoundTag tag,HolderLookup.Provider lookup){tag.putLong("day",lastDay);tag.putLong("helicopter",helicopterAt);tag.putLong("night",lastNight);tag.putLong("patrol",lastPatrol);tag.putLong("daySpawn",lastDaySpawn);ListTag list=new ListTag();for(Ticket w:tickets){CompoundTag t=new CompoundTag();t.putUUID("player",w.player);t.putLong("pos",w.pos.asLong());t.putInt("kind",w.kind);t.putInt("remaining",w.remaining);t.putLong("created",w.created);t.putLong("next",w.next);list.add(t);}tag.put("waves",list);return tag;}
 public static final class Ticket {public UUID player;public BlockPos pos;public int kind,remaining;public long created,next;public Ticket(UUID p,BlockPos b,int k,int n,long now){player=p;pos=b;kind=k;remaining=n;created=now;next=now;}}
}
