package dev.zomboid.hordes;

import java.util.*;
import com.example.soundattract.tracking.SoundTracker;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.*;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.*;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.MobSpawnEvent;
import net.neoforged.neoforge.event.tick.*;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

@EventBusSubscriber(modid=ZomboidHordes.ID)
public final class HordeEvents {
 private static final ResourceLocation DAY=ResourceLocation.fromNamespaceAndPath(ZomboidHordes.ID,"day"),NIGHT=ResourceLocation.fromNamespaceAndPath(ZomboidHordes.ID,"night");
 private static final Map<UUID,Noise> noise=new HashMap<>();
 private static final Map<SoundTracker.SoundRecord,Long> heard=new IdentityHashMap<>();
 private static final Map<ResourceLocation,List<EntityType<?>>> pools=new HashMap<>();
 private static boolean awarenessConfigured;
 private static net.minecraft.nbt.CompoundTag data(Entity e){return ((net.neoforged.neoforge.common.extensions.IEntityExtension)(Object)e).getPersistentData();}
 private static HordeConfig cfg(){return ZomboidHordes.CONFIG;}
 private static boolean eligible(ServerPlayer p){return p.isAlive()&&!p.isSpectator()&&!p.isCreative();}
 private static boolean blocked(Entity e){return e instanceof Creeper||e instanceof AbstractSkeleton;}
 @SubscribeEvent public static void spawnCheck(MobSpawnEvent.PositionCheck e){if(blocked(e.getEntity()))e.setResult(MobSpawnEvent.PositionCheck.Result.FAIL);}
 @SubscribeEvent public static void join(EntityJoinLevelEvent e){if(e.getLevel().isClientSide())return;if(blocked(e.getEntity())&&!e.loadedFromDisk())e.setCanceled(true);
  if(e.getEntity() instanceof Zombie z&&!e.loadedFromDisk()&&e.getLevel() instanceof ServerLevel level&&!HordeRules.night(level.getDayTime())&&!data(z).getBoolean("zh_spawned")){
   String reason=data(z).getString("zh_spawn_reason");if(reason.equals("COMMAND")||reason.equals("SPAWN_EGG")||reason.equals("SPAWNER"))return;
   for(ServerPlayer p:level.players())if(eligible(p)&&p.distanceToSqr(z)<=128*128&&level.getEntitiesOfClass(Zombie.class,p.getBoundingBox().inflate(96),Zombie::isAlive).size()>=cfg().dayNearbyLimit){e.setCanceled(true);break;}
  }}
 @SubscribeEvent public static void spawnReason(net.neoforged.neoforge.event.entity.living.FinalizeSpawnEvent e){if(e.getEntity() instanceof Zombie z)data(z).putString("zh_spawn_reason",e.getSpawnType().name());}
 @SubscribeEvent public static void stopped(ServerStoppedEvent e){noise.clear();heard.clear();pools.clear();TaczNoiseBridge.clear();awarenessConfigured=false;}

 @SubscribeEvent public static void zombieTick(EntityTickEvent.Post event){
  if(!(event.getEntity() instanceof Zombie z)||!(z.level() instanceof ServerLevel level)||!z.isAlive())return;
  if(Math.floorMod(z.tickCount+z.getId(),20)!=0)return;
  if(level.dimensionType().hasSkyLight())attributes(z,HordeRules.night(level.getDayTime()));
  var tag=data(z);long now=level.getGameTime();
  if(tag.getLong("zh_until")>now){
   ServerPlayer p=tag.hasUUID("zh_player")?level.getServer().getPlayerList().getPlayer(tag.getUUID("zh_player")):null;
   boolean heli=tag.getBoolean("zh_heli");
   if(p!=null&&p.serverLevel()==level&&eligible(p)&&((heli&&z.distanceToSqr(p)<192*192)||(z.distanceToSqr(p)<(p.isCrouching()?12*12:32*32)&&z.hasLineOfSight(p)))){z.setTarget(p);}
   else if(z.getTarget()==null||!z.hasLineOfSight(z.getTarget())){z.setTarget(null);}
  }else if(tag.contains("zh_until")){tag.remove("zh_until");tag.remove("zh_pos");tag.remove("zh_player");tag.remove("zh_heli");}
 }
 private static void attributes(Zombie z,boolean night){
  ResourceLocation wanted=night?NIGHT:DAY,other=night?DAY:NIGHT;
  change(z,Attributes.MOVEMENT_SPEED,wanted,other,night?cfg().nightSpeed:cfg().daySpeed);
  change(z,Attributes.ATTACK_DAMAGE,wanted,other,night?cfg().nightDamage:cfg().dayDamage);
 }
 private static boolean change(Zombie z,Holder<Attribute> attribute,ResourceLocation wanted,ResourceLocation other,double amount){AttributeInstance a=z.getAttribute(attribute);if(a==null)return false;if(a.getModifier(wanted)!=null&&a.getModifier(other)==null)return false;a.removeModifier(other);a.removeModifier(wanted);a.addTransientModifier(new AttributeModifier(wanted,amount,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));return true;}

 @SubscribeEvent public static void serverTick(ServerTickEvent.Post event){
  ServerLevel level=event.getServer().overworld();long now=level.getGameTime();if(now%20!=0)return;
  List<ServerPlayer> players=level.players().stream().filter(HordeEvents::eligible).toList();
  noise.keySet().removeIf(id->event.getServer().getPlayerList().getPlayer(id)==null);
  heard.entrySet().removeIf(e->now>e.getValue());
  if(players.isEmpty()||level.getDifficulty()==Difficulty.PEACEFUL||!level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING))return;
  configureAwareness();HordeData data=HordeData.get(level);long time=level.getDayTime(),day=Math.floorDiv(time,24000);
  if(HordeRules.newDay(time,data.lastDay)){data.lastDay=day;data.helicopterAt=HordeRules.helicopter(level.random.nextDouble(),cfg().helicopterChance)?HordeRules.schedule(time,level.random.nextInt(10001)):-1;data.setDirty();}
  if(data.helicopterAt>=0&&time>=data.helicopterAt){data.helicopterAt=-1;data.setDirty();ServerPlayer p=players.get(level.random.nextInt(players.size()));start(level,data,p,2,players,now);}
  if(HordeRules.night(time)&&day>data.lastNight){data.lastNight=day;data.lastPatrol=now;data.setDirty();for(ServerPlayer p:leaders(players))start(level,data,p,1,players,now);}
  if(HordeRules.night(time)&&now-data.lastPatrol>=2700){data.lastPatrol=now;data.setDirty();if(level.random.nextFloat()<.25f){ServerPlayer p=players.get(level.random.nextInt(players.size()));startSmall(level,data,p,1,3,now);}}
  if(!HordeRules.night(time)&&now-data.lastDaySpawn>=cfg().daySpawnIntervalTicks){data.lastDaySpawn=now;data.setDirty();for(ServerPlayer p:leaders(players)){int local=level.getEntitiesOfClass(Zombie.class,p.getBoundingBox().inflate(96),Zombie::isAlive).size();if(local<cfg().dayNearbyLimit)startSmall(level,data,p,3,Math.min(cfg().dayZombies,cfg().dayNearbyLimit-local),now);}}
  for(ServerPlayer p:players)listen(level,data,p,now);
  waves(level,data,players,now);
 }
 private static List<ServerPlayer> leaders(List<ServerPlayer> players){List<ServerPlayer> groups=new ArrayList<>();for(ServerPlayer p:players)if(groups.stream().noneMatch(g->g.distanceToSqr(p)<80*80))groups.add(p);return groups;}
 private static boolean start(ServerLevel level,HordeData data,ServerPlayer p,int kind,List<ServerPlayer> players,long now){int together=(int)players.stream().filter(q->q.distanceToSqr(p)<80*80).count();
  int count=switch(kind){case 2->HordeRules.budget(cfg().helicopterZombies,together,cfg().helicopterExtraPerPlayer,cfg().helicopterMaximum);case 1->HordeRules.budget(cfg().nightZombies,together,cfg().nightExtraPerPlayer,cfg().nightMaximum);case 3->cfg().dayZombies;default->cfg().noiseZombies;};
  return startSmall(level,data,p,kind,count,now);
 }
 private static void announce(ServerLevel level,ServerPlayer p,int kind){String text=switch(kind){case 2->"§c[Helicóptero] Un helicóptero sobrevuela la zona. ¡Se aproxima una horda brutal!";case 1->"§6[Horda nocturna] Se acerca una horda ligera.";case 3->"§7[Actividad diurna] Un pequeño grupo de zombis deambula cerca.";default->"§c[Horda] El ruido ha atraído una horda a la zona.";};
  for(ServerPlayer q:level.players())if(q.distanceToSqr(p)<=160*160){q.sendSystemMessage(net.minecraft.network.chat.Component.literal(text));if(kind!=3)q.playNotifySound((kind==2?ZomboidHordes.HELICOPTER:ZomboidHordes.HORDE).get(),SoundSource.AMBIENT,kind==2?.85f:.65f,1f);}
 }
 private static boolean startSmall(ServerLevel level,HordeData data,ServerPlayer p,int kind,int count,long now){
  if(count<=0)return false;
  for(HordeData.Ticket t:data.tickets)if(t.pos.distSqr(p.blockPosition())<80*80){
   if(kind==2&&t.kind!=2){t.kind=2;t.player=p.getUUID();t.remaining=Math.max(count,t.remaining);t.created=now;t.next=now;t.pos=p.blockPosition();data.setDirty();alert(level,p.blockPosition(),p,192,now+1800,true);announce(level,p,kind);return true;}
   if(kind==1&&t.kind==1){t.remaining=Math.min(cfg().nightMaximum,t.remaining+count);data.setDirty();announce(level,p,kind);return true;}
   if(kind==1&&t.kind!=1)continue;
   return false;
  }
  if(data.tickets.size()>=8)return false;data.tickets.add(new HordeData.Ticket(p.getUUID(),p.blockPosition(),kind,count,now));data.setDirty();if(kind!=3)alert(level,p.blockPosition(),p,kind==2?192:kind==1?48:80,now+(kind==2?1800:kind==1?600:1200),kind==2,kind==1?Math.min(12,count):320);announce(level,p,kind);return true;
 }
 public static boolean testHorde(ServerPlayer p,int kind){ServerLevel level=p.serverLevel();if(!eligible(p)||!level.dimension().equals(Level.OVERWORLD)||level.getDifficulty()==Difficulty.PEACEFUL||!level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING))return false;
  HordeData d=HordeData.get(level);d.tickets.removeIf(t->t.pos.distSqr(p.blockPosition())<80*80);d.setDirty();return start(level,d,p,kind,level.players().stream().filter(HordeEvents::eligible).toList(),level.getGameTime());
 }
 public static int stopHordes(ServerPlayer p){HordeData d=HordeData.get(p.serverLevel());int before=d.tickets.size();d.tickets.removeIf(t->t.pos.distSqr(p.blockPosition())<80*80);d.setDirty();return before-d.tickets.size();}
 public static void recordGunShot(ServerPlayer p,double range){ServerLevel level=p.serverLevel();if(!eligible(p)||!level.dimension().equals(Level.OVERWORLD)||level.getDifficulty()==Difficulty.PEACEFUL||!level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING)||!Double.isFinite(range)||range<=0)return;
  Noise n=noise.computeIfAbsent(p.getUUID(),id->new Noise());n.score+=HordeRules.quietGun(range)?1:5;long now=level.getGameTime();if(now>=n.nextGunAlert){n.nextGunAlert=now+20;alert(level,p.blockPosition(),p,HordeRules.hearing(range),now+600,false);}
 }
 private static void listen(ServerLevel level,HordeData data,ServerPlayer p,long now){Noise n=noise.computeIfAbsent(p.getUUID(),id->new Noise());n.score=Math.max(0,n.score-.35);
  for(SoundTracker.SoundRecord r:SoundTracker.getNearbySounds(level,p.blockPosition(),12)){
   if(r.soundId==null||r.range<=0)continue;String id=r.soundId.toLowerCase(Locale.ROOT);
   boolean gun=id.startsWith("tacz:gun#")&&id.contains("/shoot");boolean explosion=id.contains("explode")||id.contains("explosion");
   boolean mine=id.contains(p.getUUID().toString())||(r instanceof SoundTracker.VirtualSoundRecord v&&p.getUUID().equals(v.sourcePlayer));
   if(!mine&&!explosion)continue;
   if(heard.containsKey(r))continue;heard.put(r,now+Math.max(20,r.ticksRemaining)+20);
   double radius=HordeRules.hearing(r.range);alert(level,r.pos,p,radius,now+600,false);
   if(explosion)n.score+=8;else if(!gun&&r.range>=24)n.score+=2;
  }
  List<Zombie> nearby=level.getEntitiesOfClass(Zombie.class,p.getBoundingBox().inflate(28),Zombie::isAlive);
  boolean moving=p.getDeltaMovement().horizontalDistanceSqr()>.025||p.isSprinting();
  if(moving&&!p.isCrouching()&&nearby.size()>=6){n.score+=1.5;alert(level,p.blockPosition(),p,40,now+240,false);}
  if(n.score>=cfg().noiseThreshold&&now>=n.next){if(startSmall(level,data,p,0,cfg().noiseZombies,now)){n.next=now+cfg().noiseCooldownTicks;}n.score=0;}
 }
 private static void alert(ServerLevel level,BlockPos pos,ServerPlayer p,double radius,long until,boolean heli){alert(level,pos,p,radius,until,heli,320);}
 private static void alert(ServerLevel level,BlockPos pos,ServerPlayer p,double radius,long until,boolean heli,int cap){AABB box=new AABB(pos).inflate(radius);List<Zombie> mobs=level.getEntitiesOfClass(Zombie.class,box,z->z.isAlive()&&z.blockPosition().distSqr(pos)<=radius*radius);if(cap<320)mobs.sort(Comparator.comparingDouble(z->z.blockPosition().distSqr(pos)));int count=0;for(Zombie z:mobs){if(count++>=cap)break;var tag=data(z);if(!heli&&tag.getBoolean("zh_heli")&&tag.getLong("zh_until")>level.getGameTime())continue;tag.putLong("zh_pos",pos.asLong());tag.putLong("zh_until",until);tag.putUUID("zh_player",p.getUUID());tag.putBoolean("zh_heli",heli);}}
 private static void waves(ServerLevel level,HordeData data,List<ServerPlayer> players,long now){int total=0;for(Entity e:level.getAllEntities())if(e instanceof Zombie&&data(e).getBoolean("zh_spawned")&&e.isAlive())total++;
  int attemptsBudget=48;
  Iterator<HordeData.Ticket> it=data.tickets.iterator();while(it.hasNext()){
   HordeData.Ticket t=it.next();if(t.remaining<=0||now-t.created>9600){it.remove();data.setDirty();continue;}if(t.next>now)continue;
   ServerPlayer p=level.getServer().getPlayerList().getPlayer(t.player);if(p==null||p.serverLevel()!=level||!eligible(p)){it.remove();data.setDirty();continue;}
   t.next=now+(t.kind==1?cfg().nightWaveIntervalTicks:40);data.setDirty();
   if(t.kind==2&&now-t.created<=800){t.pos=p.blockPosition();alert(level,t.pos,p,192,now+100,true);}
   if(t.pos.distSqr(p.blockPosition())>192*192)continue;
   int nearby=level.getEntitiesOfClass(Zombie.class,new AABB(t.pos).inflate(96),Zombie::isAlive).size();
   int quota=Math.min(t.kind==1?cfg().nightWaveSize:cfg().zombiesPerWave,Math.min((t.kind==3?cfg().dayNearbyLimit:cfg().maxNearbyZombies)-nearby,cfg().maxEventZombiesPerLevel-total));
   for(int i=0;i<quota&&t.remaining>0&&attemptsBudget>0;i++){
    boolean success=false;for(int tries=0;tries<6&&attemptsBudget>0;tries++){attemptsBudget--;if(spawn(level,t,p,players,now)){success=true;break;}}
    if(success){t.remaining--;total++;data.setDirty();}
   }
  }
 }
 private static boolean spawn(ServerLevel level,HordeData.Ticket t,ServerPlayer p,List<ServerPlayer> players,long now){double angle=level.random.nextDouble()*Math.PI*2;int radius=32+level.random.nextInt(33);int x=t.pos.getX()+(int)(Math.cos(angle)*radius),z=t.pos.getZ()+(int)(Math.sin(angle)*radius);BlockPos column=new BlockPos(x,t.pos.getY(),z);if(!level.hasChunkAt(column))return false;
  BlockPos pos=level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,column);
  if(!level.getWorldBorder().isWithinBounds(pos)||players.stream().anyMatch(q->q.distanceToSqr(pos.getX()+.5,pos.getY(),pos.getZ()+.5)<24*24)||Math.abs(pos.getY()-t.pos.getY())>28)return false;
  if(!level.getBlockState(pos.below()).isValidSpawn(level,pos.below(),EntityType.ZOMBIE)||!level.getFluidState(pos).isEmpty())return false;
  EntityType<?> type=pick(level,pos);Entity e=type.create(level);if(!(e instanceof Zombie mob))return false;
  mob.moveTo(pos.getX()+.5,pos.getY(),pos.getZ()+.5,level.random.nextFloat()*360,0);
  if(!level.noCollision(mob)||!level.getFluidState(pos.above()).isEmpty())return false;
  mob.finalizeSpawn(level,level.getCurrentDifficultyAt(pos),MobSpawnType.EVENT,null);
  mob.setCanPickUpLoot(false);var tag=data(mob);tag.putBoolean("zh_spawned",true);if(t.kind!=3){tag.putLong("zh_pos",t.pos.asLong());tag.putLong("zh_until",now+(t.kind==2?1800:1200));tag.putUUID("zh_player",p.getUUID());tag.putBoolean("zh_heli",t.kind==2&&now-t.created<=800);}
  attributes(mob,HordeRules.night(level.getDayTime()));return level.addFreshEntity(mob);
 }
 private static EntityType<?> pick(ServerLevel level,BlockPos pos){if(level.random.nextFloat()<.85f)return EntityType.ZOMBIE;
  ResourceLocation biome=level.getBiome(pos).unwrapKey().map(k->k.location()).orElse(ResourceLocation.withDefaultNamespace("plains"));
  List<EntityType<?>> pool=pools.computeIfAbsent(biome,key->{List<EntityType<?>> list=new ArrayList<>();String path=key.getPath();
   for(EntityType<?> type:BuiltInRegistries.ENTITY_TYPE){ResourceLocation id=BuiltInRegistries.ENTITY_TYPE.getKey(type);if(!id.getNamespace().equals("zombie_variants"))continue;
    String name=id.getPath().replace("_zombie","").replace("zombie_","");if(path.contains(name))list.add(type);
   }return list;});return pool.isEmpty()?EntityType.ZOMBIE:pool.get(level.random.nextInt(pool.size()));
 }
 private static void configureAwareness(){if(awarenessConfigured)return;awarenessConfigured=true;try{Class<?> c=Class.forName("com.corosus.zombieawareness.config.ZAConfigGeneral");c.getField("soundStrength").setInt(null,90);c.getField("maxPFRangeSense").setInt(null,96);c.getField("findSense_PercentChance").setInt(null,25);c.getField("tickCooldownBetweenPathfinds").setInt(null,100);c.getField("noisyZombiesReinforceOddsTo1").setInt(null,3);}catch(ClassNotFoundException e){/* Optional integration. */}catch(ReflectiveOperationException e){System.err.println("[zomboid_hordes] Zombie Awareness integration unavailable: "+e);}}
 private static final class Noise {double score;long next,nextGunAlert;}
}
