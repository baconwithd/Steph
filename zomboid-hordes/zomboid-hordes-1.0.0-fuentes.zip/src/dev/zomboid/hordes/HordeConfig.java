package dev.zomboid.hordes;
import com.google.gson.GsonBuilder;import java.nio.file.*;import java.io.*;
public final class HordeConfig {
 public double helicopterChance=0.15;
 public int helicopterZombies=220, helicopterExtraPerPlayer=80, helicopterMaximum=400;
 public int nightZombies=32, noiseZombies=24;
 public int maxNearbyZombies=180, maxEventZombiesPerLevel=320, zombiesPerWave=8;
 public int noiseCooldownTicks=2400, noiseThreshold=12;
 public double daySpeed=-0.12, dayDamage=-0.15;
 public double nightSpeed=0.15, nightDamage=0.25;
 public static HordeConfig load(){Path p=Path.of("config","zomboid-hordes.json");var gson=new GsonBuilder().setPrettyPrinting().create();
  try {if(Files.exists(p)){var c=gson.fromJson(Files.readString(p),HordeConfig.class);if(c==null)throw new IOException("Empty config");c.validate();return c;}
   Files.createDirectories(p.getParent());var c=new HordeConfig();Files.writeString(p,gson.toJson(c));return c;
  }catch(Exception e){throw new IllegalStateException("Invalid config/zomboid-hordes.json: "+e.getMessage(),e);}}
 public void validate(){if(!Double.isFinite(helicopterChance)||helicopterChance<0||helicopterChance>1)throw new IllegalArgumentException("helicopterChance must be 0..1");
  if(helicopterZombies<1||helicopterZombies>1000||helicopterMaximum<helicopterZombies||helicopterMaximum>2000||helicopterExtraPerPlayer<0||helicopterExtraPerPlayer>1000||nightZombies<1||nightZombies>200||noiseZombies<1||noiseZombies>200||maxNearbyZombies<16||maxNearbyZombies>500||maxEventZombiesPerLevel<16||maxEventZombiesPerLevel>1000||zombiesPerWave<1||zombiesPerWave>24||noiseCooldownTicks<200||noiseThreshold<1)throw new IllegalArgumentException("Invalid horde limits");
  for(double v:new double[]{daySpeed,dayDamage,nightSpeed,nightDamage})if(!Double.isFinite(v)||v<=-0.9||v>1)throw new IllegalArgumentException("Attribute multipliers must be > -0.9 and <= 1");
 }
}
