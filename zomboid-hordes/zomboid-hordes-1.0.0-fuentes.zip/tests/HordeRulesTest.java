import dev.zomboid.hordes.*;
public final class HordeRulesTest {
 private static int checks;private static void ok(boolean b,String name){checks++;if(!b)throw new AssertionError(name);}
 public static void main(String[] args){
  ok(!HordeRules.night(12999),"last daylight tick");ok(HordeRules.night(13000),"night begins");ok(HordeRules.night(22999),"last night tick");ok(!HordeRules.night(23000),"dawn");ok(!HordeRules.night(24000),"next day");
  int wins=0;for(int i=0;i<1000;i++)if(HordeRules.helicopter(i/1000.0,.15))wins++;ok(wins==150,"exact 15 percent threshold");ok(!HordeRules.helicopter(.15,.15),"boundary does not win");
  ok(HordeRules.newDay(0,Long.MIN_VALUE),"first login");ok(!HordeRules.newDay(23999,0),"no reroll same day after reconnect/restart");ok(HordeRules.newDay(24000,0),"roll new day");ok(!HordeRules.newDay(0,5),"clock rollback cannot farm events");ok(HordeRules.newDay(24000L*10,5),"skipped days do not stack rolls");
  for(long now:new long[]{0,1000,15000,23979,23999,24000,47999})for(int r:new int[]{0,5000,10000}){long at=HordeRules.schedule(now,r);ok(at>=now&&Math.floorDiv(at,24000)==Math.floorDiv(now,24000),"schedule remains in its rolled day");}
  ok(HordeRules.budget(220,1,80,400)==220,"solo helicopter");ok(HordeRules.budget(220,2,80,400)==300,"two nearby players");ok(HordeRules.budget(220,8,80,400)==400,"multiplayer budget capped");
  ok(HordeRules.hearing(100)==150,"increased noise range");ok(HordeRules.hearing(300)==192,"hearing capped");ok(HordeRules.hearing(20)<HordeRules.hearing(100),"suppressor remains useful");ok(HordeRules.quietGun(40)&&!HordeRules.quietGun(100),"gun noise threshold");
  HordeConfig cfg=new HordeConfig();cfg.validate();ok(cfg.helicopterChance==.15,"default chance");cfg.helicopterChance=Double.NaN;try{cfg.validate();throw new AssertionError("NaN accepted");}catch(IllegalArgumentException expected){checks++;}
  System.out.println("PASS: "+checks+" scheduler, probability, noise, multiplayer and config checks");
 }
}
