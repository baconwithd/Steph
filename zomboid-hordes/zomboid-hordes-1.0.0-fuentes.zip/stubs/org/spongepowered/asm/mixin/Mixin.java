package org.spongepowered.asm.mixin;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) @java.lang.annotation.Target(java.lang.annotation.ElementType.TYPE)
public @interface Mixin {Class<?>[] value() default {}; String[] targets() default {}; int priority() default 1000; boolean remap() default true;}
