import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public final class Compatibility22Test {
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Compatibility check "+n);}
 static ClassNode cls(ZipFile z,String name)throws Exception{ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name)).readAllBytes()).accept(c,0);return c;}
 static MethodNode method(ClassNode c,String name){return c.methods.stream().filter(m->m.name.equals(name)).findFirst().orElseThrow();}
 static boolean call(MethodNode m,String name){for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals(name))return true;return false;}
 public static void main(String[] args)throws Exception{
  try(var legacy=new ZipFile(args[0]);var weight=new ZipFile(args[1]);var melee=new ZipFile(args[2]);var mc=new ZipFile(args[3])){
   var progression=cls(legacy,"dev/zomboidprogression/ProgressionEvents.class");
   ok(method(progression,"updateStamina").desc.equals("(Lnet/minecraft/server/level/ServerPlayer;II)V"));
   ok(call(method(progression,"onPlayerTick"),"updateStamina"));
   ok(method(progression,"staminaPercent").desc.equals("(Lnet/minecraft/world/entity/player/Player;)D"));
   String desc="(Lnet/minecraft/client/gui/GuiGraphics;IIIIDIII)V";ok(method(progression,"drawVerticalBar").desc.equals(desc));
   int bars=0;for(var i:method(progression,"onHud").instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals("drawVerticalBar")){ok(x.desc.equals(desc));bars++;}ok(bars==2);
   var mixin=cls(weight,"com/armilp/ezweight/stamina/mixin/ProgressionStaminaMixin.class");
   ok(call(method(mixin,"ezs$oneAuthority"),"cancel"));ok(call(method(mixin,"ezs$oneValue"),"getStaminaPercent"));ok(call(method(mixin,"ezs$oneValue"),"setReturnValue"));
   var redirect=method(mixin,"ezs$hideDuplicate");ok(redirect.desc.equals(desc));ok(redirect.instructions.size()<6);
   AnnotationNode at=(AnnotationNode)redirect.visibleAnnotations.getFirst().values.get(3);ok(at.values.contains("ordinal")&&at.values.contains(0));
   var hud=method(cls(weight,"com/armilp/ezweight/stamina/StaminaHudOverlay.class"),"onRender");ok(call(hud,"fill"));ok(!call(hud,"blit"));
   var shove=method(cls(melee,"dev/zomboidmelee/combat/ShoveCombat.class"),"push");boolean reduced=false;for(var i:shove.instructions.toArray())if(i instanceof LdcInsnNode x&&x.cst.equals(.55d))reduced=true;ok(reduced);
   var nativeStock=cls(melee,"dev/zomboidmelee/combat/NativeStockAnimation.class");boolean stock=false,wrong=false;for(var m:nativeStock.methods)for(var i:m.instructions.toArray())if(i instanceof LdcInsnNode x){stock|="bayonet_stock".equals(x.cst);wrong|="bayonet_push".equals(x.cst);}ok(stock&&!wrong);
   var hand=cls(mc,"net/minecraft/client/renderer/ItemInHandRenderer.class");ok(method(hand,"renderArmWithItem").desc.equals("(Lnet/minecraft/client/player/AbstractClientPlayer;FFLnet/minecraft/world/InteractionHand;FLnet/minecraft/world/item/ItemStack;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"));
   ok(call(method(cls(melee,"dev/zomboidmelee/mixin/VanillaPushPoseMixin.class"),"zpush$stock"),"pose"));
  }
  System.out.println("PASS: "+n+" exact legacy stamina suppression, single HUD, preserved weight draw, stock animation and reduced knockback checks");
 }
}
