package net.neoforged.neoforge.client.extensions.common;
public interface IClientItemExtensions {
 static IClientItemExtensions of(net.minecraft.world.item.ItemStack s){return new Extension();}
 Object getCustomRenderer();
 class Extension implements IClientItemExtensions {public Object getCustomRenderer(){return new Renderer();}}
 class Renderer {public com.tacz.guns.api.TimelessAPI.Machine getStateMachine(net.minecraft.world.item.ItemStack s){return com.tacz.guns.api.TimelessAPI.machine;}}
}
