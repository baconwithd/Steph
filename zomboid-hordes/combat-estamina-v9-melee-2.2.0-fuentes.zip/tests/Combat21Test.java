import com.armilp.ezweight.stamina.*;import dev.zomboidmelee.combat.CombatRules;
public class Combat21Test {
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Check "+n);}
 public static void main(String[] a){
  var empty=new StaminaRules.State(0,true,40);for(int t=0;t<20;t++)empty=StaminaRules.tick(empty,true,true,true);ok(empty.locked());ok(!StaminaRules.canSpend(empty,StaminaRules.JUMP));
  var recovered=new StaminaRules.State(600,false,0);for(int t=0;t<100;t++)recovered=StaminaRules.tick(recovered,true,false,true);ok(recovered.energy()==500);ok(recovered.delay()==40);
  ok(StaminaRules.MAX==3000);var s=new StaminaRules.State(3,false,0);
  for(int t=0;t<3;t++)s=StaminaRules.tick(s,true,false,true);
  ok(s.energy()==0&&s.locked());ok(!StaminaRules.canSpend(s,StaminaRules.JUMP));
  int lockedTicks=0;while(s.locked()){
   ok(!StaminaRules.canSpend(s,StaminaRules.SHOVE));double before=s.energy();s=StaminaRules.tick(s,true,false,false);lockedTicks++;
   if(s.energy()<600)ok(s.locked());ok(s.energy()>=before);if(lockedTicks>1000)throw new AssertionError("Never recovers");
  }ok(s.energy()>=600);ok(lockedTicks>=StaminaRules.REST+120);
  s=new StaminaRules.State(60,false,0);s=StaminaRules.spend(s,StaminaRules.NORMAL);ok(s.energy()==0&&s.locked()&&s.delay()==40);
  s=new StaminaRules.State(59,false,0);ok(!StaminaRules.canSpend(s,StaminaRules.NORMAL));ok(StaminaRules.HEAVY==StaminaRules.NORMAL*2);
  s=new StaminaRules.State(3000,false,0);for(int t=0;t<3000;t++)s=StaminaRules.tick(s,true,false,true);ok(s.energy()==0&&s.locked());
  for(int t=0;t<30000;t++){s=StaminaRules.tick(s,true,t%7==0,true);ok(s.energy()>=0&&s.energy()<=3000);if(s.locked())ok(!StaminaRules.canSpend(s,StaminaRules.JUMP));}
  s=new StaminaRules.State(3000,false,0);for(int t=0;t<10000;t++)s=StaminaRules.tick(s,false,false,false);ok(s.energy()==3000);
  for(int original:new int[]{4,12,16,24,40}){ok(CombatRules.cooldown(original,false)==(int)Math.ceil(original*.75));ok(CombatRules.cooldown(original,true)==original);ok(CombatRules.delay(original,false)<=original);}
  ok(CombatRules.damage(10,true)==15);ok(CombatRules.damage(10,false)==10);ok(CombatRules.STUN==15&&CombatRules.SHOVE_COOLDOWN==15);
  ok(CombatRules.inCone(2,1));ok(!CombatRules.inCone(2,-1));ok(!CombatRules.inCone(4,1));
  System.out.println("PASS: "+n+" capacity, exhaustion/recovery latch, continuous sprint, jump/attack costs, normal timing and +50% heavy damage checks");
 }
}
