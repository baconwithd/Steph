import com.tacz.guns.api.TimelessAPI;import dev.zomboidmelee.combat.*;
public final class NativeAnimation22Test {
 static int checks;static void ok(boolean b){checks++;if(!b)throw new AssertionError("Native animation "+checks);}
 public static void main(String[] a){
  ok(NativeStockAnimation.play(null));ok("bayonet_stock".equals(TimelessAPI.machine.trigger));ok("melee_stock".equals(TimelessAPI.machine.controller.prototype.name));
  ok(NativeStockAnimation.play(null));ok(TimelessAPI.machine.controller.registered==1);
  TimelessAPI.gun=false;TimelessAPI.machine=new TimelessAPI.Machine();ok(NativeStockAnimation.play(null));
  ok(TimelessAPI.machine.controller.runs==1);ok(TimelessAPI.machine.controller.track==1&&!TimelessAPI.machine.controller.blend);ok("melee_stock".equals(TimelessAPI.machine.controller.name));
  TimelessAPI.machine=null;ok(!NativeStockAnimation.play(null));
  ok(StockMotion.at(0).equals(new StockMotion.Frame(0,0,0,0,0,0)));ok(StockMotion.at(StockMotion.LENGTH).equals(StockMotion.at(0)));
  for(int i=1;i<710;i++){var f=StockMotion.at(i/1000.0);ok(Double.isFinite(f.x())&&Double.isFinite(f.y())&&Double.isFinite(f.z())&&Float.isFinite(f.rx()));}
  var impact=StockMotion.at(.125);ok(impact.rx()>140&&impact.rz()>75&&impact.z()<-.43);
  System.out.println("PASS: "+checks+" mocked native rifle stock insertion/reuse, gun trigger, melee playback and stock keyframe checks");
 }
}
