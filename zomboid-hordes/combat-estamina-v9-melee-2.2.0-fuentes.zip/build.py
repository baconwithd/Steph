from pathlib import Path
import subprocess,zipfile,json,argparse
root=Path(__file__).resolve().parent;ws=root.parent.parent
mc=ws/'attachments/1338682b-fcc2-4d11-9002-1714ece5faed/client-1.21.1-20240808.144430-srg.jar';neo=ws/'attachments/31294bde-ea70-4506-8023-e3eaaf3a59ac/neoforge-21.1.255-universal.jar';lr=ws/'attachments/c534c9db-a999-45a6-9229-53729c01cad1/LesRaisins-Tactical-Equipements-1.21.1-0.4.3-zomboid-jsononly-safe.jar'
p=argparse.ArgumentParser()
p.add_argument('--minecraft',default=str(mc));p.add_argument('--neoforge',default=str(neo));p.add_argument('--lrtactical',default=str(lr));p.add_argument('--libs',default=str(ws/'work/lib'))
p.add_argument('--weight',default=str(ws/'attachments/642608df-cd5f-4121-8131-3653d0cee03c/eZWeight-neoforge-1.21.1-1.8.4-stamina-v7-balanced.jar'))
p.add_argument('--melee',default=str(ws/'attachments/68cc6356-3492-4772-b637-f669135e9686/zomboid-global-melee-animations-2.0.0-native-bat.jar'))
p.add_argument('--out-dir',default=str(ws/'outputs'));a=p.parse_args();mc=Path(a.minecraft);neo=Path(a.neoforge);lr=Path(a.lrtactical)
libs=[str(p) for p in Path(a.libs).glob('*.jar')];ecj=Path(a.libs)/'ecj.jar';output=Path(a.out_dir);output.mkdir(parents=True,exist_ok=True)
for kind in ('weight','melee'):
 (root/('classes-'+kind)).mkdir(exist_ok=True)
 cp=':'.join([str(mc),str(neo),str(lr),str(root/'classes-weight')]+libs)
 sources=[str(p) for p in (root/('src-'+kind)).rglob('*.java')]
 subprocess.run(['java','-jar',str(ecj),'-21','-proc:none','-warn:none','-cp',cp,'-sourcepath',str(root/('src-'+kind))+':'+str(root/'stubs'),'-d',str(root/('classes-'+kind))]+sources,check=True)
originals={'weight':Path(a.weight),'melee':Path(a.melee)}
for kind in ('weight','melee'):
 name='eZWeight-neoforge-1.21.1-1.8.4-stamina-v9-combat.jar' if kind=='weight' else 'zomboid-global-melee-animations-2.2.0-stock-shove-hud.jar'
 overrides={}
 package='com/armilp/ezweight/stamina' if kind=='weight' else 'dev/zomboidmelee'
 for p in (root/('classes-'+kind)/package).rglob('*.class'):overrides[p.relative_to(root/('classes-'+kind)).as_posix()]=p.read_bytes()
 with zipfile.ZipFile(originals[kind]) as old:
  toml=old.read('META-INF/neoforge.mods.toml').decode()
  if kind=='weight':
   toml=toml.replace('1.8.4-stamina-v7','1.8.4-stamina-v9')+'\n[[mixins]]\nconfig="ezweight_stamina.mixins.json"\n'
   overrides['ezweight_stamina.mixins.json']=json.dumps({'required':True,'minVersion':'0.8','package':'com.armilp.ezweight.stamina.mixin','compatibilityLevel':'JAVA_21','mixins':['ExhaustionMixin','ProgressionStaminaMixin'],'injectors':{'defaultRequire':1}},indent=2).encode()
  else:
   toml=toml.replace('version="2.0.0"','version="2.2.0"')+'\n[[dependencies.zomboid_global_melee]]\nmodId="ezweight"\ntype="required"\nversionRange="[1.8.4-stamina-v9]"\nordering="AFTER"\nside="BOTH"\n'
   d=json.loads(old.read('zomboid_global_melee.mixins.json'));d['mixins']+=['MeleeTimingMixin','MeleeStaminaMixin','VanillaCombatMixin','ShoveStunMixin'];d['client']+=['NativePushKeyMixin','MeleePushPoseMixin','VanillaPushPoseMixin','GunPushPoseMixin'];overrides['zomboid_global_melee.mixins.json']=json.dumps(d,indent=2).encode()
  overrides['META-INF/neoforge.mods.toml']=toml.encode()
  with zipfile.ZipFile(output/name,'w',zipfile.ZIP_DEFLATED) as z:
   for n in old.namelist():
    if n not in overrides:z.writestr(n,old.read(n))
   for n,b in overrides.items():z.writestr(n,b)
 print('Built',name)
