package com.armilp.ezweight.stamina;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
@net.neoforged.fml.common.EventBusSubscriber(modid="ezweight",value=net.neoforged.api.distmarker.Dist.CLIENT)
public final class StaminaHudOverlay {
 @net.neoforged.bus.api.SubscribeEvent
 public static void onRender(RenderGuiEvent.Post e){
  var mc=Minecraft.getInstance();if(mc.player==null||mc.options.hideGui||mc.player.isSpectator()||mc.player.isCreative())return;
  GuiGraphics g=e.getGuiGraphics();double percent=StaminaCommon.getStaminaPercent(mc.player);
  int x=Math.min(g.guiWidth()-9,g.guiWidth()/2+116),bottom=g.guiHeight()-16,height=54;
  int top=Math.max(2,bottom-height),fill=(int)Math.round((bottom-top-2)*percent);
  int color=StaminaCommon.exhausted(mc.player)?0xffff5555:percent>.55?0xff45ff45:percent>.25?0xffffff00:0xffff5555;
  // One vertical stamina bar; the progression mod keeps only its weight bar beside it.
  g.fill(x-1,top-1,x+6,bottom+1,0xcc000000);g.fill(x,top,x+5,bottom,0x99111111);
  if(fill>0)g.fill(x+1,bottom-1-fill,x+4,bottom-1,color);
 }
 @net.neoforged.bus.api.SubscribeEvent
 public static void disconnected(net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut e){StaminaCommon.clearClient();}
}
