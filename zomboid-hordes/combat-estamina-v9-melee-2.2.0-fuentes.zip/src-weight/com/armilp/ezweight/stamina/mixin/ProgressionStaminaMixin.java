package com.armilp.ezweight.stamina.mixin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import com.armilp.ezweight.stamina.StaminaCommon;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Pseudo @Mixin(targets="dev.zomboidprogression.ProgressionEvents",remap=false)
public abstract class ProgressionStaminaMixin {
 @Inject(method="updateStamina",at=@At("HEAD"),cancellable=true,require=0,remap=false)
 private static void ezs$oneAuthority(ServerPlayer p,int fitness,int sprinting,CallbackInfo ci){ci.cancel();}
 @Inject(method="staminaPercent",at=@At("HEAD"),cancellable=true,require=0,remap=false)
 private static void ezs$oneValue(Player p,CallbackInfoReturnable<Double> cir){cir.setReturnValue(StaminaCommon.getStaminaPercent(p));}
 @Redirect(method="onHud",at=@At(value="INVOKE",target="Ldev/zomboidprogression/ProgressionEvents;drawVerticalBar(Lnet/minecraft/client/gui/GuiGraphics;IIIIDIII)V",ordinal=0,remap=false),require=0,remap=false)
 private static void ezs$hideDuplicate(net.minecraft.client.gui.GuiGraphics g,int x,int y,int w,int h,double percent,int high,int medium,int low){}
}
