package dev.zomboidmelee.mixin;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemInHandRenderer.class)
public abstract class VanillaPushPoseMixin {
 @Unique private final java.util.ArrayDeque<Boolean> zpush$frames=new java.util.ArrayDeque<>();
 @Inject(method="renderArmWithItem",at=@At("HEAD"))
 private void zpush$stock(AbstractClientPlayer player,float partial,float pitch,InteractionHand hand,float swing,ItemStack item,float equip,PoseStack pose,MultiBufferSource buffers,int light,CallbackInfo ci){
  boolean active=player instanceof LocalPlayer p&&hand==InteractionHand.MAIN_HAND&&dev.zomboidmelee.combat.PushClient.needsPose()&&dev.zomboidmelee.combat.PushClient.wave(p,partial)>0;
  zpush$frames.push(active);if(active){pose.pushPose();dev.zomboidmelee.combat.PushClient.pose((LocalPlayer)player,partial,pose);}
 }
 @Inject(method="renderArmWithItem",at=@At("RETURN"))
 private void zpush$restore(AbstractClientPlayer player,float partial,float pitch,InteractionHand hand,float swing,ItemStack item,float equip,PoseStack pose,MultiBufferSource buffers,int light,CallbackInfo ci){if(zpush$frames.pop())pose.popPose();}
}
