package dev.zomboidmelee.combat;
import net.minecraft.world.item.ItemStack;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;
public final class NativeStockAnimation {
 private static final Set<Object> PROVIDED=Collections.newSetFromMap(new WeakHashMap<>());
 private static boolean warned;
 public static boolean play(ItemStack stack){
  try{
   Object display=((Optional<?>)Class.forName("com.tacz.guns.api.TimelessAPI").getMethod("getGunDisplay",ItemStack.class).invoke(null,stack)).orElse(null);
   boolean gun=display!=null;Object machine;
   if(gun)machine=display.getClass().getMethod("getAnimationStateMachine").invoke(display);
   else{
    Object extension=Class.forName("net.neoforged.neoforge.client.extensions.common.IClientItemExtensions").getMethod("of",ItemStack.class).invoke(null,stack);
    Object renderer=Class.forName("net.neoforged.neoforge.client.extensions.common.IClientItemExtensions").getMethod("getCustomRenderer").invoke(extension);
    // Use the public interface method even when the extension implementation is anonymous.
    machine=renderer.getClass().getMethod("getStateMachine",ItemStack.class).invoke(renderer,stack);
   }
   if(machine==null)return false;
   Object controller=machine.getClass().getMethod("getAnimationController").invoke(machine);
   if(!PROVIDED.contains(controller)){
    var animations=(List<?>)Class.forName("com.tacz.guns.client.resource.InternalAssetLoader").getMethod("getDefaultRifleAnimations").invoke(null);
    Object stock=null;for(Object a:animations)if("melee_stock".equals(a.getClass().getField("name").get(a))){stock=a;break;}
    if(stock==null)return false;
    Object original=stock;Constructor<?> copy=stock.getClass().getConstructor(stock.getClass());
    Supplier<Object> supplier=()->{try{return copy.newInstance(original);}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}};
    controller.getClass().getMethod("providePrototypeIfAbsent",String.class,Supplier.class).invoke(controller,"melee_stock",supplier);PROVIDED.add(controller);
   }
   if(gun){machine.getClass().getMethod("trigger",String.class).invoke(machine,"bayonet_stock");return true;}
   boolean[] played={false};Object animationController=controller;
   Consumer<Object> run=context->{try{
    int track=((Number)context.getClass().getMethod("getTrack",int.class,int.class).invoke(context,0,1)).intValue();
    Class<?> playType=Class.forName("com.tacz.guns.api.client.animation.ObjectAnimation$PlayType");
    @SuppressWarnings({"rawtypes","unchecked"}) Object once=Enum.valueOf((Class)playType,"PLAY_ONCE_STOP");
    animationController.getClass().getMethod("setBlending",int.class,boolean.class).invoke(animationController,track,false);
    animationController.getClass().getMethod("runAnimation",int.class,String.class,playType,float.class).invoke(animationController,track,"melee_stock",once,.2f);played[0]=true;
   }catch(ReflectiveOperationException|RuntimeException e){warn(e);}};
   machine.getClass().getMethod("processContextIfExist",Consumer.class).invoke(machine,run);return played[0];
  }catch(NoSuchMethodException e){return false;}catch(ReflectiveOperationException|RuntimeException e){warn(e);return false;}
 }
 private static void warn(Exception e){if(!warned){warned=true;org.slf4j.LoggerFactory.getLogger("ZomboidMelee").warn("Native stock animation unavailable; using shared rifle stock motion",e);}}
}
