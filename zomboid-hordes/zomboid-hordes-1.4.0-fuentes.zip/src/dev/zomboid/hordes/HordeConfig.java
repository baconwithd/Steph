package dev.zomboid.hordes;
import com.google.gson.GsonBuilder;import java.nio.file.*;import java.io.*;
public final class HordeConfig {
 public double helicopterChance=0.15;
 public double chestRestockChance=0.10;
 public int helicopterZombies=480, helicopterExtraPerPlayer=120, helicopterMaximum=800;
 public int nightZombies=80, noiseZombies=100;
 public int maxNearbyZombies=300, maxEventZombiesPerLevel=600, zombiesPerWave=20;
 public int nightExtraPerPlayer=25,nightMaximum=180,nightWaveSize=16,nightWaveIntervalTicks=40;
 public int dayZombies=8,daySpawnIntervalTicks=1200,dayNearbyLimit=60;
 public int balanceVersion=1;
 public int noiseCooldownTicks=2400, noiseThreshold=12;
 public double daySpeed=0.25, dayDamage=-0.15;
 public double nightSpeed=0.40, nightDamage=0.25;
 public static HordeConfig load(){Path p=Path.of("config","zomboid-hordes.json");var gson=new GsonBuilder().setPrettyPrinting().create();
  try {if(Files.exists(p)){var c=gson.fromJson(Files.readString(p),HordeConfig.class);if(c==null)throw new IOException("Empty config");if(c.balanceVersion<4){c.helicopterZombies=480;c.helicopterExtraPerPlayer=120;c.helicopterMaximum=800;c.nightZombies=80;c.noiseZombies=100;c.maxNearbyZombies=300;c.maxEventZombiesPerLevel=600;c.zombiesPerWave=20;c.nightExtraPerPlayer=25;c.nightMaximum=180;c.nightWaveSize=16;c.nightWaveIntervalTicks=40;c.dayZombies=8;c.daySpawnIntervalTicks=1200;c.dayNearbyLimit=60;c.daySpeed=.25;c.nightSpeed=.40;c.balanceVersion=4;c.validate();Files.writeString(p,gson.toJson(c));}c.validate();return c;}
   Files.createDirectories(p.getParent());var c=new HordeConfig();c.balanceVersion=4;Files.writeString(p,gson.toJson(c));return c;
  }catch(Exception e){throw new IllegalStateException("Invalid config/zomboid-hordes.json: "+e.getMessage(),e);}}
 public void validate(){if(!Double.isFinite(chestRestockChance)||chestRestockChance<0||chestRestockChance>1)throw new IllegalArgumentException("chestRestockChance must be 0..1");if(!Double.isFinite(helicopterChance)||helicopterChance<0||helicopterChance>1)throw new IllegalArgumentException("helicopterChance must be 0..1");
  if(nightExtraPerPlayer<0||nightMaximum<1||nightMaximum>200||nightWaveSize<1||nightWaveSize>24||nightWaveIntervalTicks<40||dayZombies<1||dayZombies>10||daySpawnIntervalTicks<1200||dayNearbyLimit<1||dayNearbyLimit>150)throw new IllegalArgumentException("Invalid calm night/day limits");
  if(helicopterZombies<1||helicopterZombies>1000||helicopterMaximum<helicopterZombies||helicopterMaximum>2000||helicopterExtraPerPlayer<0||helicopterExtraPerPlayer>1000||nightZombies<1||nightZombies>200||noiseZombies<1||noiseZombies>200||maxNearbyZombies<16||maxNearbyZombies>500||maxEventZombiesPerLevel<16||maxEventZombiesPerLevel>1000||zombiesPerWave<1||zombiesPerWave>24||noiseCooldownTicks<200||noiseThreshold<1)throw new IllegalArgumentException("Invalid horde limits");
  for(double v:new double[]{daySpeed,dayDamage,nightSpeed,nightDamage})if(!Double.isFinite(v)||v<=-0.9||v>1)throw new IllegalArgumentException("Attribute multipliers must be > -0.9 and <= 1");
 }
}
