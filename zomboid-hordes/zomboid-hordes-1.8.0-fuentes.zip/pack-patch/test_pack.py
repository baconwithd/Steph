import json,zipfile,pathlib,math
src=zipfile.ZipFile(next(pathlib.Path('attachments/1e9105d8-0d3f-4cf7-8980-86464daf3992').glob('*.zip')))
z=zipfile.ZipFile('outputs/Blues-Better-Zombies-v0.13-PZ-smooth.zip')
models=0;texture_count=0
for n in src.namelist():
 assert n in z.namelist(),n
 if n.endswith(('.jem','.jpm')):
  d=json.loads(z.read(n));models+=1
  def check(node):
   if isinstance(node,dict):
    if 'animations' in node:
     allkeys=[k for a in node['animations'] for k in a];assert len(allkeys)==len(set(allkeys)),n
     for a in node['animations']:
      for k,v in a.items():
       if not isinstance(v,str):continue
       assert 'sqrt((death_time - 1)' not in v,(n,k)
       assert 'var.body_bendattack_return' not in v,(n,k)
       if k=='var.body_bend_walk':assert 'var.body_bend -' not in v,(n,k)
    for k,v in node.items():
     if k!='animations':check(v)
   elif isinstance(node,list):
    for a in node:check(a)
  check(d)
 elif n not in ('pack.mcmeta',):
  assert src.read(n)==z.read(n),n
  texture_count+=n.endswith('.png')
# Evaluate the actual patched smooth variables at multiple frame rates.
base=json.loads(z.read('assets/minecraft/optifine/cem/zombie.jem'));expressions={}
def collect(node):
 if isinstance(node,dict):
  for a in node.get('animations',[]):expressions.update(a)
  for k,v in node.items():
   if k!='animations':collect(v)
 elif isinstance(node,list):
  for a in node:collect(a)
collect(base)
keys=['var.pz_walk','var.counter','var.counter2','var.counter3','var.counter4','var.body_bend','var.body_bend_walk','var.haymaker']
snapshots=[]
for fps in (30,60,144):
 state={k:0 for k in keys};maxframe=0
 for frame in range(fps*3):
  t=frame/fps
  env={'frame_time':1/fps,'limb_speed':.10+(.012 if frame%2 else -.012) if t<1 else .25 if t<2 else 0,'swing_progress':.5 if 1<t<1.3 else 0,'pi':math.pi,'min':min,'sin':math.sin,'clamp':lambda x,a,b:max(a,min(b,x))}
  for key in keys:
   expr=expressions[key]
   for k,v in sorted(state.items(),key=lambda kv:-len(kv[0])):expr=expr.replace(k,str(v))
   new=eval(expr,{'__builtins__':{}},env)
   assert math.isfinite(new),(fps,key)
   if key=='var.counter4':maxframe=max(maxframe,abs(new-state[key]))
   state[key]=new
  assert 0<=state['var.counter4']<=45
  assert 0<=state['var.haymaker']<=12.00001
 snapshots.append(state)
 assert maxframe<3,(fps,maxframe)
for key in keys:
 assert max(s[key] for s in snapshots)-min(s[key] for s in snapshots)<.3,key
for death in (0,.05,.2,.5,.99,1,20):assert math.isfinite(math.sqrt(max(0,(death-1)/20*1.6)))
print(f'PASS: {models} models JSON/animation checks, {texture_count} unchanged textures, bounded smooth motion at 30/60/144 FPS, finite early-death rotations')
