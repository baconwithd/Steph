"""Preserves models/textures; smooths render animation variables and removes unsafe expressions."""
import pathlib,zipfile,json,re,collections
source=next(pathlib.Path('attachments/1e9105d8-0d3f-4cf7-8980-86464daf3992').glob('*.zip'))
out=pathlib.Path('outputs/Blues-Better-Zombies-v0.13-PZ-smooth.zip')
changes=collections.Counter();files=0

def fix(key,value):
 if not isinstance(value,str):return value
 original=value
 if key in ('var.counter','var.counter2','var.counter3','var.counter4'):
  target={'var.counter':10,'var.counter2':12,'var.counter3':35,'var.counter4':45}[key]
  value=f'{key} + ({target} * var.pz_walk - {key}) * min(frame_time * 5, 1)'
 elif key=='var.body_bend':value='var.body_bend + (8 + var.pz_walk * 8 - var.body_bend) * min(frame_time * 4, 1)'
 elif key=='var.body_bend_walk':value='var.body_bend_walk + (6 + var.pz_walk * 5 - var.body_bend_walk) * min(frame_time * 4, 1)'
 elif key in ('var.body_punch_right','var.punch_right','var.haymaker','var.body_bend_attack'):
  target={'var.body_punch_right':20,'var.punch_right':18,'var.haymaker':12,'var.body_bend_attack':8}[key]
  value=f'{key} + (sin(swing_progress * pi) * {target} - {key}) * min(frame_time * 10, 1)'
 elif key=='var.walk_bounce':value='var.walk_bounce + (clamp(limb_speed * 2, 0, 1) - var.walk_bounce) * min(frame_time * 5, 1)'
 # Negative sqrt early in the death animation produces NaN rotations.
 value=value.replace('sqrt((death_time - 1) / 20 * 1.6)','sqrt(max(0, (death_time - 1) / 20 * 1.6))')
 value=value.replace('var.body_bendattack_return','0')
 value=value.replace('if(var.distance < var.limit, torad(var.body_bend), torad(var.body_bend_walk))','torad(var.body_bend)')
 value=value.replace('if(var.distance < var.limit, -torad(var.haymaker)*3 , -torad(var.haymaker))','-torad(var.haymaker)')
 # Bound excessively large gait rotations on the trunk/head while retaining each variant's look.
 if key in ('zombie_new_body.rx','zombie_new_skull_head.rx'):
  value=value.replace('limb_speed*0.8','limb_speed*0.18').replace('limb_speed*0.7','limb_speed*0.18')
 # Slow high-frequency idle oscillation; age is continuous across the day/night boundary.
 value=re.sub(r'\btime\b','age',value)
 value=re.sub(r'(sin|cos)\(age\s*\*\s*([0-9.]+)\)',lambda m:f'{m[1]}(age * {min(float(m[2]),.18):g})' if float(m[2])>.35 else m[0],value)
 value=re.sub(r'(sin|cos)\(age\)',r'\1(age * 0.15)',value)
 if value!=original:changes[key]+=1
 return value

def walk(node):
 if isinstance(node,dict):
  if 'animations' in node:
   groups=node['animations'];needs=any(any(k in ('var.counter','var.walk_bounce') for k in a) for a in groups)
   if needs:groups.insert(0,{'var.pz_walk':'var.pz_walk + (clamp(limb_speed * 2, 0, 1) - var.pz_walk) * min(frame_time * 5, 1)'})
   # Preserve the final assignment as CEM normally does; remove duplicate writes per render.
   last={k:i for i,a in enumerate(groups) for k in a}
   for i,a in enumerate(groups):
    for k in list(a):
     if last[k]!=i:del a[k];changes['duplicate_assignments']+=1
     else:a[k]=fix(k,a[k])
   node['animations']=[a for a in groups if a]
  for k,v in node.items():
   if k!='animations':walk(v)
 elif isinstance(node,list):
  for a in node:walk(a)
with zipfile.ZipFile(source) as src,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for name in src.namelist():
  content=src.read(name)
  if name.endswith(('.jem','.jpm')):
   d=json.loads(content);before=json.dumps(d);walk(d)
   if json.dumps(d)!=before:files+=1
   content=json.dumps(d,ensure_ascii=False,separators=(',',':')).encode()
  elif name=='pack.mcmeta':
   d=json.loads(content);d['pack']['description']='§3Blue’s Better Zombies §7v0.13 — PZ smooth patch (1.21.1)';content=json.dumps(d,ensure_ascii=False,indent=2).encode()
  z.writestr(name,content)
 z.writestr('PZ-SMOOTH-LEEME.txt','Parche de animación para Blue\'s Better Zombies v0.13, autor original MrBlueYeti.\nReemplaza el ZIP anterior en resourcepacks y actívalo. Conserva modelos, texturas y variantes.\nSuaviza cambios de postura, corrige una referencia de inclinación, limita ataques acumulados y evita raíces negativas al morir.\nNecesita Entity Model Features y Entity Texture Features compatibles con NeoForge 1.21.1 (o un motor CEM compatible).\nLas texturas y modelos originales mantienen sus condiciones originales. No se ha verificado visualmente en Minecraft.\n')
print('Patched models:',files,'Changed expressions:',sum(changes.values()),'Output:',out)
pathlib.Path('work/pack18/changes.json').write_text(json.dumps(changes,indent=2))
