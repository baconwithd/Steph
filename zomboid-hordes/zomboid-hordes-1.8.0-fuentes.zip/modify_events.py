from pathlib import Path
import json
p=Path('work/hordes17/src/dev/zomboid/hordes/HordeEvents.java');s=p.read_text()
s=s.replace('SoundTracker.getNearbySounds(level,p.blockPosition(),12)', 'SoundTracker.getNearbySounds(level,p.blockPosition(),64)')
s=s.replace('boolean gun=id.startsWith("tacz:gun#")&&id.contains("/shoot");boolean explosion=id.contains("explode")||id.contains("explosion");','boolean gun=NoiseRules.gun(id);boolean explosion=NoiseRules.explosion(id);')
s=s.replace('if(!mine&&!explosion)continue;', 'if(!mine&&!explosion&&!r.isPlayerProduced())continue;')
s=s.replace('double radius=HordeRules.hearing(r.range);alert', 'double radius=NoiseRules.radius(id,r.range,p.isCrouching());alert')
s=s.replace('else if(!gun&&r.range>=24)n.score+=2;', 'else if(!gun)n.score+=.15;')
s=s.replace('if(moving&&!p.isCrouching()&&nearby.size()>=6){n.score+=1.5;alert(level,p.blockPosition(),p,40,now+240,false);}', 'if(moving&&!p.isCrouching()){n.score+=.15;alert(level,p.blockPosition(),p,p.isSprinting()?8:4,now+120,false);}')
s=s.replace('List<Zombie> mobs=level.getEntitiesOfClass(Zombie.class,box,z->z.isAlive()&&z.blockPosition().distSqr(pos)<=radius*radius);', 'List<Mob> mobs=level.getEntitiesOfClass(Mob.class,box,z->z.isAlive()&&ZombieIndividual.supported(z)&&z.blockPosition().distSqr(pos)<=radius*radius);')
s=s.replace('for(Zombie z:mobs){if(count>=cap)', 'for(Mob z:mobs){if(count>=cap)')
s=s.replace(' private static void listen(', ''' public static void quietAction(ServerPlayer p,BlockPos pos,double radius){
  if(!eligible(p)||!(p.serverLevel().dimension().equals(Level.OVERWORLD)))return;
  long now=p.serverLevel().getGameTime();Noise n=noise.computeIfAbsent(p.getUUID(),id->new Noise());
  if(now<n.nextQuiet)return;n.nextQuiet=now+10;n.score+=.15;alert(p.serverLevel(),pos,p,Math.min(8,radius),now+160,false);
 }
 private static void listen(''')
s=s.replace('long next,nextGunAlert;', 'long next,nextGunAlert,nextQuiet;')
# Keep all helicopter and horde budgets unchanged from 1.6.0.
s=s.replace('  List<Zombie> nearby=level.getEntitiesOfClass(Zombie.class,p.getBoundingBox().inflate(28),Zombie::isAlive);\n','')
p.write_text(s)
p=Path('work/hordes17/resources/zomboid_hordes.mixins.json');cfg=json.loads(p.read_text());cfg['mixins'].append('ZombieAwarenessPerceptionMixin');p.write_text(json.dumps(cfg,indent=2))
p=Path('work/hordes17/src/dev/zomboid/hordes/ZombieIndividual.java');s=p.read_text().replace('"FollowerEdgeRelayGoal").contains','"FollowerEdgeRelayGoal","FollowScentGoal").contains').replace('a.addTransientModifier(', 'a.addPermanentModifier(');p.write_text(s)
