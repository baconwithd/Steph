package dev.zomboid.hordes;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
/** Only nearby barriers in the direction of a visible pursuit or remembered noise. */
public final class BarrierBreakGoal extends Goal {
 private final Mob mob;private BlockPos pos;private BlockState original;private int ticks,duration,next;
 public BarrierBreakGoal(Mob mob){this.mob=mob;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
 private boolean grief(){return mob.level() instanceof ServerLevel&&net.neoforged.neoforge.event.EventHooks.canEntityGrief(mob.level(),mob);}
 private Vec3 destination(){
  if(mob.getTarget()!=null&&mob.getTarget().isAlive())return mob.getTarget().position();
  var t=ZombieIndividual.profile(mob);return t.getLong("zh_until")>mob.level().getGameTime()?Vec3.atCenterOf(BlockPos.of(t.getLong("zh_pos"))):null;
 }
 public static boolean glass(BlockState s){String id=BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath();return s.is(BlockTags.IMPERMEABLE)||id.equals("glass_pane")||id.endsWith("_stained_glass_pane")||id.contains("window");}
 private static boolean barrier(BlockState s){return s.getBlock() instanceof DoorBlock||s.getBlock() instanceof TrapDoorBlock||glass(s);}
 @Override public boolean canUse(){
  if(mob.tickCount<next||!grief())return false;next=mob.tickCount+10;Vec3 end=destination();if(end==null)return false;
  var t=ZombieIndividual.profile(mob);if(t.getLong("zc_stun")>mob.level().getGameTime())return false;
  Vec3 delta=end.subtract(mob.position());double length=Math.sqrt(delta.x*delta.x+delta.z*delta.z);if(length<.1)return false;
  BlockPos base=mob.blockPosition();BlockPos best=null;double bestD=Double.MAX_VALUE;
  for(int x=-2;x<=2;x++)for(int y=0;y<=1;y++)for(int z=-2;z<=2;z++){
   BlockPos p=base.offset(x,y,z);if(!mob.level().hasChunkAt(p))continue;BlockState s=mob.level().getBlockState(p);
   if(!barrier(s)||s.getDestroySpeed(mob.level(),p)<0||s.getCollisionShape(mob.level(),p).isEmpty())continue;
   Vec3 c=Vec3.atCenterOf(p).subtract(mob.position());double horizontal=Math.sqrt(c.x*c.x+c.z*c.z),distance=c.length();
   double dot=horizontal<.01?1:(c.x*delta.x+c.z*delta.z)/(horizontal*length);
   if(BarrierRules.onRoute(distance,dot)&&distance<bestD&&horizontal<=length+.5){var hit=mob.level().clip(new net.minecraft.world.level.ClipContext(mob.getEyePosition(),Vec3.atCenterOf(p),net.minecraft.world.level.ClipContext.Block.COLLIDER,net.minecraft.world.level.ClipContext.Fluid.NONE,mob));if(hit.getBlockPos().equals(p)){best=p;bestD=distance;}}
  }
  if(best==null)return false;pos=best.immutable();original=mob.level().getBlockState(pos);
  String id=BuiltInRegistries.BLOCK.getKey(original.getBlock()).getPath();duration=BarrierRules.duration(glass(original),id.contains("iron")||id.contains("metal"),original.getBlock() instanceof TrapDoorBlock);return true;
 }
 @Override public void start(){ticks=0;mob.getNavigation().stop();}
 @Override public boolean canContinueToUse(){return pos!=null&&mob.isAlive()&&grief()&&destination()!=null&&mob.level().getBlockState(pos).equals(original)&&mob.position().distanceToSqr(Vec3.atCenterOf(pos))<=2.25*2.25&&ZombieIndividual.profile(mob).getLong("zc_stun")<=mob.level().getGameTime()&&ticks<duration;}
 @Override public boolean requiresUpdateEveryTick(){return true;}
 @Override public void tick(){
  mob.getNavigation().stop();mob.getLookControl().setLookAt(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5);
  ticks++;if(ticks%20==1){mob.swing(net.minecraft.world.InteractionHand.MAIN_HAND);var sound=original.getSoundType();mob.level().playSound(null,pos,sound.getHitSound(),net.minecraft.sounds.SoundSource.HOSTILE,.8f,.8f);}
  mob.level().destroyBlockProgress(mob.getId(),pos,Math.min(9,ticks*10/duration));
  if(ticks>=duration&&grief()&&mob.level().getBlockState(pos).equals(original)){mob.level().destroyBlock(pos,true,mob);mob.level().destroyBlockProgress(mob.getId(),pos,-1);}
 }
 @Override public void stop(){if(pos!=null)mob.level().destroyBlockProgress(mob.getId(),pos,-1);pos=null;ticks=0;next=mob.tickCount+10;}
}
