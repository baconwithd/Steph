package dev.zomboid.hordes;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.neoforged.neoforge.common.extensions.IEntityExtension;
/** Gives heard locations priority over random wandering without seeing through walls. */
public final class InvestigateNoiseGoal extends Goal {
 private final Mob zombie;private int retry;
 public InvestigateNoiseGoal(Mob z){zombie=z;setFlags(EnumSet.of(Flag.MOVE));}
 private CompoundTag memory(){return ((IEntityExtension)(Object)zombie).getPersistentData();}
 @Override public boolean canUse(){if(zombie.level().isClientSide()||zombie.getTarget()!=null)return false;var t=memory();return t.getLong("zc_stun")<=zombie.level().getGameTime()&&t.getLong("zh_until")>zombie.level().getGameTime()&&zombie.blockPosition().distSqr(BlockPos.of(t.getLong("zh_pos")))>9;}
 @Override public boolean canContinueToUse(){return canUse();}
 @Override public void start(){retry=0;tick();}
 @Override public void tick(){if(retry--<=0){retry=20+ZombieIndividual.profile(zombie).getInt("zi_delay");BlockPos p=BlockPos.of(memory().getLong("zh_pos"));zombie.getNavigation().moveTo(p.getX()+.5,p.getY(),p.getZ()+.5,1.05);}}
 @Override public void stop(){zombie.getNavigation().stop();}
}
