package dev.zomboid.hordes;
import java.util.Locale;
public final class NoiseRules {
 public static boolean gun(String name){String id=name.toLowerCase(Locale.ROOT);return (id.startsWith("tacz:gun#")&&id.contains("/shoot"))||((id.startsWith("cgm:")||id.startsWith("musketmod:"))&&(id.contains("fire")||id.contains("shoot")));}
 public static boolean explosion(String name){String id=name.toLowerCase(Locale.ROOT);return id.contains("explode")||id.contains("explosion");}
 public static double radius(String name,double original,boolean crouch){
  if(!Double.isFinite(original)||original<=0)return 0;
  if(gun(name))return Math.max(12,Math.min(192,original*1.5));
  if(explosion(name))return Math.max(32,Math.min(144,original*1.5));
  String id=name.toLowerCase(Locale.ROOT);
  if(id.contains("step")||id.contains("walk")||id.contains("rustle"))return Math.min(original,crouch?1:4);
  if(id.contains("break")||id.contains("place"))return Math.min(original,crouch?2:4);
  return Math.min(original,8);
 }
 public static double heardRadius(double base,double hearing){return base<=8?Math.min(8,base*hearing):Math.min(192,base*hearing);}
}
