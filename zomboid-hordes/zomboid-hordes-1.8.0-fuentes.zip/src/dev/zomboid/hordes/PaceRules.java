package dev.zomboid.hordes;
/** Mob.setSpeed also sets forward input: ground travel scales with speed squared. */
public final class PaceRules {
 public static int type(double roll){return roll<.40?0:roll<.80?1:roll<.95?2:3;}
 public static double ratio(int type){return switch(type){case 0->.90;case 1->.75;case 2->.55;default->1.0;};}
 public static double navigationSpeed(int type){return Math.sqrt(.1*ratio(type));}
 public static float cap(float requested,int type,boolean night){return Math.min(requested,(float)(navigationSpeed(type)*(night?1:.975)));}
 public static String name(int type){return switch(type){case 0->"normal";case 1->"lento";case 2->"muy lento";default->"rápido";};}
}
