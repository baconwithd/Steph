package dev.zomboid.hordes;
/** Pure balance rules for stable zombie personalities and helicopter pacing. */
public final class IndividualRules {
 public static int type(double roll){return roll<.75?0:roll<.90?1:2;}
 public static double vision(int type,boolean crouch){return crouch?(type==0?1.5:type==1?3.5:10):(type==0?8:type==1?14:24);}
 public static int delay(int type,int roll){return type==0?30+Math.floorMod(roll,41):type==1?10+Math.floorMod(roll,21):Math.floorMod(roll,9);}
 public static double hearing(int type,double roll){return (type==0?.50:type==1?.80:1.10)+Math.max(0,Math.min(1,roll))*.20;}
 public static double chance(int type,double distance,double radius){if(distance>radius)return 0;if(distance<=1.5)return 1;return Math.max(.05,(type==0?.45:type==1?.72:.95)*(1-.45*distance/Math.max(1,radius)));}
 public static boolean inView(int type,double dot,boolean crouch){return dot>=(type==0?(crouch?.70:.55):type==1?.20:-.20);}
 public static boolean smart(int type){return type==2;}
 public static int initial(int base,int players){return Math.min(30,base+Math.max(0,players-1)*4);}
 public static int activeLimit(int base,int players){return Math.min(42,base+Math.max(0,players-1)*6);}
 public static int quota(int wave,int pending,int credits,int nearby,int limit){return Math.max(0,Math.min(Math.min(wave,pending),Math.min(Math.max(0,credits),Math.max(0,limit-nearby))));}
 public static int reward(int credits,int pending){return Math.min(Math.max(0,pending),Math.max(0,credits)+1);}
}
