package dev.zomboid.hordes;
import java.util.EnumSet;import net.minecraft.world.entity.ai.goal.Goal;import net.minecraft.world.entity.Mob;
/** Brief independent pauses only when no target or remembered noise demands attention. */
public final class IndividualIdleGoal extends Goal {
 private final Mob zombie;private long next;private int left;
 public IndividualIdleGoal(Mob z){zombie=z;setFlags(EnumSet.of(Flag.MOVE));}
 private boolean free(){return zombie.getTarget()==null&&ZombieIndividual.profile(zombie).getLong("zh_until")<=zombie.level().getGameTime();}
 @Override public boolean canUse(){long now=zombie.level().getGameTime();if(now<next||!free())return false;next=now+100+zombie.getRandom().nextInt(160);return zombie.getRandom().nextFloat()<(ZombieIndividual.profile(zombie).getInt("zi_type")==0?.65:.20);}
 @Override public void start(){left=20+zombie.getRandom().nextInt(61);zombie.getNavigation().stop();}
 @Override public boolean canContinueToUse(){return left>0&&free();}
 @Override public void tick(){left--;zombie.getNavigation().stop();}
}
