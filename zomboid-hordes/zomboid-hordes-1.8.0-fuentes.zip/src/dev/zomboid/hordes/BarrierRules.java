package dev.zomboid.hordes;
public final class BarrierRules {
 public static int duration(boolean glass,boolean metal,boolean trapdoor){return glass?60:metal?320:trapdoor?120:160;}
 public static boolean onRoute(double distance,double dot){return distance<=2.25&&dot>.70;}
}
