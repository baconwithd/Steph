package dev.zomboid.hordes.mixin;
import dev.zomboid.hordes.ZombieIndividual;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** SoundAttract otherwise installs a second asynchronous block-breaking goal during pursuit. */
@Mixin(targets="com.example.soundattract.ai.BlockBreakerManager",remap=false)
public abstract class BarrierCompatMixin {
 @Inject(method="scheduleAdd(Lnet/minecraft/world/entity/Mob;Lnet/minecraft/world/entity/ai/goal/Goal;I)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void zomboid$barriers(Mob mob,Goal goal,int priority,CallbackInfo ci){if(ZombieIndividual.supported(mob))ci.cancel();}
}
