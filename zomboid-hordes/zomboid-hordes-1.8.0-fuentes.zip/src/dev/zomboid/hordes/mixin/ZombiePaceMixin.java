package dev.zomboid.hordes.mixin;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import dev.zomboid.hordes.*;
/** Caps navigation acceleration even when another goal asks for an excessive multiplier. */
@Mixin(Mob.class)
public abstract class ZombiePaceMixin {
 @ModifyVariable(method="setSpeed(F)V",at=@At("HEAD"),argsOnly=true)
 private float zomboid$pace(float speed){
  Mob mob=(Mob)(Object)this;if(!ZombieIndividual.supported(mob)||mob.level().isClientSide())return speed;
  return PaceRules.cap(speed,ZombieIndividual.profile(mob).getInt("zi_pace"),!mob.level().dimensionType().hasSkyLight()||HordeRules.night(mob.level().getDayTime()));
 }
}
