package dev.zomboid.hordes.mixin;
import net.minecraft.world.entity.Mob;
import dev.zomboid.hordes.ZombieIndividual;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** One perception controller for zombies; other mobs keep Zombie Awareness behavior. */
@Pseudo @Mixin(targets="com.corosus.zombieawareness.ZAUtil",remap=false)
public abstract class ZombieAwarenessPerceptionMixin {
 @Inject(method="tickAI(Lnet/minecraft/world/entity/Mob;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void zomboid$individualPerception(Mob mob,CallbackInfo ci){if(ZombieIndividual.supported(mob))ci.cancel();}
}
