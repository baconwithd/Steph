package dev.zomboid.hordes;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.BlockEvent;
@EventBusSubscriber(modid=ZomboidHordes.ID)
public final class ConstructionNoise {
 @SubscribeEvent public static void placed(BlockEvent.EntityPlaceEvent e){if(e.getEntity() instanceof ServerPlayer p)HordeEvents.quietAction(p,e.getPos(),p.isCrouching()?2:4);}
 @SubscribeEvent public static void broken(BlockEvent.BreakEvent e){if(e.getPlayer() instanceof ServerPlayer p)HordeEvents.quietAction(p,e.getPos(),p.isCrouching()?2:4);}
}
