import dev.zomboid.hordes.*;
import dev.zomboid.remains.*;
public class Balance18Test {
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Check "+n);}
 public static void main(String[] args){
  int[] counts=new int[4];for(int i=0;i<10000;i++)counts[PaceRules.type(i/10000.)]++;
  ok(java.util.Arrays.equals(counts,new int[]{4000,4000,1500,500}));
  for(int kind=0;kind<4;kind++){
   double nav=PaceRules.navigationSpeed(kind);ok(Math.abs(nav*nav/.1-PaceRules.ratio(kind))<.000001);
   for(float boost:new float[]{.1f,.23f,.3f,.5f,1f}){
    float capped=PaceRules.cap(boost,kind,true);ok(capped<=nav+.000001);ok(capped<=boost);ok(PaceRules.cap(boost,kind,false)<=capped);ok(PaceRules.cap(boost*.5f,kind,true)<=capped);
   }
  }
  ok(PaceRules.ratio(1)==.75);ok(PaceRules.ratio(3)==1);ok(PaceRules.ratio(0)<1);
  ok(BarrierRules.duration(true,false,false)==60);ok(BarrierRules.duration(false,false,false)==160);ok(BarrierRules.duration(false,true,true)==320);
  ok(BarrierRules.onRoute(2,1));ok(!BarrierRules.onRoute(3,1));ok(!BarrierRules.onRoute(2,-1));
  for(int q=0;q<5;q++){
   int min=ExtraLootRules.ammoMin(q),max=ExtraLootRules.ammoMax(q);ok(min>=15&&max<=128&&min<=max);
   for(int amount=min;amount<=max;amount++){int first=Math.min(amount,64),second=amount-first;ok(first+second==amount&&first<=64&&second<=64);}
   ok(ExtraLootRules.militaryChance(q,false,false)<=.08);ok(ExtraLootRules.militaryChance(q,true,false)>ExtraLootRules.militaryChance(q,false,false));ok(ExtraLootRules.backpack(q).startsWith("sophisticatedbackpacks:"));
  }
  System.out.println("PASS: "+n+" pace distribution, vanilla movement math, speed caps, barrier durations and 15–128 ammo rules");
 }
}
