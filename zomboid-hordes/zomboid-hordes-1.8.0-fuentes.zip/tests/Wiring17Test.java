import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Wiring17Test {
 static int n;static void ok(boolean x){n++;if(!x)throw new AssertionError("Integration "+n);}
 static ClassNode cls(ZipFile z,String name)throws Exception {ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name)).readAllBytes()).accept(c,0);return c;}
 static boolean calls(ClassNode c,String name,String target){for(var m:c.methods)if(m.name.equals(name))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals(target))return true;return false;}
 public static void main(String[] a)throws Exception {
  try(ZipFile z=new ZipFile(a[0]);ZipFile za=new ZipFile(a[1])){
   String p="dev/zomboid/hordes/";var individual=cls(z,p+"ZombieIndividual.class");
   ok(calls(individual,"sees","inView"));ok(calls(individual,"hear","heardRadius"));ok(calls(individual,"target","sees"));ok(calls(individual,"stat","addPermanentModifier"));ok(calls(individual,"tick","setXRot"));ok(calls(individual,"tick","supported"));
   var events=cls(z,p+"HordeEvents.class");ok(calls(events,"listen","radius"));ok(calls(events,"quietAction","alert"));ok(calls(events,"killed","reward"));ok(calls(events,"waves","quota"));
   var construction=cls(z,p+"ConstructionNoise.class");ok(calls(construction,"placed","quietAction"));ok(calls(construction,"broken","quietAction"));
   ok(cls(za,"com/corosus/zombieawareness/ZAUtil.class").methods.stream().anyMatch(m->m.name.equals("tickAI")&&m.desc.equals("(Lnet/minecraft/world/entity/Mob;)V")));
   var mix=cls(z,p+"mixin/ZombieAwarenessPerceptionMixin.class");ok(calls(mix,"zomboid$individualPerception","cancel"));ok(calls(mix,"zomboid$individualPerception","supported"));
   ok(mix.invisibleAnnotations.stream().anyMatch(x->x.desc.endsWith("/Mixin;")));
   ok(mix.methods.stream().anyMatch(m->m.visibleAnnotations!=null&&m.visibleAnnotations.stream().anyMatch(x->x.desc.endsWith("/Inject;"))));
   ok(calls(cls(z,p+"HordeCommands.class"),"profiles","profile"));
  }
  System.out.println("PASS: "+n+" integration checks for vision, noise, construction, persistent strength and ZA compatibility");
 }
}
