import dev.zomboid.hordes.*;
public class Stealth17Test {
 static int checks;static void ok(boolean b){checks++;if(!b)throw new AssertionError("Check "+checks);}
 public static void main(String[] args){
  int[] counts=new int[3];int visibleCrouch5=0;
  for(int i=0;i<10000;i++){int kind=IndividualRules.type(i/10000.0);counts[kind]++;if(IndividualRules.vision(kind,true)>=5)visibleCrouch5++;}
  ok(counts[0]==7500&&counts[1]==1500&&counts[2]==1000);ok(visibleCrouch5==1000);
  ok(IndividualRules.vision(0,true)==1.5&&IndividualRules.vision(1,true)==3.5);ok(!IndividualRules.inView(0,-1,true));ok(IndividualRules.inView(0,1,true));ok(!IndividualRules.inView(0,.6,true));ok(!IndividualRules.smart(0)&&IndividualRules.smart(2));
  for(int kind=0;kind<3;kind++)for(double hearing:new double[]{.15,.5,.8,1.1,1.3})for(double base:new double[]{1,2,4,8}){double range=NoiseRules.heardRadius(base,hearing);ok(range<=8);ok(IndividualRules.chance(kind,range+.01,range)==0);}
  ok(NoiseRules.radius("minecraft:block.wood.place",50,false)==4);ok(NoiseRules.radius("minecraft:block.stone.break",50,true)==2);ok(NoiseRules.radius("minecraft:entity.player.step",20,true)==1);ok(NoiseRules.radius("minecraft:block.chest.open",30,false)==8);
  ok(NoiseRules.radius("tacz:gun#x/shoot",80,false)==120);ok(NoiseRules.radius("minecraft:entity.generic.explode",50,false)==75);ok(NoiseRules.heardRadius(192,1.3)==192);ok(NoiseRules.radius("unknown",Double.NaN,false)==0);
  int pending=90,credits=18,alive=0,total=0;
  for(int i=0;i<20;i++){int q=IndividualRules.quota(4,pending,credits,alive,24);pending-=q;credits-=q;alive+=q;total+=q;}ok(total==18&&credits==0);ok(IndividualRules.quota(4,pending,credits,0,24)==0);
  alive--;credits=IndividualRules.reward(credits,pending);ok(IndividualRules.quota(4,pending,credits,alive,24)==1);
  System.out.println("PASS: "+checks+" distribution, crouch/FOV, 8-block noise limits, gun/explosion and reinforcement checks");
 }
}
