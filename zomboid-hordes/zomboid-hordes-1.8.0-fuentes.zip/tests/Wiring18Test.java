import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Wiring18Test{
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Wiring "+n);}
 static ClassNode cls(ZipFile z,String name)throws Exception{ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name)).readAllBytes()).accept(c,0);return c;}
 static int calls(ClassNode c,String method,String owner,String name){int n=0;for(var m:c.methods)if(m.name.equals(method))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals(name)&&(owner==null||x.owner.equals(owner)))n++;return n;}
 static boolean signature(ClassNode c,String name,String desc){return c.methods.stream().anyMatch(m->m.name.equals(name)&&m.desc.equals(desc));}
 public static void main(String[] a)throws Exception{
  try(var h=new ZipFile(a[0]);var r=new ZipFile(a[1]);var mc=new ZipFile(a[2]);var sound=new ZipFile(a[3])){
   String p="dev/zomboid/hordes/",q="dev/zomboid/remains/";
   ok(signature(cls(mc,"net/minecraft/world/entity/Mob.class"),"setSpeed","(F)V"));
   var pace=cls(h,p+"mixin/ZombiePaceMixin.class");ok(calls(pace,"zomboid$pace",p+"PaceRules","cap")==1);
   ok(pace.methods.stream().anyMatch(m->m.visibleAnnotations!=null&&m.visibleAnnotations.stream().anyMatch(x->x.desc.endsWith("/ModifyVariable;"))));
   ok(signature(cls(sound,"com/example/soundattract/ai/BlockBreakerManager.class"),"scheduleAdd","(Lnet/minecraft/world/entity/Mob;Lnet/minecraft/world/entity/ai/goal/Goal;I)V"));
   ok(calls(cls(h,p+"mixin/BarrierCompatMixin.class"),"zomboid$barriers",null,"cancel")==1);
   var breakGoal=cls(h,p+"BarrierBreakGoal.class");ok(calls(breakGoal,"grief",null,"canEntityGrief")==1);ok(calls(breakGoal,"canUse",null,"clip")==1);ok(calls(breakGoal,"tick",null,"destroyBlock")==1);ok(calls(breakGoal,"stop",null,"destroyBlockProgress")==1);
   var spawn=cls(h,p+"HordeEvents.class");boolean spider=false;for(var m:spawn.methods)if(m.name.equals("blocked"))for(var i:m.instructions.toArray())if(i instanceof TypeInsnNode t&&t.desc.equals("net/minecraft/world/entity/monster/Spider"))spider=true;ok(spider);
   var remains=cls(r,q+"ZombieRemainsLoot.class");ok(calls(remains,"death",q+"LootExtras","populate")==1);ok(calls(remains,"death",null,"playSound")==1);
   ok(calls(remains,"populateBandit",null,"addAmmo")==0);ok(calls(cls(r,q+"QualityLoot.class"),"populate",null,"addAmmo")==0);
   ok(calls(remains,"addAmmo",q+"LootExtras","priority")==1);ok(calls(remains,"addAmmo",null,"setCount")==1);
   var extras=cls(r,q+"LootExtras.class");ok(calls(extras,"populate",null,"addAmmo")==1);ok(calls(extras,"populate",null,"getMainHandItem")==1);ok(calls(extras,"populate",null,"backpackChance")==1);ok(calls(extras,"populate",null,"militaryChance")==1);
   String config=new String(r.getInputStream(r.getEntry("assets/zombie_remains_loot/sounds.json")).readAllBytes());ok(config.contains("blood_splatter")&&config.contains("\"stream\": false"));
  }System.out.println("PASS: "+n+" exact Minecraft/SoundAttract target signatures, barrier/spider hooks, ammo centralization, backpacks/military armor and single corpse sound");
 }
}
