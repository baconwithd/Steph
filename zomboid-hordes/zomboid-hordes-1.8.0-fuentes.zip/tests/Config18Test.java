import java.nio.file.*;import dev.zomboid.hordes.HordeConfig;
public class Config18Test {
 public static void main(String[] args)throws Exception{
  Files.createDirectories(Path.of("config"));Files.writeString(Path.of("config/zomboid-hordes.json"),"{\"balanceVersion\":7,\"daySpeed\":0.05,\"nightSpeed\":0.10,\"helicopterZombies\":90,\"helicopterInitial\":18,\"chestRestockChance\":0.15}");
  HordeConfig c=HordeConfig.load();if(c.balanceVersion!=8||c.daySpeed!=-.025||c.nightSpeed!=0||c.helicopterZombies!=90||c.helicopterInitial!=18||c.chestRestockChance!=.15)throw new AssertionError("Migration changed unrelated settings");
  c=HordeConfig.load();if(c.balanceVersion!=8||c.daySpeed!=-.025)throw new AssertionError("Migration not stable");
  Files.delete(Path.of("config/zomboid-hordes.json"));c=HordeConfig.load();if(c.balanceVersion!=8||c.daySpeed!=-.025||c.helicopterInitial!=18)throw new AssertionError("Fresh config");
  System.out.println("PASS: v7 config migration, repeat load and fresh config preserve helicopter limits and customized restock chance");
 }
}
