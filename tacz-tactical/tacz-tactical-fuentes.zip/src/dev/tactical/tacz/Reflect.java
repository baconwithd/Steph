package dev.tactical.tacz;
import java.lang.reflect.*;import java.util.*;import java.util.concurrent.ConcurrentHashMap;
public final class Reflect {
 private static final Map<String,Method> METHODS=new ConcurrentHashMap<>();
 private static final Map<String,Field> FIELDS=new ConcurrentHashMap<>();
 private static final Set<String> WARNED=ConcurrentHashMap.newKeySet();
 public static Class<?> type(String name)throws Exception{return Class.forName(name);}
 private static boolean accepts(Class<?> p,Object a){if(a==null)return !p.isPrimitive();if(!p.isPrimitive())return p.isInstance(a);return p==int.class&&a instanceof Integer||p==long.class&&a instanceof Long||p==float.class&&a instanceof Float||p==double.class&&a instanceof Double||p==boolean.class&&a instanceof Boolean;}
 public static Object call(Object target,String name,Object...args)throws Exception{
  Class<?> c=target instanceof Class<?>?(Class<?>)target:target.getClass();StringBuilder key=new StringBuilder(c.getName()).append('#').append(name);for(Object a:args)key.append('/').append(a==null?"null":a.getClass().getName());Method method=METHODS.get(key.toString());
  if(method==null){List<Method> choices=new ArrayList<>(Arrays.asList(c.getMethods()));for(Class<?> k=c;k!=null;k=k.getSuperclass())choices.addAll(Arrays.asList(k.getDeclaredMethods()));for(Method m:choices){if(!m.getName().equals(name)||m.getParameterCount()!=args.length)continue;boolean ok=true;Class<?>[] params=m.getParameterTypes();for(int i=0;i<params.length;i++)if(!accepts(params[i],args[i])){ok=false;break;}if(ok){m.setAccessible(true);method=m;break;}}if(method==null)throw new NoSuchMethodException(key.toString());METHODS.put(key.toString(),method);}
  return method.invoke(target instanceof Class<?>?null:target,args);
 }
 public static Object field(Object target,String name)throws Exception{Class<?> c=target instanceof Class<?>?(Class<?>)target:target.getClass();String key=c.getName()+"#"+name;Field f=FIELDS.get(key);if(f==null){for(Class<?> k=c;k!=null;k=k.getSuperclass())try{f=k.getDeclaredField(name);break;}catch(NoSuchFieldException ignored){}if(f==null)throw new NoSuchFieldException(key);f.setAccessible(true);FIELDS.put(key,f);}return f.get(target instanceof Class<?>?null:target);}
 public static double num(Object value){return ((Number)value).doubleValue();}
 public static boolean yes(Object value){return Boolean.TRUE.equals(value);}
 public static void warn(String feature,Exception e){if(WARNED.add(feature))System.err.println("[TacZ Tactical] "+feature+": "+e);}
}
