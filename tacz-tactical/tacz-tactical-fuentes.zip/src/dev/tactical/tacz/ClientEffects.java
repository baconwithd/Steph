package dev.tactical.tacz;
import java.util.*;
import static dev.tactical.tacz.Reflect.*;
/** Client-only transient lighting. Never sends block changes to the server. */
public final class ClientEffects {
 private record Light(Object original,Object installed,long expiry){}
 private static final Map<Object,Light> LIGHTS=new LinkedHashMap<>();
 private static Object activeLevel;
 private static Object minecraft()throws Exception{return call(type("net.minecraft.client.Minecraft"),"getInstance");}
 private static long time(Object level)throws Exception{return ((Number)call(level,"getGameTime")).longValue();}
 private static boolean useLevel(Object level)throws Exception{if(level==null||field(minecraft(),"level")!=level)return false;if(activeLevel!=level){LIGHTS.clear();activeLevel=level;}return true;}
 private static void particle(Object level,String name,double x,double y,double z,double vx,double vy,double vz)throws Exception{Object particle=field(type("net.minecraft.core.particles.ParticleTypes"),name);call(level,"addParticle",particle,x,y,z,vx,vy,vz);}
 public static void muzzle(Object shooter,boolean suppressed){try{
  Object level=call(shooter,"level");if(!useLevel(level))return;Object look=call(shooter,"getLookAngle");double dx=num(field(look,"x")),dy=num(field(look,"y")),dz=num(field(look,"z"));
  double x=num(call(shooter,"getX"))+dx*.65,y=num(call(shooter,"getEyeY"))-.14+dy*.65,z=num(call(shooter,"getZ"))+dz*.65;
  if(!suppressed){particle(level,"FLAME",x,y,z,dx*.025,dy*.025,dz*.025);particle(level,"ELECTRIC_SPARK",x,y,z,dx*.045,dy*.045,dz*.045);pulse(level,x,y,z,Settings.MUZZLE,Settings.MUZZLE_TICKS);}
 }catch(Exception e){warn("muzzle effects",e);}}
 public static void message(Object message,Object shooter){try{String name=String.valueOf(call(message,"getSoundName"));if("shoot_3p".equals(name)||"shoot".equals(name))muzzle(shooter,false);}catch(Exception e){warn("remote muzzle effects",e);}}
 public static void impact(Object level,double x,double y,double z,Object direction){try{
  if(!useLevel(level))return;double dx=num(call(direction,"getStepX")),dy=num(call(direction,"getStepY")),dz=num(call(direction,"getStepZ"));x+=dx*.12;y+=dy*.12;z+=dz*.12;
  for(int i=0;i<4;i++)particle(level,"ELECTRIC_SPARK",x,y,z,dx*.06+(Math.random()-.5)*.08,dy*.06+(Math.random()-.5)*.08,dz*.06+(Math.random()-.5)*.08);
  pulse(level,x,y,z,Settings.IMPACT,Settings.IMPACT_TICKS);
 }catch(Exception e){warn("impact effects",e);}}
 public static void pulse(Object level,double x,double y,double z,int brightness,int duration){
  if(!Settings.LIGHTS)return;
  try{
   if(!useLevel(level))return;Object player=field(minecraft(),"player");if(player==null||num(call(player,"distanceToSqr",x,y,z))>Settings.LIGHT_RADIUS*Settings.LIGHT_RADIUS)return;
   Object pos=call(type("net.minecraft.core.BlockPos"),"containing",x,y,z);if(!yes(call(level,"hasChunkAt",pos)))return;
   Object current=call(level,"getBlockState",pos);Light existing=LIGHTS.get(pos);long expiry=time(level)+duration;
   if(existing!=null){
    if(!current.equals(existing.installed)){LIGHTS.remove(pos);return;}
    // Overlapping pulses extend the existing light without rebuilding geometry each shot.
    LIGHTS.put(pos,new Light(existing.original,existing.installed,Math.max(existing.expiry,expiry)));return;
   }
   if(LIGHTS.size()>=Settings.MAX_LIGHTS||!yes(call(current,"isAir")))return;
   Object block=field(type("net.minecraft.world.level.block.Blocks"),"LIGHT");Object state=call(block,"defaultBlockState");Object property=field(type("net.minecraft.world.level.block.LightBlock"),"LEVEL");state=call(state,"setValue",property,brightness);
   if(yes(call(level,"setBlock",pos,state,2)))LIGHTS.put(pos,new Light(current,state,expiry));
  }catch(Exception e){warn("dynamic light",e);}
 }
 public static void tick(){try{
  Object level=field(minecraft(),"level");if(level==null){LIGHTS.clear();activeLevel=null;return;}if(!useLevel(level))return;long now=time(level);
  for(var it=LIGHTS.entrySet().iterator();it.hasNext();){var entry=it.next();Light light=entry.getValue();if(now<light.expiry)continue;
   Object pos=entry.getKey();if(yes(call(level,"hasChunkAt",pos))&&call(level,"getBlockState",pos).equals(light.installed))call(level,"setBlock",pos,light.original,2);it.remove();
  }
 }catch(Exception e){warn("light cleanup",e);}}
}
