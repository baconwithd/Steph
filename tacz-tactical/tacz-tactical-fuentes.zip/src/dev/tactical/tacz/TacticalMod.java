package dev.tactical.tacz;
@net.neoforged.fml.common.Mod("tacz_tactical")
public final class TacticalMod {public TacticalMod(){Settings.init();}}
