package dev.tactical.tacz.mixin;
import dev.tactical.tacz.Settings;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="com.tacz.guns.entity.EntityKineticBullet",remap=false)
public abstract class TracerMixin {
 @Inject(method="getTracerSizeOverride()F",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$size(CallbackInfoReturnable<Float> cir){cir.setReturnValue(cir.getReturnValueF()*Settings.TRACER);}
}
