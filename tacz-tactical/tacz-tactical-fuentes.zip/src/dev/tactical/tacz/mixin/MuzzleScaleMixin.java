package dev.tactical.tacz.mixin;
import dev.tactical.tacz.Settings;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="com.tacz.guns.client.resource.pojo.display.gun.MuzzleFlash",remap=false)
public abstract class MuzzleScaleMixin {
 @Inject(method="getScale()F",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$scale(CallbackInfoReturnable<Float> cir){cir.setReturnValue(cir.getReturnValueF()*Settings.FLASH_SCALE);}
}
