package dev.tactical.tacz.mixin;
import dev.tactical.tacz.Tuning;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="com.tacz.guns.resource.pojo.data.gun.BurstData",remap=false)
public abstract class BurstDataMixin {
 @Inject(method="getCount()I",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$count(CallbackInfoReturnable<Integer> cir){cir.setReturnValue(Tuning.burstCount(cir.getReturnValueI()));}
 @Inject(method="getMinInterval()D",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$pause(CallbackInfoReturnable<Double> cir){cir.setReturnValue(Tuning.burstPause(cir.getReturnValueD()));}
}
