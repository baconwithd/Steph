package dev.tactical.tacz.mixin;
import dev.tactical.tacz.ClientEffects;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="com.tacz.guns.client.particle.BulletHoleParticle",remap=false)
public abstract class ImpactMixin {
 @Inject(method="<init>(Lnet/minecraft/client/multiplayer/ClientLevel;DDDLnet/minecraft/core/Direction;Lnet/minecraft/core/BlockPos;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",at=@At("RETURN"),require=1)
 private void tactical$impact(@Coerce Object level,double x,double y,double z,@Coerce Object direction,@Coerce Object pos,String texture,String ammo,String gun,CallbackInfo ci){ClientEffects.impact(level,x,y,z,direction);}
}
