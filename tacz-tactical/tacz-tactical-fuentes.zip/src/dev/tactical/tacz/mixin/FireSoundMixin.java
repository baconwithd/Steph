package dev.tactical.tacz.mixin;
import dev.tactical.tacz.Settings;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="com.tacz.guns.resource.pojo.data.gun.FireSound",remap=false)
public abstract class FireSoundMixin {
 @Inject(method="getFireMultiplier()F",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$fire(CallbackInfoReturnable<Float> cir){cir.setReturnValue(cir.getReturnValueF()*Settings.SOUND);}
 @Inject(method="getSilenceMultiplier()F",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$silenced(CallbackInfoReturnable<Float> cir){cir.setReturnValue(cir.getReturnValueF()*Settings.SILENCED);}
}
