package dev.tactical.tacz.mixin;
import dev.tactical.tacz.Settings;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;
@Mixin(targets="com.tacz.guns.client.model.functional.MuzzleFlashRender",remap=false)
public abstract class MuzzleDurationMixin {
 @ModifyConstant(method="render(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/item/ItemDisplayContext;II)V",constant=@Constant(longValue=50L),require=1)
 private long tactical$duration(long original){return Settings.FLASH_MS;}
}
