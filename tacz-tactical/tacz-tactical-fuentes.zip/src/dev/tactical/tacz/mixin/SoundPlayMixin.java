package dev.tactical.tacz.mixin;
import dev.tactical.tacz.ClientEffects;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="com.tacz.guns.client.sound.SoundPlayManager",remap=false)
public abstract class SoundPlayMixin {
 @Inject(method="playShootSound(Lnet/minecraft/world/entity/LivingEntity;Lcom/tacz/guns/client/resource/GunDisplayInstance;Lcom/tacz/guns/resource/pojo/data/gun/GunData;)V",at=@At("RETURN"),require=1)
 private static void tactical$shot(@Coerce Object shooter,@Coerce Object display,@Coerce Object data,CallbackInfo ci){ClientEffects.muzzle(shooter,false);}
 @Inject(method="lambda$playMessageSound$1(Lcom/tacz/guns/network/message/ServerMessageSound;Lnet/minecraft/world/entity/LivingEntity;Lcom/tacz/guns/client/resource/GunDisplayInstance;)V",at=@At("HEAD"),require=1)
 private static void tactical$remote(@Coerce Object message,@Coerce Object shooter,@Coerce Object display,CallbackInfo ci){ClientEffects.message(message,shooter);}
 @Inject(method="onClientTick(Lnet/neoforged/neoforge/client/event/ClientTickEvent$Post;)V",at=@At("RETURN"),require=1)
 private static void tactical$tick(CallbackInfo ci){ClientEffects.tick();}
}
