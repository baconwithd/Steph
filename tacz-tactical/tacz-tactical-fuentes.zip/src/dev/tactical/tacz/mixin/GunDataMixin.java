package dev.tactical.tacz.mixin;
import java.util.Map;
import dev.tactical.tacz.Tuning;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="com.tacz.guns.resource.pojo.data.gun.GunData",remap=false)
public abstract class GunDataMixin {
 @Inject(method="getInaccuracy()Ljava/util/Map;",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$map(CallbackInfoReturnable<Map<Object,Float>> cir){cir.setReturnValue(Tuning.accuracyMap(this,cir.getReturnValue()));}
 @Inject(method="getInaccuracy(Lcom/tacz/guns/resource/pojo/data/gun/InaccuracyType;)F",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$single(@Coerce Object kind,CallbackInfoReturnable<Float> cir){cir.setReturnValue(Tuning.accuracy(this,kind,cir.getReturnValueF()));}
 @Inject(method="getInaccuracy(Lcom/tacz/guns/resource/pojo/data/gun/InaccuracyType;F)F",at=@At("RETURN"),cancellable=true,require=1)
 private void tactical$adjusted(@Coerce Object kind,float adjustment,CallbackInfoReturnable<Float> cir){cir.setReturnValue(Tuning.accuracy(this,kind,cir.getReturnValueF()));}
}
