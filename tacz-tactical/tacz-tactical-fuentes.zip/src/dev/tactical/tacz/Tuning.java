package dev.tactical.tacz;
import java.util.*;
public final class Tuning {
 public static float accuracy(Object gun,Object kind,float original){if(!"AIM".equals(String.valueOf(kind)))return original;float factor=Settings.AIM;try{Object data=Reflect.call(gun,"getBulletData");if(data!=null&&Reflect.num(Reflect.call(data,"getBulletAmount"))>1)factor=Settings.SHOTGUN_AIM;}catch(Exception e){Reflect.warn("accuracy metadata",e);}return Math.max(0,original*factor);}
 public static Map<Object,Float> accuracyMap(Object gun,Map<?,?> original){if(original==null)return null;Map<Object,Float> copy=new LinkedHashMap<>();for(var e:original.entrySet()){float n=((Number)e.getValue()).floatValue();copy.put(e.getKey(),accuracy(gun,e.getKey(),n));}return copy;}
 public static int burstCount(int n){return n==3?Settings.BURST_COUNT:n;}
 public static double burstPause(double pause){return pause>0?Math.max(.05,pause*Settings.BURST_PAUSE):pause;}
}
