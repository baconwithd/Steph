package dev.tactical.tacz;
import java.nio.file.*;import java.util.*;import java.io.*;
public final class Settings {
 private static final Properties P=new Properties();
 static {
  try {
   Path dir=Path.of("config");
   try {Object config=Class.forName("net.neoforged.fml.loading.FMLPaths").getField("CONFIGDIR").get(null);dir=(Path)config.getClass().getMethod("get").invoke(config);}catch(ReflectiveOperationException ignored){}
   Path file=Path.of(System.getProperty("tacz.tactical.config",dir.resolve("tacz-tactical.properties").toString()));
   P.setProperty("aim_spread_multiplier","0.55");P.setProperty("shotgun_aim_spread_multiplier","0.85");
   P.setProperty("fire_sound_distance_multiplier","2.0");P.setProperty("silenced_sound_distance_multiplier","1.25");
   P.setProperty("burst_pause_multiplier","0.75");P.setProperty("three_round_burst_count","4");
   P.setProperty("tracer_width_multiplier","1.2");P.setProperty("muzzle_flash_scale_multiplier","1.2");P.setProperty("muzzle_flash_duration_ms","80");
   P.setProperty("dynamic_lights","true");P.setProperty("muzzle_light_level","14");P.setProperty("impact_light_level","11");
   P.setProperty("muzzle_light_ticks","4");P.setProperty("impact_light_ticks","5");P.setProperty("max_dynamic_lights","16");P.setProperty("dynamic_light_radius","48");
   if(Files.exists(file)){try(InputStream in=Files.newInputStream(file)){P.load(in);}}
   else {if(file.getParent()!=null)Files.createDirectories(file.getParent());try(OutputStream out=Files.newOutputStream(file)){P.store(out,"TacZ Tactical - restart the game/server after changing these settings. Lower aim_spread_multiplier means better aimed precision.");}}
  }catch(IOException|RuntimeException e){System.err.println("[TacZ Tactical] Cannot read/write settings; using defaults: "+e);}
 }
 public static void init(){}
 private static double value(String k,double fallback,double min,double max){try{double v=Double.parseDouble(P.getProperty(k));return Double.isFinite(v)?Math.max(min,Math.min(max,v)):fallback;}catch(RuntimeException e){return fallback;}}
 public static final float AIM=(float)value("aim_spread_multiplier",.55,.1,1);
 public static final float SHOTGUN_AIM=(float)value("shotgun_aim_spread_multiplier",.85,.3,1);
 public static final float SOUND=(float)value("fire_sound_distance_multiplier",2,1,4);
 public static final float SILENCED=(float)value("silenced_sound_distance_multiplier",1.25,1,2);
 public static final double BURST_PAUSE=value("burst_pause_multiplier",.75,.25,1);
 public static final int BURST_COUNT=(int)value("three_round_burst_count",4,3,6);
 public static final float TRACER=(float)value("tracer_width_multiplier",1.2,.5,2);
 public static final float FLASH_SCALE=(float)value("muzzle_flash_scale_multiplier",1.2,.5,2);
 public static final long FLASH_MS=(long)value("muzzle_flash_duration_ms",80,50,120);
 public static final boolean LIGHTS=Boolean.parseBoolean(P.getProperty("dynamic_lights","true"));
 public static final int MUZZLE=(int)value("muzzle_light_level",14,1,15),IMPACT=(int)value("impact_light_level",11,1,15);
 public static final int MUZZLE_TICKS=(int)value("muzzle_light_ticks",4,1,10),IMPACT_TICKS=(int)value("impact_light_ticks",5,1,10);
 public static final int MAX_LIGHTS=(int)value("max_dynamic_lights",16,1,32),LIGHT_RADIUS=(int)value("dynamic_light_radius",48,8,64);
}
