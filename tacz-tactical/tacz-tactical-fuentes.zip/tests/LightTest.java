import java.util.*;import dev.tactical.tacz.*;import net.minecraft.client.Minecraft;import net.minecraft.core.BlockPos;import net.minecraft.world.level.block.Blocks.State;
public class LightTest {
 static State AIR=new State("air",0),STONE=new State("stone",0);
 public static class World {long now;int writes;boolean loaded=true;Map<BlockPos,State> blocks=new HashMap<>();public long getGameTime(){return now;}public boolean hasChunkAt(BlockPos p){return loaded;}public State getBlockState(BlockPos p){return blocks.getOrDefault(p,AIR);}public boolean setBlock(BlockPos p,State s,int flags){if(flags!=2)throw new AssertionError("Unexpected update flags");blocks.put(p,s);writes++;return true;}}
 public static class Player {public double distanceToSqr(double x,double y,double z){return x*x+y*y+z*z;}}
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
 public static void main(String[] args){Minecraft mc=Minecraft.getInstance();World w=new World();mc.level=w;mc.player=new Player();BlockPos p=new BlockPos(1,0,0);
  ClientEffects.pulse(w,1,0,0,14,4);
  if(args.length>0){check(w.writes==0,"Disabled light still modified client state");System.out.println("PASS: dynamic_lights=false disables transient lighting.");return;}
  check(w.getBlockState(p).light()==14,"Missing light");w.now=2;ClientEffects.pulse(w,1,0,0,14,4);check(w.writes==1,"Overlapping pulse rebuilt block");w.now=4;ClientEffects.tick();check(w.getBlockState(p).light()==14,"Overlap expired too early");w.now=6;ClientEffects.tick();check(w.getBlockState(p).equals(AIR),"Air was not restored");
  ClientEffects.pulse(w,1,0,0,14,4);w.blocks.put(p,STONE);w.now=11;ClientEffects.tick();check(w.getBlockState(p).equals(STONE),"Overwrote real world update");
  int writes=w.writes;ClientEffects.pulse(w,1,0,0,14,4);check(w.writes==writes,"Changed solid block");ClientEffects.pulse(w,50,0,0,14,4);check(w.writes==writes,"Out-of-radius light created");w.loaded=false;ClientEffects.pulse(w,2,0,0,14,4);check(w.writes==writes,"Unloaded chunk touched");w.loaded=true;
  for(int i=2;i<18;i++)ClientEffects.pulse(w,i,0,0,14,4);check(w.writes==writes+16,"Light budget count");ClientEffects.pulse(w,18,0,0,14,4);check(w.writes==writes+16,"Light budget exceeded");w.now=16;ClientEffects.tick();for(int i=2;i<18;i++)check(w.getBlockState(new BlockPos(i,0,0)).equals(AIR),"Budget lights were not cleaned up");
  World other=new World();ClientEffects.pulse(other,1,0,0,14,4);check(other.writes==0,"Modified non-client level");mc.level=null;ClientEffects.tick();
  System.out.println("PASS: transient light lifecycle, overlap extension, server-update preservation, solid blocks, range, unloaded chunks, light cap, world identity and disconnect.");
 }
}
