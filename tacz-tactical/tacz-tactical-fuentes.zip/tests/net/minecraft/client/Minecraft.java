package net.minecraft.client;
public class Minecraft {private static final Minecraft INSTANCE=new Minecraft();public Object level;public Object player;public static Minecraft getInstance(){return INSTANCE;}}
