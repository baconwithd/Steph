package net.minecraft.core;
public record BlockPos(int x,int y,int z){public static BlockPos containing(double x,double y,double z){return new BlockPos((int)Math.floor(x),(int)Math.floor(y),(int)Math.floor(z));}}
