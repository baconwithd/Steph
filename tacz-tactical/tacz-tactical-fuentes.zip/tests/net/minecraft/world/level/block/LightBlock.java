package net.minecraft.world.level.block;
public class LightBlock {public static final String LEVEL="level";}
