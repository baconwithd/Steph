package net.minecraft.world.level.block;
public class Blocks {
 public static final Block LIGHT=new Block();
 public static class Block {public State defaultBlockState(){return new State("light",15);}}
 public record State(String kind,int light){public boolean isAir(){return kind.equals("air");}public State setValue(Object property,Comparable<?> value){return new State(kind,((Number)value).intValue());}}
}
