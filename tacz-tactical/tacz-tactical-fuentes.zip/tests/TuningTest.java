import java.util.*;import dev.tactical.tacz.*;
public class TuningTest {
 public static class Bullet {int count;Bullet(int n){count=n;}public int getBulletAmount(){return count;}}
 public static class Gun {Bullet b;Gun(int n){b=new Bullet(n);}public Bullet getBulletData(){return b;}}
 static void near(float actual,float expected){if(Math.abs(actual-expected)>.00001)throw new AssertionError(actual+" != "+expected);}
 public static void main(String[] args){Gun rifle=new Gun(1),shotgun=new Gun(8);Map<String,Float> original=Map.of("AIM",2f,"MOVE",5f,"STAND",3f);
  Map<Object,Float> tuned=Tuning.accuracyMap(rifle,original);near(tuned.get("AIM"),1.1f);near(original.get("AIM"),2);near(tuned.get("MOVE"),5);near(tuned.get("STAND"),3);
  near(Tuning.accuracyMap(rifle,original).get("AIM"),1.1f);near(Tuning.accuracy(shotgun,"AIM",2),1.7f);near(Tuning.accuracy(rifle,"AIM",0),0);
  if(Tuning.burstCount(3)!=4||Tuning.burstCount(1)!=1||Tuning.burstCount(5)!=5)throw new AssertionError("Burst count");
  if(Math.abs(Tuning.burstPause(.3)-.225)>1e-9||Tuning.burstPause(0)!=0)throw new AssertionError("Burst pause");
  System.out.println("PASS: aimed precision, shotgun preservation, unchanged hipfire, immutable/noncompounding maps, burst count and timing.");
 }
}
