from pathlib import Path
import zipfile,hashlib,json,tomllib
root=Path(__file__).resolve().parent;out=root/'artifacts';out.mkdir(exist_ok=True)
p=out/'tacz-tactical-1.0.0-neoforge-1.21.1.jar'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['build/dev','resources']:
  for f in sorted((root/folder).rglob('*')):
   if f.is_file():
    name=str(f.relative_to(root/('build' if folder=='build/dev' else 'resources')))
    info=zipfile.ZipInfo(name,(2026,10,9,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(info,f.read_bytes())
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 assert all(not n.startswith(('net/','org/')) for n in z.namelist()),'Compile-time stubs must not be packaged'
 mix=json.loads(z.read('tacz_tactical.mixins.json'))
 for cl in mix['mixins']+mix['client']:assert (mix['package'].replace('.','/')+'/'+cl+'.class') in z.namelist()
 tomllib.loads(z.read('META-INF/neoforge.mods.toml').decode())
print(p.name,p.stat().st_size,'bytes; ZIP, metadata and stub exclusion verified.')
