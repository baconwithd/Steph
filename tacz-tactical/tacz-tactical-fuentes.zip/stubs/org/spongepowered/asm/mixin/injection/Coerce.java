package org.spongepowered.asm.mixin.injection;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.CLASS) public @interface Coerce {}
