package org.spongepowered.asm.mixin.injection;
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) public @interface ModifyConstant {String[] method(); Constant[] constant(); boolean remap() default true; int require() default -1;}
