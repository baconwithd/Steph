#!/usr/bin/env bash
set -euo pipefail
project_dir=$(cd -- "$(dirname -- "$0")" && pwd)
cd "$project_dir"
python3 make_stubs.py
python3 - <<'PY'
from pathlib import Path
Path('compile.args').write_text('\n'.join(str(p) for root in ['stubs','src'] for p in Path(root).rglob('*.java')))
PY
mkdir -p build artifacts
java -m jdk.compiler/com.sun.tools.javac.Main -d build @compile.args
python3 package.py
if [ "$#" -gt 0 ]; then
  exports=(--add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED)
  mkdir -p test-build
  java -m jdk.compiler/com.sun.tools.javac.Main "${exports[@]}" -d test-build Audit.java
  java "${exports[@]}" -cp test-build Audit "$1" build
fi
