import java.nio.file.*;import java.util.*;import java.util.jar.*;
import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;import jdk.internal.org.objectweb.asm.tree.analysis.*;
public class Audit implements Opcodes {
 static Object val(AnnotationNode a,String key){if(a.values!=null)for(int i=0;i<a.values.size();i+=2)if(a.values.get(i).equals(key))return a.values.get(i+1);return null;}
 static AnnotationNode annotation(List<AnnotationNode> list,String suffix){if(list!=null)for(var a:list)if(a.desc.endsWith(suffix+";"))return a;return null;}
 static ClassNode node(byte[] b){ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);return c;}
 public static void main(String[] args)throws Exception{int classes=0,hooks=0;try(JarFile target=new JarFile(args[0])){try(var paths=Files.walk(Path.of(args[1]).resolve("dev"))){for(Path p:paths.filter(x->x.toString().endsWith(".class")).toList()){
  ClassNode c=node(Files.readAllBytes(p));classes++;for(MethodNode m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);
  AnnotationNode mixin=annotation(c.invisibleAnnotations,"/Mixin");if(!c.name.contains("/mixin/"))continue;if(mixin==null)throw new AssertionError("Mixin must have CLASS retention: "+c.name);
  if(!Boolean.FALSE.equals(val(mixin,"remap")))throw new AssertionError("Remapping unexpectedly enabled");String targetName=((List<String>)val(mixin,"targets")).getFirst();var entry=target.getJarEntry(targetName.replace('.','/')+".class");if(entry==null)throw new AssertionError("Missing target "+targetName);ClassNode tc=node(target.getInputStream(entry).readAllBytes());
  for(MethodNode m:c.methods){AnnotationNode inject=annotation(m.visibleAnnotations,"/Inject"),constant=annotation(m.visibleAnnotations,"/ModifyConstant");AnnotationNode hook=inject!=null?inject:constant;if(hook==null)continue;
   String selector=((List<String>)val(hook,"method")).getFirst();MethodNode tm=tc.methods.stream().filter(x->(x.name+x.desc).equals(selector)).findFirst().orElseThrow(()->new AssertionError("Target selector not found: "+selector));
   if((m.access&ACC_STATIC)!=(tm.access&ACC_STATIC))throw new AssertionError("Static mismatch "+m.name);
   if(inject!=null){Type[] actual=Type.getArgumentTypes(m.desc),expected=Type.getArgumentTypes(tm.desc);String callback=Type.getReturnType(tm.desc).getSort()==Type.VOID?"org/spongepowered/asm/mixin/injection/callback/CallbackInfo":"org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable";
    if(!actual[actual.length-1].getInternalName().equals(callback))throw new AssertionError("Wrong callback "+m.name);
    if(actual.length!=1){if(actual.length!=expected.length+1)throw new AssertionError("Arity mismatch "+m.name);for(int i=0;i<expected.length;i++)if(!actual[i].equals(expected[i])){boolean object=actual[i].equals(Type.getType(Object.class));AnnotationNode coerce=m.invisibleParameterAnnotations==null?null:annotation(m.invisibleParameterAnnotations[i],"/Coerce");if(!object||coerce==null||expected[i].getSort()!=Type.OBJECT)throw new AssertionError("Missing CLASS-retention @Coerce "+m.name+" argument "+i);}}
   }else{long wanted=((Number)val(((List<AnnotationNode>)val(constant,"constant")).getFirst(),"longValue")).longValue();int found=0;for(AbstractInsnNode i:tm.instructions)if(i instanceof LdcInsnNode l&&l.cst instanceof Long n&&n==wanted)found++;if(found!=1)throw new AssertionError("Constant count: "+found);}
   hooks++;
  }
 }}}System.out.println("PASS: "+classes+" classes verified; "+hooks+" mixin hooks matched exact uploaded TACZ descriptors, staticness, annotation retention and captured argument types.");}
}
