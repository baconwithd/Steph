from pathlib import Path
r=Path('/workspace/work/tacz/stubs')
stubs={
'org.spongepowered.asm.mixin.Mixin':'public @interface Mixin {String[] targets() default {}; boolean remap() default true;}',
'org.spongepowered.asm.mixin.injection.At':'public @interface At {String value();}',
'org.spongepowered.asm.mixin.injection.Constant':'public @interface Constant {long longValue() default 0;}',
'org.spongepowered.asm.mixin.injection.Inject':'public @interface Inject {String[] method(); At[] at(); boolean cancellable() default false; boolean remap() default true; int require() default -1;}',
'org.spongepowered.asm.mixin.injection.ModifyConstant':'public @interface ModifyConstant {String[] method(); Constant[] constant(); boolean remap() default true; int require() default -1;}',
'org.spongepowered.asm.mixin.injection.Coerce':'public @interface Coerce {}',
'org.spongepowered.asm.mixin.injection.callback.CallbackInfo':'public class CallbackInfo {}',
'org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable':'public class CallbackInfoReturnable<T> extends CallbackInfo {private T value; public T getReturnValue(){return value;} public void setReturnValue(T v){value=v;} public float getReturnValueF(){return ((Number)value).floatValue();} public int getReturnValueI(){return ((Number)value).intValue();} public double getReturnValueD(){return ((Number)value).doubleValue();}}',
'net.neoforged.fml.common.Mod':'public @interface Mod {String value();}'
}
for name,body in stubs.items():
 p=r/(name.replace('.','/')+'.java');p.parent.mkdir(parents=True,exist_ok=True)
 package=name.rsplit('.',1)[0];retention='CLASS' if name.endswith('.Mixin') or name.endswith('.Coerce') else 'RUNTIME';prefix='@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.'+retention+') ' if '@interface' in body else ''
 p.write_text('package '+package+';\n'+prefix+body+'\n')
