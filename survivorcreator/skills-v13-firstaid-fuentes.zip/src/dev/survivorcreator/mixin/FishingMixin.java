package dev.survivorcreator.mixin;
import dev.survivorcreator.skills.FishingBenefits;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.projectile.FishingHook;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(FishingHook.class)
public abstract class FishingMixin {
 @Shadow private int timeUntilLured;
 @Unique private int sc_previousWait;
 @Inject(method="catchingFish",at=@At("HEAD")) private void sc_before(BlockPos pos,CallbackInfo ci){sc_previousWait=timeUntilLured;}
 @Inject(method="catchingFish",at=@At("TAIL")) private void sc_after(BlockPos pos,CallbackInfo ci){if(sc_previousWait<=0&&timeUntilLured>0)timeUntilLured=FishingBenefits.waitTime((FishingHook)(Object)this,timeUntilLured);}
 @ModifyArg(method="retrieve",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/storage/loot/LootParams$Builder;withLuck(F)Lnet/minecraft/world/level/storage/loot/LootParams$Builder;"),index=0)
 private float sc_luck(float luck){return FishingBenefits.luck((FishingHook)(Object)this,luck);}
}
