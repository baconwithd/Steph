package dev.survivorcreator.skills;
import java.util.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.resources.ResourceLocation;
public final class ActiveSkills {
 public static final List<String> IDS=List.of("fitness","strength","sprinting","carpentry","metalworking","cooking","farming","first_aid","fishing");
 public static void prune(Map<String,Skill> skills){skills.keySet().removeIf(id->!IDS.contains(id));}
 public static int level(ServerPlayer p,String id){Skill s=Skills.get(id);return s==null?0:Skills.level(p,s);}
 public static void apply(ServerPlayer p){
  AttributeInstance a=p.getAttribute(Attributes.MAX_HEALTH);if(a==null)return;
  ResourceLocation id=ResourceLocation.fromNamespaceAndPath("survivorcreator","skill_health");a.removeModifier(id);
  double amount=Rules13.health(level(p,"fitness"),level(p,"strength"));
  if(amount>0)a.addTransientModifier(new AttributeModifier(id,amount,AttributeModifier.Operation.ADD_VALUE));
 }
}
