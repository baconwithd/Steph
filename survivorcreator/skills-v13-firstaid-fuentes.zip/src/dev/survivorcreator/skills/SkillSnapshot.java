package dev.survivorcreator.skills;
public final class SkillSnapshot {
 private static volatile String json="";
 public static void accept(String value){json=value;}
 public static String json(){return json;}
}
