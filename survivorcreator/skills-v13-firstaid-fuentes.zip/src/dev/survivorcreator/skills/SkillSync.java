package dev.survivorcreator.skills;
import com.google.gson.*;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
@EventBusSubscriber(modid="survivorcreator")
public final class SkillSync {
 public record Snapshot(String json) implements CustomPacketPayload {
  public static final Type<Snapshot> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("survivorcreator","skill_snapshot"));
  public static final StreamCodec<RegistryFriendlyByteBuf,Snapshot> CODEC=ByteBufCodecs.stringUtf8(16384).map(Snapshot::new,Snapshot::json).cast();
  public Type<? extends CustomPacketPayload> type(){return TYPE;}
 }
 public static void register(RegisterPayloadHandlersEvent e){e.registrar("1").playToClient(Snapshot.TYPE,Snapshot.CODEC,(p,c)->c.enqueueWork(()->SkillSnapshot.accept(p.json())));}
 @SubscribeEvent public static void tick(PlayerTickEvent.Post e){
  if(!(e.getEntity() instanceof ServerPlayer p)||p.tickCount%20!=0)return;
  JsonObject root=new JsonObject();root.addProperty("player",p.getUUID().toString());JsonArray rows=new JsonArray();
  for(Skill s:Skills.all()){JsonObject row=new JsonObject();row.addProperty("id",s.id());row.addProperty("level",Skills.level(p,s));row.addProperty("xp",Skills.xp(p,s));rows.add(row);}root.add("rows",rows);
  PacketDistributor.sendToPlayer(p,new Snapshot(root.toString()));
 }
}
