package dev.survivorcreator.skills;
import java.util.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.*;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
@EventBusSubscriber(modid="survivorcreator")
public final class SkillEvents {
 private static final Map<ServerPlayer,Vec3> MOVEMENT=new WeakHashMap<>();
 @SubscribeEvent public static void tick(PlayerTickEvent.Post e){
  if(!(e.getEntity() instanceof ServerPlayer p)||!p.isAlive()||p.isCreative()||p.isSpectator())return;
  Vec3 prev=MOVEMENT.put(p,p.position());if(prev==null)return;double d=p.position().subtract(prev).horizontalDistanceSqr();
  if(d<.0004||d>1||p.isPassenger())return;
  if(p.isSprinting()&&p.onGround()&&!p.isInWater()){Skills.addXp(p,Skills.FITNESS,.10);WorkEvents.xp(p,"sprinting",.10);}
 }
 @SubscribeEvent public static void jump(LivingEvent.LivingJumpEvent e){if(e.getEntity() instanceof ServerPlayer p&&!p.isCreative()&&!p.isSpectator())Skills.addXp(p,Skills.FITNESS,1);}
 @SubscribeEvent public static void hit(LivingDamageEvent.Post e){
  if(e.getEntity() instanceof Player||!(e.getSource().getEntity() instanceof ServerPlayer p)||p.isCreative()||p.isSpectator()||e.getSource().getDirectEntity()!=p||!e.getSource().is(DamageTypes.PLAYER_ATTACK)||e.getNewDamage()<=0)return;
  ItemStack stack=p.getMainHandItem();String id=net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
  if(stack.getItem() instanceof TieredItem||Arrays.stream(new String[]{"knife","dagger","katana","machete","bat","crowbar","pipe","hammer","spear","trident","club","pike","skillet","karambit","pan","wrench","halberd"}).anyMatch(id::contains))Skills.addXp(p,Skills.STRENGTH,1);
 }
 @SubscribeEvent public static void server(ServerTickEvent.Post e){SkillPopups.tick(e.getServer());DamagePopups.tick();}
 @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){SkillPopups.removeFor(e.getEntity().getUUID());MOVEMENT.remove(e.getEntity());}
 @SubscribeEvent public static void stop(ServerStoppingEvent e){SkillPopups.clearAll();MOVEMENT.clear();DamagePopups.clear();}
 @SubscribeEvent public static void join(EntityJoinLevelEvent e){if(e.loadedFromDisk()&&(e.getEntity().getTags().contains("survivorcreator_popup")||e.getEntity().getTags().contains("survivorcreator_damage_popup")))e.setCanceled(true);}
}
