package dev.survivorcreator.skills;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
@EventBusSubscriber(modid="survivorcreator")
public final class WorkEvents {
 static void xp(ServerPlayer p,String id,double amount){Skill s=Skills.get(id);if(s!=null&&!p.isCreative()&&!p.isSpectator())Skills.addXp(p,s,amount);}
 static String id(ItemStack stack){return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();}
 static String craftKind(ItemStack stack){
  String id=id(stack);
  if(stack.has(DataComponents.FOOD))return "cooking";
  if(WorkRules.electric(id))return "electrical";
  if(WorkRules.metal(id))return "metalworking";
  if(id.contains("wooden_")||stack.is(Items.STICK)||stack.is(Items.BOW)||stack.is(Items.CROSSBOW))return "carpentry";
  if(stack.getItem() instanceof BlockItem b){
   BlockState state=b.getBlock().defaultBlockState();
   if(state.is(BlockTags.PLANKS)||state.is(BlockTags.LOGS)||state.is(BlockTags.WOODEN_FENCES)||state.is(BlockTags.WOODEN_TRAPDOORS)||state.is(BlockTags.WOODEN_DOORS)||WorkRules.wood(id))return "carpentry";
  }
  if(id.contains("bandage")||id.contains("suture")||id.contains("splint"))return "first_aid";
  if(id.contains("cloth")||id.contains("fabric")||id.contains("wool")||stack.getItem() instanceof ArmorItem)return "tailoring";
  if(stack.getItem() instanceof TieredItem)return "metalworking";
  return null;
 }
 @SubscribeEvent public static void craft(PlayerEvent.ItemCraftedEvent e){
  if(!(e.getEntity() instanceof ServerPlayer p))return;
  if(e.getCrafting().getItem() instanceof BlockItem output&&(output.getBlock() instanceof SlabBlock||output.getBlock() instanceof SignBlock))return;
  // Recycling a single fence/trapdoor into planks does not allow an infinite XP loop.
  int nonempty=0;ItemStack input=ItemStack.EMPTY;boolean allSlabs=true;
  for(int i=0;i<e.getInventory().getContainerSize();i++)if(!e.getInventory().getItem(i).isEmpty()){nonempty++;input=e.getInventory().getItem(i);if(!(input.getItem() instanceof BlockItem slab)||!(slab.getBlock() instanceof SlabBlock))allSlabs=false;}
  if(nonempty>0&&allSlabs&&e.getCrafting().getItem() instanceof BlockItem result&&result.getBlock().defaultBlockState().is(BlockTags.PLANKS))return;
  if(nonempty==1&&input.getItem() instanceof BlockItem b&&(b.getBlock() instanceof FenceBlock||b.getBlock() instanceof TrapDoorBlock||b.getBlock() instanceof SignBlock))return;
  String kind=craftKind(e.getCrafting());if(kind!=null)xp(p,kind,WorkRules.craftXp(e.getCrafting().getCount()));
 }
 @SubscribeEvent public static void smelt(PlayerEvent.ItemSmeltedEvent e){
  if(!(e.getEntity() instanceof ServerPlayer p))return;
  ItemStack output=e.getSmelting();String id=id(output);
  if(output.has(DataComponents.FOOD))xp(p,"cooking",WorkRules.craftXp(output.getCount()));
  else if(WorkRules.metal(id)||id.contains("brick")||id.contains("glass"))xp(p,"metalworking",WorkRules.craftXp(output.getCount()));
 }
 @SubscribeEvent public static void harvest(net.neoforged.neoforge.event.level.BlockDropsEvent e){
  if(!(e.getBreaker() instanceof ServerPlayer p)||p.isCreative())return;
  if(e.getState().getBlock() instanceof CropBlock crop&&crop.isMaxAge(e.getState())){
   xp(p,"farming",5);Skill skill=Skills.get("farming");int level=skill==null?0:Skills.level(p,skill);
   if(p.getRandom().nextDouble()<level*.02)for(net.minecraft.world.entity.item.ItemEntity drop:java.util.List.copyOf(e.getDrops())){
    if(drop.getItem().has(DataComponents.FOOD)||drop.getItem().is(Items.WHEAT)){
     ItemStack bonus=drop.getItem().copyWithCount(1);e.getDrops().add(new net.minecraft.world.entity.item.ItemEntity(p.level(),drop.getX(),drop.getY(),drop.getZ(),bonus));break;
    }
   }
  }
  else if(e.getState().is(BlockTags.LOGS))xp(p,"carpentry",2);
  else if(e.getState().is(BlockTags.FLOWERS))xp(p,"foraging",1);
 }
 @SubscribeEvent public static void plant(BlockEvent.EntityPlaceEvent e){
  if(e.getEntity() instanceof ServerPlayer p&&e.getPlacedBlock().getBlock() instanceof CropBlock)xp(p,"farming",1);
 }
 @SubscribeEvent public static void hoe(BlockEvent.BlockToolModificationEvent e){
  if(!e.isSimulated()&&e.getContext().getPlayer() instanceof ServerPlayer p&&e.getItemAbility()==net.neoforged.neoforge.common.ItemAbilities.HOE_TILL)xp(p,"farming",1);
 }
 @SubscribeEvent public static void breakSpeed(PlayerEvent.BreakSpeed e){
  if(!(e.getEntity() instanceof ServerPlayer p)||p.isCreative())return;
  String id=e.getState().is(BlockTags.LOGS)||e.getState().is(BlockTags.PLANKS)?"carpentry":e.getState().is(BlockTags.MINEABLE_WITH_PICKAXE)?"metalworking":null;
  Skill s=id==null?null:Skills.get(id);if(s!=null)e.setNewSpeed(WorkRules.workSpeed(e.getNewSpeed(),Skills.level(p,s)));
 }
 @SubscribeEvent public static void fish(net.neoforged.neoforge.event.entity.player.ItemFishedEvent e){
  if(e.getEntity() instanceof ServerPlayer p&&!e.isCanceled()){
   int level=ActiveSkills.level(p,"fishing");
   if(p.getRandom().nextDouble()<Rules13.extraFishChance(level))for(ItemStack drop:java.util.List.copyOf(e.getDrops())){
    if(drop.is(Items.COD)||drop.is(Items.SALMON)||drop.is(Items.TROPICAL_FISH)||drop.is(Items.PUFFERFISH)){e.getDrops().add(drop.copyWithCount(1));break;}
   }
   xp(p,"fishing",5);
  }
 }
 @SubscribeEvent public static void use(LivingEntityUseItemEvent.Finish e){
  if(!(e.getEntity() instanceof ServerPlayer p))return;
  String id=id(e.getItem());
  if(!id.startsWith("firstaid:")&&(id.contains("morphine")||id.contains("medical")||id.contains("painkiller")))xp(p,"first_aid",3);
  if(e.getItem().has(DataComponents.FOOD)){
   Skill s=Skills.get("cooking");int level=s==null?0:Skills.level(p,s);
   p.getFoodData().setSaturation(Math.min(p.getFoodData().getFoodLevel(),p.getFoodData().getSaturationLevel()+level*.1f));
  }
 }
}
