package dev.survivorcreator.skills;
import java.util.*;
import java.lang.reflect.*;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.damagesource.*;
import net.minecraft.server.level.*;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
@EventBusSubscriber(modid="survivorcreator")
public final class DamagePopups {
 record Mark(UUID attacker,int tick,int bullet){}
 record Popup(ArmorStand entity,int start,UUID victim){}
 private static final Map<UUID,Mark> CRITS=new HashMap<>(),HEADS=new HashMap<>();
 private static final List<Popup> ACTIVE=new ArrayList<>();
 private static final Set<UUID> FIRST_AID_VICTIMS=new HashSet<>();
 public static void init(){
  try{
   Class<?> event=Class.forName("com.tacz.guns.api.event.common.EntityHurtByGunEvent$Pre");
   Object bus=Class.forName("net.neoforged.neoforge.common.NeoForge").getField("EVENT_BUS").get(null);
   Consumer<Object> listener=DamagePopups::gun;
   for(Method m:bus.getClass().getMethods())if(m.getName().equals("addListener")&&m.getParameterCount()==4&&m.getParameterTypes()[2]==Class.class){m.invoke(bus,EventPriority.LOWEST,false,event,listener);break;}
  }catch(ClassNotFoundException|LinkageError ignored){}catch(ReflectiveOperationException ex){dev.survivorcreator.SurvivorCreator.LOGGER.warn("No se pudo conectar el aviso de headshot TaCZ",ex);}
 }
 private static void gun(Object e){try{
  if(!Boolean.TRUE.equals(e.getClass().getMethod("isHeadShot").invoke(e)))return;
  Object a=e.getClass().getMethod("getAttacker").invoke(e),v=e.getClass().getMethod("getHurtEntity").invoke(e),b=e.getClass().getMethod("getBullet").invoke(e);
  if(a instanceof ServerPlayer p&&v instanceof LivingEntity victim&&b instanceof Entity bullet)HEADS.put(victim.getUUID(),new Mark(p.getUUID(),p.tickCount,bullet.getId()));
 }catch(ReflectiveOperationException ignored){}}
 @SubscribeEvent(priority=EventPriority.LOWEST) public static void critical(CriticalHitEvent e){
  if(e.getEntity() instanceof ServerPlayer p){if(e.isCriticalHit())CRITS.put(e.getTarget().getUUID(),new Mark(p.getUUID(),p.tickCount,-1));else CRITS.remove(e.getTarget().getUUID());}
 }
 @SubscribeEvent public static void damage(LivingDamageEvent.Post e){
  if(FIRST_AID_VICTIMS.remove(e.getEntity().getUUID()))return;
  show(e.getEntity(),e.getSource(),e.getNewDamage());
 }
 public static void firstAid(net.minecraft.world.entity.player.Player victim,DamageSource source,float amount){if(amount>0){FIRST_AID_VICTIMS.add(victim.getUUID());show(victim,source,amount);}}
 public static void show(LivingEntity victim,DamageSource source,float amount){
  if(!(source.getEntity() instanceof ServerPlayer p)||!(victim instanceof net.minecraft.world.entity.player.Player||victim instanceof net.minecraft.world.entity.monster.Monster)||!Float.isFinite(amount)||amount<=0||victim.level().isClientSide())return;
  Mark head=HEADS.get(victim.getUUID()),crit=CRITS.get(victim.getUUID());
  boolean hs=head!=null&&head.attacker.equals(p.getUUID())&&head.tick==p.tickCount&&source.getDirectEntity()!=null&&source.getDirectEntity().getId()==head.bullet;
  if(!hs&&source.getDirectEntity()==p&&source.is(DamageTypes.PLAYER_ATTACK)){
   var eye=p.getEyePosition();var box=victim.getBoundingBox();var hit=box.clip(eye,eye.add(p.getLookAngle().scale(p.distanceTo(victim)+3)));
   hs=hit.isPresent()&&(hit.get().y-box.minY)/Math.max(.01,box.getYsize())>=.80;
  }
  boolean critical=crit!=null&&crit.attacker.equals(p.getUUID())&&crit.tick==p.tickCount&&source.getDirectEntity()==p&&source.is(DamageTypes.PLAYER_ATTACK);
  String label=hs?"HEADSHOT":critical?"CRÍTICO":"GOLPE";ChatFormatting color=hs?ChatFormatting.RED:critical?ChatFormatting.GOLD:ChatFormatting.WHITE;
  while(ACTIVE.size()>=80)ACTIVE.removeFirst().entity.discard();
  long count=ACTIVE.stream().filter(x->x.victim.equals(victim.getUUID())).count();
  if(count>=5){for(var it=ACTIVE.iterator();it.hasNext();){Popup x=it.next();if(x.victim.equals(victim.getUUID())){x.entity.discard();it.remove();break;}}count=4;}
  ServerLevel level=(ServerLevel)victim.level();ArmorStand as=new ArmorStand(level,victim.getX(),victim.getY()+victim.getBbHeight()+.18+count*.13,victim.getZ());
  CompoundTag tag=new CompoundTag();as.saveWithoutId(tag);tag.putBoolean("Marker",true);tag.putBoolean("Invisible",true);tag.putBoolean("NoGravity",true);as.load(tag);
  as.setCustomName(Component.literal(label+" −"+String.format(Locale.ROOT,"%.1f",amount)).withStyle(color));as.setCustomNameVisible(true);as.setInvulnerable(true);as.setSilent(true);as.addTag("survivorcreator_damage_popup");
  if(level.addFreshEntity(as))ACTIVE.add(new Popup(as,as.tickCount,victim.getUUID()));
 }
 public static void tick(){for(var it=ACTIVE.iterator();it.hasNext();){Popup p=it.next();if(p.entity.isRemoved()||p.entity.tickCount-p.start>=24){p.entity.discard();it.remove();}else p.entity.setPos(p.entity.getX(),p.entity.getY()+.012,p.entity.getZ());}CRITS.clear();HEADS.clear();FIRST_AID_VICTIMS.clear();}
 public static void clear(){for(Popup p:ACTIVE)p.entity.discard();ACTIVE.clear();CRITS.clear();HEADS.clear();FIRST_AID_VICTIMS.clear();}
}
