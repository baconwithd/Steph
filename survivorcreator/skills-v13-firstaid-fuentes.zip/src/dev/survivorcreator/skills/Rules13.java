package dev.survivorcreator.skills;
public final class Rules13 {
 public static int level(int n){return Math.max(0,Math.min(10,n));}
 public static double health(int fitness,int strength){return level(fitness)+level(strength);}
 public static double timeFactor(int n){return 1-.04*level(n);}
 public static double extraTicks(int n){return 1/timeFactor(n)-1;}
 public static float healing(float base,int n){return base*(1+.05f*level(n));}
 public static int duration(int ticks,int n){return Math.max(1,(int)Math.ceil(ticks*timeFactor(n)));}
 public static float fishingLuck(float base,int n){return base+.2f*level(n);}
 public static double extraFishChance(int n){return .05*level(n);}
 public static double nextFraction(double xp,int n){double[] curve=Skill.DEFAULT_CURVE;int l=level(n);if(l==10)return 1;double start=l==0?0:curve[l-1];return Math.max(0,Math.min(1,(xp-start)/(curve[l]-start)));}
}
