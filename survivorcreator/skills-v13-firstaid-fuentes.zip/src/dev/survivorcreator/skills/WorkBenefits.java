package dev.survivorcreator.skills;
import net.minecraft.network.chat.Component;
public final class WorkBenefits {
 public static Component describe(Skill s,int level){
  int n=Rules13.level(level);
  String text=switch(s.id()){
   case "fitness"->String.format(java.util.Locale.ROOT,"Armadura +%.1f; vida máxima +%d; carga +%.1f kg",n*.4,n,n*1.5);
   case "strength"->String.format(java.util.Locale.ROOT,"Daño cuerpo a cuerpo +%.1f; vida máxima +%d; carga +%d kg",n*.8,n,n*2);
   case "sprinting"->String.format(java.util.Locale.ROOT,"Capacidad de carga +%.1f kg",n*.5);
   case "carpentry","metalworking"->"Velocidad de trabajo +"+(n*3)+"%";
   case "cooking"->String.format(java.util.Locale.ROOT,"Saturación al comer +%.1f",n*.1);
   case "farming"->"Posibilidad de cosecha extra +"+(n*2)+"%";
   case "fishing"->String.format(java.util.Locale.ROOT,"Espera −%d%%; suerte +%.1f; pez extra %d%%",n*4,n*.2,n*5);
   case "first_aid"->"Tiempo de tratamiento −"+(n*4)+"%; curación +"+(n*5)+"%";
   default->"Sin efecto activo";
  };return Component.literal(text);
 }
}
