package dev.survivorcreator.skills;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.server.level.ServerPlayer;
public final class FishingBenefits {
 public static int level(FishingHook h){return h.getPlayerOwner() instanceof ServerPlayer p?ActiveSkills.level(p,"fishing"):0;}
 public static int waitTime(FishingHook h,int ticks){return Rules13.duration(ticks,level(h));}
 public static float luck(FishingHook h,float base){return Rules13.fishingLuck(base,level(h));}
}
