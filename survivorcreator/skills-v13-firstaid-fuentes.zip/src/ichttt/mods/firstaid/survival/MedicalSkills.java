package ichttt.mods.firstaid.survival;
import java.util.*;
import java.lang.reflect.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import ichttt.mods.firstaid.api.damagesystem.*;
import ichttt.mods.firstaid.api.healing.PartHealingContext;
public final class MedicalSkills {
 private static class State {int tick=-1,reward=-1;double fraction;}
 private static final Map<Player,State> STATES=new WeakHashMap<>();
 private static Method level,xp,get,damage;
 private static boolean missing;
 private static void bind(){if(level!=null||missing)return;try{
  Class<?> api=Class.forName("dev.survivorcreator.skills.Skills"),skill=Class.forName("dev.survivorcreator.skills.Skill");
  get=api.getMethod("get",String.class);level=api.getMethod("level",ServerPlayer.class,skill);xp=api.getMethod("addXp",ServerPlayer.class,skill,double.class);
 }catch(ReflectiveOperationException|LinkageError e){missing=true;}}
 public static int level(Player p){if(!(p instanceof ServerPlayer))return clientLevel();bind();if(missing)return 0;try{Object skill=get.invoke(null,"first_aid");return skill==null?0:Math.max(0,Math.min(10,((Number)level.invoke(null,p,skill)).intValue()));}catch(ReflectiveOperationException e){return 0;}}
 public static int clientLevel(){try{
  String json=(String)Class.forName("dev.survivorcreator.skills.SkillSnapshot").getMethod("json").invoke(null);if(json.isEmpty())return 0;
  for(com.google.gson.JsonElement e:com.google.gson.JsonParser.parseString(json).getAsJsonObject().getAsJsonArray("rows"))if(e.getAsJsonObject().get("id").getAsString().equals("first_aid"))return Math.max(0,Math.min(10,e.getAsJsonObject().get("level").getAsInt()));
 }catch(ReflectiveOperationException|RuntimeException|LinkageError ignored){}return 0;}
 public static int clientDuration(int ticks){return duration(ticks,clientLevel());}
 public static int duration(int ticks,int n){return MedicalRules.duration(ticks,n);}
 public static float amount(float base,int n){return MedicalRules.amount(base,n);}
 public static void reward(Player p){if(!(p instanceof ServerPlayer)||p.isCreative()||p.isSpectator())return;State state=STATES.computeIfAbsent(p,x->new State());if(state.reward==p.tickCount)return;state.reward=p.tickCount;bind();if(missing)return;try{Object s=get.invoke(null,"first_aid");if(s!=null)xp.invoke(null,p,s,3.0);}catch(ReflectiveOperationException ignored){}}
 public static void started(PartHealingContext ctx){reward(ctx.getPlayer());}
 public static void applied(Object model,Object player){if(player instanceof Player p)reward(p);}
 public static void beforeTick(AbstractPlayerDamageModel model,Player p){
  if(!(p instanceof ServerPlayer)||!p.isAlive()||p.isCreative()||p.isSpectator())return;
  State state=STATES.computeIfAbsent(p,x->new State());if(state.tick==p.tickCount)return;state.tick=p.tickCount;
  int n=level(p);if(n<=0)return;state.fraction+=MedicalRules.extra(n);int extra=(int)state.fraction;state.fraction-=extra;if(extra<=0)return;
  ClinicalState cs=ClinicalData.state(model);
  if(cs.dressingPart>=0)cs.dressingProgress+=extra;
  if(cs.extractionPart>=0)cs.extractionProgress+=extra;
  for(ClinicalState.Wound w:cs.wounds)if(w.active()&&w.bandaged&&ichttt.mods.firstaid.compat.lrtactical.TreatmentV33.recoveryAllowed(w)&&w.healingLeft>1)w.healingLeft=Math.max(1,w.healingLeft-extra);
  for(AbstractDamageablePart part:model)if(part.activeHealer instanceof ichttt.mods.firstaid.common.damagesystem.PartHealer healer){try{
   Field f=healer.getClass().getDeclaredField("ticksPassed");f.setAccessible(true);f.setInt(healer,f.getInt(healer)+extra);
  }catch(ReflectiveOperationException ignored){}}
 }
 public static float pulse(AbstractDamageablePart part,float value,Player player,boolean debuff){return part.heal(amount(value,level(player)),player,debuff);}
 public static String label(int ticks,boolean extraction){return (extraction?"Extraer bala · ":"Tratar parte · ")+String.format(java.util.Locale.ROOT,"%.1f s",clientDuration(ticks)/20.0);}
 public static boolean extract(ClinicalState cs,boolean valid,Player player){boolean done=cs.tickExtraction(valid);if(done)reward(player);return done;}
 public static void extraction(Object player){if(player instanceof Player p)reward(p);}
 public static boolean scaleEnabled(boolean configured,Player player){return configured||player.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH)>20;}
 public static void damageAfter(Player player,DamageSource source,AbstractPlayerDamageModel model,AbstractPlayerDamageModel before){
  float dealt=0;for(AbstractDamageablePart p:model)dealt+=Math.max(0,before.getFromEnum(p.part).currentHealth-p.currentHealth);
  if(dealt<=0)return;try{if(damage==null)damage=Class.forName("dev.survivorcreator.skills.DamagePopups").getMethod("firstAid",Player.class,DamageSource.class,float.class);damage.invoke(null,player,source,dealt);}catch(ReflectiveOperationException|LinkageError ignored){}
 }
}
