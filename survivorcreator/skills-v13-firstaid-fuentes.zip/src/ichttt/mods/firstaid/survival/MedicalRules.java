package ichttt.mods.firstaid.survival;
public final class MedicalRules {
 public static int level(int n){return Math.max(0,Math.min(10,n));}
 public static double factor(int n){return 1-.04*level(n);}
 public static double extra(int n){return 1/factor(n)-1;}
 public static int duration(int ticks,int n){return Math.max(1,(int)Math.ceil(ticks*factor(n)));}
 public static float amount(float base,int n){return base*(1+.05f*level(n));}
}
