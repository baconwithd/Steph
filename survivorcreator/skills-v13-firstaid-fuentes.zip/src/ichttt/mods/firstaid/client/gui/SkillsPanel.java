package ichttt.mods.firstaid.client.gui;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import ichttt.mods.firstaid.compat.lrtactical.TreatmentV33;
public final class SkillsPanel {
 record Hit(int x,int y,int width,SurvivorSkillsView.SkillRow row){}
 private static final Map<Object,List<Hit>> HITS=new WeakHashMap<>();
 private static final double[] CURVE={30,80,160,280,450,700,1000,1400,1900,2500};
 static String group(String id){return switch(id){case "fitness","strength"->"Pasivas";case "sprinting"->"Agilidad";case "fishing"->"Supervivencia";default->"Oficios";};}
 public static int draw(Object screen,GuiGraphics g,int x,int y){
  Object layout=TreatmentV33.get(screen,"layout");int width=((Number)TreatmentV33.get(layout,"rightWidth")).intValue();Font font=(Font)TreatmentV33.get(screen,"font");
  var snapshot=new SurvivorSkillsView().read(Minecraft.getInstance());List<Hit> hits=new ArrayList<>();HITS.put(screen,hits);
  if(snapshot.rows().isEmpty()){g.drawString(font,snapshot.status(),x+4,y+4,0xffa0a0a0,false);return y+28;}
  String previous="";int box=Math.max(4,Math.min(14,(width-92)/10-2));int bars=10*(box+2)-2;int nameWidth=width-bars-10;
  for(var row:snapshot.rows()){
   String group=group(row.id());if(!group.equals(previous)){if(!previous.isEmpty())y+=7;g.drawString(font,group,x+4,y,0xffeeeeee,false);g.fill(x+4,y+12,x+width-4,y+13,0xff474747);y+=19;previous=group;}
   g.fill(x+2,y-1,x+width-3,y+17,0xff181818);
   String name=SurvivorSkillsView.name(row.id());float scale=Math.min(1f,(float)Math.max(20,nameWidth-3)/Math.max(1,font.width(name)));
   g.pose().pushPose();g.pose().translate(x+6,y+4,0);g.pose().scale(scale,scale,1);g.drawString(font,name,0,0,0xffbababa,false);g.pose().popPose();
   int level=Math.max(0,Math.min(10,row.level()));double xp=row.xp()==null?0:row.xp();double start=level==0?0:CURVE[level-1],fraction=level==10?1:Math.max(0,Math.min(1,(xp-start)/(CURVE[level]-start)));
   int bx=x+width-bars-5;
   for(int i=0;i<10;i++){int px=bx+i*(box+2);g.fill(px,y+1,px+box,y+15,0xff555555);g.fill(px+1,y+2,px+box-1,y+14,0xff111111);
    if(i<level)g.fillGradient(px+1,y+2,px+box-1,y+14,0xffffefa3,0xffac9049);
    else if(i==level&&fraction>0){int fill=Math.max(1,(int)Math.round((box-2)*fraction));g.fillGradient(px+1,y+2,Math.min(px+box-1,px+1+fill),y+14,0xffacb7be,0xff596269);}
   }
   hits.add(new Hit(x,y,width,row));y+=19;
  }return y+5;
 }
 public static void tooltip(Object screen,GuiGraphics g,int mx,int my){
  if(((Number)TreatmentV33.get(screen,"tab")).intValue()!=1)return;
  Object layout=TreatmentV33.get(screen,"layout");if(layout==null)return;
  int top=((Number)TreatmentV33.get(layout,"contentTop")).intValue(),bottom=((Number)TreatmentV33.get(layout,"contentBottom")).intValue();if(my<top||my>=bottom)return;
  Font font=(Font)TreatmentV33.get(screen,"font");for(Hit hit:HITS.getOrDefault(screen,List.of()))if(mx>=hit.x&&mx<hit.x+hit.width&&my>=hit.y&&my<hit.y+17){
   var row=hit.row;int level=Math.max(0,Math.min(10,row.level()));double start=level==0?0:CURVE[level-1];
   List<String> lines=new ArrayList<>();lines.add(SurvivorSkillsView.name(row.id())+" · Nivel "+level);
   lines.add(level==10?"Nivel máximo":String.format(Locale.ROOT,"XP: %.1f / %.0f",Math.max(0,(row.xp()==null?0:row.xp())-start),CURVE[level]-start));
   lines.addAll(benefits(row.id(),level));
   int width=lines.stream().mapToInt(font::width).max().orElse(100)+12;int sx=((Number)TreatmentV33.get(screen,"width")).intValue(),sy=((Number)TreatmentV33.get(screen,"height")).intValue();
   int x=Math.max(2,Math.min(mx+12,sx-width-3)),y=Math.max(2,Math.min(my+12,sy-lines.size()*11-12));
   g.pose().pushPose();g.pose().translate(0,0,400);g.fill(x-1,y-1,x+width+1,y+lines.size()*11+9,0xff777360);g.fill(x,y,x+width,y+lines.size()*11+8,0xf5101010);
   for(int i=0;i<lines.size();i++)g.drawString(font,lines.get(i),x+6,y+5+i*11,i==0?0xffffe4a0:0xffc7c7c7,false);g.pose().popPose();return;
  }
 }
 static List<String> benefits(String id,int n){return switch(id){
  case "fitness"->List.of(String.format(Locale.ROOT,"Armadura +%.1f · Vida máxima +%d",n*.4,n),String.format(Locale.ROOT,"Carga +%.1f kg",n*1.5));
  case "strength"->List.of(String.format(Locale.ROOT,"Daño melee +%.1f · Vida máxima +%d",n*.8,n),"Carga +"+(n*2)+" kg");
  case "sprinting"->List.of(String.format(Locale.ROOT,"Carga +%.1f kg",n*.5));
  case "carpentry","metalworking"->List.of("Velocidad de trabajo +"+(n*3)+"%");
  case "cooking"->List.of(String.format(Locale.ROOT,"Saturación al comer +%.1f",n*.1));
  case "farming"->List.of("Cosecha extra: "+(n*2)+"%");
  case "first_aid"->List.of("Tiempo −"+(n*4)+"% · Curación +"+(n*5)+"%");
  case "fishing"->List.of(String.format(Locale.ROOT,"Espera −%d%% · Suerte +%.1f",n*4,n*.2),"Pez extra: "+(n*5)+"%");
  default->List.of();};}
}
