package ichttt.mods.firstaid.client.gui;
import java.util.*;
import net.minecraft.client.Minecraft;
import com.google.gson.*;
public final class SurvivorSkillsView {
 public record SkillRow(String id,int level,Double xp){}
 public record Snapshot(List<SkillRow> rows,String status){}
 public Snapshot read(Minecraft mc){
  if(mc.player==null)return new Snapshot(List.of(),"Sin jugador");
  try{
   String json=(String)Class.forName("dev.survivorcreator.skills.SkillSnapshot").getMethod("json").invoke(null);
   if(json.isEmpty())return new Snapshot(List.of(),"Esperando habilidades del servidor…");
   JsonObject obj=JsonParser.parseString(json).getAsJsonObject();if(!mc.player.getUUID().toString().equals(obj.get("player").getAsString()))return new Snapshot(List.of(),"Esperando habilidades…");
   List<SkillRow> rows=new ArrayList<>();for(JsonElement e:obj.getAsJsonArray("rows")){JsonObject row=e.getAsJsonObject();rows.add(new SkillRow(row.get("id").getAsString(),row.get("level").getAsInt(),row.get("xp").getAsDouble()));}
   return new Snapshot(List.copyOf(rows),"Practica para mejorar");
  }catch(ReflectiveOperationException|LinkageError|RuntimeException e){return new Snapshot(List.of(),"Requiere Survivor Creator v13");}
 }
 public static String name(String id){return switch(id){case "fitness"->"Condición física";case "strength"->"Fuerza";case "sprinting"->"Carrera";case "carpentry"->"Carpintería";case "metalworking"->"Metalurgia";case "cooking"->"Cocina";case "farming"->"Agricultura";case "first_aid"->"Primeros auxilios";case "fishing"->"Pesca";default->id;};}
}
