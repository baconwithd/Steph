import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Patch13 implements Opcodes {
 static final String S="dev/survivorcreator/skills/",M="ichttt/mods/firstaid/survival/MedicalSkills",P="ichttt/mods/firstaid/client/gui/SkillsPanel";
 static void callBeforeReturns(MethodNode m,String owner,String name,String desc,int... slots){for(var i:m.instructions.toArray())if(i.getOpcode()==RETURN){InsnList list=new InsnList();for(int slot:slots)list.add(new VarInsnNode(ALOAD,slot));list.add(new MethodInsnNode(INVOKESTATIC,owner,name,desc,false));m.instructions.insertBefore(i,list);}}
 static byte[] patch(String path,byte[] bytes,boolean survivor){ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);int changes=0;
  for(var m:c.methods){
   if(survivor){
    if(path.equals(S+"Skills.class")&&m.name.equals("<clinit>")){for(var i:m.instructions.toArray())if(i.getOpcode()==RETURN){InsnList list=new InsnList();list.add(new FieldInsnNode(GETSTATIC,S+"Skills","REGISTRY","Ljava/util/Map;"));list.add(new MethodInsnNode(INVOKESTATIC,S+"ActiveSkills","prune","(Ljava/util/Map;)V",false));m.instructions.insertBefore(i,list);changes++;}}
    if(path.equals(S+"Skills.class")&&m.name.equals("apply")){callBeforeReturns(m,S+"ActiveSkills","apply","(Lnet/minecraft/server/level/ServerPlayer;)V",0);changes++;}
    if(path.equals(S+"Skills.class")&&m.name.equals("init")){callBeforeReturns(m,S+"DamagePopups","init","()V");changes++;}
    if(path.equals("dev/survivorcreator/net/Net.class")&&m.name.equals("register")){callBeforeReturns(m,S+"SkillSync","register","(Lnet/neoforged/neoforge/network/event/RegisterPayloadHandlersEvent;)V",0);changes++;}
   }else{
    if(path.endsWith("/GuiHealthScreen.class")&&m.name.equals("skills")){
     m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;
     m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new VarInsnNode(ILOAD,2));m.instructions.add(new VarInsnNode(ILOAD,3));m.instructions.add(new MethodInsnNode(INVOKESTATIC,P,"draw","(Ljava/lang/Object;Lnet/minecraft/client/gui/GuiGraphics;II)I",false));m.instructions.add(new InsnNode(IRETURN));changes++;
    }
    if(path.endsWith("/GuiHealthScreen.class")&&m.name.equals("render")){for(var i:m.instructions.toArray())if(i.getOpcode()==RETURN){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ILOAD,2));l.add(new VarInsnNode(ILOAD,3));l.add(new MethodInsnNode(INVOKESTATIC,P,"tooltip","(Ljava/lang/Object;Lnet/minecraft/client/gui/GuiGraphics;II)V",false));m.instructions.insertBefore(i,l);}changes++;}
    if(path.endsWith("/ClinicalHooks.class")&&m.name.equals("tick")){
     InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(new MethodInsnNode(INVOKESTATIC,M,"beforeTick","(Lichttt/mods/firstaid/api/damagesystem/AbstractPlayerDamageModel;Lnet/minecraft/world/entity/player/Player;)V",false));m.instructions.insert(l);changes++;
     for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call){
      if(call.name.equals("heal")&&call.desc.equals("(FLnet/minecraft/world/entity/player/Player;Z)F")){call.setOpcode(INVOKESTATIC);call.owner=M;call.name="pulse";call.desc="(Lichttt/mods/firstaid/api/damagesystem/AbstractDamageablePart;FLnet/minecraft/world/entity/player/Player;Z)F";call.itf=false;changes++;}
      if(call.name.equals("tickExtraction")){m.instructions.insertBefore(i,new VarInsnNode(ALOAD,1));call.setOpcode(INVOKESTATIC);call.owner=M;call.name="extract";call.desc="(Lichttt/mods/firstaid/survival/ClinicalState;ZLnet/minecraft/world/entity/player/Player;)Z";call.itf=false;changes++;}
     }
    }
    if(path.endsWith("/DamageablePart.class")&&m.name.equals("tick")&&m.desc.equals("(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;ZZ)V"))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.name.equals("heal")&&call.desc.equals("(FLnet/minecraft/world/entity/player/Player;Z)F")){call.setOpcode(INVOKESTATIC);call.owner=M;call.name="pulse";call.desc="(Lichttt/mods/firstaid/api/damagesystem/AbstractDamageablePart;FLnet/minecraft/world/entity/player/Player;Z)F";call.itf=false;changes++;}
    if(path.endsWith("/TreatmentV33.class")&&m.name.equals("applied")){callBeforeReturns(m,M,"applied","(Ljava/lang/Object;Ljava/lang/Object;)V",0,1);changes++;}
    if(path.endsWith("/TreatmentV33.class")&&m.name.equals("startClient")){InsnList l=new InsnList();l.add(new VarInsnNode(ILOAD,2));l.add(new MethodInsnNode(INVOKESTATIC,M,"clientDuration","(I)I",false));l.add(new VarInsnNode(ISTORE,2));m.instructions.insert(l);changes++;}
    if(path.endsWith("/TreatmentV33.class")&&m.name.equals("treatmentLabel"))for(var i:m.instructions.toArray())if(i instanceof LdcInsnNode ldc&&ldc.cst instanceof String str&&(str.startsWith("Extraer bala")||str.startsWith("Tratar parte"))){InsnList l=new InsnList();l.add(new IntInsnNode(BIPUSH,str.startsWith("Extraer")?80:66));l.add(new InsnNode(str.startsWith("Extraer")?ICONST_1:ICONST_0));l.add(new MethodInsnNode(INVOKESTATIC,M,"label","(IZ)Ljava/lang/String;",false));m.instructions.insertBefore(i,l);m.instructions.remove(i);changes++;}
    if(path.endsWith("/ItemHealing.class")&&m.name.equals("onTreatmentStarted")){callBeforeReturns(m,M,"started","(Lichttt/mods/firstaid/api/healing/PartHealingContext;)V",1);changes++;}
    if(path.endsWith("/PlayerDamageModel.class")&&m.name.equals("runScaleLogic")){boolean found=false;for(var i:m.instructions.toArray()){if(i instanceof FieldInsnNode f&&f.name.equals("scaleMaxHealth"))found=true;if(found&&i instanceof MethodInsnNode call&&call.owner.equals("java/lang/Boolean")&&call.name.equals("booleanValue")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(new MethodInsnNode(INVOKESTATIC,M,"scaleEnabled","(ZLnet/minecraft/world/entity/player/Player;)Z",false));m.instructions.insert(i,l);changes++;break;}}}
    if(path.endsWith("/DamageDistribution.class")&&m.name.equals("clinicalNativeHandleDamageTaken")){
     int before=-1;boolean seen=false;AbstractInsnNode ret=null;for(var i:m.instructions.toArray()){if(i instanceof TypeInsnNode t&&t.getOpcode()==NEW&&t.desc.endsWith("/PlayerDamageModel"))seen=true;if(seen&&i instanceof VarInsnNode v&&v.getOpcode()==ASTORE){before=v.var;seen=false;}if(i.getOpcode()==FRETURN)ret=i;}
     if(before<0||ret==null)throw new IllegalStateException("Missing before damage model");InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,3));l.add(new VarInsnNode(ALOAD,4));l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ALOAD,before));l.add(new MethodInsnNode(INVOKESTATIC,M,"damageAfter","(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/damagesource/DamageSource;Lichttt/mods/firstaid/api/damagesystem/AbstractPlayerDamageModel;Lichttt/mods/firstaid/api/damagesystem/AbstractPlayerDamageModel;)V",false));m.instructions.insertBefore(ret,l);changes++;
    }
    // Ordinary medical application times on the client are reduced consistently.
    for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.name.equals("getApplyTime")&&call.owner.equals("ichttt/mods/firstaid/api/healing/ItemHealing")){m.instructions.insert(i,new MethodInsnNode(INVOKESTATIC,M,"clientDuration","(I)I",false));changes++;}
   }
  }
  if(changes==0)return bytes;System.out.println(path+": "+changes+" sites");ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);return w.toByteArray();
 }
 public static void main(String[] a)throws Exception{
  boolean survivor=a[3].equals("survivor");String prefix=survivor?"dev/survivorcreator/":"ichttt/mods/firstaid/";
  try(ZipFile z=new ZipFile(a[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(a[1])))){
   for(var it=z.entries();it.hasMoreElements();){var e=it.nextElement();if(e.isDirectory())continue;String path=e.getName();if(path.startsWith(prefix)&&Files.exists(Path.of(a[2]).resolve(path)))continue;if(survivor&&Files.exists(Path.of("work/skills13/resources").resolve(path)))continue;
    byte[] b=z.getInputStream(e).readAllBytes();if(path.startsWith(prefix)&&path.endsWith(".class"))b=patch(path,b,survivor);
    if(path.equals("META-INF/neoforge.mods.toml")){String text=new String(b,java.nio.charset.StandardCharsets.UTF_8);text=survivor?text.replace("version = \"1.0.7\"","version = \"1.0.8\"")+"\n[[mixins]]\nconfig = \"survivorcreator-skills13.mixins.json\"\n":text.replace("zomboid-v3.4.4-low-infection","zomboid-v3.4.5-skills-menu");b=text.getBytes(java.nio.charset.StandardCharsets.UTF_8);}
    out.putNextEntry(new ZipEntry(path));out.write(b);out.closeEntry();
   }
   Path root=Path.of(a[2]);try(var stream=Files.walk(root.resolve(prefix))){for(Path p:stream.filter(f->f.toString().endsWith(".class")).toList()){out.putNextEntry(new ZipEntry(root.relativize(p).toString()));out.write(Files.readAllBytes(p));out.closeEntry();}}
   if(survivor){Path resources=Path.of("work/skills13/resources");try(var stream=Files.walk(resources)){for(Path p:stream.filter(Files::isRegularFile).toList()){out.putNextEntry(new ZipEntry(resources.relativize(p).toString()));out.write(Files.readAllBytes(p));out.closeEntry();}}}
  }
 }
}
