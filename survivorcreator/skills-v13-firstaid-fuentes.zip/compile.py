from pathlib import Path
import subprocess
libs=':'.join(str(p) for p in Path('work/lib').glob('*.jar'))
mc='attachments/1338682b-fcc2-4d11-9002-1714ece5faed/client-1.21.1-20240808.144430-srg.jar'
neo='attachments/31294bde-ea70-4506-8023-e3eaaf3a59ac/neoforge-21.1.255-universal.jar'
cp=':'.join([str(Path('outputs/survivorcreator-neoforge-1.21.1-1.0.7-zomboid-v12-grace-progress.jar')),str(Path('outputs/firstaid-1.21.1-ZOMBOID-v3.4.4-low-infection.jar')),mc,neo,libs])
files=[str(p) for p in Path('work/skills13/src').rglob('*.java')]
r=subprocess.run(['java','-jar','work/lib/ecj.jar','-21','-proc:none','-warn:none','-cp',cp,'-sourcepath','work/skills13/src:work/hordes/stubs:work/stubs','-d','work/skills13/classes',*files],capture_output=True,text=True)
print(r.stdout,r.stderr);raise SystemExit(r.returncode)
