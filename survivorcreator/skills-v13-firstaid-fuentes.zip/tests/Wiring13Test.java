import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Wiring13Test {
 static int n;static void ok(boolean x){n++;if(!x)throw new AssertionError("Wiring "+n);}
 static ClassNode cls(ZipFile z,String path)throws Exception {ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(path)).readAllBytes()).accept(c,0);return c;}
 static boolean call(ClassNode c,String method,String owner,String name){for(MethodNode m:c.methods)if(m.name.equals(method))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.owner.equals(owner)&&x.name.equals(name))return true;return false;}
 public static void main(String[] a)throws Exception{
  String s="dev/survivorcreator/skills/",med="ichttt/mods/firstaid/survival/MedicalSkills";
  try(ZipFile z=new ZipFile(a[0])){
   var c=cls(z,s+"Skills.class");ok(call(c,"<clinit>",s+"ActiveSkills","prune"));ok(call(c,"apply",s+"ActiveSkills","apply"));ok(call(c,"init",s+"DamagePopups","init"));ok(call(c,"addXp",s+"LevelUpQueue","scale"));ok(call(c,"grant",s+"LevelUpQueue","enqueueRange"));
   ok(call(cls(z,"dev/survivorcreator/net/Net.class"),"register",s+"SkillSync","register"));
   var mix=cls(z,"dev/survivorcreator/mixin/FishingMixin.class");ok(mix.invisibleAnnotations.stream().anyMatch(x->x.desc.endsWith("/Mixin;")));
   int inject=0,modify=0;for(var m:mix.methods)if(m.visibleAnnotations!=null)for(var ann:m.visibleAnnotations){if(ann.desc.endsWith("/Inject;"))inject++;if(ann.desc.endsWith("/ModifyArg;"))modify++;}ok(inject==2&&modify==1);
   ok(call(mix,"sc_after",s+"FishingBenefits","waitTime"));ok(call(mix,"sc_luck",s+"FishingBenefits","luck"));
   ok(call(cls(z,s+"SkillEvents.class"),"hit",s+"Skills","addXp"));
   ok(!z.stream().anyMatch(e->e.getName().startsWith("io/netty/")||e.getName().startsWith("org/spongepowered/")));
  }
  try(ZipFile z=new ZipFile(a[1])){
   var gui=cls(z,"ichttt/mods/firstaid/client/gui/GuiHealthScreen.class");ok(call(gui,"skills","ichttt/mods/firstaid/client/gui/SkillsPanel","draw"));ok(call(gui,"render","ichttt/mods/firstaid/client/gui/SkillsPanel","tooltip"));
   var clinical=cls(z,"ichttt/mods/firstaid/survival/ClinicalHooks.class");ok(call(clinical,"tick",med,"beforeTick"));ok(call(clinical,"tick",med,"extract"));ok(call(clinical,"tick",med,"pulse"));
   ok(call(cls(z,"ichttt/mods/firstaid/common/damagesystem/DamageablePart.class"),"tick",med,"pulse"));
   ok(call(cls(z,"ichttt/mods/firstaid/common/damagesystem/PlayerDamageModel.class"),"runScaleLogic",med,"scaleEnabled"));
   ok(call(cls(z,"ichttt/mods/firstaid/common/damagesystem/distribution/DamageDistribution.class"),"clinicalNativeHandleDamageTaken",med,"damageAfter"));
   ok(call(cls(z,"ichttt/mods/firstaid/compat/lrtactical/TreatmentV33.class"),"applied",med,"applied"));
   ok(call(cls(z,"ichttt/mods/firstaid/api/healing/ItemHealing.class"),"onTreatmentStarted",med,"started"));
  }
  System.out.println("PASS: "+n+" integration checks for filtering, grace/progression preservation, fishing injections, healing and multiplayer UI/damage");
 }
}
