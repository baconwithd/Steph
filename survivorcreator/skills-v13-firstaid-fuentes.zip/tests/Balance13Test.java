import dev.survivorcreator.skills.*;
import ichttt.mods.firstaid.survival.MedicalRules;
import java.util.*;
public class Balance13Test {
 static int checks;static void ok(boolean value){checks++;if(!value)throw new AssertionError("Check "+checks);}
 static int treatmentTicks(int n,int duration){int progress=0,time=0;double fraction=0;while(progress<duration){fraction+=MedicalRules.extra(n);int extra=(int)fraction;fraction-=extra;progress+=extra+1;time++;}return time;}
 public static void main(String[] a){
  Map<String,Skill> registry=new LinkedHashMap<>();for(String id:List.of("fitness","strength","sprinting","carpentry","metalworking","cooking","farming","first_aid","fishing","axe","aiming","maintenance","lightfooted","tailoring"))registry.put(id,Skill.planned(id,Skill.Category.PASSIVE));
  ActiveSkills.prune(registry);ok(registry.size()==9);ok(new ArrayList<>(registry.keySet()).equals(ActiveSkills.IDS));
  for(int n=0;n<=10;n++){
   ok(Rules13.health(n,n)==2*n);ok(Math.abs(Rules13.healing(1,n)-MedicalRules.amount(1,n))<.0001);ok(Rules13.duration(66,n)==MedicalRules.duration(66,n));
   ok(Math.abs(treatmentTicks(n,66)-Math.ceil(66*MedicalRules.factor(n)))<=1);ok(Math.abs(treatmentTicks(n,80)-Math.ceil(80*MedicalRules.factor(n)))<=1);
   ok(Rules13.fishingLuck(3,n)>=3);ok(Rules13.extraFishChance(n)<=.5);ok(Rules13.nextFraction(0,n)==0||n==10);
  }
  ok(Rules13.health(20,-1)==10);ok(Rules13.duration(100,10)==60);ok(MedicalRules.duration(80,10)==48);ok(MedicalRules.amount(2,10)==3);ok(Rules13.nextFraction(15,0)==.5);ok(Rules13.nextFraction(55,1)==.5);
  System.out.println("PASS: "+checks+" checks for active skills, health, treatment timing/effectiveness and fishing balance");
 }
}
