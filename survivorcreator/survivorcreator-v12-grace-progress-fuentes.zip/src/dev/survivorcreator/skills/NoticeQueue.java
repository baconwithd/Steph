package dev.survivorcreator.skills;
import java.util.ArrayDeque;
public final class NoticeQueue<T>{private final ArrayDeque<T> pending=new ArrayDeque<>();private int ticks;public void add(T value){pending.addLast(value);}public T tick(){if(ticks>0){ticks--;return null;}T value=pending.pollFirst();if(value!=null)ticks=89;return value;}public boolean finished(){return pending.isEmpty()&&ticks==0;}}
