package dev.survivorcreator.skills;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
public final class WorkBenefits {
 public static Component describe(Skill s,int level){
  if(!s.effects().isEmpty()){
   MutableComponent text=Component.empty();for(SkillEffect effect:s.effects()){if(!text.getString().isEmpty())text.append(", ");text.append(effect.describe(level));}return text;
  }
  return switch(s.id()){
   case "carpentry","metalworking"->Component.translatable("skill.survivorcreator.work_speed",Math.max(0,Math.min(10,level))*3);
   case "cooking"->Component.translatable("skill.survivorcreator.meal_bonus",String.format(java.util.Locale.ROOT,"%.1f",level*.1));
   case "farming"->Component.translatable("skill.survivorcreator.harvest_bonus",level*2);
   case "sprinting"->Component.translatable("skill.survivorcreator.carry_bonus",String.format(java.util.Locale.ROOT,"%.1f",level*.5));
   default->Component.translatable("skill.survivorcreator.no_bonus");
  };
 }
}
