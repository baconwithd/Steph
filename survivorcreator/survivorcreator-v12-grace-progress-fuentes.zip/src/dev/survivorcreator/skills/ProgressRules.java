package dev.survivorcreator.skills;
public final class ProgressRules{
 public static double scale(String id,int level,double amount){double rate=switch(id){case "fitness"->.20;case "sprinting","lightfooted","nimble","sneaking"->.25;case "strength","axe","long_blunt","short_blunt","long_blade","short_blade","spear","maintenance","aiming","reloading"->.35;default->.50;};return Double.isFinite(amount)&&amount>0?amount*rate/(1+Math.max(0,Math.min(10,level))*.10):0;}
}
