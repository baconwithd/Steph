package dev.survivorcreator.skills;
import java.util.*;import net.minecraft.server.MinecraftServer;import net.minecraft.server.level.ServerPlayer;import net.minecraft.network.chat.Component;import net.minecraft.ChatFormatting;
import dev.survivorcreator.*;import dev.survivorcreator.effects.Effects;import dev.survivorcreator.net.Net;import net.neoforged.neoforge.network.PacketDistributor;import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.neoforge.event.entity.player.PlayerEvent;import net.neoforged.neoforge.event.server.ServerStoppingEvent;
@EventBusSubscriber(modid="survivorcreator")
public final class LevelUpQueue{
 private record Notice(Skill skill,int level){}private static final Map<UUID,NoticeQueue<Notice>> waiting=new LinkedHashMap<>();
 public static double scale(ServerPlayer p,Skill s,double amount){return GraceProtection.active(p)?0:ProgressRules.scale(s.id(),Skills.level(p,s),amount)/Math.max(1.0,Config.SKILL_XP_MULTIPLIER.get());}
 public static void enqueue(ServerPlayer p,Skill s,int level){Effects.refresh(p);waiting.computeIfAbsent(p.getUUID(),x->new NoticeQueue<>()).add(new Notice(s,level));}
 public static void enqueueRange(ServerPlayer p,Skill s,int level,int previous){Effects.refresh(p);var queue=waiting.computeIfAbsent(p.getUUID(),x->new NoticeQueue<>());for(int n=previous+1;n<=Math.min(level,s.maxLevel());n++)queue.add(new Notice(s,n));}
 public static void tick(MinecraftServer server){for(UUID id:new ArrayList<>(waiting.keySet())){var queue=waiting.get(id);if(queue==null)continue;ServerPlayer p=server.getPlayerList().getPlayer(id);if(p==null||!p.isAlive()){waiting.remove(id);continue;}Notice n=queue.tick();if(n==null){if(queue.finished())waiting.remove(id);continue;}
  var title=Component.translatable("skill.survivorcreator.levelup",n.skill.name(),n.level).withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD);p.sendSystemMessage(title);p.sendSystemMessage(Component.translatable("skill.survivorcreator.improved",Skills.describe(n.skill,n.level)).withStyle(ChatFormatting.GRAY));p.displayClientMessage(title,true);PacketDistributor.sendToPlayer(p,new Net.LevelUp());if(Config.SKILL_POPUP.get())SkillPopups.show(p,n.skill,n.level);
 }}
 @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){waiting.remove(e.getEntity().getUUID());}
 @SubscribeEvent public static void stop(ServerStoppingEvent e){waiting.clear();}
}
