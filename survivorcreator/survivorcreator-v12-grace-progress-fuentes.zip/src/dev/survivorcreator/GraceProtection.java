package dev.survivorcreator;
import net.minecraft.server.level.ServerPlayer;import net.minecraft.nbt.CompoundTag;import net.minecraft.world.entity.player.Player;import net.minecraft.world.effect.*;import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.common.extensions.IEntityExtension;import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.*;import net.neoforged.neoforge.event.entity.player.PlayerEvent;import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;import net.neoforged.neoforge.event.tick.PlayerTickEvent;
@EventBusSubscriber(modid="survivorcreator")
public final class GraceProtection{
 private static CompoundTag tag(Player p){return ((IEntityExtension)(Object)p).getPersistentData();}
 private static boolean completed(ServerPlayer p){return ((net.neoforged.neoforge.attachment.IAttachmentHolder)(Object)p).getData(SurvivorCreator.CHARACTER.get()).completed();}
 public static void give(ServerPlayer p){tag(p).putInt("sc_grace_ticks",200);tag(p).remove("sc_grace_started");}
 public static boolean active(ServerPlayer p){return tag(p).getInt("sc_grace_ticks")>0;}
 @SubscribeEvent public static void respawn(PlayerEvent.PlayerRespawnEvent e){if(e.getEntity() instanceof ServerPlayer p&&!e.isEndConquered())give(p);}
 @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent e){if(e.getEntity() instanceof ServerPlayer p&&!completed(p)&&!active(p))give(p);}
 @SubscribeEvent(priority=EventPriority.HIGHEST) public static void damage(LivingIncomingDamageEvent e){if(e.getEntity() instanceof ServerPlayer p&&active(p))e.setCanceled(true);}
 @SubscribeEvent public static void tick(PlayerTickEvent.Post e){if(!(e.getEntity() instanceof ServerPlayer p)||!active(p)||!p.isAlive()||!completed(p))return;CompoundTag t=tag(p);int remaining=t.getInt("sc_grace_ticks");
  if(!t.getBoolean("sc_grace_started")){t.putBoolean("sc_grace_started",true);p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,remaining,1,false,true,true));p.displayClientMessage(Component.literal("Protección de aparición: 10 segundos — Velocidad II"),true);}
  remaining--;if(remaining<=0){t.remove("sc_grace_ticks");t.remove("sc_grace_started");p.displayClientMessage(Component.literal("Terminó la protección de aparición"),true);}else t.putInt("sc_grace_ticks",remaining);
 }
}
