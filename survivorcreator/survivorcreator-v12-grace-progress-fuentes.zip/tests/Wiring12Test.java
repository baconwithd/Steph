import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Wiring12Test{
 static ClassNode read(ZipFile z,String name)throws Exception{ClassNode n=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class")).readAllBytes()).accept(n,0);return n;}
 public static void main(String[] a)throws Exception{try(ZipFile z=new ZipFile(a[0])){
  var c=read(z,"dev/survivorcreator/skills/Skills");boolean scale=false,queue=false;for(var m:c.methods)for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call){if(m.name.equals("addXp")&&call.name.equals("scale"))scale=true;if(m.name.equals("grant")&&call.name.equals("enqueueRange"))queue=true;}if(!scale||!queue)throw new AssertionError("Missing skill hooks");
  c=read(z,"dev/survivorcreator/effects/Effects");boolean give=false;for(var m:c.methods)if(m.name.equals("firstGrant"))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.owner.endsWith("GraceProtection")&&call.name.equals("give"))give=true;if(!give)throw new AssertionError("Creation grace missing");
  c=read(z,"dev/survivorcreator/GraceProtection");boolean ticks=false,speed=false,damage=false;for(var m:c.methods)for(var i:m.instructions.toArray()){if(m.name.equals("give")&&i instanceof IntInsnNode v&&v.operand==200)ticks=true;if(i instanceof FieldInsnNode f&&f.name.equals("MOVEMENT_SPEED"))speed=true;if(m.name.equals("damage")&&i instanceof MethodInsnNode call&&call.name.equals("setCanceled"))damage=true;}if(!ticks||!speed||!damage)throw new AssertionError("Grace duration/speed/protection");
  c=read(z,"dev/survivorcreator/skills/SkillPopups");long hooked=c.methods.stream().filter(m->m.name.equals("tick")).flatMap(m->java.util.Arrays.stream(m.instructions.toArray())).filter(i->i instanceof MethodInsnNode call&&call.owner.endsWith("LevelUpQueue")).count();if(hooked!=2)throw new AssertionError("Queue not ticked when popups are empty");
  System.out.println("PASS: skill scaling, ordered multi-level queue, grace after creation, 200 ticks, speed and damage cancellation wiring");
 }}
}
