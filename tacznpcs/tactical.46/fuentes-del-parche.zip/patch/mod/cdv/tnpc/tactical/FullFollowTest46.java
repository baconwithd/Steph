package mod.cdv.tnpc.tactical;
import java.util.*;import java.lang.ref.WeakReference;
public class FullFollowTest46 {
 public static class Tag{
  Map<String,Object> data=new HashMap<>();public String getString(String k){return (String)data.getOrDefault(k,"");}public void putString(String k,String v){data.put(k,v);}public boolean getBoolean(String k){return (boolean)data.getOrDefault(k,false);}public void putBoolean(String k,boolean v){data.put(k,v);}public long getLong(String k){return (long)data.getOrDefault(k,0L);}public void putLong(String k,long v){data.put(k,v);}
 }
 public static class World{long time=1000;Actor player;public boolean isClientSide(){return false;}public long getGameTime(){return time;}public Object getPlayerByUUID(UUID id){return player.id.equals(id)?player:null;}}
 public static class Path{public boolean canReach(){return true;}}
 public static class Nav{int moves,stops;public Object createPath(net.minecraft.core.BlockPos pos,int radius){return new Path();}public boolean moveTo(Object path,double speed){moves++;return true;}public void stop(){stops++;}}
 public static class Look{public void setLookAt(Object p,float yaw,float pitch){}}
 public static class Actor{
  UUID id=UUID.randomUUID();Tag tag=new Tag();World world;Nav nav=new Nav();double x;boolean alive=true;
  public Tag getPersistentData(){return tag;}public World level(){return world;}public UUID getUUID(){return id;}public boolean isAlive(){return alive;}public boolean isSprinting(){return true;}public double getX(){return x;}public double getY(){return 64;}public double getZ(){return 0;}public double distanceToSqr(Actor other){return (x-other.x)*(x-other.x);}public Nav getNavigation(){return nav;}public void setTarget(Object t){}public void aim(boolean b){}public void setAggressive(boolean b){}public Look getLookControl(){return new Look();}
 }
 static void check(boolean b,String msg){if(!b)throw new AssertionError(msg);}
 public static void main(String[] args)throws Exception{
  World w=new World();Actor n=new Actor(),p=new Actor();n.world=p.world=w;w.player=p;p.x=12;
  n.tag.putString("npc78_owner",p.id.toString());n.tag.putString("soc_owner",p.id.toString());n.tag.putString("soc_order","follow");
  Authority70.state(n).player=new WeakReference<>(p);Conversation.SESSIONS.put(p,new Conversation.Session(n,2000));Navigation78.INIT.add(n);Authority70.state(n).until=2000;
  check(!Immersion82.weaponBreak(p),"owner's weapon interrupts dialogue");check(Boolean.FALSE.equals(Immersion82.call(p,"isSprinting",new Object[0])),"sprinting owner closes dialogue");
  check(Authority70.busy(n),"busy flag lost");check(n.nav.moves==1,"conversation did not start following route");
  int stops=n.nav.stops;
  for(int tick=1;tick<80;tick++){w.time++;check(Authority70.busy(n),"conversation closed during owner sprint");}
  check(n.nav.stops==stops,"conversation repeatedly stopped navigation while owner was distant");
  check(n.nav.moves>1,"follow route failed to update while talking");
  p.x=1;w.time+=40;Authority70.busy(n);check(n.nav.stops>stops,"follow did not stop near owner");
  n.alive=false;Expression20.react(n,p,"harm");SpeechSounds20.play(n,"hostile");check(Immersion82.silent(n),"dead NPC still speaks");
  System.out.println("PASS: owner weapon/sprint exemption, following during dialogue, route update, stopping nearby, silent dead NPC");
 }
}
