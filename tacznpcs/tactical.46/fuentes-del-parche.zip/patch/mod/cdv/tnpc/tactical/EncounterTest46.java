package mod.cdv.tnpc.tactical;
import java.util.*;import com.google.gson.*;
public class EncounterTest46 {
 public static class Tag extends FullFollowTest46.Tag{
  public boolean contains(String k){return data.containsKey(k);}public int getInt(String k){return (int)data.getOrDefault(k,0);}public void putInt(String k,int v){data.put(k,v);}public Object getList(String k,int type){return new EmptyList();}public double getDouble(String k){return ((Number)data.getOrDefault(k,0d)).doubleValue();}public void putDouble(String k,double v){data.put(k,v);}
 }
 public static class EmptyList{public int size(){return 0;}}
 public static class Vec{public double x,y,z;Vec(double x,double y,double z){this.x=x;this.y=y;this.z=z;}}
 public static class Box{public Object inflate(double d){return this;}}
 public static class Gun implements com.tacz.guns.api.item.IGun{}
 public static class Stack{boolean gun;public boolean isEmpty(){return !gun;}public Object getItem(){return new Gun();}}
 public static class World extends FullFollowTest46.World{
  Actor player46,npc46;public List<?> getEntitiesOfClass(Class<?> type,Object box){return type.getName().endsWith("player.Player")?List.of(player46):type==Actor.class?List.of(npc46):List.of();}
 }
 public static class Actor extends FullFollowTest46.Actor{
  Tag tag46=new Tag();Stack hand=new Stack();Vec look=new Vec(-1,0,0);
  public Tag getPersistentData(){return tag46;}public Stack getMainHandItem(){return hand;}public boolean isCreative(){return false;}public boolean isSpectator(){return false;}public boolean hasLineOfSight(Object p){return true;}public double getEyeY(){return 65.0175;}public double getBbHeight(){return 1.85;}public Vec getLookAngle(){return look;}public Object getBoundingBox(){return new Box();}public float getHealth(){return 20;}public float getMaxHealth(){return 20;}
 }
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception{
  World w=new World();Actor n=new Actor();Actor p=new net.minecraft.world.entity.player.Player();n.world=p.world=w;w.player46=p;p.x=5;n.tag46.putInt("npc22_role",2);
  check(!Threat27.allowed(n,p),"unarmed player attacked before extortion window");check(TalkNetwork.packets.stream().anyMatch(s->s.contains("comida")||s.contains("provisiones")),"extortion was not delivered");
  p.hand.gun=true;check(Threat27.allowed(n,p),"crosshair threat did not acquire target");check(Social.enemy(n,p),"panic failed to mark enemy");
  p.look=new Vec(1,0,0);check(!Immersion82.aimed(p,n),"looking away counted as aiming");
  n.tag46.putBoolean("soc_down20",true);int before=TalkNetwork.packets.size();Expression20.react(n,p,"harm");check(TalkNetwork.packets.size()==before+1,"downed NPC did not emit groan");check(TalkNetwork.packets.get(before).contains("…"),"missing groan text");check(Immersion82.silent(n),"downed hostile still speaks aggressively");
  n.tag46.putBoolean("soc_down20",false);Social74.CACHE.put(n,new Social74.Cache(Social74.create(n)));
  for(int trust:new int[]{0,40,80}){
   n.tag46.putInt("soc_trust_"+p.id,trust);
   for(String voice:DialogueData71.VOICES){Chat71.State state=new Chat71.State("test",voice,"inicio");state.encounter=JsonParser.parseString("{\"modo_libre\":true}").getAsJsonObject();
    String previous="";for(int i=0;i<10;i++){String actual=Immersion82.opening(n,p,state,new JsonArray(),null).toString();check(!actual.equals("[]"),"opening not selected");check(!actual.equals(previous),"opening repeated consecutively");previous=actual;}
   }
  }
  SocialR.types.put("mod.cdv.tnpc.entity.AutoGunOperator",Actor.class);w.npc46=n;Navigation78.INIT.add(n);CalmBrain.state(n).corpse=new Object();Social.mem(n).occupied=true;
  Sense28.emit(w,15,64,0,3,p);check(CalmBrain.state(n).corpse==null,"looter ignored the shot");check(Social.l(Social.tag(n),"npc82_investigate")>w.time,"looter did not decide to investigate");
  check(Life79.work(n),"investigation not claimed by life scheduler");check(n.nav.moves>0,"curious looter did not route to the shot");
  System.out.println("PASS: real Threat27.allowed chain (extortion and crosshair panic), downed hostile groans, contextual openings across 8 voices and 3 trust levels");
 }
}
