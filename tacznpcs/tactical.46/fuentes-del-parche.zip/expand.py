import json,copy
x=json.load(open('work/jar/data/tacznpcs/dialogue/dialogue-phase2.json'))
packs={
'seco':[['Ya nos conocemos. Habla.','No hace falta que des tantas vueltas.'],['Me cuesta soltar el pasado.','Contigo puedo intentarlo.'],['Te cubro. Tú haz lo mismo.','Así llegamos más lejos.']],
'cansado':[['Hoy pesa todo un poco más.','Al menos no voy solo.'],['Antes evitaba recordar.','Ahora prefiero contártelo a guardármelo todo.'],['Si me quedo atrás, avísame.','Todavía quiero salir de esta contigo.']],
'sarcastico':[['Mira quién sigue aguantando mi compañía.','Debes de tener paciencia de sobra.'],['Iba a hacer un chiste.','Pero esto sí me importa. Gracias por escuchar.'],['Tú y yo contra otro día horrible.','Casi parece un plan.']],
'religioso':[['Me alegra volver a escucharte.','Compartir el camino hace más llevadero el miedo.'],['Hay recuerdos que aún duelen.','Gracias por darme un lugar para hablar de ellos.'],['Esta noche pediré por los dos.','Mañana volveré a cuidar tu espalda.']],
'educado':[['Me tranquiliza tenerle cerca.','¿Cómo se encuentra usted hoy?'],['No suelo hablar de esto.','Con usted siento que puedo hacerlo.'],['Puede contar conmigo.','Me gustaría que ambos saliéramos de aquí.']],
'aterrado':[['Aún me asusto con cualquier ruido.','Pero contigo logro respirar un poco mejor.'],['¿P-puedo contarte algo?','No necesito que lo arregles. Solo que escuches.'],['Si me entra el pánico, háblame.','Tu voz me ayuda a volver.']],
'veterano':[['Seguimos enteros. Eso cuenta.','¿Cómo llevas tú la marcha?'],['La experiencia no borra lo que uno recuerda.','Solo enseña a seguir andando con ello.'],['Confío en tu criterio.','Si ves algo que no veo, dímelo.']],
'joven':[['Oye, me alegra que sigas aquí.','Me hago el duro, pero ir solo era otra cosa.'],['A veces hablo demasiado para no pensar.','Contigo no tengo que fingir tanto.'],['La próxima vez te cubro yo.','En serio. Ya puedes contar conmigo.']]}
def response(lines,target,req=None):
 r={'lineas_npc':lines,'efectos':{},'siguiente':target}
 if req:r['condicion']={'medidores':{'confianza':req}}
 return r
def option(id,text,lines,trust):
 return {'id':id,'texto':text,'tono':1,'utilidad':'normal','requiere':{'medidores':{'confianza':{'min':trust}}},'respuestas':[response(lines,'vinculo82')]}
for e in x['encuentros']:
 if not e.get('modo_libre'):continue
 voice=e['voz'];p=packs[voice]
 for n in e['nodos']:
  for o in n['opciones']:
   if o['id']=='pasado':
    for r in o['respuestas']:r['siguiente']='vinculo82'
   if o['id'] in ('animo','escuchar'):
    for r in o['respuestas']:
     r.setdefault('variantes',[]).extend([{'condicion':{'medidores':{'confianza':{'min':30}}},'lineas_npc':p[0]},{'condicion':{'medidores':{'confianza':{'min':60}}},'lineas_npc':p[1]}])
 back={'id':'volver82','texto':'Hablemos de otra cosa.','tono':2,'utilidad':'normal','respuestas':[response(['De acuerdo. Te escucho.','¿Qué tienes en mente?'],'inicio')]}
 threat={'id':'amenaza82','texto':'Te estoy amenazando. Dame lo que llevas.','tono':4,'utilidad':'amenaza','respuestas':[{'lineas_npc':['¿Lo dices en serio?','Baja el arma. Necesito distancia.'],'efectos':{'confianza':-25,'miedo':30,'hostilidad':15,'evento_memoria':{'tipo':'amenazo','texto':'lo amenazó explícitamente'},'resultado':'huida'},'siguiente':None}]}
 e['nodos'].append({'id':'vinculo82','lineas_npc':['Podemos hablar de algo más personal.','Dime.'],'opciones':[option('charla82','¿Cómo llevas viajar conmigo?',p[0],30),option('recuerdo82','Puedes confiar en mí. Te escucho.',p[1],60),option('apoyo82','¿Podemos contar el uno con el otro?',p[2],85),threat,back],'reaccion_silencio':{'lineas':['Podemos retomarlo después.','Sigamos atentos al camino.'],'efectos':{'resultado':'separacion_pacifica'}}})
json.dump(x,open('work/expanded.json','w'),ensure_ascii=False,indent=2)
# Resource with only changed encounters, merged into existing configuration at load.
json.dump({'encuentros':[e for e in x['encuentros'] if e.get('modo_libre')]},open('work/jar/data/tacznpcs/dialogue/immersion82.json','w'),ensure_ascii=False)
