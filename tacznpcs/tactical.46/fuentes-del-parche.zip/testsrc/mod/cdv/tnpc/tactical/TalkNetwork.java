package mod.cdv.tnpc.tactical; public class TalkNetwork{static final java.util.List<String> packets=new java.util.ArrayList<>();public static void send(Object player,String text){packets.add(text);}}
