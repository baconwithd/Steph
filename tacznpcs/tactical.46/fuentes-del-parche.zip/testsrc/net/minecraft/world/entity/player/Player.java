package net.minecraft.world.entity.player; public class Player extends mod.cdv.tnpc.tactical.EncounterTest46.Actor{}
