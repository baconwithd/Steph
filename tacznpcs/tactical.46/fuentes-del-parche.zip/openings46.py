import json
pools={
'seco':{
'stranger':[['Alto. Desde ahí te escucho.','Dime qué necesitas.'],['No te conozco. Mantén distancia.','Podemos hablar si vas de frente.'],['Te vi venir. Sin movimientos raros.','Habla.']],
'familiar':[['Tú otra vez. Bien.','¿Cómo te fue desde la última vez?'],['Ya sé quién eres. Acércate un poco.','¿Qué te trae por aquí?'],['Me acuerdo de ti.','Dime cómo van las cosas.']],
'close':[['Llegas en buen momento.','Me vendría bien hablar contigo.'],['Contigo puedo bajar la guardia un momento.','¿Cómo estás tú?'],['Me alegra verte entero.','Cuéntame qué ha pasado.']],
'companion':[['Te sigo. Puedes hablar.','No hace falta parar por mí.'],['Voy a tu lado. Te escucho.','¿Qué tienes en mente?'],['Sigamos andando.','Cuéntame, estoy atento.']]},
'cansado':{
'stranger':[['Dame un segundo para respirar.','Si quieres algo, podemos hablar desde ahí.'],['Otro rostro que no conozco…','Espero que esta vez podamos entendernos.'],['No me quedan fuerzas para una pelea.','Dime qué buscas.']],
'familiar':[['Vaya, sigues por aquí.','¿Has conseguido descansar algo?'],['Reconozco esa cara.','Espero que te haya ido mejor que a mí.'],['Me alegra no tener que empezar de cero.','¿Qué tal llevas el día?']],
'close':[['Hoy me pesa todo un poco.','Quédate conmigo un rato, si puedes.'],['Contigo no necesito fingir que estoy bien.','¿Cómo te encuentras tú?'],['Pensaba en nuestra última charla.','Me hizo bien escucharte.']],
'companion':[['Sigo detrás de ti.','Si voy callado es por cansancio. Te escucho.'],['Podemos hablar andando.','Me ayuda a no pensar en los pies.'],['No te pares por mí todavía.','Cuéntame algo mientras avanzamos.']]},
'sarcastico':{
'stranger':[['Una visita. Justo lo que le faltaba al día.','¿Vienes a hablar o a complicarlo?'],['Bueno, tú respiras y yo también.','Ya tenemos algo en común. ¿Qué buscas?'],['No suelo dar la bienvenida con abrazos.','Pero podemos empezar hablando.']],
'familiar':[['Mira quién sobrevivió a otra excursión.','¿Alguna novedad que no sea terrible?'],['Otra vez tú. Empiezo a reconocer los pasos.','¿Cómo va esa gran vida de superviviente?'],['Al menos no tengo que preguntarte quién eres.','¿Qué desastre nos toca comentar hoy?']],
'close':[['Iba a soltarte un chiste, pero me alegra verte.','No te acostumbres a que lo admita.'],['Qué bien. Alguien con quien puedo hablar de verdad.','¿Cómo estás llevando todo esto?'],['Contigo hasta el silencio resulta llevadero.','Pero cuéntame, ¿qué te pasa por la cabeza?']],
'companion':[['Habla, que caminar en silencio me deja pensar.','Y eso últimamente sale caro.'],['Te sigo. Puedo conversar y esquivar escombros.','Casi siempre. Tú dirás.'],['Otra caminata de lujo.','Al menos llevo buena compañía. ¿Qué pasa?']]},
'religioso':{
'stranger':[['Que podamos encontrarnos sin hacernos daño.','¿Qué necesitas, caminante?'],['Todavía quedan personas con quienes hablar.','Eso ya da un poco de esperanza.'],['Acércate con calma.','Prefiero escuchar antes que juzgar.']],
'familiar':[['Es bueno volver a encontrarte.','¿Has tenido un camino tranquilo?'],['Te recuerdo. Espero que hayas estado a salvo.','¿Cómo se encuentra tu ánimo?'],['Hoy nuestros caminos se cruzan de nuevo.','Cuéntame cómo te ha ido.']],
'close':[['He pedido que pudiéramos volver a vernos.','Me alegra tenerte aquí.'],['Conoces mis dudas y aun así vuelves a escucharme.','Gracias. ¿Cómo estás tú?'],['La esperanza también llega con rostros conocidos.','Hoy el tuyo me trae calma.']],
'companion':[['Voy contigo. No hace falta detenerse.','Podemos compartir unas palabras en el camino.'],['Te escucho mientras avanzamos.','Caminar acompañado alivia el miedo.'],['Sigamos. Yo vigilaré este lado.','Dime qué llevas en el corazón.']]},
'educado':{
'stranger':[['Buenas. Le agradecería que se acercara despacio.','¿En qué puedo ayudarle?'],['Disculpe mi cautela. No nos conocemos.','Podemos hablar desde aquí.'],['Me gustaría evitar un malentendido.','Dígame qué está buscando.']],
'familiar':[['Es un placer volver a verle.','¿Ha tenido alguna dificultad en el camino?'],['Le recuerdo. Me alegra encontrarle bien.','¿Cómo le ha ido desde la última vez?'],['Con usted ya puedo ahorrarme las presentaciones.','¿Qué tal se encuentra hoy?']],
'close':[['Su compañía me tranquiliza.','Si necesita hablar, dispone de mi tiempo.'],['Me alegra mucho verle.','Esta vez me gustaría saber cómo se siente usted.'],['No suelo confiar con facilidad. Usted lo sabe.','Con usted puedo hablar sin medir cada palabra.']],
'companion':[['Le sigo. Podemos conversar mientras caminamos.','¿Qué quería contarme?'],['Estoy a su lado. Le escucho.','No es necesario detener la marcha.'],['Continúe, por favor. Puedo seguir el ritmo.','Hablemos mientras avanzamos.']]},
'aterrado':{
'stranger':[['E-espera. No te acerques tan rápido.','Podemos hablar desde ahí, ¿sí?'],['No quiero problemas.','Dime qué buscas y lo hablamos.'],['Me has asustado…','Dame un momento. Ya te escucho.']],
'familiar':[['Ah… eres tú.','Tardé un segundo en reconocerte. ¿Estás bien?'],['Tu cara me suena. Eso ayuda.','¿Qué ha pasado desde la otra vez?'],['Me alegra encontrar a alguien conocido.','Hoy cualquier ruido me pone nervioso.']],
'close':[['Contigo puedo respirar un poco mejor.','¿Te quedas hablando conmigo un momento?'],['Sabía que podía contarte esto a ti.','No hace falta que tengas una respuesta.'],['Me alegra tanto verte…','No quería pasar otro día sin alguien de confianza.']],
'companion':[['S-sigo contigo. No me he quedado atrás.','Puedes hablar; reconozco tu voz.'],['Caminar contigo me ayuda.','Cuéntame algo mientras seguimos.'],['Estoy aquí, a tu lado.','Si escucho algo te aviso. Tú sigue hablando.']]},
'veterano':{
'stranger':[['Te he visto antes de que llegaras.','Mantengamos las cosas claras. ¿Qué necesitas?'],['Tienes espacio para hablar.','No hagamos movimientos que ninguno entienda.'],['Primero nos escuchamos.','Luego decidimos cómo seguir.']],
'familiar':[['Otra vez por aquí. Bien.','¿Aprendiste algo útil en el camino?'],['Me acuerdo de ti.','Dime cómo te ha tratado esta zona.'],['Seguimos vivos. No es poca cosa.','¿Cómo llevas el día?']],
'close':[['Contigo puedo hablar sin rodeos.','Hoy me preocupa más tu estado que el equipo.'],['Me alegra tenerte cerca.','La experiencia sirve menos cuando no hay con quién compartirla.'],['Confío en lo que me digas.','¿Hay algo que te esté pesando?']],
'companion':[['Te sigo. Mantén el paso.','Podemos conversar y seguir atentos.'],['Voy cubriendo este lado.','Te escucho; no hace falta detenernos.'],['Sigamos hablando durante la marcha.','Si veo peligro, te aviso.']]},
'joven':{
'stranger':[['Oye, espera. ¿Quién va?','Vale… podemos hablar desde ahí.'],['No esperaba encontrar a nadie aquí.','¿Estás buscando algo?'],['Tranquilo. Yo también estoy tratando de salir adelante.','Dime qué necesitas.']],
'familiar':[['¡Oye, te conozco!','¿Cómo te fue desde la última vez?'],['Pensaba que habías tomado otro camino.','Me alegra verte de nuevo.'],['Mira, otra cara conocida.','¿Tienes algo bueno que contar?']],
'close':[['Me alegra que hayas venido. En serio.','Contigo no necesito hacerme el fuerte.'],['Tenía ganas de hablar contigo.','Hoy me ha costado mantener la cabeza en su sitio.'],['Te confiaría la espalda sin pensarlo.','Pero también quiero saber cómo estás.']],
'companion':[['Te sigo. Puedo hablar mientras camino.','¿Qué pasa?'],['Estoy aquí, no me he quedado atrás.','Cuéntame algo mientras avanzamos.'],['Oye, caminar contigo se hace más corto.','¿De qué querías hablar?']]}}
json.dump(pools,open('work/jar/data/tacznpcs/dialogue/openings46.json','w'),ensure_ascii=False)
