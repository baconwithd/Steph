#!/usr/bin/env bash
set -euo pipefail
base_jar=${1:?Usage: bash build47.sh /path/to/tactical.44-context-null-guard.jar}
mkdir -p work/jar work/classes output
python3 - "$base_jar" <<'PY'
import zipfile,sys
zipfile.ZipFile(sys.argv[1]).extractall('work/jar')
PY
for spec in 'org/eclipse/jdt/ecj/3.38.0/ecj-3.38.0.jar ecj' 'com/google/code/gson/gson/2.10.1/gson-2.10.1.jar gson' 'org/ow2/asm/asm/9.7/asm-9.7.jar asm' 'org/ow2/asm/asm-tree/9.7/asm-tree-9.7.jar asm-tree'; do
 read -r maven_path artifact_name <<< "$spec"
 curl -fsSL "https://repo.maven.apache.org/maven2/$maven_path" -o "work/$artifact_name.jar"
done
python3 expand.py
python3 openings46.py
java -jar work/ecj.jar -21 -proc:none -cp work/jar:work/gson.jar:work/asm.jar:work/asm-tree.jar -d work/classes Patch.java patch/mod/cdv/tnpc/tactical/{Immersion82,Encounters47,Shelter47,Routes47}.java
java -cp work/classes:work/asm.jar:work/asm-tree.jar Patch work/jar
cp work/classes/mod/cdv/tnpc/tactical/{Immersion82,Encounters47,Shelter47,Routes47,Routes47\$Route}.class work/jar/mod/cdv/tnpc/tactical/
python3 - <<'PY'
from pathlib import Path
import zipfile,re
p=Path('work/jar/META-INF/neoforge.mods.toml')
p.write_text(re.sub(r'version="2\.1\.0-tactical\.[^"]+"','version="2.1.0-tactical.47-encounters-paths-shelters"',p.read_text()))
with zipfile.ZipFile('output/tacznpcs-2.1.0-1.21.1-tactical.47-encounters-paths-shelters.jar','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(Path('work/jar').rglob('*')):
  if p.is_file():z.write(p,p.relative_to('work/jar'))
PY
