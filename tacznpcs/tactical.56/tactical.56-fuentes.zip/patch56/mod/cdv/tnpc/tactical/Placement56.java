package mod.cdv.tnpc.tactical;
import java.util.*;
/** Native furniture callbacks and events are part of the same placement transaction. */
public final class Placement56 {
 static Object c(Object o,String m,Object...a){return Social.c(o,m,a);}
 public static boolean place(Object n,Object p,String item){if(!item.startsWith("doomsday_decoration:"))return Social.yes(c(Base48.class,"placeNative55",n,p,item));
  Object world=Social.world(n);if(Social.client(n)||!Shelter77.grief(n)||p==null||!Shelter77.loaded(world,p)||!Decor82.space(n,p,item))return false;Object state=c(Shelter77.registry("BLOCK",item),"defaultBlockState");if(!Shelter77.id(state).equals(item)||!Social.yes(c(state,"canSurvive",world,p)))return false;
  List<Object> oldBag=DialogueRules72.copies(DialogueRules72.bag(n)),bag=DialogueRules72.copies(oldBag);if(!Base48.take(bag,item,1))return false;
  List<Object> positions=new ArrayList<>(List.of(p));Set<String> seen=new HashSet<>(Set.of(Base48.key(p)));Class<?> footprint=Social.t("dev.zomboid.decor.Footprint");for(Object cell:(Iterable<?>)c(footprint,"cells",state,world,p)){Object at=c(footprint,"pos",p,cell);if(seen.add(Base48.key(at)))positions.add(at);if(positions.size()>64)return false;}
  List<Object> states=new ArrayList<>(),snapshots=new ArrayList<>();for(Object at:positions){if(!Shelter77.loaded(world,at)||!Shelter77.permitted(n,at)||!Shelter77.air(world,at)||Shelter77.occupied(world,at)||c(world,"getBlockEntity",at)!=null)return false;states.add(Shelter77.state(world,at));snapshots.add(c(Social.t("net.neoforged.neoforge.common.util.BlockSnapshot"),"create",c(world,"dimension"),world,at));}
  boolean committed=false;try{if(!Social.yes(c(world,"setBlock",p,state,2)))return false;c(c(state,"getBlock"),"setPlacedBy",world,p,state,n,Shelter77.item(item,1));
   Object up=SocialR.get(Social.t("net.minecraft.core.Direction"),"UP");for(Object snapshot:snapshots)if(Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"),"onBlockPlace",n,snapshot,up)))return false;
   c(CalmLoot.class,"saveBag",n,bag);committed=true;
  }finally{if(!committed){RuntimeException failure=null;for(int i=0;i<positions.size();i++)try{c(world,"setBlock",positions.get(i),states.get(i),3);}catch(RuntimeException error){if(failure==null)failure=error;else failure.addSuppressed(error);}try{c(CalmLoot.class,"saveBag",n,oldBag);}catch(RuntimeException error){if(failure==null)failure=error;else failure.addSuppressed(error);}if(failure!=null)throw failure;}}
  Object be=c(world,"getBlockEntity",p);if(be!=null){c(c(be,"getPersistentData"),"putString","npc48_dueno",Social.uuid(n).toString());c(be,"setChanged");}for(Object at:positions)c(world,"blockUpdated",at,c(Shelter77.state(world,at),"getBlock"));Shelter77.swing(n);return true;
 }
}
