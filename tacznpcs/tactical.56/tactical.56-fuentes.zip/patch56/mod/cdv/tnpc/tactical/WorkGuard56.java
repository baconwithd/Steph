package mod.cdv.tnpc.tactical;

import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

/** A profession must release control when a claimed trip never makes progress. */
public final class WorkGuard56 {
 static final Map<Object,Map<String,Watch>> WATCHES=new WeakHashMap<>();
 static final class Watch {
  boolean initialized;
  long since,last,retry;
  double x,y,z;
  String signature="";
 }
 static Object c(Object o,String method,Object... args){return Social.c(o,method,args);}
 static String signature(Object n,JsonObject group,String task){
  StringBuilder s=new StringBuilder().append(Base48.num(n,"ultimo_progreso")).append('|');
  String[] keys=task.startsWith("fort")?new String[]{"fase","cursor_muro","reparacion"}:
    task.equals("mine")?new String[]{"mina_paso","mina_bloqueada_hasta"}:new String[]{"parcela_x","parcela_y","parcela_z"};
  for(String key:keys)s.append(key).append('=').append(group.get(key)).append(';');
  if(task.startsWith("farm"))s.append("scan=").append(Farm87.SCAN.get(n)).append(';');
  if(task.equals("mine")){Object job=Industry87.JOBS.get(n);if(job!=null)s.append("job=").append(SocialR.get(job,"progress")).append(';');}
  for(Object stack:DialogueRules72.bag(n))s.append(DialogueRules72.itemId(stack)).append(':').append(DialogueRules72.size(stack)).append(':').append(c(stack,"getDamageValue")).append(';');
  return s.toString();
 }
 static boolean run(Object n,JsonObject group,String task,Class<?> owner,String method){
  if(group==null||Social.client(n))return false;
  long now=Social.time(n);
  Watch watch=WATCHES.computeIfAbsent(n,k->new HashMap<>()).computeIfAbsent(task,k->new Watch());
  if(now<watch.last){watch.initialized=false;watch.retry=0;}
  watch.last=now;
  if(now<watch.retry)return false;
  boolean result=Social.yes(c(owner,method+"Native55",n,group));
  if(!result){watch.initialized=false;return false;}
  double x=Social.num(c(n,"getX")),y=Social.num(c(n,"getY")),z=Social.num(c(n,"getZ"));
  String signature=signature(n,group,task);
  if(!watch.initialized||Math.pow(x-watch.x,2)+Math.pow(y-watch.y,2)+Math.pow(z-watch.z,2)>.0625||!signature.equals(watch.signature)){
   watch.initialized=true;watch.since=now;watch.x=x;watch.y=y;watch.z=z;watch.signature=signature;
  }
  if(now-watch.since<400)return true;
  watch.initialized=false;watch.retry=now+200;
  Settlement87.status(n,"tarea_sin_progreso_cambiar_objetivo");
  Social.mem(n).occupied=false;
  c(c(n,"getNavigation"),"stop");
  return false;
 }
 public static boolean fortWork(Object n,JsonObject group){return run(n,group,"fortWork",Fort87.class,"work");}
 public static boolean fortRepair(Object n,JsonObject group){return run(n,group,"fortRepair",Fort87.class,"repair");}
 public static boolean fortGates(Object n,JsonObject group){return run(n,group,"fortGates",Fort87.class,"gates");}
 public static boolean farmWork(Object n,JsonObject group){return run(n,group,"farmWork",Farm87.class,"work");}
 public static boolean farmTree(Object n,JsonObject group){return run(n,group,"farmTree",Farm87.class,"tree");}
 public static boolean mine(Object n,JsonObject group){return run(n,group,"mine",Industry87.class,"mine");}
}
