package mod.cdv.tnpc.tactical;
import java.util.*;
/** Transactions use exact ItemStack snapshots, and slot admission is checked per destination. */
public final class Inventory56 {
 static Object c(Object o,String m,Object...a){return Social.c(o,m,a);}
 static Object container(Object n,Object p){if(p==null||!Shelter77.loaded(Social.world(n),p)||!Shelter77.permitted(n,p))return null;Object be=c(Social.world(n),"getBlockEntity",p);if(be==null||!Social.t("net.minecraft.world.Container").isInstance(be))return null;int size=((Number)c(be,"getContainerSize")).intValue();return size>0&&size<=256?be:null;}
 static List<Object> snapshot(Object be){List<Object> result=new ArrayList<>();int size=((Number)c(be,"getContainerSize")).intValue();for(int i=0;i<size;i++)result.add(DialogueRules72.copy(c(be,"getItem",i)));return result;}
 static void restore(Object be,List<Object> items){for(int i=0;i<items.size();i++)c(be,"setItem",i,DialogueRules72.copy(items.get(i)));c(be,"setChanged");}
 static List<Object> stores(Object n){List<Object> stores=new ArrayList<>();Set<String> keys=new HashSet<>();for(Object p:new Object[]{Base48.point(n,"chest"),Hunt78.point(n,"npc49_drawer")})if(p!=null&&Shelter77.loaded(Social.world(n),p)&&Shelter77.permitted(n,p)&&Hunt78.container(Social.world(n),p)&&keys.add(Base48.key(p)))stores.add(p);return stores;}
 public static int stored(Object n,String suffix){int count=0;for(Object s:DialogueRules72.bag(n))if(DialogueRules72.itemId(s).endsWith(suffix))count+=DialogueRules72.size(s);for(Object p:stores(n)){Object be=container(n,p);if(be!=null)for(Object s:snapshot(be))if(DialogueRules72.itemId(s).endsWith(suffix))count+=DialogueRules72.size(s);}return count;}
 public static boolean retrieve(Object n,String item,int amount){if(amount<=0||Social.client(n))return false;
  for(Object p:stores(n)){if(Base48.dist(n,p)>9)continue;Object be=container(n,p);if(be==null)continue;List<Object> old=snapshot(be),next=DialogueRules72.copies(old),oldBag=DialogueRules72.copies(DialogueRules72.bag(n)),bag=DialogueRules72.copies(oldBag);int taken=0;
   for(int i=0;i<next.size()&&taken<amount;i++){Object s=next.get(i);if(DialogueRules72.empty(s)||!DialogueRules72.itemId(s).equals(item))continue;int take=Math.min(amount-taken,DialogueRules72.size(s));List<Object> candidate=DialogueRules72.copies(bag);if(!DialogueRules72.insert(candidate,new ArrayList<>(List.of(c(s,"copyWithCount",take))),false))continue;bag=candidate;c(s,"shrink",take);taken+=take;}
   if(taken==0)continue;
   try{for(int i=0;i<next.size();i++)c(be,"setItem",i,next.get(i));c(CalmLoot.class,"saveBag",n,bag);c(be,"setChanged");}
   catch(RuntimeException error){try{restore(be,old);}catch(RuntimeException rollback){error.addSuppressed(rollback);}try{c(CalmLoot.class,"saveBag",n,oldBag);}catch(RuntimeException rollback){error.addSuppressed(rollback);}throw error;}return true;
  }return false;
 }
 static int insert(Object be,List<Object> slots,Object source,int wanted){int moved=0;for(int pass=0;pass<2&&moved<wanted;pass++)for(int i=0;i<slots.size()&&moved<wanted;i++){
  Object dst=slots.get(i);boolean empty=DialogueRules72.empty(dst);if((pass==0&&empty)||(pass==1&&!empty))continue;
  if(!empty&&!Social.yes(c(Social.t("net.minecraft.world.item.ItemStack"),"isSameItemSameComponents",dst,source)))continue;
  Object one=c(source,"copyWithCount",1);if(!Social.yes(c(be,"canPlaceItem",i,one)))continue;
  int stackMax=((Number)c(source,"getMaxStackSize")).intValue();int containerMax=((Number)c(be,"getMaxStackSize")).intValue();int capacity=Math.min(stackMax,containerMax)-(empty?0:DialogueRules72.size(dst));int count=Math.min(wanted-moved,Math.max(0,capacity));if(count==0)continue;
  if(empty)slots.set(i,c(source,"copyWithCount",count));else c(dst,"grow",count);moved+=count;
 }return moved;}
 public static boolean transfer(Object n,Object p,boolean fuel){if(Social.client(n)||p==null||!Shelter77.loaded(Social.world(n),p)||Base48.dist(n,p)>9)return false;Object be=container(n,p);if(be==null)return false;
  List<Object> old=snapshot(be),next=DialogueRules72.copies(old),oldBag=DialogueRules72.copies(DialogueRules72.bag(n)),bag=DialogueRules72.copies(oldBag);int inMachine=0;for(Object s:next)if(Set.of("minecraft:coal","minecraft:charcoal").contains(DialogueRules72.itemId(s)))inMachine+=DialogueRules72.size(s);if(fuel&&inMachine>=16)return false;
  Map<String,Integer> reserves=new HashMap<>();boolean changed=false;
  for(Object s:bag){if(DialogueRules72.empty(s))continue;String id=DialogueRules72.itemId(s);if(fuel?!Set.of("minecraft:coal","minecraft:charcoal").contains(id):!Activity78.hasCategory(s,"comida"))continue;int keep=fuel?0:Math.min(DialogueRules72.size(s),Math.max(0,4-reserves.getOrDefault(id,0)));reserves.merge(id,keep,Integer::sum);int max=Math.min(DialogueRules72.size(s)-keep,fuel?16-inMachine:64);if(max<=0)continue;
   int moved=insert(be,next,s,max);if(moved==0)continue;c(s,"shrink",moved);changed=true;if(fuel){inMachine+=moved;if(inMachine>=16)break;}
  }if(!changed)return false;
  try{for(int i=0;i<next.size();i++)c(be,"setItem",i,next.get(i));c(CalmLoot.class,"saveBag",n,bag);c(be,"setChanged");}
  catch(RuntimeException error){try{restore(be,old);}catch(RuntimeException rollback){error.addSuppressed(rollback);}try{c(CalmLoot.class,"saveBag",n,oldBag);}catch(RuntimeException rollback){error.addSuppressed(rollback);}throw error;}
  Settlement87.status(n,fuel?"reponer_combustible_del_generador":"guardar_excedente_de_comida_en_frio");return true;
 }
}
