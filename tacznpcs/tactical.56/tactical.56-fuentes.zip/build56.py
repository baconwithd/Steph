#!/usr/bin/env python3
"""Rebuild the tactical.56 delta against the exact user-supplied tactical.55."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
BASE_SHA = "e7d38239407e8e80d7cb5f5dff5456a7b6ec8c7d89ab3310513d17cf59fac6a8"
NAME = "tacznpcs-2.1.0-1.21.1-tactical.56-stability.jar"
TOOLS = {
    "ecj": ("org/eclipse/jdt/ecj/3.38.0/ecj-3.38.0.jar", "97c566b120009c203a2fc8b291f4a9adbc171cf1ccb70f06f6b4e1828c00ce8e"),
    "gson": ("com/google/code/gson/gson/2.10.1/gson-2.10.1.jar", "4241c14a7727c34feea6507ec801318a3d4a90f070e4525681079fb94ee4c593"),
    "asm": ("org/ow2/asm/asm/9.7/asm-9.7.jar", "adf46d5e34940bdf148ecdd26a9ee8eea94496a72034ff7141066b3eea5c4e9d"),
    "asm-tree": ("org/ow2/asm/asm-tree/9.7/asm-tree-9.7.jar", "62f4b3bc436045c1acb5c3ba2d8ec556ec3369093d7f5d06c747eb04b56d52b1"),
}
MODIFIED = {"Base48", "Chat71", "Free75", "Gate74", "Immersion82", "Navigation85", "Settlement87", "Utilities89", "Fort87", "Farm87", "Industry87"}
PREFIX = "mod/cdv/tnpc/tactical/"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(*args):
    subprocess.run([str(a) for a in args], check=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base", type=Path)
    parser.add_argument("--tools", type=Path, default=ROOT / "tooling")
    parser.add_argument("--test", action="store_true")
    args = parser.parse_args()
    base = args.base.resolve()
    if sha(base) != BASE_SHA:
        raise SystemExit("El JAR base no coincide con tactical.55-native-utilities suministrado; no se modifica.")
    args.tools.mkdir(parents=True, exist_ok=True)
    libraries = {}
    for name, (url, expected) in TOOLS.items():
        target = args.tools.resolve() / (name + ".jar")
        if not target.exists():
            urllib.request.urlretrieve("https://repo.maven.apache.org/maven2/" + url, target)
        if sha(target) != expected:
            raise SystemExit("Checksum de herramienta incorrecto: " + name)
        libraries[name] = target
    build = ROOT / "_build56"
    shutil.rmtree(build, ignore_errors=True)
    jar = build / "jar"
    classes = build / "classes"
    jar.mkdir(parents=True)
    classes.mkdir()
    with zipfile.ZipFile(base) as z:
        z.extractall(jar)
    cp = ":".join(str(x) for x in (jar, libraries["gson"], libraries["asm"], libraries["asm-tree"]))
    sources = [ROOT / "Patch56.java", *sorted((ROOT / "patch56").rglob("*.java"))]
    run("java", "-jar", libraries["ecj"], "-21", "-proc:none", "-cp", cp, "-d", classes, *sources)
    run("java", "-cp", f'{classes}:{libraries["asm"]}:{libraries["asm-tree"]}', "Patch56", jar)
    for source in (classes / PREFIX).glob("*.class"):
        shutil.copy2(source, jar / PREFIX / source.name)
    metadata = jar / "META-INF/neoforge.mods.toml"
    text = metadata.read_text()
    assert text.count("2.1.0-tactical.55-native-utilities") == 1
    metadata.write_text(text.replace("2.1.0-tactical.55-native-utilities", "2.1.0-tactical.56-stability"))
    with zipfile.ZipFile(base) as z:
        for info in z.infolist():
            if info.is_dir() or info.filename == "META-INF/neoforge.mods.toml" or info.filename in {PREFIX + name + ".class" for name in MODIFIED}:
                continue
            if (jar / info.filename).read_bytes() != z.read(info):
                raise AssertionError("Unexpected change: " + info.filename)
    if args.test:
        tests = build / "tests"
        tests.mkdir()
        run("java", "-jar", libraries["ecj"], "-21", "-proc:none", "-cp", f'{jar}:{libraries["gson"]}', "-d", tests, *sorted((ROOT / "tests").rglob("*.java")))
        for name in ("InventoryTest56", "PlacementTest56", "DialogueTest56", "GuardTest56", "WorkTest56"):
            run("java", "-Xmx256m", "-Xverify:all", "-cp", f'{tests}:{jar}:{libraries["gson"]}', "mod.cdv.tnpc.tactical." + name)
    output = ROOT / "output"
    output.mkdir(exist_ok=True)
    artifact = output / NAME
    with zipfile.ZipFile(artifact, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(jar.rglob("*")):
            if path.is_file():
                info = zipfile.ZipInfo(path.relative_to(jar).as_posix(), (2026, 10, 23, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                z.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    (output / "SHA256.json").write_text(json.dumps({NAME: sha(artifact), "base_tactical55": BASE_SHA}, indent=2) + "\n")
    print("BUILD OK", artifact, sha(artifact))

if __name__ == "__main__":
    main()
