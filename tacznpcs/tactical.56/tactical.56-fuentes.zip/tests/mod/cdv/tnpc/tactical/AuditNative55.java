package mod.cdv.tnpc.tactical;
import com.google.gson.JsonObject;
/** A reproducer against unmodified production Fort87 and TradeWorld87. */
public class AuditNative55 {
 public static class FailingTag extends Sim47.Tag {
  boolean fail;
  @Override public void put(String key,Object value){if(fail&&key.equals("TacZNpcCalmInventory")){fail=false;throw new IllegalStateException("injected save failure");}super.put(key,value);}
 }
 public static void main(String[] args) throws Exception {
  Sim47.setup();
  Sim47.World world = new Sim47.World();
  world.forceUnreachable = true;
  Sim47.Actor npc = new Sim47.Actor(world);
  JsonObject group = new JsonObject();
  group.addProperty("x", 0); group.addProperty("y", 65); group.addProperty("z", 0);
  group.addProperty("fase", 0); group.addProperty("cursor_muro", 0);
  group.add("construido", new JsonObject());
  int claimed = 0;
  for (int i=0; i<100; i++) {
   world.now += 20;
   if (Fort87.work(npc, group)) claimed++;
  }
  if (claimed != 100 || group.get("cursor_muro").getAsInt()!=0 || world.placed!=0 || npc.nav.moves!=0)
   throw new AssertionError("Reproducer assumptions changed");
  System.out.println("REPRODUCED native55: Fort87 claimed 100 work ticks across 2000 game ticks with an impossible target, no movement, cursor=0 and no placement");
  FailingTag tag = new FailingTag(); npc.tag = tag;
  CalmLoot.saveBag(npc, new java.util.ArrayList<>(java.util.List.of(Shelter77.item("minecraft:dirt",1))));
  Sim47.Pos at = new Sim47.Pos(2,65,0);
  tag.fail=true;
  try {TradeWorld87.mutate(npc,at,new Sim47.State("minecraft:dirt"),"minecraft:dirt",null);throw new AssertionError("failure did not fire");}
  catch(IllegalStateException expected){}
  System.out.println("TradeWorld87 bag save failure: world="+Base48.id(world,at)+" bag="+Base48.count(npc,"minecraft:dirt"));
 }
}
