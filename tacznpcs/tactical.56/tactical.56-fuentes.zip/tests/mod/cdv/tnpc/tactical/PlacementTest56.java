package mod.cdv.tnpc.tactical;
import java.util.*;
/** Fault injection around the actual Base48 placement hook; no replacement production logic. */
public class PlacementTest56 {
 static final String ID="doomsday_decoration:woodendrawer";
 static Sim47.Pos child(Sim47.Pos p){return new Sim47.Pos(p.x()+1,p.y(),p.z());}
 static class Registry extends Sim47.Registry {
  Registry(boolean block){super(block);}
  public Object get(Object key){return blocks&&key.toString().equals(ID)?new Furniture():super.get(key);}
 }
 public static class Registries {public static final Registry BLOCK=new Registry(true),ITEM=new Registry(false);}
 static class Furniture extends Sim47.Block {
  Furniture(){super(ID);}
  public Sim47.State defaultBlockState(){return new FurnitureState();}
  public void setPlacedBy(Sim47.World w,Sim47.Pos p,Sim47.State state,Sim47.Actor n,Sim47.Stack item){World world=(World)w;world.callbacks++;world.setBlock(child(p),new Sim47.State("doomsday_decoration:interaction_part"),3);if(world.failCallback)throw new IllegalStateException("injected furniture callback failure");}
 }
 static class FurnitureState extends Sim47.State {
  FurnitureState(){super(ID);}
  public Sim47.Block getBlock(){return new Furniture();}
  public boolean canSurvive(Object w,Object p){return true;}
 }
 public static class Footprint {
  public static List<Integer> cells(Object state,Object world,Object pos){return state instanceof FurnitureState?List.of(1):List.of();}
  public static Sim47.Pos pos(Sim47.Pos p,Integer cell){return child(p);}
 }
 public static class Hooks extends Sim47.EventHooks {
  public static boolean onBlockPlace(Object n,Object snapshot,Object dir){World w=(World)((Sim47.Actor)n).world;w.events++;return !w.allowPlace||w.cancelChild&&((Sim47.Snapshot)snapshot).pos.equals(w.part);}
 }
 static class World extends Sim47.World {
  int callbacks,events;boolean failCallback,cancelChild,unloadedChild;Sim47.Pos part;
  public boolean hasChunkAt(Object p){return !(unloadedChild&&p.equals(part));}
 }
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 static void stock(Sim47.Actor n)throws Exception{CalmLoot.saveBag(n,new ArrayList<>(List.of(Shelter77.item(ID,2))));}
 static void empty(World w,Sim47.Pos p){w.setBlock(p,new Sim47.State("minecraft:air"),3);w.setBlock(child(p),new Sim47.State("minecraft:air"),3);}
 public static void main(String[] args)throws Exception{Sim47.setup();Sim47.decor=true;SocialR.types.put("net.minecraft.core.registries.BuiltInRegistries",Registries.class);SocialR.types.put("dev.zomboid.decor.Footprint",Footprint.class);SocialR.types.put("net.neoforged.neoforge.event.EventHooks",Hooks.class);
  World w=new World();Sim47.Actor n=new Sim47.Actor(w);Sim47.Pos p=new Sim47.Pos(3,65,3);w.part=child(p);stock(n);empty(w,p);
  check(Base48.placeBefore86(n,p,ID),"native furniture placement failed");check(w.callbacks==1&&Shelter77.id(w.getBlockState(w.part)).endsWith(":interaction_part")&&Base48.count(n,ID)==1,"callback/part/item consumption missing");check(w.events==2,"root and child must both be checked by placement events");
  empty(w,p);stock(n);w.cancelChild=true;check(!Base48.placeBefore86(n,p,ID),"child event cancellation ignored");check(w.getBlockState(p).isAir()&&w.getBlockState(w.part).isAir()&&Base48.count(n,ID)==2,"cancel left root/part or consumed item");w.cancelChild=false;
  w.failCallback=true;try{Base48.placeBefore86(n,p,ID);throw new AssertionError("callback failure missing");}catch(IllegalStateException expected){}check(w.getBlockState(p).isAir()&&w.getBlockState(w.part).isAir()&&Base48.count(n,ID)==2,"callback failure left blocks or consumed item");w.failCallback=false;
  w.setBlock(w.part,new Sim47.State("minecraft:stone"),3);int before=w.callbacks;check(!Base48.placeBefore86(n,p,ID)&&w.callbacks==before&&Shelter77.id(w.getBlockState(w.part)).equals("minecraft:stone")&&Base48.count(n,ID)==2,"occupied footprint overwritten");empty(w,p);
  w.unloadedChild=true;check(!Base48.placeBefore86(n,p,ID)&&w.callbacks==before,"unloaded footprint accepted");w.unloadedChild=false;w.protectedArea=true;check(!Base48.placeBefore86(n,p,ID)&&Base48.count(n,ID)==2,"protected area placement accepted");w.protectedArea=false;
  CalmLoot.saveBag(n,new ArrayList<>(List.of(Shelter77.item("minecraft:white_bed",1))));check(Base48.placeBefore86(n,p,"minecraft:white_bed"),"native vanilla bed placement regressed");check(Shelter77.id(w.getBlockState(p)).equals("minecraft:white_bed")&&Shelter77.id(w.getBlockState(new Sim47.Pos(3,65,4))).equals("minecraft:white_bed")&&Base48.count(n,"minecraft:white_bed")==0,"vanilla bed halves/consumption regressed");
  System.out.println("PASS: actual Base48 furniture callback; root+part event cancellation; callback rollback; occupied/unloaded/protected footprint; native vanilla bed preserved");
 }
}
