import java.nio.file.*;import java.util.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** Apply only verified deltas to the supplied tactical.55. */
public class Patch56 implements Opcodes {
 static final String P="mod/cdv/tnpc/tactical/";
 static MethodNode forward(String name,String descriptor,String owner,String method){MethodNode m=new MethodNode(ACC_PUBLIC|ACC_STATIC,name,descriptor,null,null);int local=0;for(Type t:Type.getArgumentTypes(descriptor)){m.instructions.add(new VarInsnNode(t.getOpcode(ILOAD),local));local+=t.getSize();}m.instructions.add(new MethodInsnNode(INVOKESTATIC,owner,method,descriptor,false));m.instructions.add(new InsnNode(Type.getReturnType(descriptor).getOpcode(IRETURN)));return m;}
 static void body(MethodNode m,String owner,String target){m.instructions=forward(m.name,m.desc,owner,target).instructions;m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();}
 public static void main(String[] args)throws Exception{Path root=Path.of(args[0]);Set<String> changed=new TreeSet<>();try(var stream=Files.walk(root)){for(Path file:stream.filter(p->p.toString().endsWith(".class")).toList()){
  ClassNode cls=new ClassNode();new ClassReader(Files.readAllBytes(file)).accept(cls,0);String simple=cls.name.substring(cls.name.lastIndexOf('/')+1);boolean edit=false;
  for(MethodNode m:new ArrayList<MethodNode>(cls.methods)){
   if(simple.equals("Chat71")&&Set.of("start","pump").contains(m.name)){body(m,P+"Dialogue56",m.name);edit=true;}
   if(simple.equals("Free75")&&m.name.equals("take")){body(m,P+"Dialogue56","take");edit=true;}
   if(simple.equals("Free75")&&m.name.equals("resume"))for(AbstractInsnNode a:m.instructions.toArray())if(a instanceof MethodInsnNode call&&call.owner.equals(P+"Chat71")&&call.name.equals("armed")){call.owner=P+"Dialogue56";call.name="resumeArmed";edit=true;}
   if(simple.equals("Free75")&&m.name.equals("closing")){InsnList hook=new InsnList();hook.add(new VarInsnNode(ALOAD,0));hook.add(new VarInsnNode(ALOAD,2));hook.add(new MethodInsnNode(INVOKESTATIC,P+"Dialogue56","interrupted","(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;",false));hook.add(new VarInsnNode(ASTORE,2));m.instructions.insert(hook);edit=true;}
   if(simple.equals("Gate74")&&m.name.equals("reject"))for(AbstractInsnNode a:m.instructions.toArray())if(a instanceof MethodInsnNode call&&call.owner.equals(P+"Immersion82")&&call.name.equals("call")&&call.desc.equals("(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")){m.instructions.insertBefore(call,new VarInsnNode(ALOAD,0));call.owner=P+"Dialogue56";call.name="gateCall";call.desc="(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;";edit=true;}
   if(simple.equals("Base48")&&Set.of("retrieve","stored").contains(m.name)){body(m,P+"Inventory56",m.name);edit=true;}
   if(simple.equals("Base48")&&m.name.equals("placeBefore86")){String desc=m.desc;m.name="placeNative55";cls.methods.add(forward("placeBefore86",desc,P+"Placement56","place"));edit=true;}
   if(simple.equals("Navigation85")&&m.name.equals("init")){body(m,P+"Guard56","navigationInit");edit=true;}
   if(simple.equals("Utilities89")&&m.name.equals("transfer")){body(m,P+"Inventory56","transfer");edit=true;}
   if(simple.equals("Utilities89")&&m.name.equals("service")){body(m,P+"Guard56","service");edit=true;}
   if(simple.equals("Utilities89")&&Set.of("work","maintain").contains(m.name)){String old=m.name,desc=m.desc;m.name=old+"Native55";cls.methods.add(forward(old,desc,P+"Guard56",old.equals("work")?"utilitiesWork":"utilitiesMaintain"));edit=true;}
   if(simple.equals("Fort87")&&Set.of("work","repair","gates").contains(m.name)||simple.equals("Farm87")&&Set.of("work","tree").contains(m.name)||simple.equals("Industry87")&&m.name.equals("mine")){String old=m.name,desc=m.desc;String target=simple.equals("Fort87")?"fort"+Character.toUpperCase(old.charAt(0))+old.substring(1):simple.equals("Farm87")?"farm"+Character.toUpperCase(old.charAt(0))+old.substring(1):"mine";m.name=old+"Native55";cls.methods.add(forward(old,desc,P+"WorkGuard56",target));edit=true;}
   if(simple.equals("Settlement87")&&m.name.equals("group")){String desc=m.desc;m.name="groupNative55";cls.methods.add(forward("group",desc,P+"Guard56","group"));edit=true;}
   if(simple.equals("Immersion82")&&m.name.equals("active46"))for(AbstractInsnNode a:m.instructions.toArray()){if(a instanceof LdcInsnNode constant&&constant.cst instanceof String s&&s.contains("[TacZ NPCs tactical.48]")){constant.cst=s.replace("tactical.48","tactical.56");edit=true;}if(a instanceof InvokeDynamicInsnNode dynamic)for(int i=0;i<dynamic.bsmArgs.length;i++)if(dynamic.bsmArgs[i] instanceof String s&&s.contains("[TacZ NPCs tactical.48]")){dynamic.bsmArgs[i]=s.replace("tactical.48","tactical.56");edit=true;}}
  }
  if(edit){ClassWriter out=new ClassWriter(ClassWriter.COMPUTE_MAXS);cls.accept(out);Files.write(file,out.toByteArray());changed.add(cls.name);}
 }}for(String name:changed)System.out.println(name);if(changed.size()!=11)throw new AssertionError("Unexpected changed class count "+changed.size());}
}
