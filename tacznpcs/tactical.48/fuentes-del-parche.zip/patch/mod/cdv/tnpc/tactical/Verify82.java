package mod.cdv.tnpc.tactical;
import java.nio.file.*;import com.google.gson.*;
public class Verify82 {
 public static void main(String[] args)throws Exception{
  JsonObject data=JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonObject();DialogueData71.validate(data,false);
  JsonObject migrated=Immersion82.augment(data.deepCopy());DialogueData71.validate(migrated,false);if(!migrated.equals(Immersion82.augment(migrated.deepCopy())))throw new AssertionError("migration is not idempotent");
  for(String cls:new String[]{"Authority70","Chat71","Companion78","DialogueRules72","Free75","Sense28","Data73","Expression20","SpeechSounds20","Navigation78","Life79","Threat27","Social","Gate74","Immersion82","Base48","Encounters47","Shelter47","Routes47","Activity78","Events76","Shelter77","Ambient78"})Class.forName("mod.cdv.tnpc.tactical."+cls,true,Verify82.class.getClassLoader()).getDeclaredMethods();
  Object npc=new Object();String last="";for(int i=0;i<100;i++){String s=Immersion82.pick(npc,"test","a","b","c");if(last.equals(s))throw new AssertionError("repeat");last=s;}
  System.out.println("PASS: dialogue validation, migration/idempotence, class verification, 100 no-repeat selections");
 }
}
