package mod.cdv.tnpc.tactical;
import java.util.*;
/** Persistent, finite base jobs. All world and inventory mutations run on the server thread. */
public final class Base48 {
 static Object c(Object o,String m,Object...a){return Social.c(o,m,a);}
 static final Map<Object,Job> JOBS=new WeakHashMap<>();
 static final Set<Object> WARN=Collections.newSetFromMap(new WeakHashMap<>());
 static final String[] FURN={"crafting_table","furnace","white_bed","chest"};
 static class Job {Object target,escape;long escapeUntil;String signature="";String type="",block="";long next,started,progress,checked,retry;double lastX,lastZ;int failures,scan,patrol;Shelter77.Camp wood;}
 static Object tag(Object n){return Social.tag(n);}static long now(Object n){return Social.time(n);}
 static void str(Object n,String k,String v){c(tag(n),"putString","npc48_"+k,v);}static String str(Object n,String k){return Social.s(tag(n),"npc48_"+k);}
 static void num(Object n,String k,long v){c(tag(n),"putLong","npc48_"+k,v);}static long num(Object n,String k){return Social.l(tag(n),"npc48_"+k);}
 static boolean yes(Object n,String k){return Social.yes(c(tag(n),"getBoolean","npc48_"+k));}static void flag(Object n,String k){c(tag(n),"putBoolean","npc48_"+k,true);}
 static Object point(Object n,String k){return Hunt78.point(n,"npc48_"+k);}static void point(Object n,String k,Object p){Hunt78.point(n,"npc48_"+k,p);}
 static Object off(Object p,int x,int y,int z){return Shelter77.offset(p,x,y,z);}static String id(Object w,Object p){return Shelter77.id(Shelter77.state(w,p));}
 static double dist(Object n,Object p){return Hunt78.distance(n,p);}static Object base(Object n){return point(n,"base");}
 static boolean floor(Object n,Object p){Object w=Social.world(n),b=off(p,0,-1,0);return Shelter77.loaded(w,p)&&Shelter77.loaded(w,off(p,0,1,0))&&Shelter77.air(w,p)&&Shelter77.air(w,off(p,0,1,0))&&Social.yes(c(Shelter77.state(w,b),"isFaceSturdy",w,b,SocialR.get(Social.t("net.minecraft.core.Direction"),"UP")))&&Shelter77.permitted(n,p);}
 static String key(Object p){return Shelter77.axis(p,"getX")+","+Shelter77.axis(p,"getY")+","+Shelter77.axis(p,"getZ");}
 static boolean same(Object a,Object b){return a!=null&&b!=null&&key(a).equals(key(b));}
 static boolean visible(Object n,Object p){return Social.yes(c(Social.t("mod.cdv.tnpc.tactical.Tasks"),"visibleBlock",n,p,Shelter77.axis(p,"getX")+.5,(double)Shelter77.axis(p,"getY"),Shelter77.axis(p,"getZ")+.5));}
 static void look(Object n,Object p){c(c(n,"getLookControl"),"setLookAt",Shelter77.axis(p,"getX")+.5,Shelter77.axis(p,"getY")+.6,Shelter77.axis(p,"getZ")+.5);}
 static void status(Object n,String s){str(n,"tarea",s);Life79.mark(n,s);Social.mem(n).occupied=true;}
 static boolean safe(Object n){return Authority70.enabled(n)&&Activity78.free(n)&&!Life79.servicing(n)&&now(n)>=Social.l(tag(n),"npc82_investigate");}
 static boolean reachable(Object n,Object p){return Navigation78.complete(Navigation78.path(c(n,"getNavigation"),Shelter77.axis(p,"getX")+.5,(double)Shelter77.axis(p,"getY"),Shelter77.axis(p,"getZ")+.5));}
 static Object approach(Object n,Object p){List<Object> options=new ArrayList<>();for(int r=1;r<=2;r++)for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++)if(x*x+z*z<=4){Object q=off(p,x,0,z);if(floor(n,q))options.add(q);}options.sort(Comparator.comparingDouble(q->dist(n,q)));for(Object q:options)if(reachable(n,q))return q;return null;}
 static boolean walk(Object n,Object p){return Navigation78.go(n,Shelter77.axis(p,"getX")+.5,Shelter77.axis(p,"getY"),Shelter77.axis(p,"getZ")+.5,.85);}
 static boolean hasRoom(Object n,Object home){if(!floor(n,home)||!Shelter47.roof(n,home))return false;int count=0;for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++){Object p=off(home,x,0,z);if(floor(n,p)&&Shelter47.roof(n,p))count++;}return count>=7&&reachable(n,home);}
 // A local connectivity check keeps circulation and access to all furniture, including both bed halves.
 static Set<String> flood(Object n,Object home,Set<String> blocked){Set<String> seen=new HashSet<>();ArrayDeque<Object> queue=new ArrayDeque<>();queue.add(home);seen.add(key(home));while(!queue.isEmpty()){Object p=queue.removeFirst();for(int[] d:new int[][]{{1,0},{-1,0},{0,1},{0,-1}}){Object q=off(p,d[0],0,d[1]);if(Math.abs(Shelter77.axis(q,"getX")-Shelter77.axis(home,"getX"))>6||Math.abs(Shelter77.axis(q,"getZ")-Shelter77.axis(home,"getZ"))>6||blocked.contains(key(q))||seen.contains(key(q))||!floor(n,q))continue;seen.add(key(q));queue.add(q);}}return seen;}
 static boolean connected(Object n,Object home,Set<String> blocked){Set<String> before=flood(n,home,Set.of()),after=flood(n,home,blocked);if(after.size()<3)return false;for(String p:before)if(!blocked.contains(p)&&!after.contains(p))return false;
  for(String b:blocked){String[] a=b.split(",");Object p=Shelter77.pos(Integer.parseInt(a[0]),Integer.parseInt(a[1]),Integer.parseInt(a[2]));boolean access=false;for(int[] d:new int[][]{{1,0},{-1,0},{0,1},{0,-1}})if(after.contains(key(off(p,d[0],0,d[1]))))access=true;if(!access)return false;}return true;
 }
 static boolean spot(Object n,Object home,Object p,boolean bed){Object w=Social.world(n);if(!floor(n,p)||!Shelter47.roof(n,p)||same(p,home)||Shelter77.occupied(w,p)||dist(n,p)<1)return false;
  for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++){String s=id(w,off(p,x,0,z));if(s.endsWith("_door")||s.endsWith("_trapdoor"))return false;}
  Set<String> blocked=new HashSet<>();for(String f:FURN){Object q=point(n,f);if(q!=null){blocked.add(key(q));if(f.equals("white_bed"))blocked.add(key(off(q,0,0,1)));}}
  blocked.add(key(p));if(bed){Object head=off(p,0,0,1);if(!floor(n,head)||!Shelter47.roof(n,head)||same(home,head)||Shelter77.occupied(w,head))return false;blocked.add(key(head));}
  return connected(n,home,blocked)&&approach(n,p)!=null;
 }
 static Object findSpot(Object n,Object home,boolean bed){List<Object> list=new ArrayList<>();for(int r=1;r<=5;r++)for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++)if(Math.max(Math.abs(x),Math.abs(z))==r)list.add(off(home,x,0,z));
  // Against the room edges, leaving the home/entrance in the circulation area.
  list.sort(Comparator.comparingDouble(p->{int solid=0;for(int[] d:new int[][]{{1,0},{-1,0},{0,1},{0,-1}})if(!Shelter77.air(Social.world(n),off(p,d[0],0,d[1])))solid++;return -solid*10+Math.abs(Shelter77.axis(p,"getX")-Shelter77.axis(home,"getX"))+Math.abs(Shelter77.axis(p,"getZ")-Shelter77.axis(home,"getZ"));}));
  for(Object p:list)if(spot(n,home,p,bed))return p;return null;
 }
 static boolean register(Object n){Object home=base(n);if(home!=null)return true;
  Shelter77.Camp camp=Shelter77.get(n);Object p=camp!=null&&camp.phase.equals("descansar")?Shelter77.pos(camp.x,camp.y,camp.z):Hunt78.point(n,"npc78_home");if(p==null)return false;
  if(!hasRoom(n,p)){str(n,"estado","refugio_sin_espacio_para_base");return false;}
  // Nearby allied residents share one base and its kit, rather than generating one set each.
  for(Object other:Social.nearby(n,"mod.cdv.tnpc.entity.AutoGunOperator",16d))if(other!=n&&Social.kind(other)==Social.kind(n)&&base(other)!=null&&Hunt78.distance(n,base(other))<144&&key(base(other)).equals(key(p))){str(n,"lider",Social.uuid(other).toString());str(n,"nombre",str(other,"nombre"));str(n,"estado","base_compartida");point(n,"base",base(other));return true;}
  point(n,"base",p);str(n,"nombre",c(c(n,"getName"),"getString").toString());str(n,"dueno",Social.uuid(n).toString());str(n,"estado","preparando_base");num(n,"creada",now(n));str(n,"tarea","amueblar_base");
  Activity78.Roof r=Activity78.ROOFS.get(n);if(r!=null)r.pos=null;return true;
 }
 static boolean kit(Object n){if(yes(n,"kit"))return true;List<Object> bag=DialogueRules72.copies(DialogueRules72.bag(n));List<Object> add=new ArrayList<>();for(String f:FURN)if(Shelter77.count(bag,"minecraft:"+f)==0)add.add(Shelter77.item("minecraft:"+f,1));
  for(String t:new String[]{"wooden_pickaxe","wooden_axe","wooden_sword"})if(tool(n,t.substring(t.indexOf('_')))==null)add.add(Shelter77.item("minecraft:"+t,1));
  if(!DialogueRules72.insert(bag,add,false)){str(n,"estado","sin_espacio_para_equipo_inicial");return false;}c(CalmLoot.class,"saveBag",n,bag);flag(n,"kit");return true;
 }
 static Object tool(Object n,String suffix){Object held=c(n,"getMainHandItem");if(!DialogueRules72.empty(held)&&DialogueRules72.itemId(held).endsWith(suffix))return held;for(Object s:DialogueRules72.bag(n))if(!DialogueRules72.empty(s)&&DialogueRules72.itemId(s).endsWith(suffix))return s;return null;}
 static Object equip(Object n,String suffix){Object held=c(n,"getMainHandItem");if(!DialogueRules72.empty(held)&&DialogueRules72.itemId(held).endsWith(suffix))return held;List<Object> bag=DialogueRules72.copies(DialogueRules72.bag(n));Object chosen=null;for(Object s:bag)if(!DialogueRules72.empty(s)&&DialogueRules72.itemId(s).endsWith(suffix)){chosen=DialogueRules72.copy(s);c(s,"shrink",1);break;}if(chosen==null)return null;List<Object> old=DialogueRules72.copies(DialogueRules72.bag(n));if(!DialogueRules72.empty(held)&&!DialogueRules72.insert(bag,new ArrayList<>(List.of(DialogueRules72.copy(held))),false))return null;
  c(CalmLoot.class,"saveBag",n,bag);try{c(n,"setItemInHand",SocialR.get(Social.t("net.minecraft.world.InteractionHand"),"MAIN_HAND"),chosen);}catch(Exception e){c(CalmLoot.class,"saveBag",n,old);throw e;}return c(n,"getMainHandItem");
 }
 static void defend(Object n){Object current=c(n,"getMainHandItem");String id=DialogueRules72.itemId(current);if(!DialogueRules72.empty(current)&&!id.endsWith("_axe")&&!id.endsWith("_pickaxe"))return;for(Object s:DialogueRules72.bag(n)){String q=DialogueRules72.itemId(s);if(q.contains("tacz:")||q.contains("gun")){equip(n,q.substring(q.indexOf(':')+1));return;}}equip(n,"_sword");}
 static void wear(Object n,Object s){if(s==null)return;int max=((Number)c(s,"getMaxDamage")).intValue();if(max>0){int d=((Number)c(s,"getDamageValue")).intValue()+1;if(d>=max)c(s,"shrink",1);else c(s,"setDamageValue",d);}}
 static Object bedState(Object state,boolean head){Object dir=SocialR.get(Social.t("net.minecraft.core.Direction"),"SOUTH"),part=SocialR.get(Social.t("net.minecraft.world.level.block.state.properties.BedPart"),head?"HEAD":"FOOT");state=c(state,"setValue",SocialR.get(Social.t("net.minecraft.world.level.block.BedBlock"),"FACING"),dir);return c(state,"setValue",SocialR.get(Social.t("net.minecraft.world.level.block.BedBlock"),"PART"),part);}
 static boolean place(Object n,Object p,String item){Object w=Social.world(n);if(!Shelter77.grief(n)||!Shelter77.permitted(n,p)||!Shelter77.air(w,p))return false;boolean bed=item.endsWith("_bed");Object head=off(p,0,0,1);if(bed&&(!Shelter77.permitted(n,head)||!Shelter77.air(w,head)))return false;
  List<Object> oldBag=DialogueRules72.copies(DialogueRules72.bag(n)),bag=DialogueRules72.copies(oldBag);boolean found=false;for(Object s:bag)if(DialogueRules72.itemId(s).equals(item)&&!DialogueRules72.empty(s)){c(s,"shrink",1);found=true;break;}if(!found)return false;
  Object old=Shelter77.state(w,p),oldHead=bed?Shelter77.state(w,head):null,bs=c(Shelter77.registry("BLOCK",item),"defaultBlockState");if(bed)bs=bedState(bs,false);
  Object snap=c(Social.t("net.neoforged.neoforge.common.util.BlockSnapshot"),"create",c(w,"dimension"),w,p),hs=bed?c(Social.t("net.neoforged.neoforge.common.util.BlockSnapshot"),"create",c(w,"dimension"),w,head):null;
  boolean complete=false;try{if(!Social.yes(c(w,"setBlock",p,bs,2)))return false;if(bed&&!Social.yes(c(w,"setBlock",head,bedState(bs,true),2)))return false;
   Object up=SocialR.get(Social.t("net.minecraft.core.Direction"),"UP");if(Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"),"onBlockPlace",n,snap,up))||(bed&&Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"),"onBlockPlace",n,hs,up))))return false;
   c(CalmLoot.class,"saveBag",n,bag);complete=true;
  }finally{if(!complete){c(w,"setBlock",p,old,3);if(bed)c(w,"setBlock",head,oldHead,3);c(CalmLoot.class,"saveBag",n,oldBag);}}
  c(w,"blockUpdated",p,c(bs,"getBlock"));if(bed)c(w,"blockUpdated",head,c(bs,"getBlock"));Object be=c(w,"getBlockEntity",p);if(be!=null){Object t=c(be,"getPersistentData");c(t,"putString","npc48_dueno",Social.uuid(n).toString());if(item.endsWith(":chest")||item.endsWith(":furnace"))c(be,"setCustomName",c(Social.t("net.minecraft.network.chat.Component"),"literal","Base de "+str(n,"nombre")));c(be,"setChanged");}Shelter77.swing(n);return true;
 }
 static void reset(Object n,Job j,String why){j.target=null;j.wood=null;j.type="";j.started=0;j.progress=0;j.failures++;j.retry=now(n)+100;str(n,"tarea",why);Social.mem(n).occupied=false;c(c(n,"getNavigation"),"stop");Navigation78.Route r=Navigation78.ROUTES.get(n);if(r!=null)r.retry=0;Routes47.Route r47=Routes47.ROUTES.get(n);if(r47!=null){r47.requested=false;r47.manualUntil=0;r47.detourUntil=0;}}
 static boolean furnish(Object n,Job j){Object home=base(n),w=Social.world(n);for(String f:FURN){Object p=point(n,f);if(p!=null&&Shelter77.loaded(w,p)&&id(w,p).equals("minecraft:"+f)){if(f.equals("chest"))Hunt78.point(n,"npc78_depot",p);continue;}
   if(yes(n,"placed_"+f)){str(n,"estado","falta_"+f);return false;}
   if(!Shelter77.grief(n)){str(n,"estado","base_protegida_sin_amueblar");return false;}
   // A table built during shelter construction counts as the supplied table.
   if(f.equals("crafting_table")){Shelter77.Camp camp=Shelter77.get(n);if(camp!=null){Object t=Shelter77.pos(camp.x+camp.size-1,camp.y,camp.z+camp.size-1);if(id(w,t).equals("minecraft:crafting_table")){point(n,f,t);flag(n,"placed_"+f);continue;}}}
   if(p==null||!spot(n,home,p,f.equals("white_bed"))){p=findSpot(n,home,f.equals("white_bed"));if(p!=null)point(n,f,p);}
   if(p==null){str(n,"estado","base_sin_espacio_para_"+f);return false;}
   if(!j.type.equals("amueblar_"+f)||!same(j.target,p)){j.type="amueblar_"+f;j.target=p;j.started=now(n);}
   if(dist(n,p)>9||!visible(n,p)){Object q=approach(n,p);if(q==null||!walk(n,q)){reset(n,j,"buscar_otro_acceso_a_base");return false;}status(n,"llevar_"+f+"_a_base");return true;}
   look(n,p);if(place(n,p,"minecraft:"+f)){flag(n,"placed_"+f);num(n,"ultimo_progreso",now(n));if(f.equals("chest"))Hunt78.point(n,"npc78_depot",p);}else{str(n,"estado","no_se_pudo_colocar_"+f);return false;}status(n,"amueblar_base");return true;
  }str(n,"estado","base_principal");return false;
 }
 static boolean ready(Object n){Object w=Social.world(n);for(String f:FURN){Object p=point(n,f);if(p==null||!Shelter77.loaded(w,p)||!id(w,p).equals("minecraft:"+f))return false;}return true;}
 static int count(Object n,String item){return Shelter77.count(DialogueRules72.bag(n),item);}
 static boolean take(List<Object> bag,String item,int amount){if(Shelter77.count(bag,item)<amount)return false;for(Object s:bag)if(DialogueRules72.itemId(s).equals(item)){int d=Math.min(amount,DialogueRules72.size(s));c(s,"shrink",d);amount-=d;if(amount==0)return true;}return false;}
 static boolean refuel(Object n){Object p=point(n,"furnace"),be=c(Social.world(n),"getBlockEntity",p);if(be==null||!Shelter77.permitted(n,p))return false;List<Object> old=DialogueRules72.copies(DialogueRules72.bag(n)),bag=DialogueRules72.copies(old);Object input=c(be,"getItem",0),fuel=c(be,"getItem",1),output=c(be,"getItem",2);Object ni=DialogueRules72.copy(input),nf=DialogueRules72.copy(fuel);boolean changed=false;
  if(!DialogueRules72.empty(output)){if(DialogueRules72.insert(bag,new ArrayList<>(List.of(DialogueRules72.copy(output))),false))changed=true;else return false;}
  // Vanilla furnace performs actual smelting; the NPC only inserts real inputs/fuel.
  if(DialogueRules72.empty(input)){for(String s:new String[]{"minecraft:raw_iron","minecraft:raw_gold","minecraft:raw_copper","minecraft:oak_log","minecraft:spruce_log","minecraft:birch_log"})if(Shelter77.count(bag,s)>0){int a=Math.min(8,Shelter77.count(bag,s));if(take(bag,s,a)){ni=Shelter77.item(s,a);changed=true;}break;}}
  if(DialogueRules72.empty(fuel)&&!DialogueRules72.empty(ni)){for(String s:new String[]{"minecraft:coal","minecraft:charcoal","minecraft:oak_planks","minecraft:spruce_planks","minecraft:birch_planks"})if(Shelter77.count(bag,s)>0){int a=Math.min(4,Shelter77.count(bag,s));if(take(bag,s,a)){nf=Shelter77.item(s,a);changed=true;}break;}}
  if(!changed)return false;try{c(be,"setItem",0,ni);c(be,"setItem",1,nf);if(!DialogueRules72.empty(output))c(be,"setItem",2,Shelter77.item("minecraft:air",0));c(CalmLoot.class,"saveBag",n,bag);c(be,"setChanged");}catch(Exception e){c(be,"setItem",0,input);c(be,"setItem",1,fuel);c(be,"setItem",2,output);c(CalmLoot.class,"saveBag",n,old);throw e;}num(n,"ultimo_progreso",now(n));return true;
 }
 static int stored(Object n,String suffix){int result=0;Object p=point(n,"chest");if(p!=null&&Shelter77.loaded(Social.world(n),p)){Object be=c(Social.world(n),"getBlockEntity",p);if(be!=null){int size=((Number)c(be,"getContainerSize")).intValue();for(int i=0;i<size;i++){Object s=c(be,"getItem",i);if(DialogueRules72.itemId(s).endsWith(suffix))result+=DialogueRules72.size(s);}}}for(Object s:DialogueRules72.bag(n))if(DialogueRules72.itemId(s).endsWith(suffix))result+=DialogueRules72.size(s);return result;}
 static boolean retrieve(Object n,String item,int amount){Object p=point(n,"chest"),be=c(Social.world(n),"getBlockEntity",p);if(be==null||dist(n,p)>9||!Shelter77.permitted(n,p))return false;List<Object> bag=DialogueRules72.copies(DialogueRules72.bag(n));for(int i=0;i<((Number)c(be,"getContainerSize")).intValue();i++){Object s=c(be,"getItem",i);if(!DialogueRules72.itemId(s).equals(item)||DialogueRules72.empty(s))continue;int take=Math.min(amount,DialogueRules72.size(s));Object remain=c(s,"copyWithCount",DialogueRules72.size(s)-take);if(!DialogueRules72.insert(bag,new ArrayList<>(List.of(c(s,"copyWithCount",take))),false))return false;c(CalmLoot.class,"saveBag",n,bag);try{c(be,"setItem",i,remain);c(be,"setChanged");}catch(Exception e){List<Object> undo=DialogueRules72.copies(bag);take(undo,item,take);c(CalmLoot.class,"saveBag",n,undo);c(be,"setItem",i,s);throw e;}return true;}return false;}
 static boolean improve(Object n){Object home=base(n);if(num(n,"mejoras")>=8)return false;Object w=Social.world(n);for(int x=-4;x<=4;x++)for(int z=-4;z<=4;z++){Object p=off(home,x,-1,z);String old=id(w,p);if(!Set.of("minecraft:dirt","minecraft:grass_block","minecraft:oak_planks","minecraft:spruce_planks","minecraft:birch_planks").contains(old)||!Shelter47.roof(n,off(p,0,1,0))||!Shelter77.permitted(n,p)||!Shelter77.grief(n)||c(w,"getBlockEntity",p)!=null)continue;
   if(dist(n,p)>9||!visible(n,p))continue;if(count(n,"minecraft:cobblestone")==0&&!retrieve(n,"minecraft:cobblestone",8))return false;
   Object state=Shelter77.state(w,p);if(!Social.yes(c(state,"canEntityDestroy",w,p,n))||!Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"),"onEntityDestroyBlock",n,p,state)))continue;
   List<Object> oldBag=DialogueRules72.copies(DialogueRules72.bag(n)),bag=DialogueRules72.copies(oldBag);if(!take(bag,"minecraft:cobblestone",1))return false;Object replacement=c(Shelter77.registry("BLOCK","minecraft:cobblestone"),"defaultBlockState"),snapshot=c(Social.t("net.neoforged.neoforge.common.util.BlockSnapshot"),"create",c(w,"dimension"),w,p);
   if(!Social.yes(c(w,"setBlock",p,replacement,2)))return false;try{if(Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"),"onBlockPlace",n,snapshot,SocialR.get(Social.t("net.minecraft.core.Direction"),"UP")))){c(w,"setBlock",p,state,3);return false;}c(CalmLoot.class,"saveBag",n,bag);}catch(Exception e){c(w,"setBlock",p,state,3);c(CalmLoot.class,"saveBag",n,oldBag);throw e;}c(w,"blockUpdated",p,c(replacement,"getBlock"));num(n,"mejoras",num(n,"mejoras")+1);num(n,"ultimo_progreso",now(n));look(n,p);Shelter77.swing(n);return true;
  }return false;}
 static boolean mineable(Object n,Object home,Object p){Object w=Social.world(n);String s=id(w,p);if(!Set.of("minecraft:stone","minecraft:coal_ore","minecraft:iron_ore").contains(s)||!Shelter77.grief(n)||!Shelter77.permitted(n,p)||c(w,"getBlockEntity",p)!=null)return false;
  // Never mine base blocks, underfoot support, or a buried tunnel. Only exposed surface faces.
  if(Math.abs(Shelter77.axis(p,"getX")-Shelter77.axis(home,"getX"))<7&&Math.abs(Shelter77.axis(p,"getZ")-Shelter77.axis(home,"getZ"))<7)return false;
  if(Shelter77.axis(p,"getY")<Shelter77.axis(home,"getY")||!Shelter77.air(w,off(p,0,1,0)))return false;return approach(n,p)!=null;
 }
 static boolean mine(Object n,Job j){Object home=base(n),w=Social.world(n);if(tool(n,"_pickaxe")==null)return false;
  if(j.target==null){for(int i=0;i<128;i++){int v=Math.floorMod(j.scan++,625),x=v%25-12,z=v/25-12;Object p=off(home,x,0,z);if(Shelter77.loaded(w,p)&&mineable(n,home,p)){j.target=p;j.block=id(w,p);j.started=now(n);j.progress=0;break;}}if(j.target==null)return false;}
  Object p=j.target;if(!mineable(n,home,p)||!id(w,p).equals(j.block)){reset(n,j,"buscar_otro_recurso");return false;}Object tool=equip(n,"_pickaxe");if(tool==null||!Social.yes(c(tool,"isCorrectToolForDrops",Shelter77.state(w,p)))){reset(n,j,"necesita_mejor_pico");return false;}
  if(dist(n,p)>9||!visible(n,p)){Object q=approach(n,p);if(q==null||!walk(n,q)){reset(n,j,"recurso_sin_acceso");return false;}j.progress=0;status(n,"ir_por_piedra_y_minerales");return true;}
  c(c(n,"getNavigation"),"stop");look(n,p);Shelter77.swing(n);status(n,"extraer_piedra_para_base");j.progress+=10;
  if(j.progress<60)return true;Object state=Shelter77.state(w,p);if(!Social.yes(c(state,"canEntityDestroy",w,p,n))||!Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"),"onEntityDestroyBlock",n,p,state))){reset(n,j,"recurso_protegido");return false;}
  List<?> drops=(List<?>)c(Social.t("net.minecraft.world.level.block.Block"),"getDrops",state,w,p,null,n,tool);List<Object> bag=DialogueRules72.copies(DialogueRules72.bag(n)),add=new ArrayList<>();for(Object s:drops)add.add(DialogueRules72.copy(s));if(!DialogueRules72.insert(bag,add,false)){reset(n,j,"volver_a_guardar_materiales");return false;}
  if(Social.yes(c(w,"destroyBlock",p,false,n))){try{c(CalmLoot.class,"saveBag",n,bag);}catch(Exception e){c(w,"setBlock",p,state,3);throw e;}wear(n,tool);num(n,"ultimo_progreso",now(n));}j.target=null;j.progress=0;j.type="";return true;
 }
 static boolean wood(Object n,Job j){if(tool(n,"_axe")==null||!Shelter77.grief(n))return false;if(j.wood==null){Object h=base(n);j.wood=new Shelter77.Camp(Shelter77.axis(h,"getX"),Shelter77.axis(h,"getY"),Shelter77.axis(h,"getZ"),2);j.started=now(n);j.type="madera";}
  if(now(n)<j.wood.next)return !j.wood.wait;int before=stored(n,"_log");equip(n,"_axe");Shelter47.gather(n,j.wood);status(n,"talar_para_horno_y_construccion");if(stored(n,"_log")>before){wear(n,c(n,"getMainHandItem"));num(n,"ultimo_progreso",now(n));}
  if(j.wood.giveUp||j.wood.wait){reset(n,j,"sin_arbol_accesible_explorar");return false;}if(stored(n,"_log")>=16){j.wood=null;j.type="";j.started=0;}return true;
 }
 static boolean patrol(Object n,Job j){Object home=base(n);defend(n);if(j.target==null||!j.type.equals("patrulla")||dist(n,j.target)<1){j.type="patrulla";j.target=null;for(int i=0;i<8;i++){double a=(j.patrol++%8)*Math.PI/4;Object p=off(home,(int)Math.round(Math.cos(a)*4),0,(int)Math.round(Math.sin(a)*4));if(floor(n,p)&&reachable(n,p)){j.target=p;j.started=now(n);break;}}}
  if(j.target!=null){if(walk(n,j.target)){look(n,j.target);status(n,"vigilar_base_y_aliados");return true;}reset(n,j,"buscar_punto_de_vigilancia");}return false;
 }
 public static boolean work(Object n){try{
  if(!safe(n))return false;
  if(Social.yes(c(n,"isSleeping"))){long day=((Number)c(Social.world(n),"getDayTime")).longValue()%24000;if(day>=13000&&day<22500){status(n,"dormir_en_su_base");return true;}c(n,"stopSleeping");}
  String leader=Social.s(tag(n),"npc77_refugio_lider");if(!leader.isBlank()){for(Object other:Social.nearby(n,"mod.cdv.tnpc.entity.AutoGunOperator",32d))if(Social.uuid(other).toString().equals(leader)&&base(other)!=null){point(n,"base",base(other));str(n,"lider",leader);str(n,"nombre",str(other,"nombre"));str(n,"estado","base_compartida");c(tag(n),"putString","npc77_refugio_lider","");break;}if(!Social.s(tag(n),"npc77_refugio_lider").isBlank())return false;}Shelter77.Camp camp=Shelter77.get(n);if(camp!=null&&!camp.phase.equals("descansar"))return false;
  if(!register(n))return false;Job j=JOBS.computeIfAbsent(n,k->new Job());long t=now(n);if(t<j.retry)return false;if(t<j.next){status(n,str(n,"tarea"));return true;}j.next=t+10;
  if(!str(n,"lider").isBlank())return patrol(n,j);if(!kit(n))return false;
  if(j.started>0&&t-j.started>500){reset(n,j,"tarea_sin_progreso_cambiar_plan");return false;}
  if(!ready(n)&&furnish(n,j))return true;if(!ready(n))return patrol(n,j);
  str(n,"estado","base_principal");if(j.type.startsWith("amueblar_")){j.type="";j.target=null;j.started=0;}
  if(j.started>0&&t-j.started>500){reset(n,j,"tarea_sin_progreso_cambiar_plan");return false;}
  if(j.type.equals("madera"))return wood(n,j);if(j.type.equals("piedra")&&j.target!=null)return mine(n,j);
  Object chest=point(n,"chest"),furnace=point(n,"furnace");
  // Return regularly before any new expedition; never leave all loot in the backpack.
  if(t-num(n,"deposito")>600){if(dist(n,chest)>9){Object q=approach(n,chest);if(q!=null&&walk(n,q)){status(n,"volver_a_guardar_pertenencias");return true;}}else{Hunt78.deposit(n,chest);num(n,"deposito",t);look(n,chest);status(n,"guardar_pertenencias_en_cofre");return true;}}
  if(t-num(n,"horno")>400&&dist(n,furnace)<=9){if(count(n,"minecraft:oak_log")==0)retrieve(n,"minecraft:oak_log",4);for(String resource:new String[]{"raw_iron","raw_copper","raw_gold","coal","charcoal","oak_planks","spruce_log","birch_log"})if(count(n,"minecraft:"+resource)==0)retrieve(n,"minecraft:"+resource,4);if(Shelter77.planks(DialogueRules72.bag(n))<2)Shelter77.craft(n,false);num(n,"horno",t);if(refuel(n)){look(n,furnace);status(n,"abastecer_horno");return true;}}
  if(t-num(n,"obra")>100&&stored(n,"cobblestone")>0){num(n,"obra",t);if(improve(n)){status(n,"reforzar_suelo_de_base");return true;}}
  // Bounded stock goals, with failed searches yielding to patrol rather than blocking AI.
  if(t>=num(n,"buscar_madera")&&stored(n,"_log")<16){num(n,"buscar_madera",t+1200);j.target=null;return wood(n,j);}
  if(t>=num(n,"buscar_piedra")&&stored(n,"cobblestone")<24){num(n,"buscar_piedra",t+200);j.type="piedra";j.target=null;if(mine(n,j))return true;j.type="";}
  if(((Number)c(Social.world(n),"getDayTime")).longValue()%24000>=13000&&((Number)c(Social.world(n),"getDayTime")).longValue()%24000<22500){Object bed=point(n,"white_bed");if(dist(n,bed)>6){Object q=approach(n,bed);if(q!=null&&walk(n,q)){status(n,"volver_a_dormir");return true;}}else{c(c(n,"getNavigation"),"stop");c(n,"startSleeping",bed);status(n,"dormir_en_su_base");return true;}}
  if(Social.yes(c(n,"isSleeping")))c(n,"stopSleeping");return patrol(n,j);
 }catch(Exception e){Social.mem(n).occupied=false;str(n,"tarea","base_error_recuperable");Job j=JOBS.computeIfAbsent(n,k->new Job());j.retry=now(n)+200;if(WARN.add(n))Social.warn("base48 (NPC remains active)",e);return false;}}
 public static boolean legacyShelter(Object n){Shelter77.Camp camp=Shelter77.get(n);if(camp!=null&&camp.phase.equals("descansar")&&Shelter77.need(n)==null)return false;return Social.yes(c(Shelter77.class,"workBefore48",n));}
 public static boolean roofWork(Object n){if(base(n)!=null&&Shelter77.need(n)==null)return false;return Shelter47.roofWork(n);}
 public static boolean recover(Object n){Job j=JOBS.get(n);if(j==null||j.escape==null||!safe(n))return false;if(now(n)>=j.escapeUntil||dist(n,j.escape)<1){j.escape=null;return false;}if(!walk(n,j.escape)){j.escape=null;return false;}look(n,j.escape);status(n,"buscar_otro_acceso");return true;}
 static String progress(Object n,Job j){Shelter77.Camp camp=Shelter77.get(n);String s=camp==null?"":camp.index+":"+camp.treeCount+":"+camp.chop;return s+":"+j.progress+":"+num(n,"ultimo_progreso");}
 static void unstick(Object n,Job j){long t=now(n);reset(n,j,"replanificar_por_atasco");Activity78.Roof roof=Activity78.ROOFS.get(n);if(roof!=null){roof.pos=null;roof.retry=t+200;}
  Shelter77.Camp camp=Shelter77.get(n);if(camp!=null&&!camp.phase.equals("descansar")){camp.tree=null;camp.scan=0;camp.fails++;camp.wait=true;camp.next=t+100;if(camp.fails>=3)Shelter77.abandon(n,"cambiar_ubicacion_sin_progreso");}
  Hunt78.Run run=Hunt78.RUNS.get(n);if(run!=null){run.phase="descansar";run.target=null;run.next=t+400;}Mining79.Job mining=Mining79.JOBS.get(n);if(mining!=null){mining.pos=null;mining.next=t+400;}
  CalmBrain.State state=CalmBrain.state(n);if(state.corpse!=null)c(CalmLoot.class,"release",n,state);
  Object origin=c(n,"blockPosition");for(int r:new int[]{2,4,6})for(int[] d:new int[][]{{1,0},{0,1},{-1,0},{0,-1},{1,1},{-1,-1}}){Object p=off(origin,d[0]*r,0,d[1]*r);if(floor(n,p)&&reachable(n,p)&&walk(n,p)){j.escape=p;j.escapeUntil=t+160;return;}}
 }
 static void aid(Object n)throws Exception{if(base(n)==null||Downed20.down(n)||Motion76.conversing(n)||CalmBrain.state(n).target!=null)return;
  for(Object ally:Social.nearby(n,"mod.cdv.tnpc.entity.AutoGunOperator",12d)){if(ally==n||!Social.alive(ally)||base(ally)==null||!same(base(n),base(ally)))continue;Object enemy=c(ally,"getLastHurtByMob");if(enemy==null||enemy==n||CalmBrain.state(ally).target!=enemy||!Social.alive(enemy)||CalmBrain.allied(n,enemy)||!Social.yes(c(n,"hasLineOfSight",enemy)))continue;
   defend(n);if(Social.yes(c(n,"isSleeping")))c(n,"stopSleeping");Social.target(n,enemy);str(n,"tarea","defender_aliado_de_base");return;}
 }
 public static void tick(Object n){try{if(Social.client(n)||!Social.alive(n))return;long t=now(n);if(t%20!=0)return;
  aid(n);if(CalmBrain.state(n).target!=null||Social.mem(n).threats>0){defend(n);if(Social.yes(c(n,"isSleeping")))c(n,"stopSleeping");return;}
  if(safe(n)&&!Social.yes(c(n,"isSleeping"))){Job j=JOBS.computeIfAbsent(n,k->new Job());double x=Social.num(c(n,"getX")),z=Social.num(c(n,"getZ"));String signature=progress(n,j);
   if(j.checked==0||Math.pow(x-j.lastX,2)+Math.pow(z-j.lastZ,2)>.1||!signature.equals(j.signature)||t-num(n,"ultimo_progreso")<60){j.checked=t;j.lastX=x;j.lastZ=z;j.signature=signature;}else if(t-j.checked>240){unstick(n,j);j.checked=t;}}
  if(t%40==0)hud(n);
 }catch(Exception e){if(WARN.add(n))Social.warn("base48 tick",e);}}
 static String display(String s){return s.replace('_',' ');}
 static String info(Object n){Object p=base(n);String name=str(n,"nombre");if(name.isBlank())name=c(c(n,"getName"),"getString").toString();return p==null?name+" | Sin base | "+display(Social.s(tag(n),"npc79_tarea")):"Base de "+name+" | "+key(p)+" | "+display(str(n,"estado"))+" | "+display(str(n,"tarea"));}
 static void hud(Object n){Object p=base(n);for(Object player:Social.nearby(n,"net.minecraft.world.entity.player.Player",24d)){if(Social.yes(c(player,"isSpectator")))continue;boolean inside=p!=null&&dist(player,p)<=64;boolean watching=Social.distance(n,player)<100&&Social.yes(c(player,"hasLineOfSight",n));if(!inside&&!watching)continue;
   // Only the nearest visible NPC owns the contextual action bar.
   boolean closer=false;for(Object other:Social.nearby(player,"mod.cdv.tnpc.entity.AutoGunOperator",16d))if(other!=n&&other!=player&&Social.alive(other)&&Social.distance(player,other)<Social.distance(player,n)){closer=true;break;}if(closer)continue;c(player,"displayClientMessage",c(Social.t("net.minecraft.network.chat.Component"),"literal",(inside?"Zona de base | ":"")+info(n)),true);
  }}
}
