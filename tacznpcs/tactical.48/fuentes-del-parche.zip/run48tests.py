import subprocess,pathlib
classes=[('work/test47classes',n) for n in ['BaseTest48','BaseScheduleTest48','BaseSafetyTest48','RecoveryTest48','SettlementTest48','SurvivalTest47','ScheduleTest47','RouteTest47','MenuTest47']]+[('work/testclasses',n) for n in ['FullFollowTest46','EncounterTest46','Verify82']]
pathlib.Path('work/tests48').mkdir(exist_ok=True)
failed=[]
for folder,name in classes:
 r=subprocess.run(['java','-Xmx256m','-Xverify:all','-cp',folder+':output/tactical.48/tacznpcs-2.1.0-1.21.1-tactical.48-bases-and-purpose.jar:work/gson.jar','mod.cdv.tnpc.tactical.'+name]+(['work/expanded.json'] if name=='Verify82' else []),capture_output=True,text=True)
 pathlib.Path('work/tests48/'+name+'.txt').write_text(r.stdout+r.stderr)
 print(name,r.returncode,(r.stdout+r.stderr)[-180:])
 if r.returncode:failed.append(name)
assert not failed,failed
