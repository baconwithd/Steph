#!/usr/bin/env bash
set -euo pipefail
npc_base=${1:?Usage: bash build49.sh tactical44.jar remains27.jar gore43.jar}
remains_base=${2:?Missing remains27.jar}
gore_base=${3:?Missing gore43.jar}
mkdir -p work/classes output
python3 - "$npc_base" "$remains_base" "$gore_base" <<'PY'
import zipfile,shutil,sys
for directory,source in zip(['work/jar','work/remains28','work/gore44'],sys.argv[1:]):
 shutil.rmtree(directory,ignore_errors=True)
 zipfile.ZipFile(source).extractall(directory)
PY
for spec in 'org/eclipse/jdt/ecj/3.38.0/ecj-3.38.0.jar ecj' 'com/google/code/gson/gson/2.10.1/gson-2.10.1.jar gson' 'org/ow2/asm/asm/9.7/asm-9.7.jar asm' 'org/ow2/asm/asm-tree/9.7/asm-tree-9.7.jar asm-tree'; do
 read -r maven_path artifact_name <<< "$spec"
 if [ ! -s "work/$artifact_name.jar" ]; then curl -fsSL "https://repo.maven.apache.org/maven2/$maven_path" -o "work/$artifact_name.jar"; fi
done
python3 expand.py
python3 openings46.py
java -jar work/ecj.jar -21 -proc:none -cp work/jar:work/gson.jar:work/asm.jar:work/asm-tree.jar -d work/classes Patch.java Compat49Patch.java patch/mod/cdv/tnpc/tactical/{Immersion82,Encounters47,Shelter47,Routes47,Base48,Dialogue49,Decor49}.java
java -jar work/ecj.jar -21 -proc:none -cp work/remains28 -d work/classes patch/dev/zomboid/remains/expand/Validity28.java
java -jar work/ecj.jar -21 -proc:none -cp work/gore44 -d work/classes patch/dev/zomboid/gore/Clone44.java
java -cp work/classes:work/asm.jar:work/asm-tree.jar Patch work/jar
java -cp work/classes:work/asm.jar:work/asm-tree.jar Compat49Patch work/remains28 remains
java -cp work/classes:work/asm.jar:work/asm-tree.jar Compat49Patch work/gore44 gore
cp work/classes/mod/cdv/tnpc/tactical/{Immersion82,Encounters47,Shelter47,Routes47,Routes47\$Route,Base48,Base48\$Job,Dialogue49,Decor49}.class work/jar/mod/cdv/tnpc/tactical/
cp work/classes/dev/zomboid/remains/expand/Validity28.class work/remains28/dev/zomboid/remains/expand/
cp work/classes/dev/zomboid/gore/Clone44.class work/gore44/dev/zomboid/gore/
cp recipes49.json work/jar/data/tacznpcs/dialogue/decor49-recipes.json
python3 - <<'PY'
import shutil
shutil.rmtree('work/jar49',ignore_errors=True)
shutil.copytree('work/jar','work/jar49')
PY
python3 package49.py
