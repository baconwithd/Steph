import java.nio.file.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public class Patch implements Opcodes{
 static String P="mod/cdv/tnpc/tactical/",H=P+"Immersion82";
 static MethodInsnNode call(String name,String desc){return new MethodInsnNode(INVOKESTATIC,H,name,desc,false);}
 static void hook(MethodNode m,AbstractInsnNode at,String name,String desc,int... locals){InsnList s=new InsnList();for(int v:locals)s.add(new VarInsnNode(ALOAD,v));s.add(call(name,desc));m.instructions.insertBefore(at,s);}
 static MethodNode forward(String name,String desc,String owner,String target){MethodNode m=new MethodNode(ACC_PUBLIC|ACC_STATIC,name,desc,null,null);int v=0;for(Type t:Type.getArgumentTypes(desc)){m.instructions.add(new VarInsnNode(t.getOpcode(ILOAD),v));v+=t.getSize();}m.instructions.add(new MethodInsnNode(INVOKESTATIC,owner,target,desc,false));m.instructions.add(new InsnNode(Type.getReturnType(desc).getOpcode(IRETURN)));return m;}
 static void body(MethodNode m,String owner,String target){MethodNode replacement=forward(m.name,m.desc,owner,target);m.instructions=replacement.instructions;m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();}
 static void guard(MethodNode m){InsnList s=new InsnList();LabelNode l=new LabelNode();s.add(new VarInsnNode(ALOAD,0));s.add(call("silent","(Ljava/lang/Object;)Z"));s.add(new JumpInsnNode(IFEQ,l));if(Type.getReturnType(m.desc).getSort()==Type.VOID)s.add(new InsnNode(RETURN));else {s.add(new InsnNode(ICONST_0));s.add(new InsnNode(IRETURN));}s.add(l);s.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(s);}
 public static void main(String[] args)throws Exception{
  Path root=Path.of(args[0]);int changed=0;
  try(var paths=Files.walk(root)){for(Path f:paths.filter(p->p.toString().endsWith(".class")).toList()){
   ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(f)).accept(c,0);boolean edit=false;
   String simple=c.name.substring(c.name.lastIndexOf('/')+1);
   for(MethodNode m:new ArrayList<MethodNode>(c.methods)){
    if(c.name.startsWith(P)&&!simple.equals("Motion76"))for(AbstractInsnNode a:m.instructions.toArray())if(a instanceof MethodInsnNode i&&i.owner.equals(P+"Motion76")&&i.name.equals("conversing")){i.owner=H;edit=true;}
    if(Set.of("Authority70","Chat71","Gate74","Free75").contains(simple))for(AbstractInsnNode a:m.instructions.toArray())if(a instanceof MethodInsnNode i){
     if(i.owner.equals(P+"Gate74")&&i.name.equals("weaponBreak")){i.owner=H;edit=true;}
     if(i.owner.equals(c.name)&&i.name.equals("c")&&i.desc.equals("(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")){i.owner=H;i.name="call";edit=true;}
     if(simple.equals("Gate74")&&m.name.equals("reject")&&i.owner.equals(P+"Chat71")&&i.name.equals("armed")){m.instructions.insertBefore(i,new VarInsnNode(ALOAD,0));i.owner=H;i.name="armed";i.desc="(Ljava/lang/Object;Ljava/lang/Object;)Z";edit=true;}
    }
    if(simple.equals("Navigation78")&&m.name.equals("go")){String desc=m.desc;m.name="goBase47";c.methods.add(forward("go",desc,P+"Routes47","go"));edit=true;}
    if(simple.equals("Navigation78")&&m.name.equals("tick")){body(m,P+"Routes47","tick");edit=true;}
    if(simple.equals("Shelter77")&&m.name.equals("work")){String desc=m.desc;m.name="workBefore48";c.methods.add(forward("work",desc,P+"Base48","legacyShelter"));edit=true;}
    if(simple.equals("AutoGunOperator")&&m.name.equals("onTickServerSide")){InsnList s=new InsnList();s.add(new VarInsnNode(ALOAD,0));s.add(new MethodInsnNode(INVOKESTATIC,P+"Base48","tick","(Ljava/lang/Object;)V",false));m.instructions.insert(s);edit=true;}
    if(simple.equals("Shelter77")&&m.name.equals("move")){body(m,P+"Shelter47","move");edit=true;}
    if(simple.equals("Shelter77")&&m.name.equals("tick")){body(m,P+"Shelter47","tick");edit=true;}
    if(simple.equals("Shelter77")&&m.name.equals("exposed")){body(m,P+"Shelter47","exposed");edit=true;}
    if(simple.equals("Activity78")&&m.name.equals("roofWork")){body(m,P+"Base48","roofWork");edit=true;}
    if(simple.equals("Activity78")&&m.name.equals("cover")){body(m,P+"Shelter47","cover");edit=true;}
    if(simple.equals("Shelter77")&&m.name.equals("gather")){String desc=m.desc;m.name="gatherBase47";c.methods.add(forward("gather",desc,P+"Shelter47","gather"));edit=true;}
    if(simple.equals("Shelter77")&&m.name.equals("num"))for(AbstractInsnNode a:m.instructions.toArray())if(a.getOpcode()==IRETURN){m.instructions.insertBefore(a,new VarInsnNode(ALOAD,0));m.instructions.insertBefore(a,new MethodInsnNode(INVOKESTATIC,P+"Shelter47","number","(ILjava/lang/String;)I",false));edit=true;}
    if(simple.equals("Life79")&&m.name.equals("work"))for(String helper:new String[]{"Base48","Shelter47","Routes47"}){InsnList s=new InsnList();LabelNode l=new LabelNode();s.add(new VarInsnNode(ALOAD,0));s.add(new MethodInsnNode(INVOKESTATIC,P+helper,helper.equals("Shelter47")?"priority":"work","(Ljava/lang/Object;)Z",false));s.add(new JumpInsnNode(IFEQ,l));s.add(new InsnNode(ICONST_1));s.add(new InsnNode(IRETURN));s.add(l);s.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(s);edit=true;}
    if(simple.equals("AutoGunOperator")&&m.name.equals("onTickServerSide")){InsnList s=new InsnList();s.add(new VarInsnNode(ALOAD,0));s.add(new MethodInsnNode(INVOKESTATIC,P+"Encounters47","tick","(Ljava/lang/Object;)V",false));m.instructions.insert(s);edit=true;}
    if(simple.equals("AutoGunOperator")&&m.name.equals("onTickServerSide")){InsnList s=new InsnList();s.add(new VarInsnNode(ALOAD,0));s.add(call("active46","(Ljava/lang/Object;)V"));m.instructions.insert(s);edit=true;}
    if(simple.equals("Chat71")&&m.name.equals("open"))for(AbstractInsnNode a:m.instructions.toArray())if(a instanceof LdcInsnNode l&&"familiar_enfermo".equals(l.cst)){l.cst="encuentro";edit=true;}
    if(simple.equals("Free75")&&m.name.equals("closing")){InsnList s=new InsnList();s.add(new VarInsnNode(ALOAD,0));s.add(new VarInsnNode(ALOAD,2));s.add(new MethodInsnNode(INVOKESTATIC,P+"Dialogue49","interrupted","(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;",false));s.add(new VarInsnNode(ASTORE,2));m.instructions.insert(s);edit=true;}
    if(simple.equals("Chat71")&&Set.of("start","pump").contains(m.name)){body(m,P+"Dialogue49",m.name);edit=true;}
    if(simple.equals("Authority70")&&m.name.equals("busy")){for(AbstractInsnNode a:m.instructions.toArray())if(a.getOpcode()==IRETURN){hook(m,a,"busy","(ZLjava/lang/Object;)Z",0);edit=true;}}
    if(simple.equals("DialogueRules72")&&m.name.equals("format")){for(AbstractInsnNode a:m.instructions.toArray())if(a.getOpcode()==ARETURN){hook(m,a,"line","(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;L"+P+"Chat71$State;)Ljava/lang/String;",1,2,3);edit=true;}}
    if(simple.equals("Free75")&&m.name.equals("lines")){for(AbstractInsnNode a:m.instructions.toArray())if(a.getOpcode()==ARETURN){hook(m,a,"variants","(Lcom/google/gson/JsonArray;Ljava/lang/Object;Ljava/lang/Object;L"+P+"Chat71$State;Lcom/google/gson/JsonObject;)Lcom/google/gson/JsonArray;",0,1,2,3);edit=true;}}
    if(simple.equals("Data73")&&Set.of("load","normalize").contains(m.name)){for(AbstractInsnNode a:m.instructions.toArray())if(a.getOpcode()==ARETURN){hook(m,a,"augment","(Lcom/google/gson/JsonObject;)Lcom/google/gson/JsonObject;");edit=true;}}
    if(simple.equals("Social")&&m.name.equals("death")){InsnList s=new InsnList();s.add(new VarInsnNode(ALOAD,0));s.add(call("dying","(Ljava/lang/Object;)V"));m.instructions.insert(s);edit=true;}
    if((simple.equals("Expression20")&&Set.of("react","chat").contains(m.name))||(simple.equals("SpeechSounds20")&&m.name.equals("play"))){guard(m);edit=true;}
    if(simple.equals("Sense28")&&m.name.equals("emit"))for(AbstractInsnNode a:m.instructions.toArray())if(a instanceof MethodInsnNode i&&i.owner.equals(P+"Social")&&i.name.equals("pause")){i.owner=H;i.name="hearingPaused";edit=true;}
    if(simple.equals("Sense28")&&m.name.equals("hear")){for(AbstractInsnNode a:m.instructions.toArray())if(a.getOpcode()==RETURN){hook(m,a,"heard","(Ljava/lang/Object;)V",0);edit=true;}}
    if(simple.equals("Life79")&&m.name.equals("tick")){for(AbstractInsnNode a:m.instructions.toArray())if(a.getOpcode()==RETURN){hook(m,a,"investigate","(Ljava/lang/Object;)V",0);edit=true;}}
    if(simple.equals("Ambient78")&&m.name.equals("eligible")){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(call("ambientEligible",m.desc));m.instructions.add(new InsnNode(IRETURN));edit=true;}
    if(simple.equals("Ambient78")&&m.name.equals("tick"))for(AbstractInsnNode a:m.instructions.toArray())if(a instanceof MethodInsnNode i&&i.owner.equals(P+"Social")&&i.name.equals("kind")){i.owner=H;i.name="ambientKind";edit=true;}
    if(simple.equals("Life79")&&m.name.equals("work")){InsnList s=new InsnList();LabelNode l=new LabelNode();s.add(new VarInsnNode(ALOAD,0));s.add(call("soundWork","(Ljava/lang/Object;)Z"));s.add(new JumpInsnNode(IFEQ,l));s.add(new InsnNode(ICONST_1));s.add(new InsnNode(IRETURN));s.add(l);s.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(s);edit=true;}
    if(simple.equals("Life79")&&m.name.equals("work")){InsnList s=new InsnList();LabelNode l=new LabelNode();s.add(new VarInsnNode(ALOAD,0));s.add(new MethodInsnNode(INVOKESTATIC,P+"Base48","recover","(Ljava/lang/Object;)Z",false));s.add(new JumpInsnNode(IFEQ,l));s.add(new InsnNode(ICONST_1));s.add(new InsnNode(IRETURN));s.add(l);s.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(s);edit=true;}
    if(simple.equals("Threat27")&&m.name.equals("allowed")){m.name="baseAllowed82";edit=true;}
    if(simple.equals("AutoGunOperator")&&m.name.equals("<clinit>")){for(AbstractInsnNode a:m.instructions.toArray())if(a instanceof LdcInsnNode l&&Float.valueOf(.75f).equals(l.cst)){l.cst=.6f;edit=true;}}
   }
   if(simple.equals("Threat27")){MethodNode m=new MethodNode(ACC_PUBLIC|ACC_STATIC,"allowed","(Ljava/lang/Object;Ljava/lang/Object;)Z",null,null);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(call("hostileAllowed",m.desc));m.instructions.add(new InsnNode(IRETURN));c.methods.add(m);edit=true;}
   if(edit){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(f,w.toByteArray());System.out.println(c.name);changed++;}
  }}System.out.println("Patched classes: "+changed);
 }
}
