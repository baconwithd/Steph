from pathlib import Path
import zipfile,re,hashlib,json
out=Path('output/paquete49');out.mkdir(parents=True,exist_ok=True)
items=[('work/jar49','tacznpcs-2.1.0-1.21.1-tactical.49-decor-dialogue.jar','2.1.0-tactical.49-decor-dialogue'),('work/remains28','zombie-remains-loot-1.6.1-neoforge-1.21.1-useful-loot.28-safe-corpses.jar','1.6.1-useful-loot28-safe-corpses'),('work/gore44','zomboid-zombie-gore-1.0.20-neoforge-1.21.1-direct-lethal-damage.44-no-ghost-clones.jar','1.0.20.69')]
results=[]
for directory,name,version in items:
 root=Path(directory);p=root/'META-INF/neoforge.mods.toml';s=p.read_text();s=re.sub(r'^version="[^"]+"',f'version="{version}"',s,count=1,flags=re.M)
 if directory.endswith('gore44'):s=s.replace('Gore .43','Gore .44')
 if directory.endswith('remains28'):s=s.replace('Breaking a corpse destroys its contents and drops flesh.','Protected ordinary hits and safe corpse-menu validity.')
 p.write_text(s)
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(root))
 with zipfile.ZipFile(out/name) as z:
  assert z.testzip() is None
  assert not any('Sim47' in p or 'Test49' in p or 'Test48' in p for p in z.namelist())
 results.append({'name':name,'bytes':(out/name).stat().st_size,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()})
(out/'NOTAS.txt').write_text((Path('work/NOTAS49.txt') if Path('work/NOTAS49.txt').exists() else Path('NOTAS49.txt')).read_text()+'\nSHA-256:\n'+'\n'.join(r['name']+' '+r['sha256'] for r in results)+'\n')
(out/'SHA256.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results))
