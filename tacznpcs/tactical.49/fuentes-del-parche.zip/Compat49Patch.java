import java.nio.file.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Compat49Patch implements Opcodes {
 static void replace(MethodNode m,String owner,String name,String desc){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();int v=0;for(Type t:Type.getArgumentTypes(m.desc)){m.instructions.add(new VarInsnNode(t.getOpcode(ILOAD),v));v+=t.getSize();}m.instructions.add(new MethodInsnNode(INVOKESTATIC,owner,name,desc,false));m.instructions.add(new InsnNode(Type.getReturnType(m.desc).getOpcode(IRETURN)));}
 public static void main(String[] args)throws Exception{Path root=Path.of(args[0]);String mode=args[1];try(var stream=Files.walk(root)){for(Path p:stream.filter(f->f.toString().endsWith(".class")).toList()){ClassNode cls=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(cls,0);boolean edit=false;
 for(MethodNode m:cls.methods){if(mode.equals("remains")&&cls.name.equals("dev/zomboid/remains/expand/ExpandedBodies")&&m.name.equals("valid")){replace(m,"dev/zomboid/remains/expand/Validity28","valid",m.desc);edit=true;}
 if(mode.equals("remains")&&cls.name.equals("dev/zomboid/remains/ZombieRemainsLoot")&&m.name.equals("hitCorpse")){replace(m,"dev/zomboid/remains/expand/Validity28","hit","(Ljava/lang/Object;)V");edit=true;}
 if(mode.equals("remains")&&cls.name.equals("dev/zomboid/remains/CorpseIntegration")&&m.name.equals("attack")){replace(m,"dev/zomboid/remains/expand/Validity28","attack","(Ljava/lang/Object;)V");edit=true;}
 if(mode.equals("gore")&&cls.name.equals("dev/zomboid/gore/Linked45")&&m.name.equals("hide")){replace(m,"dev/zomboid/gore/Clone44","hide",m.desc);edit=true;}
 if(mode.equals("gore")&&cls.name.equals("dev/zomboid/gore/CorpseChoice51")&&m.name.equals("skipDeath")){m.name="skipDeathBefore44";edit=true;}}
 if(mode.equals("gore")&&cls.name.equals("dev/zomboid/gore/CorpseChoice51")){MethodNode method=new MethodNode(ACC_PUBLIC|ACC_STATIC,"skipDeath","(Ljava/lang/Object;)Z",null,null);method.instructions.add(new VarInsnNode(ALOAD,0));method.instructions.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/gore/Clone44","skipDeath",method.desc,false));method.instructions.add(new InsnNode(IRETURN));cls.methods.add(method);edit=true;}
 if(edit){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);cls.accept(w);Files.write(p,w.toByteArray());System.out.println(cls.name);}
 }}}
}
