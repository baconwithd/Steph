import subprocess,pathlib
classes=[('work/test47classes',n) for n in ['DecorTest49','DecorScheduleTest49','DialogueTest49','BaseTest48','BaseScheduleTest48','BaseSafetyTest48','RecoveryTest48','SettlementTest48','SurvivalTest47','ScheduleTest47','RouteTest47','MenuTest47']]+[('work/testclasses',n) for n in ['FullFollowTest46','EncounterTest46','Verify82']]
pathlib.Path('work/tests49').mkdir(exist_ok=True)
failed=[]
for folder,name in classes:
 r=subprocess.run(['java','-Xmx256m','-Xverify:all','-cp',folder+':output/paquete49/tacznpcs-2.1.0-1.21.1-tactical.49-decor-dialogue.jar:work/gson.jar','mod.cdv.tnpc.tactical.'+name]+(['work/expanded.json'] if name=='Verify82' else []),capture_output=True,text=True)
 pathlib.Path('work/tests49/'+name+'.txt').write_text(r.stdout+r.stderr)
 print(name,r.returncode,(r.stdout+r.stderr)[-180:])
 if r.returncode:failed.append(name)
for name,cp,main in [('ValidityTest28','work/test49classes:work/test47classes:output/paquete49/zombie-remains-loot-1.6.1-neoforge-1.21.1-useful-loot.28-safe-corpses.jar:output/paquete49/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-direct-lethal-damage.44-no-ghost-clones.jar:work/gson.jar','dev.zomboid.remains.expand.ValidityTest28'),('CloneTest44','work/test49classes:output/paquete49/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-direct-lethal-damage.44-no-ghost-clones.jar','dev.zomboid.gore.CloneTest44')]:
 r=subprocess.run(['java','-Xmx256m','-Xverify:all','-cp',cp,main],capture_output=True,text=True)
 pathlib.Path('work/tests49/'+name+'.txt').write_text(r.stdout+r.stderr)
 print(name,r.returncode,(r.stdout+r.stderr)[-180:])
 if r.returncode:failed.append(name)
assert not failed,failed
