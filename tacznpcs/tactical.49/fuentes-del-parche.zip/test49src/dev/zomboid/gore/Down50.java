package dev.zomboid.gore;public class Down50 {public static boolean skipDeath(Object e){return false;}}
