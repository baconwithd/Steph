package dev.zomboid.gore;
import com.raiiiden.ragdollified.client.ClientRagdollManager;import com.raiiiden.ragdollified.server.ServerRagdollSyncManager;
public class CloneTest44 {
 public static class World {public Object dimension(){return "overworld";}}
 public static class Body {int id;boolean alive;Body(int i){id=i;}public int getId(){return id;}public boolean isAlive(){return alive;}public World level(){return new World();}}
 public static class Retained {public Object dimension="overworld";}
 public static void main(String[] args){Body corpse=new Body(3);ClientRagdollManager.active=false;if(Linked45.hide(corpse))throw new AssertionError("hides unlinked corpse");ClientRagdollManager.active=true;if(!Linked45.hide(corpse))throw new AssertionError("doesn't hide vanilla clone while ragdoll present");ClientRagdollManager.active=false;if(!Linked45.hide(corpse))throw new AssertionError("vanilla ghost reappears after gore removes ragdoll");
  Body source=new Body(5);if(CorpseChoice51.skipDeath(source))throw new AssertionError("prevents first body");ServerRagdollSyncManager.RETAINED.put(5,new Retained());if(!CorpseChoice51.skipDeath(source))throw new AssertionError("repeated death can create duplicate");Body owner=new Body(8);Linked45.ACTIVE.set(owner);if(CorpseChoice51.skipDeath(source))throw new AssertionError("source id suppresses linked corpse's own id");ServerRagdollSyncManager.RETAINED.put(8,new Retained());if(!CorpseChoice51.skipDeath(source))throw new AssertionError("repeated linked owner allowed");Linked45.ACTIVE.remove();
  System.out.println("PASS: actual Linked45.hide preserves plain corpse fallback until ragdoll exists, then prevents reappearing vanilla clone after gore; actual death guard allows first/source-to-owner spawn but blocks repeated retained body in same dimension");
 }
}
