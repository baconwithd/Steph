package dev.zomboid.remains.expand;
import java.util.*;import java.lang.reflect.*;
public class ValidityTest28 {
 public static class Vec {public double distanceToSqr(Object other){return 1;}}
 public static class World {public boolean hasChunkAt(Object pos){return true;}public String getBlockState(Object p){return "corpse";}}
 public static class Marker {boolean removed;public boolean isRemoved(){return removed;}public Object position(){return new Vec();}}
 public static class Player {Object world;Player(Object w){world=w;}public Object level(){return world;}public boolean isAlive(){return true;}public boolean isSpectator(){return false;}public Object position(){return new Vec();}public double distanceToSqr(double x,double y,double z){return 1;}}
 public static class Pos {public long asLong(){return 1L;}public int getX(){return 0;}public int getY(){return 0;}public int getZ(){return 0;}}
 public static class Corpse {public boolean skeleton;public String block="corpse";}
 public static class Data {public Map<Long,Object> corpses=new HashMap<>();}
 public static class Event {boolean cancel;String state;Event(String s){state=s;}public Object getLevel(){return new World(){public String getBlockState(Object p){return state;}};}public Object getPos(){return new Pos();}public void setCanceled(boolean b){cancel=b;}}
 public static class Attack{Object target;boolean cancelled;Attack(Object t){target=t;}public Object getTarget(){return target;}public void setCanceled(boolean c){cancelled=c;}}
 public static void main(String[] args)throws Exception{World w=new World();Player p=new Player(w);Object corpse=new Corpse();Class<?> bodyType=Class.forName("dev.zomboid.remains.BodyLoot16$Body");Constructor<?> ctor=bodyType.getDeclaredConstructor(Object.class,Object.class,Object.class,Object.class,int.class,long.class);ctor.setAccessible(true);Marker marker=new Marker();Object body=ctor.newInstance(w,marker,corpse,null,17,0L);
  Class<?> bodyLoot=Class.forName("dev.zomboid.remains.BodyLoot16");Field owners=bodyLoot.getDeclaredField("OWNERS");owners.setAccessible(true);Map<Object,Object> map=(Map<Object,Object>)owners.get(null);map.put(corpse,body);
  if(!ExpandedBodies.valid(corpse,body,new Pos(),w,p))throw new AssertionError("live ragdoll menu invalid");map.remove(corpse);if(ExpandedBodies.valid(corpse,body,new Pos(),w,p))throw new AssertionError("removed ragdoll menu remained open");
  Data data=new Data();data.corpses.put(1L,corpse);if(!ExpandedBodies.valid(corpse,data,new Pos(),w,p))throw new AssertionError("block corpse loot failed");data.corpses.remove(1L);if(ExpandedBodies.valid(corpse,data,new Pos(),w,p))throw new AssertionError("deleted block corpse valid");
  Event hit=new Event("corpse");Validity28.hit(hit);if(!hit.cancel)throw new AssertionError("ordinary corpse hit not cancelled");Event normal=new Event("stone");Validity28.hit(normal);if(normal.cancel)throw new AssertionError("ordinary blocks protected");
  Attack corpseHit=new Attack(new de.maxhenkel.corpse.entities.CorpseEntity());Validity28.attack(corpseHit);if(!corpseHit.cancelled)throw new AssertionError("corpse entity ordinary attack not cancelled");Attack otherHit=new Attack(new Object());Validity28.attack(otherHit);if(otherHit.cancelled)throw new AssertionError("protects unrelated entities");
  System.out.println("PASS: actual ExpandedBodies.valid -> valid ragdoll -> OWNERS removal while menu open returns false without corpses-field crash; block corpse validity retained; normal corpse hit cancelled, other blocks unaffected");
 }
}
