package com.raiiiden.ragdollified.server;public class ServerRagdollSyncManager {public static final java.util.Map<Integer,Object> RETAINED=new java.util.HashMap<>();}
