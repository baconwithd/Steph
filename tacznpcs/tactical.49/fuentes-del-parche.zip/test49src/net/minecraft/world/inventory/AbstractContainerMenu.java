package net.minecraft.world.inventory;public class AbstractContainerMenu {public AbstractContainerMenu(MenuType<?> type,int id){}}
