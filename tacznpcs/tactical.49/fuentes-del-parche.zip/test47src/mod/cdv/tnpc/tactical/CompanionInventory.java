package mod.cdv.tnpc.tactical;
/** GUI boundary: no player has the inventory screen open in this simulation. */
public class CompanionInventory {public static boolean active(Object n){return false;}}
