package dev.zomboid.remains.expand;
import java.lang.reflect.*;import java.util.*;
public final class Validity28 {
 static Object c(Object o,String m,Object...a){return FastReflection.call(o,m,a);}static Class<?> t(String s){return FastReflection.type(s);}
 static Object field(Object o,String name){if(o==null)return null;for(Class<?> k=o.getClass();k!=null;k=k.getSuperclass())try{Field f=k.getDeclaredField(name);f.setAccessible(true);return f.get(o);}catch(NoSuchFieldException e){}catch(IllegalAccessException e){return null;}return null;}
 public static boolean valid(Object corpse,Object data,Object pos,Object world,Object player){
  // A ragdoll Body ceases to be in OWNERS when removed while a menu can still be open.
  if(data!=null&&data.getClass().getName().equals("dev.zomboid.remains.BodyLoot16$Body")||Boolean.TRUE.equals(c(t("dev.zomboid.remains.BodyLoot16"),"isBody",corpse)))return Boolean.TRUE.equals(c(t("dev.zomboid.remains.BodyLoot16"),"valid",corpse,player));
  if(Boolean.TRUE.equals(field(corpse,"skeleton")))return false;Object objects=field(data,"corpses");if(!(objects instanceof Map<?,?> map)||pos==null||world==null||player==null)return false;
  if(c(player,"level")!=world||!Boolean.TRUE.equals(c(player,"isAlive"))||Boolean.TRUE.equals(c(player,"isSpectator")))return false;
  if(!Boolean.TRUE.equals(c(world,"hasChunkAt",pos))||map.get(c(pos,"asLong"))!=corpse)return false;
  if(!Objects.equals(c(t("dev.zomboid.remains.ZombieRemainsLoot"),"blockId",c(world,"getBlockState",pos)),field(corpse,"block")))return false;
  return ((Number)c(player,"distanceToSqr",((Number)c(pos,"getX")).doubleValue()+.5,((Number)c(pos,"getY")).doubleValue()+.5,((Number)c(pos,"getZ")).doubleValue()+.5)).doubleValue()<=64;
 }
 public static void attack(Object event){Object target=c(event,"getTarget");for(Class<?> k=target==null?null:target.getClass();k!=null;k=k.getSuperclass())if(k.getName().equals("de.maxhenkel.corpse.entities.CorpseEntity")){c(event,"setCanceled",true);return;}}
 public static void hit(Object event){Object world=c(event,"getLevel"),pos=c(event,"getPos");if(Boolean.TRUE.equals(c(t("dev.zomboid.remains.ZombieRemainsLoot"),"remains",c(world,"getBlockState",pos))))c(event,"setCanceled",true);}
}
