package dev.zomboid.gore;
import java.util.*;
public final class Clone44 {
 static final Map<Object,Boolean> SHOWN=Collections.synchronizedMap(new WeakHashMap<>());
 public static boolean hide(Object corpse){boolean active=R.yes(R.call(R.type("com.raiiiden.ragdollified.client.ClientRagdollManager"),"hasPendingOrActiveRagdoll",Linked45.id(corpse)));if(active){SHOWN.put(corpse,true);R.call(R.type("com.raiiiden.ragdollified.client.ClientRagdollManager"),"setPersistent",Linked45.id(corpse),true);return true;}return SHOWN.containsKey(corpse);}
 public static boolean skipDeath(Object entity){if(R.yes(R.call(CorpseChoice51.class,"skipDeathBefore44",entity)))return true;if(R.yes(R.call(entity,"isAlive")))return false;
  Object owner=Linked45.ACTIVE.get();int id=Linked45.id(owner==null?entity:owner);Object retained=((Map<?,?>)R.get(R.type("com.raiiiden.ragdollified.server.ServerRagdollSyncManager"),"RETAINED")).get(id);
  return retained!=null&&Objects.equals(R.get(retained,"dimension"),R.call(R.call(entity,"level"),"dimension"));
 }
}
