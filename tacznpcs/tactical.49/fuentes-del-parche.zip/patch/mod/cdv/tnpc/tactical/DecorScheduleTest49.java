package mod.cdv.tnpc.tactical;
import java.util.*;
public class DecorScheduleTest49 {
 public static void main(String[] args)throws Exception{Sim47.setup();DecorTest49.World w=new DecorTest49.World();Sim47.Actor n=BaseTest48.resident(w);for(int i=0;i<2000&&!Base48.ready(n);i++)BaseTest48.step(n,1);Sim47.decor=true;n.x=.5;n.z=.5;List<Object> bag=DialogueRules72.copies(DialogueRules72.bag(n));DialogueRules72.insert(bag,new ArrayList<>(List.of(Shelter77.item("minecraft:oak_log",18))),false);CalmLoot.saveBag(n,bag);w.blocks.put(new Sim47.Pos(5,66,0),new Sim47.State("minecraft:glass"));Set<String> tasks=new HashSet<>();
  for(int i=0;i<3500;i++){w.now++;Life79.work(n);n.step();Navigation78.tick(n);Base48.tick(n);tasks.add(Base48.str(n,"tarea"));}
  if(Decor49.point(n,"drawer")==null||Decor49.point(n,"crate")==null||Social.l(Social.tag(n),"npc49_boards")!=1)throw new AssertionError("decoration scheduler stalled: "+n.tag.values+" tasks="+tasks+" pos="+n.x+","+n.z);
  if(!w.getBlockState(new Sim47.Pos(5,66,0)).id.equals("minecraft:glass")||!tasks.contains("reforzar_ventana_con_tablones"))throw new AssertionError("window not protected");
  System.out.println("PASS: actual Life79/Base48 scheduler -> recipe-selected boards -> one protected intact window -> crafted/placed drawer and crate -> usable persistent stores, 3500 simulated ticks");
 }
}
