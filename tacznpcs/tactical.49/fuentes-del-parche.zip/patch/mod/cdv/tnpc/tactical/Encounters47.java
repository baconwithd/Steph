package mod.cdv.tnpc.tactical;
import java.util.*;
import com.google.gson.*;
/** Pointed-weapon encounter: standard signed conversation choices, never raw commands. */
public final class Encounters47 {
 static final Map<Object,Long> NEXT=new WeakHashMap<>();
 static boolean active(Object p){Conversation.Session s=Conversation.SESSIONS.get(p);Chat71.State state=s==null?null:Chat71.state(s);return state!=null&&state.encounter!=null&&state.encounter.get("id").getAsString().equals("apuntar47");}
 static boolean protects(Object n,Object p){Conversation.Session s=Conversation.SESSIONS.get(p);return s!=null&&s.npc==n&&active(p);}
 static JsonArray lines(String... a){JsonArray r=new JsonArray();for(String s:a)r.add(s);return r;}
 static JsonObject response(JsonArray lines,JsonObject effects){JsonObject r=new JsonObject();r.add("lineas_npc",lines);r.add("efectos",effects);r.add("siguiente",JsonNull.INSTANCE);return r;}
 static JsonObject effects(int trust,int fear,int anger,String outcome){JsonObject r=new JsonObject();r.addProperty("confianza",trust);r.addProperty("miedo",fear);r.addProperty("hostilidad",anger);r.addProperty("resultado",outcome);return r;}
 static JsonObject option(String id,String text,int tone,JsonArray lines,JsonObject effects){JsonObject r=new JsonObject();r.addProperty("id",id);r.addProperty("texto",text);r.addProperty("tono",tone);r.addProperty("utilidad",tone==4?"amenaza":"normal");JsonArray a=new JsonArray();a.add(response(lines,effects));r.add("respuestas",a);return r;}
 static JsonObject encounter(Object n,Object p){
  boolean member=Immersion82.owner(n,p),armed=Chat71.armed(n);int fear=Social74.effective(n,p,"miedo"),anger=Social74.effective(n,p,"hostilidad");
  JsonArray opening=member?lines("¿Por qué me estás apuntando? Soy yo.","Dime qué pasa antes de que alguien haga una tontería."):fear>=50||Social.kind(n)==2?lines("N-no dispares. Te estoy viendo…","¿Qué quieres de mí?"):anger>=45||Roles22.hostile(n)?lines("Te veo apuntándome. Baja eso.","Habla ya, antes de que esto termine mal."):lines("¿Qué haces? ¿Por qué me apuntas?","Podemos hablar, pero no muevas el dedo.");
  JsonObject node=new JsonObject();node.addProperty("id","entrada47");node.add("lineas_npc",opening);JsonArray options=new JsonArray();
  boolean refuses=armed&&fear<45&&!member;
  JsonObject extort=effects(-25,25,refuses?30:10,refuses?"ruptura_combate":"tregua");JsonArray reply=refuses?lines("¿Pretendes robarme? Te equivocaste de persona.","¡Se acabó!"):lines(member?"¿Después de todo vas a hacerme esto?":"Está bien… sin disparar.","No quiero morir por lo que llevo.");
  if(!refuses){Object first=null;for(Object item:DialogueRules72.bag(n))if(!DialogueRules72.empty(item)){first=item;break;}if(first!=null){JsonObject transfer=new JsonObject();transfer.addProperty("objeto",DialogueRules72.itemId(first));transfer.addProperty("cantidad",1);extort.add("da_item",transfer);}else reply=lines("No tengo nada que darte.","Baja el arma. No vale la pena.");}
  options.add(option("extorsionar47","Dame lo que llevas. Esto es un robo.",4,reply,extort));
  options.add(option("broma47","Era una broma. No voy a hacerte nada.",1,lines(member?"No me hagas eso. No tiene gracia.":"¿Una broma? Casi haces que alguien dispare.","Baja el arma y dejémoslo aquí."),effects(-5,-10,3,"tregua")));
  options.add(option("bajar47","Voy a bajar el arma. Tranquilo, podemos hablar.",1,lines("Despacio. Eso es.","Ahora sí podemos evitar un malentendido."),effects(2,-15,-5,"tregua")));
  node.add("opciones",options);JsonObject silence=new JsonObject();silence.add("lineas",lines("Te he preguntado qué quieres.",Roles22.hostile(n)?"¡No voy a esperar a que dispares!":"Me aparto. No te acerques."));silence.add("efectos",effects(-5,10,10,Roles22.hostile(n)?"ruptura_combate":"huida"));node.add("reaccion_silencio",silence);
  JsonObject e=new JsonObject();e.addProperty("id","apuntar47");e.addProperty("voz",Chat71.personality(n));e.addProperty("situacion","tension");e.addProperty("peso",1);e.addProperty("inicio","entrada47");e.addProperty("turnos_max",3);e.addProperty("necesidad","aleatoria");JsonArray nodes=new JsonArray();nodes.add(node);e.add("nodos",nodes);return e;
 }
 public static void tick(Object n){try{
  long now=Social.time(n);if(Social.client(n)||now%5!=0||!Social.alive(n)||Downed20.down(n)||!Authority70.enabled(n)||Ambush73.hidden(n)||now<NEXT.getOrDefault(n,0L)||Social.mem(n).threats>0)return;
  for(Object p:Social.nearby(n,"net.minecraft.world.entity.player.Player",12)){
   if(!Social.alive(p)||Social.yes(Social.c(p,"isSpectator"))||!Social.visible(n,p)||!Social.visible(p,n)||!Chat71.armed(p)||!Immersion82.aimed(p,n)||Threat27.recent(n,p,now))continue;
   Conversation.Session current=Conversation.SESSIONS.get(p);if(current!=null){if(current.npc==n&&active(p))return;if(current.npc!=n)return;Authority70.end(n,false,null);}
   if(CalmBrain.state(n).target!=null&&CalmBrain.state(n).target!=p)return;
   NEXT.put(n,now+600);JsonObject e=encounter(n,p);Conversation.Session session=new Conversation.Session(n,now+500);Conversation.SESSIONS.put(p,session);
   Chat71.State state=new Chat71.State(Chat71.random(),Chat71.personality(n),"entrada47");state.encounter=e;state.intimidation=true;state.entryDistance=Math.sqrt(Social.distance(n,p));Chat71.state(session,state);
   Authority70.sent(n,p);Chat71.start(n,p,state,e.getAsJsonArray("nodos").get(0).getAsJsonObject().getAsJsonArray("lineas_npc"),null);return;
  }
 }catch(Exception e){Social.warn("pointed weapon encounter47",e);}}
}
