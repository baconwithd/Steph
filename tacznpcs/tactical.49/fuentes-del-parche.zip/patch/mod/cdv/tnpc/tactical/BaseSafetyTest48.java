package mod.cdv.tnpc.tactical;
public class BaseSafetyTest48 {
 public static void main(String[] args){Sim47.setup();Sim47.World w=new Sim47.World();Sim47.Actor n=BaseTest48.resident(w);Base48.register(n);Base48.kit(n);Object p=new Sim47.Pos(3,65,2);w.allowPlace=false;
  if(Base48.place(n,p,"minecraft:white_bed")||!w.getBlockState((Sim47.Pos)p).isAir()||!w.getBlockState((Sim47.Pos)Base48.off(p,0,0,1)).isAir()||Base48.count(n,"minecraft:white_bed")!=1)throw new AssertionError("cancelled bed placement leaked blocks or consumed kit");
  w.allowPlace=true;Sim47.Actor ally=new Sim47.Actor(w);Navigation78.INIT.add(ally);ally.tag.putInt("soc_kind",1);Hunt78.home(ally,new Sim47.Pos(0,65,0));if(!Base48.register(ally)||Base48.str(ally,"lider").isBlank())throw new AssertionError("allied base not shared");Base48.work(ally);if(Base48.yes(ally,"kit"))throw new AssertionError("shared resident created another furniture kit");
  if(Base48.connected(n,Base48.base(n),java.util.Set.of("0,65,-2")))throw new AssertionError("allows sealing only exit");
  Sim47.World night=new Sim47.World();Sim47.Actor asleep=BaseTest48.resident(night);night.now=15000;asleep.sleeping=true;if(!Base48.work(asleep)||!asleep.sleeping)throw new AssertionError("sleep not preserved");night.now=24001;Base48.work(asleep);if(asleep.sleeping)throw new AssertionError("doesn't wake in daytime");
  System.out.println("PASS: cancelled bed placement rolls back both halves/inventory; shared base gets one kit; only exit stays open; finite sleep/wake cycle");
 }
}
