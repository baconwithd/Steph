package mod.cdv.tnpc.tactical;
import com.google.gson.*;import java.util.*;import java.lang.ref.WeakReference;
/** A turn's selected lines must survive the cross-turn repetition history. */
public final class Dialogue49 {
 static final Map<Chat71.State,List<String>> INTERRUPTED=new WeakHashMap<>();
 public static String interrupted(Object n,String reason){Object p=Authority70.state(n).player.get();Conversation.Session session=p==null?null:Conversation.SESSIONS.get(p);Chat71.State s=session==null?null:Chat71.state(session);
  if(s!=null&&s.pendingOutcome==null&&Free75.free(s)&&Chat71.ui("ended").equals(reason)&&Authority70.danger(n,p)&&Social.alive(n)&&Social.alive(p)&&Social.world(n)==Social.world(p)){
   INTERRUPTED.put(s,new ArrayList<>(s.queue));Free75.remember(n,p,s);Free75.PAUSED.put(p,new Free75.Pause(new WeakReference<>(n),s,Social.time(n)+DialogueData71.config("reanudar_ticks")));System.out.println("[TacZ NPC dialogue] paused-danger; queued lines="+s.queue.size());return Chat71.ui("pause_idle");
  }return reason;
 }
 public static void start(Object n,Object p,Chat71.State s,JsonArray lines,String outcome){
  List<String> saved=INTERRUPTED.remove(s);if(saved!=null&&!saved.isEmpty()){lines=new JsonArray();for(String text:saved)lines.add(text);}else lines=Immersion82.opening(n,p,s,lines,outcome);Chat71.invalidate(p,s);s.queue.clear();s.pendingOutcome=outcome;s.speaking=true;s.turns=Math.min(0x7ffffffe,s.turns+1);
  for(JsonElement line:lines){String text=DialogueRules72.format(line.getAsString(),n,p,s);if(!text.isBlank())s.queue.add(text);}
  if(s.restoreContext&&s.queue.isEmpty()&&outcome==null)for(JsonElement line:DialogueRules72.node(s).getAsJsonArray("lineas_npc")){String text=DialogueRules72.format(line.getAsString(),n,p,s);if(!text.isBlank())s.queue.add(text);}s.restoreContext=false;
  if(s.emotionChoice!=null){Emotion77.message(n,p,s,s.emotionChoice);s.emotionChoice=null;}if(s.turns==1){Gate74.recognition(n,p,s);Emotion77.opening(n,p,s);}
  s.nextLine=Social.time(n)+(s.turns>1?Feedback77.pause():0);Conversation.Session session=Conversation.SESSIONS.get(p);if(session==null||session.npc!=n){s.speaking=false;s.queue.clear();return;}
  Chat71.holdDeadline(n,session,Social.time(n)+Math.max(1,s.queue.size())*Math.max(30,DialogueData71.config("pausa_lineas_ticks"))+Feedback77.pause()*2+Gate74.responseTicks());pump(n,p,s);
 }
 public static void pump(Object n,Object p,Chat71.State s){if(!s.speaking||Social.time(n)<s.nextLine)return;
  if(!s.queue.isEmpty()){String text=s.queue.peekFirst();Continuity78.heard(n,p,s,text);Feedback77.openBlock(p,s);Flow73.say(n,p,s,text);s.queue.removeFirst();s.seen.add(Chat71.seenKey(text));s.nextLine=Social.time(n)+Math.max(30,DialogueData71.config("pausa_lineas_ticks"));return;}
  s.speaking=false;Reputation76.finished(n,p,s);if(s.pendingOutcome!=null){Feedback77.closeBlock(p,s);Chat71.outcome(n,p,s.pendingOutcome);}else Chat71.show(n,p,s,true);
 }
}
