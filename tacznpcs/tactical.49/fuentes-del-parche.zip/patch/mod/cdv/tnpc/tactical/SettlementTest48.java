package mod.cdv.tnpc.tactical;
public class SettlementTest48 {
 public static void main(String[] args){Sim47.setup();Sim47.World w=new Sim47.World();Sim47.Actor n=new Sim47.Actor(w);Navigation78.INIT.add(n);n.tag.putInt("soc_kind",1);n.tag.putLong("npc79_asentarse",500);
  for(int x:new int[]{-9,-6,-3,3,6,9})for(int z:new int[]{-8,8}){for(int y=65;y<69;y++)w.blocks.put(new Sim47.Pos(x,y,z),new Sim47.State("minecraft:oak_log"));w.blocks.put(new Sim47.Pos(x,69,z),new Sim47.State("minecraft:oak_leaves"));}
  for(int x=-12;x<=12;x++)for(int z:new int[]{-11,11})w.blocks.put(new Sim47.Pos(x,65,z),new Sim47.State("minecraft:stone"));
  for(int i=0;i<15000;i++){w.now++;Shelter77.tick(n);Life79.work(n);n.step();Navigation78.tick(n);Base48.tick(n);}
  Shelter77.Camp camp=Shelter77.get(n);if(camp==null||camp.size!=4||!camp.phase.equals("descansar")||!Base48.ready(n)||Base48.num(n,"mejoras")<1)throw new AssertionError("settlement not complete "+n.tag.values+" camp="+(camp==null?null:camp.index)+" pos="+n.x+","+n.z);
  System.out.println("PASS: empty inventory/outdoors -> full 4x4 shelter -> all furniture and primary base -> stone improvements, via real Shelter77/Life79 scheduler, 15000 simulated ticks");
 }
}
