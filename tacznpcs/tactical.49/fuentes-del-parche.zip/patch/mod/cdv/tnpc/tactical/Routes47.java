package mod.cdv.tnpc.tactical;
import java.util.*;
/** Physical stuck recovery. No teleports: side steps, alternate route, then timed block breaking. */
public final class Routes47 {
 static Object c(Object o,String m,Object... a){return Social.c(o,m,a);}
 static final Map<Object,Route> ROUTES=new WeakHashMap<>();
 static final class Route {double gx,gy,gz,speed=1,x,z,bestGoal=Double.POSITIVE_INFINITY;int sideAttempts;long checked,stuck,alternateAt,manualUntil,lastBreak,lastTick=-1,detourUntil;double mx,my,mz;Object breaking;String block="";int progress,duration;boolean requested;}
 static double coord(Object n,String axis){return Social.num(c(n,"get"+axis));}
 public static boolean go(Object n,double x,double y,double z,double speed){
  Route r=ROUTES.computeIfAbsent(n,k->new Route());boolean changed=!r.requested||Math.abs(r.gx-x)+Math.abs(r.gy-y)+Math.abs(r.gz-z)>2;
  r.gx=x;r.gy=y;r.gz=z;r.speed=speed;r.requested=true;
  if(changed){r.sideAttempts=0;r.bestGoal=Math.pow(x-coord(n,"X"),2)+Math.pow(z-coord(n,"Z"),2);cancelBreak(n,r);r.stuck=0;r.alternateAt=0;r.x=coord(n,"X");r.z=coord(n,"Z");r.checked=Social.time(n);}
  if(r.manualUntil>Social.time(n)||r.breaking!=null||r.detourUntil>Social.time(n))return true;
  return Social.yes(c(Navigation78.class,"goBase47",n,x,y,z,speed));
 }
 static boolean baseGo(Object n,Route r){Navigation78.Route legacy=Navigation78.ROUTES.get(n);if(legacy!=null){legacy.retry=0;legacy.failures=0;}return Social.yes(c(Navigation78.class,"goBase47",n,r.gx,r.gy,r.gz,r.speed));}
 static boolean eligible(Object n){return Social.alive(n)&&!Social.client(n)&&!Downed20.down(n)&&CalmBrain.state(n).target==null&&Social.mem(n).threats==0&&(!Motion76.conversing(n)||Immersion82.walking(n));}
 static boolean free(Object n,double dx,double dz){
  Object w=Social.world(n),box=c(n,"getBoundingBox");int samples=Math.max(1,(int)Math.ceil(Math.hypot(dx,dz)/.15));
  for(int i=1;i<=samples;i++)if(!Social.yes(c(w,"noCollision",n,c(box,"move",dx*i/samples,0d,dz*i/samples))))return false;
  Object floor=Shelter77.pos((int)Math.floor(coord(n,"X")+dx),(int)Math.floor(coord(n,"Y")-.05),(int)Math.floor(coord(n,"Z")+dz));
  return Shelter77.loaded(w,floor)&&Social.yes(c(Shelter77.state(w,floor),"isFaceSturdy",w,floor,SocialR.get(Social.t("net.minecraft.core.Direction"),"UP")));
 }
 static boolean sideStep(Object n,Route r){if(r.sideAttempts>=2)return false;
  double aimX=r.gx,aimZ=r.gz;try{Object path=c(c(n,"getNavigation"),"getPath");if(path!=null){int index=((Number)c(path,"getNextNodeIndex")).intValue(),count=((Number)c(path,"getNodeCount")).intValue();if(index<count){Object node=c(path,"getNode",index);aimX=((Number)SocialR.get(node,"x")).doubleValue()+.5;aimZ=((Number)SocialR.get(node,"z")).doubleValue()+.5;}}}catch(Exception ignored){}
  double dx=aimX-coord(n,"X"),dz=aimZ-coord(n,"Z"),len=Math.hypot(dx,dz);if(len<.05)return false;dx/=len;dz/=len;
  for(double forward:new double[]{.5,.9,1.3,0,-.3})for(double side:new double[]{-.25,.25,-.5,.5,-.8,.8}){
   double sx=dx*forward-dz*side,sz=dz*forward+dx*side;if(!free(n,sx,sz))continue;
   r.sideAttempts++;c(c(n,"getNavigation"),"stop");r.mx=coord(n,"X")+sx;r.my=coord(n,"Y");r.mz=coord(n,"Z")+sz;r.manualUntil=Social.time(n)+35;r.stuck=0;
   c(Social.tag(n),"putString","npc47_ruta","rodear_panel_abierto");return true;
  }return false;
 }
 static boolean alternate(Object n,Route r){
  Object nav=c(n,"getNavigation"),world=Social.world(n);boolean indoors=!Social.yes(c(world,"canSeeSky",c(n,"blockPosition")));
  // Ask for a new complete route after opening reachable wooden doors.
  int bx=(int)Math.floor(coord(n,"X")),by=(int)Math.floor(coord(n,"Y")),bz=(int)Math.floor(coord(n,"Z"));
  for(int x=-6;x<=6;x++)for(int z=-6;z<=6;z++){
   Object p=Shelter77.pos(bx+x,by,bz+z);if(!Shelter77.loaded(world,p))continue;Object s=Shelter77.state(world,p);String id=Shelter77.id(s);
   if(!id.endsWith("_door")||id.contains("iron")||!Shelter77.permitted(n,p))continue;
   Object block=c(s,"getBlock");try{Object prop=SocialR.get(Social.t("net.minecraft.world.level.block.DoorBlock"),"OPEN");if(!Social.yes(c(s,"getValue",prop)))c(block,"setOpen",n,world,s,p,true);}catch(Exception ignored){}
  }
  // A complete path to a different exterior waypoint proves that another exit is reachable.
  double best=Double.MAX_VALUE;Object bestPath=null;
  for(int radius:new int[]{4,8,12})for(int[] d:new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{-1,1},{1,-1},{-1,-1}})for(int dy:new int[]{0,-1,1}){
   double x=bx+d[0]*radius+.5,y=by+dy,z=bz+d[1]*radius+.5;Object p=Shelter77.pos((int)Math.floor(x),(int)y,(int)Math.floor(z));
   if(!Shelter77.loaded(world,p)||!Shelter77.air(world,p)||!Shelter77.air(world,Shelter77.offset(p,0,1,0)))continue;
   if(indoors&&!Social.yes(c(world,"canSeeSky",p)))continue;
   Object path=Navigation78.path(nav,x,y,z);if(!Navigation78.complete(path)||crossesStall(path,(int)Math.floor(coord(n,"X")+(r.gx-coord(n,"X"))/Math.max(.001,Math.hypot(r.gx-coord(n,"X"),r.gz-coord(n,"Z")))*.8),by,(int)Math.floor(coord(n,"Z")+(r.gz-coord(n,"Z"))/Math.max(.001,Math.hypot(r.gx-coord(n,"X"),r.gz-coord(n,"Z")))*.8)))continue;
   double score=(x-r.gx)*(x-r.gx)+(z-r.gz)*(z-r.gz)+radius*radius*.2;if(score<best){best=score;bestPath=path;}
  }
  if(bestPath==null)return false;
  c(nav,"moveTo",bestPath,r.speed);r.manualUntil=0;r.stuck=0;r.detourUntil=Social.time(n)+Math.max(160,Math.min(800,((Number)c(bestPath,"getNodeCount")).intValue()*12+60));r.alternateAt=r.detourUntil;
  // Retain the ultimate goal; suppress repeated direct requests while traversing the detour.
  c(Social.tag(n),"putString","npc47_ruta","otra_salida");return true;
 }
 static boolean crossesStall(Object path,int x,int y,int z){
  int count=((Number)c(path,"getNodeCount")).intValue();int start=((Number)c(path,"getNextNodeIndex")).intValue();
  for(int i=start+1;i<count;i++){Object node=c(path,"getNode",i);int nx=((Number)SocialR.get(node,"x")).intValue(),nz=((Number)SocialR.get(node,"z")).intValue();if(nx==x&&nz==z)return true;}
  return false;
 }
 static boolean breakable(Object n,Object p,Object state){
  Object w=Social.world(n);if(!Shelter77.loaded(w,p)||!Shelter77.grief(n)||!Shelter77.permitted(n,p)||c(w,"getBlockEntity",p)!=null)return false;
  String id=Shelter77.id(state);if(id.contains("bedrock")||id.contains("command_block")||id.contains("portal")||id.contains("spawner")||id.contains("structure_block"))return false;
  double hardness=Social.num(c(state,"getDestroySpeed",w,p));if(hardness<0||hardness>12||Social.yes(c(state,"isAir"))||!Social.yes(c(c(w,"getFluidState",p),"isEmpty")))return false;
  return !Social.yes(c(c(state,"getCollisionShape",w,p),"isEmpty"))&&Social.yes(c(state,"canEntityDestroy",w,p,n));
 }
 static Object blocker(Object n,Route r){
  Object w=Social.world(n);double dx=r.gx-coord(n,"X"),dz=r.gz-coord(n,"Z"),len=Math.hypot(dx,dz);if(len<.01)return null;dx/=len;dz/=len;
  for(double step:new double[]{.55,.9,1.35})for(int height:new int[]{1,0}){
   Object p=Shelter77.pos((int)Math.floor(coord(n,"X")+dx*step),(int)Math.floor(coord(n,"Y"))+height,(int)Math.floor(coord(n,"Z")+dz*step));
   if(!Shelter77.loaded(w,p))continue;Object s=Shelter77.state(w,p);if(breakable(n,p,s))return p;
  }return null;
 }
 static void cancelBreak(Object n,Route r){if(r.breaking!=null){try{c(Social.world(n),"destroyBlockProgress",c(n,"getId"),r.breaking,-1);}catch(Exception ignored){}r.breaking=null;r.progress=0;}}
 static void breaking(Object n,Route r){
  Object w=Social.world(n),s=Shelter77.state(w,r.breaking);String id=Shelter77.id(s);
  if(!id.equals(r.block)||!breakable(n,r.breaking,s)||Math.abs(Shelter77.axis(r.breaking,"getX")+.5-coord(n,"X"))>2.5||Math.abs(Shelter77.axis(r.breaking,"getZ")+.5-coord(n,"Z"))>2.5){cancelBreak(n,r);return;}
  c(c(n,"getNavigation"),"stop");Social.mem(n).occupied=true;r.progress++;
  c(Social.tag(n),"putString","npc47_ruta","romper_obstaculo_"+id);
  c(w,"destroyBlockProgress",c(n,"getId"),r.breaking,Math.min(9,r.progress*10/r.duration));if(r.progress%10==0)Shelter77.swing(n);
  if(r.progress<r.duration)return;
  if(Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"),"onEntityDestroyBlock",n,r.breaking,s))&&Social.yes(c(w,"destroyBlock",r.breaking,true,n))){r.lastBreak=Social.time(n);r.stuck=0;r.alternateAt=0;}
  cancelBreak(n,r);c(c(n,"getNavigation"),"recomputePath");baseGo(n,r);
 }
 public static boolean work(Object n){Route r=ROUTES.get(n);if(r==null||!eligible(n))return false;long now=Social.time(n);
  if(r.breaking!=null){Social.mem(n).occupied=true;return true;}
  if(now<r.manualUntil){Social.mem(n).occupied=true;return true;}return false;
 }
 public static void tick(Object n){try{
  if(Social.client(n))return;Route r=ROUTES.computeIfAbsent(n,k->new Route());long now=Social.time(n);if(r.lastTick==now)return;r.lastTick=now;Object nav=c(n,"getNavigation");
  if(!eligible(n)){cancelBreak(n,r);r.manualUntil=0;r.stuck=0;return;}
  if(r.breaking!=null){breaking(n,r);return;}
  if(now<r.manualUntil){
   double dx=r.mx-coord(n,"X"),dz=r.mz-coord(n,"Z");if(dx*dx+dz*dz<.04){r.manualUntil=0;baseGo(n,r);}else {c(nav,"stop");c(c(n,"getMoveControl"),"setWantedPosition",r.mx,r.my,r.mz,r.speed);Social.mem(n).occupied=true;}return;
  }
  if(r.detourUntil>0){if(now<r.detourUntil&&!Social.yes(c(nav,"isDone")))return;r.detourUntil=0;baseGo(n,r);}
  if(now-r.checked<20)return;
  if(!r.requested){Object target=c(nav,"getTargetPos");if(target==null)return;r.gx=Shelter77.axis(target,"getX")+.5;r.gy=Shelter77.axis(target,"getY");r.gz=Shelter77.axis(target,"getZ")+.5;r.requested=true;}
  double x=coord(n,"X"),z=coord(n,"Z");double moved=(x-r.x)*(x-r.x)+(z-r.z)*(z-r.z);r.x=x;r.z=z;r.checked=now;
  if((x-r.gx)*(x-r.gx)+(z-r.gz)*(z-r.gz)<.5){r.stuck=0;r.requested=false;return;}
  if(moved>.025){double remaining=(x-r.gx)*(x-r.gx)+(z-r.gz)*(z-r.gz);if(remaining<r.bestGoal-.2){r.bestGoal=remaining;r.sideAttempts=0;}r.stuck=0;return;}if(r.stuck==0){r.stuck=now;return;}if(now-r.stuck<40)return;
  if(sideStep(n,r))return;
  if(now>=r.alternateAt){r.alternateAt=now+200;if(alternate(n,r))return;}
  if(now-r.stuck<100||now-r.lastBreak<20)return;
  Object p=blocker(n,r);if(p==null){c(Social.tag(n),"putString","npc47_ruta","sin_salida_transitable");return;}
  Object s=Shelter77.state(Social.world(n),p);r.breaking=p;r.block=Shelter77.id(s);r.progress=0;r.duration=Math.max(20,(int)Math.ceil(Social.num(c(s,"getDestroySpeed",Social.world(n),p))*30));
 }catch(Exception e){Social.warn("physical route recovery47",e);}}
}
