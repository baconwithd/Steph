package mod.cdv.tnpc.tactical;
import com.google.gson.*;
public class MenuTest47 {
 public static class Gun extends Sim47.Item implements com.tacz.guns.api.item.IGun{Gun(){super("tacz:modern_kinetic_gun");}}
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception{
  Sim47.setup();Sim47.World w=new Sim47.World();Sim47.Actor n=new Sim47.Actor(w),p=new Sim47.Actor(w);Navigation78.INIT.add(n);p.x=5.5;p.look=new Sim47.Vec(-1,0,0);p.held=new net.minecraft.world.item.ItemStack(new Gun(),1);n.tag.putString("npc71_personality","seco");
  JsonObject identity=new JsonObject();identity.addProperty("propietario",n.id.toString());identity.addProperty("nombre","NPC");identity.addProperty("necesidad","familiar_enfermo");identity.add("datos",new JsonObject());n.tag.putString("npc73_identidad",identity.toString());n.tag.putString("soc_full_name20","NPC");Social74.CACHE.put(n,new Social74.Cache(Social74.create(n)));
  JsonObject e=Encounters47.encounter(n,p);JsonObject data=DialogueData71.DATA.deepCopy();data.getAsJsonArray("encuentros").add(e);DialogueData71.validate(data,false);
  Encounters47.tick(n);check(Encounters47.protects(n,p),"aiming did not start the encounter");check(!Immersion82.weaponBreak(p),"weapon closed the pointed-gun dialogue");
  for(int i=0;i<3;i++){w.now+=40;Chat71.tick(n);}
  Conversation.Session session=Conversation.SESSIONS.get(p);check(session!=null,"encounter vanished");Chat71.State state=Chat71.state(session);check(state.offered.size()==3,"expected three choices: "+state.offered);
  check(TalkNetwork.packets.stream().anyMatch(s->s.contains("extorsionar47")&&s.contains("broma47")&&s.contains("bajar47")),"choices were not sent to the player");
  check(Chat71.choose(p,state.id,"broma47",state.token)==1,"joke choice failed");for(int i=0;i<4;i++){w.now+=40;Chat71.tick(n);}
  check(!Conversation.SESSIONS.containsKey(p),"encounter failed to end after reply");check(Chat71.protectedPlayer(n,p),"joke did not grant a de-escalation window");
  Sim47.Actor victim=new Sim47.Actor(w);victim.tag.putString("npc71_personality","seco");identity.addProperty("propietario",victim.id.toString());victim.tag.putString("npc73_identidad",identity.toString());victim.tag.putString("soc_full_name20","NPC");Social74.CACHE.put(victim,new Social74.Cache(Social74.create(victim)));Navigation78.INIT.add(victim);
  CalmLoot.saveBag(victim,new java.util.ArrayList<>(java.util.List.of(new net.minecraft.world.item.ItemStack(new Sim47.Item("minecraft:coal"),3))));w.now+=600;while(w.now%5!=0)w.now++;Encounters47.tick(victim);for(int i=0;i<3;i++){w.now+=40;Chat71.tick(victim);}
  session=Conversation.SESSIONS.get(p);check(session!=null&&session.npc==victim,"extortion encounter did not open");state=Chat71.state(session);check(Chat71.choose(p,state.id,"extorsionar47",state.token)==1,"extortion reply failed");check(Shelter77.count(DialogueRules72.bag(victim),"minecraft:coal")==2,"NPC items not debited exactly once");check(Shelter77.count(DialogueRules72.playerSlots(p),"minecraft:coal")==1,"player did not receive extorted item");
  System.out.println("PASS: validated weapon encounter, actual conversation/pump/choice chain, three delivered choices, joke response and de-escalation; actual extortion transfer debits NPC and credits player once");
 }
}
