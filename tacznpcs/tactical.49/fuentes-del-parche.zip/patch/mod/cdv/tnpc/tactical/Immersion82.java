package mod.cdv.tnpc.tactical;
import java.util.*;
import com.google.gson.*;
/** Server-side additions; no client or Minecraft compile-time dependencies. */
public final class Immersion82 {
 static final Map<Object,Map<String,Integer>> HISTORY=new WeakHashMap<>();
 static boolean announced46;
 public static void active46(Object n){
  if(Social.client(n))return;
  Object tag=Social.tag(n);
  if(!Social.yes(Social.c(tag,"getBoolean","npc49_migrated"))){
   boolean wasDisabled=Social.yes(Social.c(tag,"getBoolean","npc70_disabled"));
   Social.c(tag,"putBoolean","npc70_disabled",false);Authority70.FAILED.remove(n);Social74.FAILED.remove(n);Social.c(tag,"putBoolean","npc49_migrated",true);
   if(wasDisabled)System.out.println("[TacZ NPCs tactical.49] Retrying NPC previously disabled after a runtime error: "+Social.uuid(n));
  }
  if(!announced46){announced46=true;System.out.println("[TacZ NPCs tactical.49] Runtime active; Doomsday furniture, window boards and complete dialogue turns loaded. NPC width="+Social.c(n,"getBbWidth"));}
 }
 static boolean owner(Object n,Object p){return p!=null && (Companion78.member(n,p)||Social.s(Social.tag(n),"soc_owner").equals(Social.uuid(p).toString()));}
 static boolean walking(Object n){return Social.s(Social.tag(n),"soc_order").equals("follow")&&owner(n,Authority70.state(n).player.get());}
 public static boolean conversing(Object n){return !walking(n)&&Motion76.conversing(n);}
 public static boolean weaponBreak(Object p){if(Encounters47.active(p))return false;Conversation.Session s=Conversation.SESSIONS.get(p);return s!=null&&owner(s.npc,p)?false:Gate74.weaponBreak(p);}
 public static boolean armed(Object p,Object n){return !owner(n,p)&&Chat71.armed(p);}
 public static Object call(Object o,String method,Object[] args){
  if(method.equals("stop")){
   for(Conversation.Session session:Conversation.SESSIONS.values())if(walking(session.npc)&&Social.c(session.npc,"getNavigation")==o)return null;
  }
  if(method.equals("isSprinting")){Conversation.Session s=Conversation.SESSIONS.get(o);if(s!=null&&owner(s.npc,o))return false;}
  return Social.c(o,method,args);
 }
 public static boolean busy(boolean result,Object n){
  if(result&&walking(n))try{if(!Companion78.recruited(n))Social.c(Social.tag(n),"putString","npc78_owner",Social.s(Social.tag(n),"soc_owner"));Companion78.work(n);}catch(Exception e){Social.warn("walking conversation",e);}return result;
 }
 public static String pick(Object n,String key,String... lines){
  Map<String,Integer> h=HISTORY.computeIfAbsent(n,k->new HashMap<>());int previous=h.getOrDefault(key,-1);
  int next=Chat71.RANDOM.nextInt(lines.length);if(lines.length>1&&next==previous)next=(next+1+Chat71.RANDOM.nextInt(lines.length-1))%lines.length;h.put(key,next);return lines[next];
 }
 public static String line(String text,Object n,Object p,Chat71.State state){
  if(text.equals("Mantén las manos a la vista.")&&owner(n,p))return pick(n,"hands","Te sigo. Habla, te escucho.","Podemos hablar mientras avanzamos.","Sigo contigo. ¿Qué necesitas?");
  if(text.equals("No cuento mi vida a cualquiera.")&&Social74.effective(n,p,"confianza")>=60)return pick(n,"personal","Contigo puedo hablar de estas cosas.","Después de lo que hemos pasado, puedes preguntar.","Me cuesta hablar de eso, pero confío en ti.");
  switch(text){
   case "Mira. Podemos hablar.":return pick(n,"greet","Mira. Podemos hablar.","Te escucho. Sin prisas.","Dime qué necesitas.","Tengo un momento. Habla.");
   case "Sigo de pie.":return pick(n,"standing","Sigo de pie.","Cansado, pero todavía puedo seguir.","He tenido días mejores. Aquí sigo.","Por ahora aguanto.");
   case "Pregunta lo que tengas que preguntar.":return pick(n,"ask","Pregunta lo que tengas que preguntar.","¿Qué querías saber?","Te escucho. ¿Qué tienes en mente?");
   case "Podemos seguir hablando después.":return pick(n,"later","Podemos seguir hablando después.","Ya retomaremos esto con calma.","Seguimos luego. Mantente atento.");
   default:return text;
  }
 }
 static void emit(Object n,String key,String... lines){String text=pick(n,key,lines);for(Object p:Social.nearby(n,"net.minecraft.world.entity.player.Player",16))Flow73.emit(n,p,text,"tone_normal");}
 public static void dying(Object n){
  try{if(Social.client(n)||!Social.actor(n)||Social.yes(Social.c(Social.tag(n),"getBoolean","npc82_last_breath")))return;
   Social.c(Social.tag(n),"putBoolean","npc82_last_breath",true);emit(n,"death","Arghh…","N-no…","Ahh…","Ugh…","No… todavía…","Agh…");
  }catch(Exception e){Social.warn("last breath",e);}
 }
 public static boolean silent(Object n){
  if(!Social.alive(n)||Social.yes(Social.c(Social.tag(n),"getBoolean","npc82_last_breath")))return true;
  if(Downed20.down(n)){
   try{long now=Social.time(n);if(!Social.client(n)&&now>=Social.l(Social.tag(n),"npc46_gasp_after")){Social.c(Social.tag(n),"putLong","npc46_gasp_after",now+400);emit(n,"gasp","Arghh…","Ugh… no…","Ahh…","N-no…");}}catch(Exception e){Social.warn("downed groan",e);}return true;
  }return false;
 }
 static boolean aimed(Object p,Object n){
  double width=.6;try{width=Social.num(Social.c(n,"getBbWidth"));}catch(Exception ignored){}
  double nx=Social.num(Social.c(n,"getX")),ny=Social.num(Social.c(n,"getY")),nz=Social.num(Social.c(n,"getZ"));
  double[] min={nx-width/2-.04,ny,nz-width/2-.04},max={nx+width/2+.04,ny+Social.num(Social.c(n,"getBbHeight"))+.04,nz+width/2+.04};
  Object look=Social.c(p,"getLookAngle");double[] from={Social.num(Social.c(p,"getX")),Social.num(Social.c(p,"getEyeY")),Social.num(Social.c(p,"getZ"))},dir={Social.num(SocialR.get(look,"x")),Social.num(SocialR.get(look,"y")),Social.num(SocialR.get(look,"z"))};
  double enter=0,leave=32;for(int i=0;i<3;i++){if(Math.abs(dir[i])<1e-8){if(from[i]<min[i]||from[i]>max[i])return false;continue;}double first=(min[i]-from[i])/dir[i],last=(max[i]-from[i])/dir[i];if(first>last){double temp=first;first=last;last=temp;}enter=Math.max(enter,first);leave=Math.min(leave,last);if(leave<enter)return false;}return leave>=enter;
 }
 public static boolean hostileAllowed(Object n,Object p){if(Encounters47.protects(n,p))return false;
  try{
   if(!Roles22.hostile(n)||owner(n,p))return Social.yes(Social.c(Threat27.class,"baseAllowed82",n,p));
   if(!Social.alive(p)||!Social.visible(n,p)||Social.yes(Social.c(p,"isCreative"))||Social.yes(Social.c(p,"isSpectator")))return false;
   long now=Social.time(n);String id=Social.identity(p).toString();
   if(Chat71.armed(p)&&aimed(p,n)){
    Authority70.end(n,false,null);Social.c(Social.tag(n),"putString","soc_enemy",id);Social.c(Social.tag(n),"putLong","soc_enemy_until",now+1200);
    if(now>=Social.l(Social.tag(n),"npc82_panic")){Social.c(Social.tag(n),"putLong","npc82_panic",now+200);emit(n,"panic","¡No me apuntes!","¡Va a disparar!","¡Baja el arma!");}
    CalmBrain.state(n).nextShot=Math.min(CalmBrain.state(n).nextShot,now);return true;
   }
   if(!Chat71.armed(p)&&!Threat27.recent(n,p,now)&&!Social.enemy(n,p)&&Social.distance(n,p)<=100){
    String key="npc82_extort_"+id;long start=Social.l(Social.tag(n),key);
    if(start==0){Social.c(Social.tag(n),"putLong",key,now);Flow73.emit(n,p,pick(n,"extort","Quieto. Suelta comida o munición al suelo y podrás irte.","No llevas un arma. Deja provisiones aquí. Despacio.","Necesito lo que llevas. Tira comida o munición; no hagas movimientos raros."),"tone_normal");start=now;}
    if(now<Social.l(Social.tag(n),"npc82_paid_"+id))return false;
    for(Object item:Social.nearby(n,"net.minecraft.world.entity.item.ItemEntity",3)){
     Object stack=Social.c(item,"getItem");JsonObject food=new JsonObject();food.addProperty("categoria","comida");JsonObject ammo=new JsonObject();ammo.addProperty("categoria","municion");
     if((DialogueRules72.matches(stack,food)||DialogueRules72.matches(stack,ammo))&&CalmLoot.transfer(n,new CalmLoot.Source(null,new ArrayList<Object>(List.of(stack)),item,Social.num(Social.c(item,"getX")),Social.num(Social.c(item,"getY")),Social.num(Social.c(item,"getZ"))))){
      Social.c(Social.tag(n),"putLong","npc82_paid_"+id,now+1200);Social.c(Social.tag(n),"putLong",DialogueRules72.key(p,"tregua"),now+1200);Social.target(n,null);Flow73.emit(n,p,pick(n,"paid","Eso sirve. Ahora vete.","Bien. Guarda las distancias y sigue tu camino.","Trato hecho. Puedes marcharte."),"tone_normal");return false;
     }
    }
    if(now-start<400)return false;
   }
   return Social.yes(Social.c(Threat27.class,"baseAllowed82",n,p));
  }catch(Exception e){Social.warn("hostile encounter",e);return Social.yes(Social.c(Threat27.class,"baseAllowed82",n,p));}
 }
 public static void heard(Object n){
  try{Sense28.State s=Sense28.state(n);if(s.priority<3||Social.time(n)-s.heard>2||Social.client(n)||!Social.alive(n)||Downed20.down(n))return;
   long now=Social.time(n);if(now<Social.l(Social.tag(n),"npc82_noise"))return;
   Social.c(Social.tag(n),"putLong","npc82_noise",now+200);Peace78.hit(n);CalmLoot.release(n,CalmBrain.state(n));
   boolean equipped=Chat71.armed(n)&&Social.num(Social.c(n,"getHealth"))>Social.num(Social.c(n,"getMaxHealth"))*.65;
   boolean desperate=!Free75.context(n,"comida_en_bolsa");
   emit(n,"noise","¿Disparos? Espera…","He oído tiros. Ojos abiertos.","Deja eso. Hay disparos cerca.");
   if(!Companion78.recruited(n)&&!Motion76.conversing(n)&&CalmBrain.state(n).target==null&&(equipped||desperate)){
    Social.c(Social.tag(n),"putDouble","npc82_noise_x",s.x);Social.c(Social.tag(n),"putDouble","npc82_noise_y",s.y);Social.c(Social.tag(n),"putDouble","npc82_noise_z",s.z);Social.c(Social.tag(n),"putLong","npc82_investigate",now+160);
   }
  }catch(Exception e){Social.warn("scavenger gunfire reaction",e);}
 }
 public static void investigate(Object n){try{
  long now=Social.time(n);if(now>=Social.l(Social.tag(n),"npc82_investigate")||now%20!=0||Companion78.recruited(n)||Motion76.conversing(n)||CalmBrain.state(n).target!=null||Downed20.down(n)||!Social.alive(n))return;
  double x=Social.num(Social.c(Social.tag(n),"getDouble","npc82_noise_x")),y=Social.num(Social.c(Social.tag(n),"getDouble","npc82_noise_y")),z=Social.num(Social.c(Social.tag(n),"getDouble","npc82_noise_z"));
  double dx=Social.num(Social.c(n,"getX"))-x,dz=Social.num(Social.c(n,"getZ"))-z;
  if(dx*dx+dz*dz<25){Social.c(Social.tag(n),"putLong","npc82_investigate",0L);return;}
  Navigation78.go(n,x,y,z,.85);
 }catch(Exception e){Social.warn("gunfire investigation",e);}}

 public static JsonObject augment(JsonObject data){
  try {JsonObject patch=DialogueData71.resource("immersion82.json");
   for(JsonElement ep:patch.getAsJsonArray("encuentros")){JsonObject src=ep.getAsJsonObject();
    for(JsonElement et:data.getAsJsonArray("encuentros")){JsonObject dst=et.getAsJsonObject();if(!dst.get("id").getAsString().equals(src.get("id").getAsString()))continue;
     Set<String> ids=new HashSet<>();for(JsonElement nd:dst.getAsJsonArray("nodos"))ids.add(nd.getAsJsonObject().get("id").getAsString());
     for(JsonElement nd:src.getAsJsonArray("nodos")){JsonObject node=nd.getAsJsonObject();if(!ids.contains(node.get("id").getAsString()))dst.getAsJsonArray("nodos").add(node.deepCopy());}
     for(JsonElement nd:dst.getAsJsonArray("nodos"))for(JsonElement od:nd.getAsJsonObject().getAsJsonArray("opciones")){
      JsonObject o=od.getAsJsonObject();if(o.get("id").getAsString().equals("pasado"))for(JsonElement r:o.getAsJsonArray("respuestas"))r.getAsJsonObject().addProperty("siguiente","vinculo82");
      if(o.get("id").getAsString().equals("animo")||o.get("id").getAsString().equals("escuchar")){
       for(JsonElement ns:src.getAsJsonArray("nodos"))for(JsonElement os:ns.getAsJsonObject().getAsJsonArray("opciones"))if(os.getAsJsonObject().get("id").equals(o.get("id"))){
        JsonArray rr=os.getAsJsonObject().getAsJsonArray("respuestas");for(int i=0;i<o.getAsJsonArray("respuestas").size()&&i<rr.size();i++)if(rr.get(i).getAsJsonObject().has("variantes"))o.getAsJsonArray("respuestas").get(i).getAsJsonObject().add("variantes",rr.get(i).getAsJsonObject().get("variantes").deepCopy());
       }
      }
     }
    }
   }
  }catch(Exception e){Social.warn("dialogue expansion",e);}return data;
 }
 public static JsonArray variants(JsonArray original,Object n,Object p,Chat71.State state,JsonObject response){
  if(!response.has("variantes"))return original;
  List<JsonArray> candidates=new ArrayList<>();candidates.add(response.getAsJsonArray("lineas_npc"));
  for(JsonElement e:response.getAsJsonArray("variantes")){JsonObject v=e.getAsJsonObject();if(DialogueRules72.condition(v.has("condicion")?v.getAsJsonObject("condicion"):null,n,p,state))candidates.add(v.getAsJsonArray("lineas_npc"));}
  if(candidates.size()<2)return original;
  String key="variant:"+response.getAsJsonArray("lineas_npc").toString();Map<String,Integer> h=HISTORY.computeIfAbsent(n,k->new HashMap<>());int old=h.getOrDefault(key,-1);List<Integer> choices=new ArrayList<>();
  for(int i=0;i<candidates.size();i++){if(i==old)continue;boolean fresh=true;for(JsonElement e:candidates.get(i))if(state.seen.contains(Chat71.seenKey(DialogueRules72.format(e.getAsString(),n,p,state))))fresh=false;if(fresh)choices.add(i);}
  if(choices.isEmpty())return original;int next=choices.get(Chat71.RANDOM.nextInt(choices.size()));h.put(key,next);return candidates.get(next);
 }

 public static boolean ambientEligible(Object n){try{
  if(Social.client(n)||!Social.alive(n)||Downed20.down(n)||Motion76.conversing(n)||CalmBrain.state(n).target!=null||Social.mem(n).threats>0||Social.mem(n).medicalUntil>Social.time(n)||Social.mem(n).fearUntil>Social.time(n)||Ambush73.hidden(n))return false;
  if(!Companion78.recruited(n))return Social.s(Social.tag(n),"soc_owner").isBlank();
  Object p=Social.c(Social.world(n),"getPlayerByUUID",UUID.fromString(Companion78.owner(n)));if(p==null||!Social.alive(p)||Social.distance(n,p)>64||Social.yes(Social.c(p,"isSprinting")))return false;
  Object v=Social.c(p,"getDeltaMovement");double x=Social.num(SocialR.get(v,"x")),z=Social.num(SocialR.get(v,"z"));
  Object partner=Ambient78.partner(n);return x*x+z*z<.0025&&(partner==null||Companion78.owner(n).equals(Companion78.owner(partner)));
 }catch(Exception e){return false;}}
 public static int ambientKind(Object n){return Companion78.recruited(n)?Companion78.owner(n).hashCode():Social.kind(n);}
 public static boolean soundWork(Object n){try{
  if(Social.client(n)||Social.time(n)>=Social.l(Social.tag(n),"npc82_investigate")||!Social.alive(n)||Downed20.down(n)||Companion78.recruited(n)||Motion76.conversing(n)||CalmBrain.state(n).target!=null)return false;
  investigate(n);Social.mem(n).occupied=true;return true;
 }catch(Exception e){return false;}}

 public static JsonArray opening(Object n,Object p,Chat71.State state,JsonArray original,String outcome){
  if((state.turns!=0&&!state.restoreContext)||outcome!=null||state.intimidation||!Free75.free(state))return original;
  try{
   int trust=Social74.effective(n,p,"confianza");String band=owner(n,p)?"companion":trust>=60?"close":trust>=30?"familiar":"stranger";
   JsonObject pool=DialogueData71.resource("openings46.json").getAsJsonObject(state.personality);JsonArray variants=pool.getAsJsonArray(band);
   String key="npc46_open_"+band;int previous=((Number)Social.c(Social.tag(n),"getInt",key)).intValue()-1;
   int next=Chat71.RANDOM.nextInt(variants.size());if(next==previous)next=(next+1+Chat71.RANDOM.nextInt(variants.size()-1))%variants.size();Social.c(Social.tag(n),"putInt",key,next+1);
   return variants.get(next).getAsJsonArray();
  }catch(Exception e){Social.warn("contextual opening",e);return original;}
 }
 public static boolean hearingPaused(Object n){return !Social.alive(n)||Downed20.down(n);}
}
