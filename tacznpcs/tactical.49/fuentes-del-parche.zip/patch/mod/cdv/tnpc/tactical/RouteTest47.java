package mod.cdv.tnpc.tactical;
public class RouteTest47 {
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
 static Sim47.World room(boolean exit){Sim47.World w=new Sim47.World();for(int i=-3;i<=3;i++)for(int y=65;y<=66;y++){w.blocks.put(new Sim47.Pos(3,y,i),new Sim47.State("bop:reinforcement"));w.blocks.put(new Sim47.Pos(-3,y,i),new Sim47.State("minecraft:stone"));w.blocks.put(new Sim47.Pos(i,y,3),new Sim47.State("minecraft:stone"));w.blocks.put(new Sim47.Pos(i,y,-3),new Sim47.State("minecraft:stone"));}for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++)w.blocks.put(new Sim47.Pos(x,68,z),new Sim47.State("minecraft:stone"));if(exit)for(int y=65;y<=66;y++){Sim47.State door=new Sim47.State("minecraft:oak_door");door.open=true;w.blocks.put(new Sim47.Pos(-3,y,0),door);}w.optimistic.add(new Sim47.Pos(6,65,0));return w;}
 static Sim47.Actor start(Sim47.World w){Sim47.Actor n=new Sim47.Actor(w);Navigation78.INIT.add(n);Navigation78.go(n,6.5,65,.5,1);return n;}
 static void run(Sim47.Actor n,int ticks){for(int i=0;i<ticks;i++){n.world.now++;if(i%20==0)Navigation78.go(n,6.5,65,.5,1);n.step();Navigation78.tick(n);if(Boolean.getBoolean("trace")&&i%80==0){Routes47.Route r=Routes47.ROUTES.get(n);System.out.println("t="+n.world.now+" pos="+n.x+","+n.z+" target="+n.tx+","+n.tz+" status="+n.tag.getString("npc47_ruta")+" until="+r.detourUntil+" stuck="+r.stuck+" side="+r.sideAttempts);}}}
 public static void main(String[] args){Sim47.setup();
  Sim47.World w=room(true);Sim47.Actor n=start(w);run(n,800);check(w.destroyed==0,"broke blocks despite another reachable exit");check(n.x>3.4,"did not use alternate exit: "+n.x+","+n.z+" status="+n.tag.getString("npc47_ruta")+" target="+n.tx+","+n.tz+" navdone="+n.nav.done+" nodes="+n.nav.path.nodes+" index="+n.nav.path.index+" detour="+Routes47.ROUTES.get(n).detourUntil+" now="+w.now);
  w=room(false);n=start(w);run(n,800);check(w.destroyed>=1,"sealed room never cleared an obstacle");check(n.x>3.4,"did not cross the cleared exit");
  w=room(false);w.grief=false;n=start(w);run(n,500);check(w.destroyed==0,"ignored mobGriefing");
  w=room(false);w.protectedArea=true;n=start(w);run(n,500);check(w.destroyed==0,"broke protected territory");
  System.out.println("PASS: open alternate exit used before destruction; timed block clearing in sealed room; griefing and territory protection retained");
 }
}
