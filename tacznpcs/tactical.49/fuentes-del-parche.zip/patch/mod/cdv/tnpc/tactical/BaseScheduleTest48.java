package mod.cdv.tnpc.tactical;
public class BaseScheduleTest48 {
 public static void main(String[] args){Sim47.setup();Sim47.World w=new Sim47.World();Sim47.Actor n=BaseTest48.resident(w);
  for(int x:new int[]{-9,-6,7,10})for(int z:new int[]{-8,8}){for(int y=65;y<69;y++)w.blocks.put(new Sim47.Pos(x,y,z),new Sim47.State("minecraft:oak_log"));w.blocks.put(new Sim47.Pos(x,69,z),new Sim47.State("minecraft:oak_leaves"));}
  for(int x=8;x<=12;x++)for(int z=-4;z<=4;z++)w.blocks.put(new Sim47.Pos(x,65,z),new Sim47.State("minecraft:stone"));
  java.util.Set<String> tasks=new java.util.HashSet<>();for(int i=0;i<9000;i++){w.now++;Life79.work(n);n.step();Navigation78.tick(n);Base48.tick(n);tasks.add(Base48.str(n,"tarea"));}
  if(!Base48.ready(n)||Base48.num(n,"mejoras")<1||Base48.stored(n,"cobblestone")<1||Base48.stored(n,"_log")<1)throw new AssertionError("scheduled economy stalled "+n.tag.values+" tasks="+tasks+" pos="+n.x+","+n.z+" wood="+Base48.stored(n,"_log")+" stone="+Base48.stored(n,"cobblestone"));
  if(!tasks.contains("abastecer_horno")||!tasks.contains("guardar_pertenencias_en_cofre")||!tasks.contains("vigilar_base_y_aliados"))throw new AssertionError("missing work phases "+tasks);
  System.out.println("PASS: actual Life79 scheduler -> furnish -> chop -> deposit -> furnace -> mine -> reinforce -> patrol, 9000 ticks; tasks="+tasks);
 }
}
