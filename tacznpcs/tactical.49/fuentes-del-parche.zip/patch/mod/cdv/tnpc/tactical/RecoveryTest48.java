package mod.cdv.tnpc.tactical;
public class RecoveryTest48 {
 public static void main(String[] args){Sim47.setup();Sim47.World w=new Sim47.World();Sim47.Actor n=new Sim47.Actor(w);Navigation78.INIT.add(n);n.tag.putInt("soc_kind",1);Activity78.Roof r=new Activity78.Roof();r.pos=new Sim47.Pos(5,65,0);r.until=10000;Activity78.ROOFS.put(n,r);
  for(int i=0;i<320;i++){w.now++;Base48.tick(n);}Base48.Job j=Base48.JOBS.get(n);if(j==null||j.escape==null||r.pos!=null||!Base48.recover(n))throw new AssertionError("homeless NPC remained blocked by stale roof goal");double x=n.x;for(int i=0;i<60;i++){w.now++;Base48.recover(n);n.step();}if(Math.abs(n.x-x)<.5)throw new AssertionError("no physical recovery movement");
  Sim47.Actor follower=new Sim47.Actor(w);follower.tag.putString("npc78_owner",java.util.UUID.randomUUID().toString());follower.tag.putString("soc_order","follow");for(int i=0;i<320;i++){w.now++;Base48.tick(follower);}if(Base48.JOBS.containsKey(follower))throw new AssertionError("watchdog overrides follow order");
  Sim47.Actor sleeper=new Sim47.Actor(w);sleeper.sleeping=true;for(int i=0;i<320;i++){w.now++;Base48.tick(sleeper);}if(Base48.JOBS.containsKey(sleeper))throw new AssertionError("watchdog cancels valid sleeping");
  System.out.println("PASS: stationary NPC without a base releases stale roof and walks to alternate waypoint; follow orders and sleep preserved; no teleport or block destruction");
 }
}
