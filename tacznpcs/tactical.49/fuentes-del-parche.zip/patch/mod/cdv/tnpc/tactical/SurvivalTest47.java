package mod.cdv.tnpc.tactical;
import java.util.*;
public class SurvivalTest47 {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static Sim47.Actor actor(Sim47.World w){Sim47.Actor n=new Sim47.Actor(w);Navigation78.INIT.add(n);n.tag.putLong("npc79_asentarse",500);return n;}
 public static void main(String[] args)throws Exception{
  Sim47.setup();
  // A canopy must not become a permanent home, a solid building roof must.
  Sim47.World world=new Sim47.World();Sim47.Actor n=actor(world);world.blocks.put(new Sim47.Pos(0,69,0),new Sim47.State("minecraft:oak_leaves"));check(Shelter47.exposed(n),"leaves were counted as a shelter");world.blocks.put(new Sim47.Pos(0,70,0),new Sim47.State("minecraft:oak_planks"));check(!Shelter47.exposed(n),"solid roof was missed");world.blocks.clear();world.blocks.put(new Sim47.Pos(0,68,0),new Sim47.State("minecraft:glass"));check(Activity78.cover(n,"asentarse")&&Activity78.roofWork(n),"solid transparent roof was discarded");world.blocks.clear();
  // Use the production craft transaction: input logs are consumed and planks are stored.
  CalmLoot.saveBag(n,new ArrayList<>(List.of(new net.minecraft.world.item.ItemStack(new Sim47.Item("minecraft:oak_log"),2))));
  check(Shelter77.craft(n,false),"log crafting failed");check(Shelter77.count(DialogueRules72.bag(n),"minecraft:oak_log")==1,"logs were not consumed");check(Shelter77.planks(DialogueRules72.bag(n))==4,"crafted planks were lost");check(Shelter77.craft(n,true),"table crafting failed");check(Shelter77.count(DialogueRules72.bag(n),"minecraft:crafting_table")==1,"table was not stored");
  // Nearby natural tree: find it on the first action rather than scanning the whole distant grid.
  world.blocks.put(new Sim47.Pos(2,65,0),new Sim47.State("minecraft:oak_log"));world.blocks.put(new Sim47.Pos(2,66,0),new Sim47.State("minecraft:oak_log"));world.blocks.put(new Sim47.Pos(2,69,0),new Sim47.State("minecraft:oak_leaves"));
  Shelter77.Camp camp=new Shelter77.Camp(5,65,5,2);camp.until=world.now+24000;Shelter77.CACHE.put(n,camp);Shelter77.gather(n,camp);check(camp.tree!=null,"nearby tree was not selected in one action");
  int destroyed=world.destroyed;for(int i=0;i<100&&world.destroyed==destroyed;i++){world.now++;Shelter77.gather(n,camp);n.step();}check(world.destroyed>destroyed,"tree never chopped");
  // A seeded material stock must become actual placed shelter blocks through the real work loop.
  world.blocks.clear();camp=new Shelter77.Camp(4,65,4,2);camp.until=world.now+24000;Shelter77.CACHE.put(n,camp);
  CalmLoot.saveBag(n,new ArrayList<>(List.of(new net.minecraft.world.item.ItemStack(new Sim47.Item("minecraft:oak_log"),32))));
  for(int i=0;i<10000&&!camp.phase.equals("descansar");i++){world.now++;Shelter77.work(n);n.step();}
  check(camp.phase.equals("descansar"),"shelter failed to finish: "+Social.s(Social.tag(n),"npc77_refugio_estado")+" index="+camp.index+" cell="+camp.cells.get(Math.min(camp.index,camp.cells.size()-1))+" position="+n.x+","+n.z);
  check(world.placed>=camp.cells.size(),"shelter materials were not placed");check(Shelter77.count(DialogueRules72.bag(n),"minecraft:oak_log")<32,"shelter never consumed wood");
  System.out.println("PASS: leaf/solid roof distinction, real log->planks->table transaction, one-action tree discovery, chopping and full shelter completion with material consumption");
 }
}
