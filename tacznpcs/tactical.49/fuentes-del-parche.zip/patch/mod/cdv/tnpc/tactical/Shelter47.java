package mod.cdv.tnpc.tactical;
import java.util.*;
/** Shelter discovery and natural-tree search, with progress before secondary jobs. */
public final class Shelter47 {
 static Object c(Object o,String m,Object... a){return Social.c(o,m,a);}
 static final Map<Object,Long> NEXT=new WeakHashMap<>();
 static final Map<Object,List<int[]>> SEARCH=new WeakHashMap<>();
 static boolean roof(Object n,Object floor){Object w=Social.world(n);for(int y=2;y<=14;y++){
  Object p=Shelter77.offset(floor,0,y,0);if(!Shelter77.loaded(w,p))return false;Object s=Shelter77.state(w,p);String id=Shelter77.id(s);
  if(id.endsWith("_leaves")||id.endsWith("_log")||id.endsWith("_wood")||Social.yes(c(s,"isAir")))continue;
  if(!Social.yes(c(c(s,"getCollisionShape",w,p),"isEmpty"))&&Social.yes(c(c(w,"getFluidState",p),"isEmpty")))return true;
 }return false;}
 public static boolean exposed(Object n){return !roof(n,c(n,"blockPosition"));}
 public static boolean cover(Object n,String reason){
  Activity78.Roof roof=Activity78.ROOFS.computeIfAbsent(n,k->new Activity78.Roof());long now=Social.time(n);
  if(roof.pos!=null&&now<roof.until&&roof(n,roof.pos))return true;
  roof.pos=null;if(now<roof.retry)return false;
  Object base=c(n,"blockPosition"),w=Social.world(n),nav=c(n,"getNavigation");
  // Nearer sites first. A path must actually reach the covered floor.
  int[][] offsets={{0,0},{2,0},{-2,0},{0,2},{0,-2},{4,0},{-4,0},{0,4},{0,-4},{4,4},{4,-4},{-4,4},{-4,-4},{8,0},{-8,0},{0,8},{0,-8},{8,8},{8,-8},{-8,8},{-8,-8},{12,0},{-12,0},{0,12},{0,-12}};
  int tested=0;for(int[] d:offsets)for(int dy:new int[]{0,-1,1}){Object p=Shelter77.offset(base,d[0],dy,d[1]);
   if(!Shelter77.loaded(w,p)||!Shelter77.air(w,p)||!Shelter77.air(w,Shelter77.offset(p,0,1,0))||!roof(n,p)||!Shelter77.permitted(n,p))continue;
   Object below=Shelter77.offset(p,0,-1,0);if(!Social.yes(c(Shelter77.state(w,below),"isFaceSturdy",w,below,SocialR.get(Social.t("net.minecraft.core.Direction"),"UP"))))continue;
   if(++tested>8)break;
   if(Navigation78.complete(Navigation78.path(nav,Shelter77.axis(p,"getX")+.5,Shelter77.axis(p,"getY"),Shelter77.axis(p,"getZ")+.5))){roof.pos=p;roof.until=now+6000;roof.retry=0;c(Social.tag(n),"putString","npc78_actividad","buscar_refugio_existente");return true;}
  }
  roof.retry=now+200;return false;
 }
 public static void tick(Object n){try{
  long now=Social.time(n);if(!Shelter77.cfg().get("activos").getAsBoolean()||!Shelter77.safe(n))return;
  Shelter77.Camp camp=Shelter77.get(n);if(camp!=null){if(camp.phase.equals("descansar")&&roof(n,Shelter77.pos(camp.x,camp.y,camp.z)))Hunt78.home(n,Shelter77.pos(camp.x,camp.y,camp.z));return;}
  if(!Social.s(Social.tag(n),"npc77_refugio_lider").isBlank()||now<NEXT.getOrDefault(n,0L))return;NEXT.put(n,now+100);
  Object home=Hunt78.point(n,"npc78_home");if(home!=null){if(Shelter77.loaded(Social.world(n),home)&&roof(n,home))return;c(Social.tag(n),"putString","npc78_home","");}
  long settle=Social.l(Social.tag(n),"npc79_asentarse");if(settle>now&&Shelter77.need(n)==null)return;
  if(cover(n,"asentarse")||!Shelter77.grief(n))return;
  Object base=c(n,"blockPosition");int cursor=(int)Social.l(Social.tag(n),"npc47_site");int[][] dirs={{1,0},{0,1},{-1,0},{0,-1},{1,1},{-1,1},{1,-1},{-1,-1}};
  for(int i=0;i<6;i++){int ix=cursor++;int radius=3+(ix/24%3)*4;int[] dir=dirs[ix%8];int dy=new int[]{0,-1,1}[ix/8%3];
   camp=new Shelter77.Camp(Shelter77.axis(base,"getX")+dir[0]*radius,Shelter77.axis(base,"getY")+dy,Shelter77.axis(base,"getZ")+dir[1]*radius,4);
   if(Shelter77.site(n,camp)){camp.reason="asentarse";camp.until=now+24000;Shelter77.save(n,camp);Shelter77.status(n,"reunir_materiales");for(Object friend:Shelter77.group(n))if(friend!=n)c(Social.tag(friend),"putString","npc77_refugio_lider",Social.uuid(n).toString());break;}
  }c(Social.tag(n),"putLong","npc47_site",(long)cursor);
 }catch(Exception e){Shelter77.failure(n,e);}}
 static List<int[]> offsets(int radius){List<int[]> list=new ArrayList<>();for(int x=-radius;x<=radius;x++)for(int z=-radius;z<=radius;z++)if(x*x+z*z<=radius*radius)for(int y:new int[]{0,-1,1,-2,2})list.add(new int[]{x,y,z});list.sort(Comparator.comparingInt(a->a[0]*a[0]+a[2]*a[2]+Math.abs(a[1])*2));return list;}
 public static void gather(Object n,Shelter77.Camp camp){
  if(camp.tree!=null){c(Shelter77.class,"gatherBase47",n,camp);return;}
  if(camp.giveUp)return;
  List<int[]> list=SEARCH.computeIfAbsent(camp,k->offsets(Shelter77.num("radio_madera")));Object base=c(n,"blockPosition"),w=Social.world(n);int checked=0;
  while(checked++<512&&camp.scan<list.size()){
   int[] d=list.get(camp.scan++);Object p=Shelter77.offset(base,d[0],d[1],d[2]);if(!Shelter77.loaded(w,p))continue;
   String id=Shelter77.id(Shelter77.state(w,p));if(!id.startsWith("minecraft:")||!id.endsWith("_log")||!Shelter77.permitted(n,p))continue;
   Object ground=Shelter77.offset(p,0,-1,0);if(!Shelter77.loaded(w,ground)||!Set.of("minecraft:dirt","minecraft:grass_block","minecraft:podzol","minecraft:coarse_dirt","minecraft:rooted_dirt","minecraft:moss_block").contains(Shelter77.id(Shelter77.state(w,ground))))continue;
   boolean leaves=false;for(int y=2;y<=10&&!leaves;y++)for(int x=-1;x<=1&&!leaves;x++)for(int z=-1;z<=1;z++){Object leaf=Shelter77.offset(p,x,y,z);if(Shelter77.loaded(w,leaf)&&Shelter77.id(Shelter77.state(w,leaf)).endsWith("_leaves")){leaves=true;break;}}
   if(leaves){camp.tree=p;camp.treeCount=0;camp.chop=0;camp.fails=0;break;}
  }
  if(camp.tree!=null)c(Shelter77.class,"gatherBase47",n,camp);
  else if(camp.scan>=list.size()){camp.scan=0;camp.fails++;if(camp.fails>=3){camp.giveUp=true;Shelter77.status(n,"sin_arboles_naturales");}else{Shelter77.wander(n,camp);camp.next=Social.time(n)+40;Shelter77.status(n,"buscar_arbol_en_otra_zona");}}
 }
 public static boolean priority(Object n){try{
  if(!Life79.calm(n)||Companion78.recruited(n)||Social.mem(n).medicalUntil>Social.time(n))return false;
  Shelter77.Camp camp=Shelter77.get(n);
  if(camp!=null&&!camp.phase.equals("descansar"))return Shelter77.work(n)&&Life79.mark(n,"construir_refugio");
  if(Activity78.roofWork(n))return Life79.mark(n,"refugiarse");return false;
 }catch(Exception e){Social.warn("shelter priority47",e);return false;}}
 public static int number(int old,String key){return key.equals("accion_ticks")?Math.min(old,10):key.equals("reintento_ticks")?Math.min(old,200):old;}

 public static void move(Object n,double x,int y,double z){
  if(Navigation78.go(n,x,y,z,.85))return;
  Shelter77.Camp camp=Shelter77.get(n);Object target=null;
  if(camp!=null){boolean needsWood=camp.index==0?Shelter77.count(DialogueRules72.bag(n),"minecraft:crafting_table")==0:Shelter77.planks(DialogueRules72.bag(n))<1;if(camp.tree!=null&&needsWood)target=camp.tree;else if(camp.index<camp.cells.size()){Shelter77.Cell cell=camp.cells.get(camp.index);target=Shelter77.pos(camp.x+cell.x(),camp.y+cell.y(),camp.z+cell.z());}}
  if(target!=null){Object world=Social.world(n),nav=c(n,"getNavigation");double tx=Shelter77.axis(target,"getX")+.5,ty=Shelter77.axis(target,"getY")+.5,tz=Shelter77.axis(target,"getZ")+.5;
   List<int[]> options=new ArrayList<>();for(int dx=-3;dx<=3;dx++)for(int dz=-3;dz<=3;dz++)if(dx*dx+dz*dz<=9)options.add(new int[]{dx,dz});
   options.sort(Comparator.comparingDouble(d->Math.pow(tx+d[0]-Social.num(c(n,"getX")),2)+Math.pow(tz+d[1]-Social.num(c(n,"getZ")),2)));
   for(int[] d:options){Object p=Shelter77.pos((int)Math.floor(tx)+d[0],y,(int)Math.floor(tz)+d[1]);if(!Shelter77.loaded(world,p)||!Shelter77.air(world,p)||!Shelter77.air(world,Shelter77.offset(p,0,1,0)))continue;
    double eye=y+1.6;if(d[0]*d[0]+d[1]*d[1]+(eye-ty)*(eye-ty)>11.5)continue;Object below=Shelter77.offset(p,0,-1,0);if(!Social.yes(c(Shelter77.state(world,below),"isFaceSturdy",world,below,SocialR.get(Social.t("net.minecraft.core.Direction"),"UP"))))continue;
    Object path=Navigation78.path(nav,tx+d[0],y,tz+d[1]);if(!Navigation78.complete(path))continue;
    Navigation78.Route legacy=Navigation78.ROUTES.get(n);if(legacy!=null)legacy.retry=0;
    if(Navigation78.go(n,tx+d[0],y,tz+d[1],.85)){Shelter77.status(n,"rodear_obra_para_alcanzar_bloque");return;}
   }
  }
  if(camp!=null){camp.wait=true;camp.next=Social.time(n)+200;}Social.mem(n).occupied=false;Shelter77.status(n,"ruta_no_disponible");
 }

 public static boolean roofWork(Object n){
  if(!Activity78.free(n))return false;Activity78.Roof r=Activity78.ROOFS.get(n);if(r==null||r.pos==null)return false;long now=Social.time(n);
  if(now>r.until||!Shelter77.loaded(Social.world(n),r.pos)||!roof(n,r.pos)){r.pos=null;return false;}
  double x=Shelter77.axis(r.pos,"getX")+.5,y=Shelter77.axis(r.pos,"getY"),z=Shelter77.axis(r.pos,"getZ")+.5;Social.mem(n).occupied=true;
  double dx=x-Social.num(c(n,"getX")),dz=z-Social.num(c(n,"getZ"));if(dx*dx+dz*dz<1){c(c(n,"getNavigation"),"stop");Hunt78.home(n,r.pos);c(Social.tag(n),"putString","npc78_actividad","descansar_bajo_techo");return true;}
  if(now<Social.l(Social.tag(n),"npc78_roof_route"))return true;c(Social.tag(n),"putLong","npc78_roof_route",now+40);
  if(!Navigation78.go(n,x,y,z,.85)){r.pos=null;r.retry=now+200;Social.mem(n).occupied=false;return false;}return true;
 }
}
