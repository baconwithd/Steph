package dev.zomboid.remains;

import java.util.*;
import java.lang.reflect.*;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockDropsEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(ZombieRemainsLoot.ID)
@EventBusSubscriber(modid=ZombieRemainsLoot.ID)
public final class ZombieRemainsLoot {
 public static final String ID="zombie_remains_loot";
 private static final Logger LOG=LoggerFactory.getLogger(ID);
 private static int ticks;
 private static boolean taczWarning;
 private static final Set<String> ZOMBIES=Set.of("minecraft:zombie","minecraft:husk","minecraft:drowned","minecraft:zombie_villager");
 private static LootSettings settings=new LootSettings();

 public ZombieRemainsLoot() {
  try{
   Object configDir=Class.forName("net.neoforged.fml.loading.FMLPaths").getField("CONFIGDIR").get(null);
   java.nio.file.Path folder=(java.nio.file.Path)configDir.getClass().getMethod("get").invoke(configDir);
   settings=LootSettings.load(folder.resolve(ID+".json"));
  }catch(Exception error){LOG.error("Cannot load corpse loot configuration; using defaults",error);}
  LOG.info("Zombie Remains Loot loaded: persistent 27-slot corpse inventories"); }
 static ResourceLocation rl(String id){return ResourceLocation.parse(id);}
 static String blockId(BlockState state){return BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();}
 static boolean remains(BlockState state){return blockId(state).startsWith("doomsday_decoration:remains_");}
 static CorpseData data(ServerLevel level){return level.getDataStorage().computeIfAbsent(new SavedData.Factory<>(CorpseData::new,CorpseData::load,net.minecraft.util.datafix.DataFixTypes.SAVED_DATA_COMMAND_STORAGE),ID);}

 @SubscribeEvent(priority=EventPriority.LOWEST)
 public static void death(LivingDropsEvent event){
  if(!(event.getEntity().level() instanceof ServerLevel level))return;
  boolean vanilla=ZOMBIES.contains(BuiltInRegistries.ENTITY_TYPE.getKey(event.getEntity().getType()).toString());
  boolean modded=settings.includeModdedZombies&&event.getEntity() instanceof net.minecraft.world.entity.monster.Zombie&&!(event.getEntity() instanceof net.minecraft.world.entity.monster.ZombifiedPiglin);
  if(!vanilla&&!modded)return;
  BlockPos origin=event.getEntity().blockPosition();
  BlockPos target=null;
  outer:for(int dy=0;dy<=2;dy++)for(int radius=0;radius<=2;radius++)for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++){
   if(Math.max(Math.abs(dx),Math.abs(dz))!=radius)continue;
   BlockPos p=origin.offset(dx,dy,dz);
   if(!level.hasChunkAt(p)||!level.isInWorldBounds(p))continue;
   BlockState existing=level.getBlockState(p);
   if(existing.canBeReplaced()&&existing.getFluidState().isEmpty()&&level.getBlockState(p.below()).isFaceSturdy(level,p.below(),Direction.UP)) {target=p;break outer;}
  }
  if(target==null)return;
  List<Block> variants=new ArrayList<>();
  for(Block b:BuiltInRegistries.BLOCK)if(BuiltInRegistries.BLOCK.getKey(b).toString().startsWith("doomsday_decoration:remains_"))variants.add(b);
  if(variants.isEmpty())return;
  BlockState state=variants.get(level.random.nextInt(variants.size())).defaultBlockState();
  if(state.hasProperty(BlockStateProperties.HORIZONTAL_FACING))state=state.setValue(BlockStateProperties.HORIZONTAL_FACING,Direction.fromYRot(event.getEntity().getYRot()));
  if(!level.setBlock(target,state,3))return;
  CorpseData store=data(level);
  Corpse corpse=new Corpse(store,blockId(state));
  store.corpses.put(target.asLong(),corpse);
  populate(corpse,level);
  // Preserve actual equipment, while replacing the normal loose zombie loot.
  for(ItemEntity drop:event.getDrops()){
   ItemStack stack=drop.getItem();
   if(stack.getItem() instanceof ArmorItem || stack.getItem() instanceof TieredItem || BuiltInRegistries.ITEM.getKey(stack.getItem()).getNamespace().equals("tacz"))add(corpse,stack.copy());
  }
  event.getDrops().clear();
  store.setDirty();
 }

 static ItemStack stack(String id,int count){
  ResourceLocation key=rl(id);
  if(!BuiltInRegistries.ITEM.containsKey(key))return ItemStack.EMPTY;
  Item item=BuiltInRegistries.ITEM.get(key);
  if(item==Items.AIR)return ItemStack.EMPTY;
  return new ItemStack(item,Math.min(count,item.getDefaultMaxStackSize()));
 }
 static void add(Corpse c,ItemStack s){
  if(s.isEmpty())return;
  for(int i=0;i<27;i++)if(c.inventory.getItem(i).isEmpty()){c.inventory.setItem(i,s);return;}
 }
 static void pick(Corpse c,ServerLevel level,String[] ids,int count,boolean worn){
  List<ItemStack> valid=new ArrayList<>();
  for(String id:ids){ItemStack s=stack(id,count);if(!s.isEmpty())valid.add(s);}
  if(valid.isEmpty())return;
  ItemStack s=valid.get(level.random.nextInt(valid.size()));
  if(worn&&s.isDamageableItem())s.setDamageValue((int)(s.getMaxDamage()*(.2+level.random.nextDouble()*.6)));
  add(c,s);
 }
 static void populate(Corpse c,ServerLevel level){
  for(int i=0,n=1+level.random.nextInt(3);i<n;i++)pick(c,level,settings.utility,1+level.random.nextInt(3),false);
  if(level.random.nextFloat()<settings.clothingChance)pick(c,level,settings.clothing,1,true);
  if(level.random.nextFloat()<settings.extraClothingChance)pick(c,level,settings.clothing,1,true);
  if(level.random.nextFloat()<settings.medicalChance)pick(c,level,settings.medical,1,false);
  if(level.random.nextFloat()<settings.rareMedicalChance)pick(c,level,settings.rareMedical,1,false);
  if(level.random.nextFloat()<settings.meleeChance)pick(c,level,meleePool(),1,true);
  if(level.random.nextFloat()<settings.gunChance)tacz(c,level,true);
  else if(level.random.nextFloat()<settings.ammoOnlyChance)tacz(c,level,false);
 }

 static String[] meleePool(){
  List<String> ids=new ArrayList<>(Arrays.asList(settings.melee));
  if(settings.includeLookinSharpMelee)for(Item item:BuiltInRegistries.ITEM){
   ResourceLocation key=BuiltInRegistries.ITEM.getKey(item);
   if(key.getNamespace().equals("lookinsharp")&&item instanceof TieredItem)ids.add(key.toString());
  }
  return ids.toArray(String[]::new);
 }

 // Resolve the live gun-pack indexes and use TACZ's own setters, including data components.
 static void tacz(Corpse c,ServerLevel level,boolean gun){
  try{
   Class<?> api=Class.forName("com.tacz.guns.api.TimelessAPI");
   Object indexes=api.getMethod(gun?"getAllCommonGunIndex":"getAllCommonAmmoIndex").invoke(null);
   List<Map.Entry<?,?>> choices=new ArrayList<>();
   for(Object entry:(Iterable<?>)indexes)if(entry instanceof Map.Entry<?,?> e)choices.add(e);
   if(choices.isEmpty())return;
   Map.Entry<?,?> chosen=choices.get(level.random.nextInt(choices.size()));
   if(gun){
    ItemStack s=stack("tacz:modern_kinetic_gun",1);if(s.isEmpty())return;
    Class<?> igun=Class.forName("com.tacz.guns.api.item.IGun");
    Object instance=igun.getMethod("getIGunOrNull",ItemStack.class).invoke(null,s);
    if(instance==null)return;
    igun.getMethod("setGunId",ItemStack.class,ResourceLocation.class).invoke(instance,s,chosen.getKey());
    Object gunData=chosen.getValue().getClass().getMethod("getGunData").invoke(chosen.getValue());
    // Empty magazine by default; a separate matching ammo stack is provided.
    try{igun.getMethod("setCurrentAmmoCount",ItemStack.class,int.class).invoke(instance,s,0);}catch(NoSuchMethodException ignored){}
    Object fireModes=gunData.getClass().getMethod("getFireModeSet").invoke(gunData);
    if(fireModes instanceof java.util.List<?> modes&&!modes.isEmpty()){
     Class<?> fireModeType=Class.forName("com.tacz.guns.api.item.gun.FireMode");
     igun.getMethod("setFireMode",ItemStack.class,fireModeType).invoke(instance,s,modes.get(0));
    }
    add(c,s);
    Object ammoId=gunData.getClass().getMethod("getAmmoId").invoke(gunData);
    addAmmo(c,(ResourceLocation)ammoId,4+level.random.nextInt(9));
   }else addAmmo(c,(ResourceLocation)chosen.getKey(),4+level.random.nextInt(9));
  }catch(ClassNotFoundException ignored){}catch(ReflectiveOperationException|RuntimeException error){
   if(!taczWarning){taczWarning=true;LOG.warn("TACZ corpse loot integration unavailable; other corpse loot remains enabled",error);}
  }
 }
 static void addAmmo(Corpse c,ResourceLocation id,int amount)throws ReflectiveOperationException{
  ItemStack ammo=stack("tacz:ammo",amount);if(ammo.isEmpty())return;
  Class<?> api=Class.forName("com.tacz.guns.api.item.IAmmo");
  Object instance=api.getMethod("getIAmmoOrNull",ItemStack.class).invoke(null,ammo);
  if(instance==null)return;
  api.getMethod("setAmmoId",ItemStack.class,ResourceLocation.class).invoke(instance,ammo,id);
  add(c,ammo);
 }

 @SubscribeEvent(priority=EventPriority.HIGHEST)
 public static void open(PlayerInteractEvent.RightClickBlock event){
  if(!remains(event.getLevel().getBlockState(event.getPos())))return;
  if(event.getLevel().isClientSide){event.setCanceled(true);event.setCancellationResult(InteractionResult.SUCCESS);return;}
  if(!(event.getLevel() instanceof ServerLevel level))return;
  CorpseData store=data(level);Corpse c=store.corpses.get(event.getPos().asLong());
  if(c==null || !c.block.equals(blockId(level.getBlockState(event.getPos()))))return;
  event.setCanceled(true);event.setCancellationResult(InteractionResult.CONSUME);
  BlockPos pos=event.getPos().immutable();
  event.getEntity().openMenu(new SimpleMenuProvider((id,inv,player)->new ChestMenu(MenuType.GENERIC_9x3,id,inv,c.inventory,3){
   @Override public boolean stillValid(Player p){return store.corpses.get(pos.asLong())==c&&blockId(level.getBlockState(pos)).equals(c.block)&&p.distanceToSqr(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5)<=64;}
  },Component.literal("Cadáver")));
 }
 @SubscribeEvent(priority=EventPriority.LOWEST)
 public static void drops(BlockDropsEvent event){
  ServerLevel level=event.getLevel();CorpseData store=data(level);Corpse c=store.corpses.get(event.getPos().asLong());
  if(c==null||!c.block.equals(blockId(event.getState())))return;
  store.corpses.remove(event.getPos().asLong());c.inventory.clearContent();store.setDirty();
  event.getDrops().clear();event.setDroppedExperience(0);
  ItemStack fresh=stack(settings.freshMeatItem,1);
  Item flesh=level.random.nextFloat()<settings.freshMeatChance&&!fresh.isEmpty()?fresh.getItem():Items.ROTTEN_FLESH;
  BlockPos p=event.getPos();event.getDrops().add(new ItemEntity(level,p.getX()+.5,p.getY()+.25,p.getZ()+.5,new ItemStack(flesh,1+level.random.nextInt(2))));
 }
 @SubscribeEvent
 public static void cleanup(ServerTickEvent.Post event){
  if(++ticks%20!=0)return;
  for(ServerLevel level:event.getServer().getAllLevels()){
   CorpseData store=data(level);
   Iterator<Map.Entry<Long,Corpse>> it=store.corpses.entrySet().iterator();
   while(it.hasNext()){
    Map.Entry<Long,Corpse> e=it.next();BlockPos pos=BlockPos.of(e.getKey());
    if(level.hasChunkAt(pos)&&!e.getValue().block.equals(blockId(level.getBlockState(pos)))){
     e.getValue().inventory.clearContent();it.remove();store.setDirty();
    }
   }
  }
 }
 static final class Corpse{
  final String block;
  final SimpleContainer inventory;
  Corpse(CorpseData owner,String block){this.block=block;inventory=new SimpleContainer(27){@Override public void setChanged(){super.setChanged();owner.setDirty();}};}
 }
 public static final class CorpseData extends SavedData{
  final Map<Long,Corpse> corpses=new HashMap<>();
  static CorpseData load(CompoundTag root,HolderLookup.Provider registries){
   CorpseData store=new CorpseData();ListTag list=root.getList("Corpses",Tag.TAG_COMPOUND);
   for(int i=0;i<list.size();i++){
    CompoundTag tag=list.getCompound(i);Corpse c=new Corpse(store,tag.getString("Block"));
    ListTag items=tag.getList("Items",Tag.TAG_COMPOUND);
    for(int j=0;j<items.size();j++){
     CompoundTag item=items.getCompound(j);int slot=item.getInt("Slot");
     if(slot>=0&&slot<27)c.inventory.setItem(slot,ItemStack.parseOptional(registries,item));
    }
    store.corpses.put(tag.getLong("Pos"),c);
   }
   store.setDirty(false);return store;
  }
  @Override public CompoundTag save(CompoundTag root,HolderLookup.Provider registries){
   ListTag list=new ListTag();
   for(Map.Entry<Long,Corpse> entry:corpses.entrySet()){
    Corpse c=entry.getValue();CompoundTag tag=new CompoundTag();tag.putLong("Pos",entry.getKey());tag.putString("Block",c.block);ListTag items=new ListTag();
    for(int i=0;i<27;i++){
     ItemStack s=c.inventory.getItem(i);if(s.isEmpty())continue;
     CompoundTag item=(CompoundTag)s.save(registries);item.putInt("Slot",i);items.add(item);
    }
    tag.put("Items",items);list.add(tag);
   }
   root.put("Corpses",list);return root;
  }
 }
}
