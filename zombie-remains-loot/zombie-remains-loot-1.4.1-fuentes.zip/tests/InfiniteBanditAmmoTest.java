import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class InfiniteBanditAmmoTest {
 static ClassNode read(ZipFile z,String name)throws Exception{ClassNode n=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class")).readAllBytes()).accept(n,0);return n;}
 public static void main(String[] a)throws Exception{try(ZipFile old=new ZipFile(a[0]);ZipFile z=new ZipFile(a[1])){
  String loot="dev/zomboid/remains/ZombieRemainsLoot.class";if(!java.util.Arrays.equals(old.getInputStream(old.getEntry(loot)).readAllBytes(),z.getInputStream(z.getEntry(loot)).readAllBytes()))throw new AssertionError("Corpse loot changed");
  ClassNode c=read(z,"dev/zomboid/remains/BanditDirector$State");if(c.fields.stream().anyMatch(f->f.name.equals("shots")))throw new AssertionError("Finite reserve retained");
  c=read(z,"dev/zomboid/remains/BanditTactics");for(var m:c.methods)for(var i:m.instructions.toArray())if(i instanceof FieldInsnNode f&&f.name.equals("shots"))throw new AssertionError("Shoot budget gate retained");
  c=read(z,"dev/zomboid/remains/GunAccess");boolean refill=false,draw=false,copy=false,empty=false;
  for(var m:c.methods)for(var i:m.instructions.toArray()){if(i instanceof MethodInsnNode call){if(m.name.equals("fire")&&call.name.equals("refillCombat"))refill=true;if(m.name.equals("emptyDrop")&&call.name.equals("copy"))copy=true;if(m.name.equals("emptyDrop")&&call.name.equals("load")&&i.getPrevious().getOpcode()==Opcodes.ICONST_0)empty=true;}if(m.name.equals("initialize")&&i instanceof LdcInsnNode l&&"draw".equals(l.cst))draw=true;}
  if(!refill||!draw||!copy||!empty)throw new AssertionError("Combat/loot isolation or gun initialization missing");
  System.out.println("PASS: infinite combat ammo, drawn weapon initialization, empty independent gun drops and unchanged finite corpse loot");
 }}
}
