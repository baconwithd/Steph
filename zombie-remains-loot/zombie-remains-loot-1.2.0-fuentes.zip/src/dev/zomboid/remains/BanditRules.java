package dev.zomboid.remains;
public final class BanditRules {
 public static int cap(int players){return Math.min(24,Math.max(1,players)*3);}
 public static int gunTier(String type,String id){
  String s=(type+" "+id).toLowerCase(java.util.Locale.ROOT);
  if(s.contains("rpg")||s.contains("rocket")||s.contains("launcher")||s.contains("grenade"))return -1;
  if(s.contains("pistol")||s.contains("m1911")||s.contains("glock")||s.contains("cz75")||s.contains("deagle"))return 0;
  if(s.contains("smg")||s.contains("submachine")||s.contains("mp5")||s.contains("vector")||s.contains("shotgun")||s.contains("db_long"))return 1;
  if(s.contains("sniper")||s.contains("machine_gun")||s.contains("lmg")||s.contains("m249")||s.contains("rpk")||s.contains("m700")||s.contains("kar98"))return 3;
  return 2;
 }
 public static double detection(boolean sneaking,boolean sprinting,boolean invisible){return invisible?3:sneaking?8:sprinting?32:20;}
 public static double spread(boolean player,double speed,int tier){return !player?2.5:speed>.08?20:Math.max(7,13-tier*2);}
 public static int delay(boolean player,int tier){return player?Math.max(22,48-tier*7):Math.max(8,20-tier*3);}
 public static int lootAmmoMax(int tier){return new int[]{3,5,8,10}[Math.max(0,Math.min(3,tier))];}
 public static int lootAmmoMin(int tier){return new int[]{1,2,3,4}[Math.max(0,Math.min(3,tier))];}
 public static float playerDamage(float raw,int tier,double speed,boolean soft){
  if(soft&&speed>.13)return 0;
  float limit=soft?2+tier*.5f:3+tier;
  return Math.min(limit,raw*(speed>.08?.12f:soft?.25f:.45f));
 }
}
