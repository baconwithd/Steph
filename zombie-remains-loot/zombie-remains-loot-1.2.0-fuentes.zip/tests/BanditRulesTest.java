import dev.zomboid.remains.BanditRules;
import dev.zomboid.remains.BanditSettings;
public final class BanditRulesTest{
 static int checks;
 public static void main(String[] args){
  check(BanditRules.cap(1)==3,"Solo cannot accumulate six bandits");check(BanditRules.cap(2)==6,"Two nearby players allow two trios");check(BanditRules.cap(100)==24,"Large parties have bounded local pressure");
  check(BanditRules.gunTier("pistol","tacz:m1911")==0,"Beginners receive pistols");check(BanditRules.gunTier("smg","tacz:hk_mp5a5")==1,"SMG progression");check(BanditRules.gunTier("rifle","tacz:ak47")==2,"Rifle progression");check(BanditRules.gunTier("sniper","tacz:m700")==3,"Advanced progression");check(BanditRules.gunTier("rifle","tacz:rpg7")==-1,"Never spawn novice RPGs");
  check(BanditRules.detection(true,false,false)<BanditRules.detection(false,false,false),"Sneaking reduces detection");check(BanditRules.detection(false,true,false)>BanditRules.detection(false,false,false),"Sprinting is easier to detect");check(BanditRules.detection(false,false,true)==3,"Invisible players are not tracked at long range");
  check(BanditRules.spread(true,.2,0)>BanditRules.spread(true,0,0),"Agile players are harder to hit");check(BanditRules.spread(false,0,0)<BanditRules.spread(true,0,0),"Bots defend better against zombies than players");
  for(int tier=0;tier<=3;tier++){
   check(BanditRules.delay(true,tier)>BanditRules.delay(false,tier),"Slow fire against player");
   check(BanditRules.lootAmmoMin(tier)<=BanditRules.lootAmmoMax(tier),"Ammo bounds coherent");
   check(BanditRules.playerDamage(1000,tier,0,false)<=3+tier,"Headshot/raw damage cannot bypass difficulty cap");
   check(BanditRules.playerDamage(10,tier,.2,false)<BanditRules.playerDamage(10,tier,0,false),"Movement damage advantage");
  }
  check(BanditRules.lootAmmoMax(0)==3,"Early weapon never yields full magazines");
  BanditSettings defaults=new BanditSettings();defaults.validate();check(!defaults.softMode,"User selected medium difficulty");
  for(int bad:new int[]{0,10,99}){BanditSettings s=new BanditSettings();s.spawnIntervalTicks=bad;boolean rejected=false;try{s.validate();}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Reject excessive spawn frequency");}
  System.out.println(checks+" bandit balance/progression/stealth checks passed");
 }
 static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
}
