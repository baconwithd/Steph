package dev.zomboid.remains;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.*;

/** Server configuration, read once during mod construction. */
public final class LootSettings {
 public double clothingChance=.70,extraClothingChance=.25,medicalChance=.40,rareMedicalChance=.05,meleeChance=.12,gunChance=.02,ammoOnlyChance=.06,freshMeatChance=.15;
 public boolean includeModdedZombies=true;
 public long zombieDecayTicks=24000;
 public int skinningCuts=3;
 public String[] extraSkinningTools={};
 public String[] utility={"minecraft:string","minecraft:paper","minecraft:stick","minecraft:flint","minecraft:iron_nugget","minecraft:leather","minecraft:torch","minecraft:apple","minecraft:bread"};
 public String[] clothing={"selfexpression:gray_jacket_leggings","selfexpression:blue_jacket_chestplate","selfexpression:simple_chestplate","selfexpression:orange_jacket_leggings","selfexpression:base_helmet","selfexpression:police_boots","selfexpression:mafia_boots","selfexpression:brown_shirt_chestplate","selfexpression:zombie_survivor_chestplate","selfexpression:stalker_leggings","selfexpression:winter_boots","selfexpression:blacksmith_boots","selfexpression:doctor_helmet","selfexpression:strict_chestplate","selfexpression:survivors_armor_chestplate"};
 public String[] medical={"firstaid:bandage","firstaid:plaster","firstaid:splint","firstaid:painkillers","firstaid:cloth","firstaid:plant_fiber","lrtactical:ibuprofen","lrtactical:ai2","lrtactical:amoxycillin","lrtactical:vaseline"};
 public String[] rareMedical={"firstaid:adrenaline_injector","firstaid:morphine_injector","firstaid:defibrillator","lrtactical:blood_pack","lrtactical:carfak","lrtactical:cms"};
 public String[] melee={"lrtactical:dagger","lrtactical:baseball_bat","lrtactical:karambit","minecraft:iron_axe","minecraft:stone_axe","minecraft:iron_shovel","minecraft:iron_sword"};
 public boolean includeLookinSharpMelee=true;
 public String freshMeatItem="minecraft:beef";
 public static LootSettings load(Path file)throws IOException{
  Gson gson=new GsonBuilder().setPrettyPrinting().create();
  if(!Files.exists(file)){
   Files.createDirectories(file.getParent());LootSettings defaults=new LootSettings();Files.writeString(file,gson.toJson(defaults)+"\n");return defaults;
  }
  LootSettings result=gson.fromJson(Files.readString(file),LootSettings.class);
  if(result==null)throw new IOException("Empty corpse loot configuration");
  result.validate();
  com.google.gson.JsonObject original=com.google.gson.JsonParser.parseString(Files.readString(file)).getAsJsonObject();
  com.google.gson.JsonObject defaults=gson.toJsonTree(result).getAsJsonObject();boolean updated=false;
  for(String field:new String[]{"zombieDecayTicks","skinningCuts","extraSkinningTools"})if(!original.has(field)){original.add(field,defaults.get(field));updated=true;}
  if(updated)Files.writeString(file,gson.toJson(original)+"\n");
  return result;
 }
 public void validate(){
  if(zombieDecayTicks<20||skinningCuts<1||skinningCuts>10)throw new IllegalArgumentException("Invalid decay ticks or skinning cuts");
  double[] chances={clothingChance,extraClothingChance,medicalChance,rareMedicalChance,meleeChance,gunChance,ammoOnlyChance,freshMeatChance};
  for(double value:chances)if(!Double.isFinite(value)||value<0||value>1)throw new IllegalArgumentException("Loot probabilities must be between 0 and 1");
  for(String[] pool:new String[][]{utility,clothing,medical,rareMedical,melee,extraSkinningTools}){
   if(pool==null)throw new IllegalArgumentException("Loot pools cannot be null");
   for(String id:pool)if(id==null||!id.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"))throw new IllegalArgumentException("Invalid item ID: "+id);
  }
  if(freshMeatItem==null||!freshMeatItem.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"))throw new IllegalArgumentException("Invalid freshMeatItem");
 }
}
