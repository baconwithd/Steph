#!/usr/bin/env python3
"""Build only this add-on; original Minecraft/mod JARs are not redistributed."""
import argparse,os,pathlib,subprocess,urllib.request,zipfile
root=pathlib.Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--minecraft',required=True,help='Path to client-1.21.1-20240808.144430-srg.jar')
parser.add_argument('--neoforge',required=True,help='Path to neoforge-21.1.255-universal.jar')
args=parser.parse_args()
lib=root/'build-libs';lib.mkdir(exist_ok=True)
artifacts=['org/eclipse/jdt/ecj/3.40.0/ecj-3.40.0.jar','com/google/guava/guava/33.3.1-jre/guava-33.3.1-jre.jar','com/google/code/gson/gson/2.11.0/gson-2.11.0.jar','org/slf4j/slf4j-api/2.0.16/slf4j-api-2.0.16.jar','org/joml/joml/1.10.5/joml-1.10.5.jar','org/jetbrains/annotations/26.0.1/annotations-26.0.1.jar']
for artifact in artifacts:
 target=lib/artifact.split('/')[-1]
 if not target.exists():urllib.request.urlretrieve('https://repo.maven.apache.org/maven2/'+artifact,target)
classes=root/'build-classes';classes.mkdir(exist_ok=True)
cp=os.pathsep.join([str(pathlib.Path(args.minecraft).resolve()),str(pathlib.Path(args.neoforge).resolve())]+[str(p) for p in lib.glob('*.jar')])
# Minimal annotation/bus signatures are compile-time helpers only; never ship them.
sources=[str(p) for folder in ('src','stubs') for p in (root/folder).rglob('*.java')]
subprocess.run(['java','-jar',str(lib/'ecj-3.40.0.jar'),'-21','-proc:none','-warn:none','-cp',cp,'-d',str(classes)]+sources,check=True)
output=root/'zombie-remains-loot-1.3.0-neoforge-1.21.1.jar'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as jar:
 jar.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nFMLModType: MOD\nImplementation-Version: 1.3.0\n\n')
 for p in (classes/'dev').rglob('*.class'):jar.write(p,p.relative_to(classes).as_posix())
 for p in (root/'resources').rglob('*'):
  if p.is_file():jar.write(p,p.relative_to(root/'resources').as_posix())
print(output)
