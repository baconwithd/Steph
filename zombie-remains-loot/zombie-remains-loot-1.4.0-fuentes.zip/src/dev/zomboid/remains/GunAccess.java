package dev.zomboid.remains;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Mob;
public final class GunAccess{
 public record Profile(ResourceLocation id,ResourceLocation ammo,int capacity,int tier,Object data){}
 private static List<Profile> cache;
 static Class<?> type(String name)throws ClassNotFoundException{return Class.forName("com.tacz.guns.api."+name);}
 static Object weapon(ItemStack gun)throws ReflectiveOperationException{return type("item.IGun").getMethod("getIGunOrNull",ItemStack.class).invoke(null,gun);}
 static Object index(ResourceLocation id)throws ReflectiveOperationException{return ((Optional<?>)type("TimelessAPI").getMethod("getCommonGunIndex",ResourceLocation.class).invoke(null,id)).orElse(null);}
 static Profile profile(ResourceLocation id,Object index)throws ReflectiveOperationException{
  if(index==null)return null;
  Object data=index.getClass().getMethod("getGunData").invoke(index);
  String kind=String.valueOf(index.getClass().getMethod("getType").invoke(index));
  ResourceLocation ammo=(ResourceLocation)data.getClass().getMethod("getAmmoId").invoke(data);
  int capacity=((Number)data.getClass().getMethod("getAmmoAmount").invoke(data)).intValue();
  return new Profile(id,ammo,Math.max(1,capacity),BanditRules.gunTier(kind,id.toString()),data);
 }
 static List<Profile> profiles()throws ReflectiveOperationException{
  if(cache!=null&&!cache.isEmpty())return cache;
  List<Profile> result=new ArrayList<>();
  try{
   Object entries=type("TimelessAPI").getMethod("getAllCommonGunIndex").invoke(null);
   for(Object obj:(Iterable<?>)entries)if(obj instanceof Map.Entry<?,?> e){Profile p=profile((ResourceLocation)e.getKey(),e.getValue());if(p!=null&&p.tier>=0)result.add(p);}
  }catch(NoSuchMethodException ignored){
   for(String id:new String[]{"glock_17","glock17","m1911","cz75","deagle","hk_mp5a5","vector45","db_long","ak47","m4a1","rpk","m249","m700","kar98k"}){
    ResourceLocation key=ResourceLocation.parse("tacz:"+id);Profile p=profile(key,index(key));if(p!=null&&p.tier>=0)result.add(p);
   }
  }
  cache=result;return result;
 }
 public static Profile describe(ItemStack gun){
  try{Object weapon=weapon(gun);if(weapon==null)return null;ResourceLocation id=(ResourceLocation)type("item.IGun").getMethod("getGunId",ItemStack.class).invoke(weapon,gun);return profile(id,index(id));}
  catch(ReflectiveOperationException|RuntimeException ignored){return null;}
 }
 public static Profile choose(int tier,net.minecraft.util.RandomSource random)throws ReflectiveOperationException{
  List<Profile> options=new ArrayList<>();
  for(Profile p:profiles())if(p.tier==tier&&(tier!=0||!p.id.getPath().contains("deagle")))options.add(p);
  if(options.isEmpty())for(Profile p:profiles())if(p.tier==tier)options.add(p);
  if(options.isEmpty()&&tier>0)return choose(tier-1,random);
  return options.isEmpty()?null:options.get(random.nextInt(options.size()));
 }
 public static ItemStack create(Profile profile,int ammoCount)throws ReflectiveOperationException{
  ItemStack gun=ZombieRemainsLoot.stack("tacz:modern_kinetic_gun",1);if(gun.isEmpty())return gun;
  Object weapon=weapon(gun);Class<?> api=type("item.IGun");
  api.getMethod("setGunId",ItemStack.class,ResourceLocation.class).invoke(weapon,gun,profile.id);
  load(gun,ammoCount);
  Object modes=profile.data.getClass().getMethod("getFireModeSet").invoke(profile.data);
  if(modes instanceof List<?> list&&!list.isEmpty())api.getMethod("setFireMode",ItemStack.class,type("item.gun.FireMode")).invoke(weapon,gun,list.get(0));
  return gun;
 }
 public static void load(ItemStack gun,int amount)throws ReflectiveOperationException{
  Object weapon=weapon(gun);Class<?> api=type("item.IGun");
  api.getMethod("setCurrentAmmoCount",ItemStack.class,int.class).invoke(weapon,gun,Math.max(0,amount));
  api.getMethod("setBulletInBarrel",ItemStack.class,boolean.class).invoke(weapon,gun,false);
 }
 public static int remaining(ItemStack gun)throws ReflectiveOperationException{
  Object weapon=weapon(gun);Class<?> api=type("item.IGun");
  int amount=((Number)api.getMethod("getCurrentAmmoCount",ItemStack.class).invoke(weapon,gun)).intValue();
  boolean barrel=Boolean.TRUE.equals(api.getMethod("hasBulletInBarrel",ItemStack.class).invoke(weapon,gun));return amount+(barrel?1:0);
 }
 public static void initialize(Mob mob)throws ReflectiveOperationException{
  Object operator=type("entity.IGunOperator").getMethod("fromLivingEntity",LivingEntity.class).invoke(null,mob);
  type("entity.IGunOperator").getMethod("initialData").invoke(operator);
 }
 public static boolean fire(Mob mob,float pitch,float yaw)throws ReflectiveOperationException{
  Class<?> api=type("entity.IGunOperator");Object operator=api.getMethod("fromLivingEntity",LivingEntity.class).invoke(null,mob);
  Supplier<Float> p=()->pitch,y=()->yaw;
  Object result=api.getMethod("shoot",Supplier.class,Supplier.class).invoke(operator,p,y);
  boolean success=result==null||String.valueOf(result).equalsIgnoreCase("SUCCESS");
  if(success)mob.swing(InteractionHand.MAIN_HAND);return success;
 }
 public static ItemStack emptyDrop(ItemStack held){
  ItemStack copy=held.copy();try{load(copy,0);}catch(ReflectiveOperationException ignored){return ItemStack.EMPTY;}
  if(copy.isDamageableItem())copy.setDamageValue(Math.min(copy.getMaxDamage()-1,Math.max(copy.getDamageValue(),copy.getMaxDamage()/3)));
  return copy;
 }
}
