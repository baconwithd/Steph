package dev.zomboid.remains;
import java.lang.reflect.*;
import java.util.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.event.entity.living.MobSpawnEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.*;
import org.slf4j.LoggerFactory;
@EventBusSubscriber(modid=ZombieRemainsLoot.ID)
public final class BanditDirector{
 static BanditSettings settings(){return ZombieRemainsLoot.settings.bandits;}
 static final Map<Player,Motion> motion=new WeakHashMap<>();
 static final Set<UUID> installed=new HashSet<>();
 static boolean warning;
 public static boolean bandit(Entity entity){return entity instanceof Mob&&BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString().equals("tacz_bandits:bandit");}
 public static State state(Mob mob){return ZombieRemainsLoot.data((ServerLevel)mob.level()).bandits.computeIfAbsent(mob.getUUID(),id->new State());}
 static void dirty(Mob mob){ZombieRemainsLoot.data((ServerLevel)mob.level()).setDirty();}
 public static GoalSelector selector(Mob mob,String field)throws ReflectiveOperationException{
  Field f=Mob.class.getDeclaredField(field);f.setAccessible(true);return (GoalSelector)f.get(mob);
 }
 static boolean visible(Mob mob,LivingEntity target){return clear(mob.level(),mob.getEyePosition(),target.getEyePosition(),mob);}
 static boolean clear(Level level,Vec3 from,Vec3 to,Entity context){return level.clip(new ClipContext(from,to,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,context)).getType()==HitResult.Type.MISS;}
 static double speed(Player player){Motion m=motion.get(player);return m==null?0:m.speed;}
 static Vec3 lagged(Player player){Motion m=motion.get(player);return m==null||m.history.isEmpty()?player.getEyePosition():m.history.peekFirst();}
 static int stationary(Player player){Motion m=motion.get(player);return m==null?0:m.stationary;}
 static void problem(Throwable error){if(!warning){warning=true;LoggerFactory.getLogger(ZombieRemainsLoot.ID).error("Bandit AI/weapon integration failed",error);}}
 @SubscribeEvent(priority=EventPriority.LOWEST)
 public static void natural(MobSpawnEvent.PositionCheck event){
  if(settings().enabled&&bandit(event.getEntity())&&event.getSpawnType()==MobSpawnType.NATURAL)event.setResult(MobSpawnEvent.PositionCheck.Result.FAIL);
 }
 @SubscribeEvent(priority=EventPriority.LOWEST)
 public static void join(EntityJoinLevelEvent event){
  if(!settings().enabled||!(event.getLevel() instanceof ServerLevel level))return;
  if(bandit(event.getEntity())){
   Mob mob=(Mob)event.getEntity();
   if(!installed.add(mob.getUUID()))return;
   try{
    selector(mob,"goalSelector").removeAllGoals(goal->goal.getClass().getName().contains("BanditShootGoal"));
    selector(mob,"targetSelector").removeAllGoals(goal->true);
    selector(mob,"goalSelector").addGoal(2,new BanditTactics(mob));
    State state=state(mob);if(state.home==null)state.home=mob.position();int tier=localTier(level,mob.position());
    if(!state.equipped||mob.getMainHandItem().isEmpty())equip(mob,Math.max(state.tier,tier));
    else attributes(mob,state.tier);
    dirty(mob);
   }catch(ReflectiveOperationException|RuntimeException error){installed.remove(mob.getUUID());problem(error);}
  }else if(event.getEntity() instanceof Zombie zombie&&!(zombie instanceof ZombifiedPiglin)){
   try{selector(zombie,"targetSelector").addGoal(3,new NearestAttackableTargetGoal<Mob>(zombie,Mob.class,10,true,false,target->bandit(target)));}
   catch(ReflectiveOperationException error){problem(error);}
  }
 }
 @SubscribeEvent public static void leave(EntityLeaveLevelEvent event){
  Entity entity=event.getEntity();if(!bandit(entity)||!(event.getLevel() instanceof ServerLevel level))return;
  installed.remove(entity.getUUID());
  if(entity.getRemovalReason()==Entity.RemovalReason.KILLED||entity.getRemovalReason()==Entity.RemovalReason.DISCARDED){
   ZombieRemainsLoot.CorpseData store=ZombieRemainsLoot.data(level);if(store.bandits.remove(entity.getUUID())!=null)store.setDirty();
  }
 }
 static void attributes(Mob mob,int tier){
  mob.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20+tier*4);
  mob.setHealth(Math.min(mob.getHealth(),mob.getMaxHealth()));
  mob.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(32+tier*4);
  mob.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(.25);
 }
 static void equip(Mob mob,int tier)throws ReflectiveOperationException{
  State state=state(mob);GunAccess.Profile p=GunAccess.choose(tier,mob.getRandom());
  if(p==null)throw new IllegalStateException("No valid pistol/weapon in the loaded TACZ packs");
  state.tier=tier;state.shots=BanditRules.combatAmmo(tier);state.gun=p.id().toString();
  ItemStack gun=GunAccess.create(p,0);combatLoad(gun,Math.min(p.capacity(),state.shots));
  mob.setItemInHand(InteractionHand.MAIN_HAND,gun);mob.setDropChance(EquipmentSlot.MAINHAND,0);
  // Neutral cosmetic variant; no RPG/sniper special goal survives the replacement.
  mob.getClass().getMethod("setVariant",int.class).invoke(mob,mob.getRandom().nextInt(2));
  for(EquipmentSlot slot:new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET}){
   mob.setItemSlot(slot,ItemStack.EMPTY);mob.setDropChance(slot,0);
  }
  if(tier==0){if(mob.getRandom().nextFloat()<.4f)mob.setItemSlot(EquipmentSlot.CHEST,new ItemStack(Items.LEATHER_CHESTPLATE));}
  else{
   String prefix=tier==1?"soviet_soldier":tier==2?"ratnik":"fsb_soldier";
   mob.setItemSlot(EquipmentSlot.HEAD,ZombieRemainsLoot.stack("fracturepoint:"+prefix+"_helmet",1));
   mob.setItemSlot(EquipmentSlot.CHEST,ZombieRemainsLoot.stack("fracturepoint:"+prefix+"_chestplate",1));
   if(mob.getItemBySlot(EquipmentSlot.CHEST).isEmpty())mob.setItemSlot(EquipmentSlot.CHEST,new ItemStack(tier>=2?Items.IRON_CHESTPLATE:Items.CHAINMAIL_CHESTPLATE));
   if(mob.getItemBySlot(EquipmentSlot.HEAD).isEmpty())mob.setItemSlot(EquipmentSlot.HEAD,new ItemStack(Items.CHAINMAIL_HELMET));
  }
  attributes(mob,tier);GunAccess.initialize(mob);state.equipped=true;dirty(mob);
 }
 static void combatLoad(ItemStack gun,int rounds)throws ReflectiveOperationException{
  GunAccess.load(gun,Math.max(0,rounds-1));
  Object weapon=GunAccess.weapon(gun);
  GunAccess.type("item.IGun").getMethod("setBulletInBarrel",ItemStack.class,boolean.class).invoke(weapon,gun,rounds>0);
 }
 static int itemTier(ItemStack item){
  if(item.isEmpty())return 0;
  GunAccess.Profile p=GunAccess.describe(item);if(p!=null)return Math.max(0,p.tier());
  String id=BuiltInRegistries.ITEM.getKey(item.getItem()).toString();
  if(id.startsWith("fracturepoint:")){
   if(id.contains("level_iv")||id.contains("killa")||id.contains("tagilla")||id.contains("beta7"))return 3;
   if(id.contains("level_iiia"))return 1;
   if(id.contains("level_iii")||id.contains("ratnik")||id.contains("fsb_")||id.contains("sso_")||id.contains("nato_"))return 2;
   if(item.getItem() instanceof ArmorItem||id.contains("plate_level_iiia"))return 1;
  }
  if(item.getItem() instanceof ArmorItem armor){int defense=armor.getDefense();return defense>=8?2:defense>=5?1:0;}
  return 0;
 }
 static int observe(ServerPlayer player){
  ZombieRemainsLoot.CorpseData store=ZombieRemainsLoot.data(player.server.overworld());int tier=store.playerTiers.getOrDefault(player.getUUID(),0);
  for(ItemStack item:player.getInventory().items)tier=Math.max(tier,itemTier(item));
  for(ItemStack item:player.getArmorSlots())tier=Math.max(tier,itemTier(item));
  tier=Math.max(tier,itemTier(player.getOffhandItem()));
  if(tier!=store.playerTiers.getOrDefault(player.getUUID(),0)){store.playerTiers.put(player.getUUID(),tier);store.setDirty();}
  return tier;
 }
 static int localTier(ServerLevel level,Vec3 point){
  int tier=0;for(ServerPlayer player:level.players())if(!player.isCreative()&&!player.isSpectator()&&player.distanceToSqr(point)<96*96)tier=Math.max(tier,ZombieRemainsLoot.data(level.getServer().overworld()).playerTiers.getOrDefault(player.getUUID(),0));return tier;
 }
 static List<Mob> nearby(Mob mob,int radius){return mob.level().getEntitiesOfClass(Mob.class,mob.getBoundingBox().inflate(radius),e->bandit(e)&&e.isAlive());}
 static void alert(Mob source,LivingEntity enemy,Vec3 position,long now){
  for(Mob ally:nearby(source,settings().alertRadius)){
   State s=state(ally);if(ally.getTarget()==null||enemy instanceof Player||ally.distanceToSqr(enemy)<16){
    boolean unaware=ally.getTarget()==null;ally.setTarget(enemy);s.lastKnown=position;s.seenAt=now;if(unaware)s.guardUntil=Math.max(s.guardUntil,now+60);dirty(ally);
   }
  }
 }
 @SubscribeEvent(priority=EventPriority.HIGHEST)
 public static void damage(LivingIncomingDamageEvent event){
  if(!settings().enabled)return;
  Entity attacker=event.getSource().getEntity();
  if(bandit(event.getEntity())&&event.getEntity().level() instanceof ServerLevel level){
   Mob mob=(Mob)event.getEntity();State s=state(mob);s.guardUntil=level.getGameTime()+160;s.cover=null;
   if(attacker instanceof LivingEntity enemy&&!bandit(enemy)){mob.setTarget(enemy);s.lastKnown=enemy.position();s.seenAt=level.getGameTime();alert(mob,enemy,s.lastKnown,s.seenAt);}dirty(mob);
  }
  if(event.getEntity() instanceof Player player&&bandit(attacker)){
   State s=state((Mob)attacker);float amount=BanditRules.playerDamage(event.getAmount(),s.tier,speed(player),settings().softMode);
   if(amount<=0)event.setCanceled(true);else event.setAmount(amount);
  }
 }
 @SubscribeEvent public static void tick(ServerTickEvent.Post event){
  if(!settings().enabled)return;
  for(ServerLevel level:event.getServer().getAllLevels()){
   long now=level.getGameTime();
   for(ServerPlayer player:level.players()){
    Motion m=motion.computeIfAbsent(player,p->new Motion(player.position()));
    double instant=Math.sqrt(player.position().subtract(m.previous).horizontalDistanceSqr());m.previous=player.position();
    m.speed=instant>2?0:Math.max(instant,m.speed*.65);m.stationary=m.speed<.025?m.stationary+1:0;
    m.history.addLast(player.getEyePosition());while(m.history.size()>7)m.history.removeFirst();
    if(now%40==0&&!player.isCreative()&&!player.isSpectator())observe(player);
   }
   if(now%settings().spawnIntervalTicks==0)spawn(level);
  }
 }
 static void spawn(ServerLevel level){
  if(level.dimension()!=Level.OVERWORLD||level.getDifficulty()==Difficulty.PEACEFUL||!BuiltInRegistries.ENTITY_TYPE.containsKey(ZombieRemainsLoot.rl("tacz_bandits:bandit")))return;
  List<ServerPlayer> players=level.players().stream().filter(p->p.isAlive()&&!p.isCreative()&&!p.isSpectator()).toList();
  Set<UUID> visited=new HashSet<>();
  for(ServerPlayer anchor:players){
   if(!visited.add(anchor.getUUID()))continue;
   List<ServerPlayer> cluster=players.stream().filter(p->p.distanceToSqr(anchor)<96*96).toList();for(ServerPlayer p:cluster)visited.add(p.getUUID());
   if(level.random.nextDouble()>settings().spawnChance)continue;
   int existing=level.getEntitiesOfClass(Mob.class,anchor.getBoundingBox().inflate(96),e->bandit(e)).size();
   int room=BanditRules.cap(cluster.size())-existing;if(room<=0)continue;
   int count=Math.min(room,1+level.random.nextInt(3));BlockPos point=null;
   for(int attempt=0;attempt<16;attempt++){
    double angle=level.random.nextDouble()*Math.PI*2;int radius=settings().minimumSpawnDistance+level.random.nextInt(settings().maximumSpawnDistance-settings().minimumSpawnDistance+1);
    int x=anchor.getBlockX()+(int)(Math.cos(angle)*radius),z=anchor.getBlockZ()+(int)(Math.sin(angle)*radius);
    BlockPos probe=new BlockPos(x,anchor.getBlockY(),z);if(!level.hasChunkAt(probe))continue;
    int y=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,z);BlockPos candidate=new BlockPos(x,y,z);
    if(!safe(level,candidate))continue;
    boolean fair=true;for(ServerPlayer player:players){if(player.distanceToSqr(Vec3.atBottomCenterOf(candidate))<24*24||player.getLookAngle().dot(Vec3.atCenterOf(candidate).subtract(player.getEyePosition()).normalize())>.2&&clear(level,player.getEyePosition(),Vec3.atCenterOf(candidate).add(0,1,0),player)){fair=false;break;}}
    if(fair){point=candidate;break;}
   }
   if(point==null)continue;
   UUID group=UUID.randomUUID();int tier=localTier(level,anchor.position());
   for(int role=0;role<count;role++){
    BlockPos pos=point.offset(role%2,0,role/2);if(!safe(level,pos))continue;
    Entity entity=BuiltInRegistries.ENTITY_TYPE.get(ZombieRemainsLoot.rl("tacz_bandits:bandit")).create(level);
    if(!(entity instanceof Mob mob))continue;
    mob.moveTo(pos.getX()+.5,pos.getY(),pos.getZ()+.5,level.random.nextFloat()*360,0);
    if(!level.noCollision(mob))continue;
    mob.finalizeSpawn(level,level.getCurrentDifficultyAt(pos),MobSpawnType.TRIGGERED,null);
    State state=state(mob);state.group=group;state.role=role;state.tier=tier;state.home=Vec3.atBottomCenterOf(point);
    try{equip(mob,tier);}catch(ReflectiveOperationException|RuntimeException error){ZombieRemainsLoot.data(level).bandits.remove(mob.getUUID());problem(error);continue;}
    if(!level.addFreshEntity(mob))ZombieRemainsLoot.data(level).bandits.remove(mob.getUUID());
   }
  }
 }
 static boolean safe(ServerLevel level,BlockPos pos){return level.isInWorldBounds(pos)&&level.getWorldBorder().isWithinBounds(pos)&&level.getBlockState(pos).isAir()&&level.getBlockState(pos.above()).isAir()&&level.getBlockState(pos.below()).isFaceSturdy(level,pos.below(),Direction.UP);}
 public static final class State{
  UUID group=UUID.randomUUID();int role,tier,shots=80;boolean equipped;String gun="";long seenAt=-1,guardUntil=0;Vec3 lastKnown,home;BlockPos cover;
  CompoundTag save(UUID id){CompoundTag t=new CompoundTag();t.putUUID("Id",id);t.putUUID("Group",group);t.putInt("Role",role);t.putInt("Tier",tier);t.putInt("Shots",shots);t.putInt("CombatRevision",2);t.putBoolean("Equipped",equipped);t.putString("Gun",gun);if(home!=null){t.putDouble("HomeX",home.x);t.putDouble("HomeY",home.y);t.putDouble("HomeZ",home.z);}return t;}
  static State load(CompoundTag t){State s=new State();if(t.hasUUID("Group"))s.group=t.getUUID("Group");s.role=t.getInt("Role");s.tier=Math.max(0,Math.min(3,t.getInt("Tier")));s.shots=t.getInt("Shots");if(t.getInt("CombatRevision")<2)s.shots=(int)Math.ceil(Math.max(0,s.shots)*(double)BanditRules.combatAmmo(s.tier)/(12+s.tier*12));s.equipped=t.getBoolean("Equipped");s.gun=t.getString("Gun");if(t.contains("HomeX"))s.home=new Vec3(t.getDouble("HomeX"),t.getDouble("HomeY"),t.getDouble("HomeZ"));return s;}
 }
 static final class Motion{Vec3 previous;double speed;int stationary;ArrayDeque<Vec3> history=new ArrayDeque<>();Motion(Vec3 point){previous=point;}}
}
