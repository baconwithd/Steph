import dev.zomboid.remains.LootSettings;
import java.nio.file.*;
public final class SettingsTest{
 public static void main(String[] args)throws Exception{
  Path dir=Files.createTempDirectory("corpse-settings-test");Path file=dir.resolve("config.json");
  LootSettings first=LootSettings.load(file);
  check(Files.exists(file),"Creates config");check(first.gunChance==.02,"Rare guns default");
  LootSettings second=LootSettings.load(file);
  check(second.medical.length==first.medical.length,"Config round trip");
  Files.writeString(file,"{\"gunChance\":0.001,\"medical\":[],\"freshMeatItem\":\"minecraft:porkchop\"}");
  LootSettings custom=LootSettings.load(file);
  check(custom.gunChance==.001&&custom.medical.length==0,"Custom settings and disabled loot pool");
  check(custom.clothingChance==.7,"Omitted settings retain defaults");
  check(custom.zombieDecayTicks==24000,"20-minute decay default for old config");
  check(Files.readString(file).contains("zombieDecayTicks"),"Adds new fields to old config");
  check(custom.skinningCuts==3,"Three cuts to bones");
  for(String invalid:new String[]{"{\"gunChance\":2}","{\"zombieDecayTicks\":0}","{\"skinningCuts\":0}","{\"extraSkinningTools\":null}","{\"medical\":null}","{\"melee\":[\"wrong ID\"]}","null","{broken"}){
   Files.writeString(file,invalid);boolean failed=false;
   try{LootSettings.load(file);}catch(Exception e){failed=true;}
   check(failed,"Reject malformed config: "+invalid);
  }
  Files.delete(file);Files.delete(dir);System.out.println("16 configuration checks passed");
 }
 static void check(boolean result,String message){if(!result)throw new AssertionError(message);}
}
