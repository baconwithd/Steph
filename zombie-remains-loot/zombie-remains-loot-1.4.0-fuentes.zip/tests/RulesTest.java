import dev.zomboid.remains.RemainsRules;
public final class RulesTest{
 static int count;
 public static void main(String[] args){
  // Regression: #111 shown in the user's screenshot is a seated pose, never a floor pose.
  check(RemainsRules.family("doomsday_decoration:remains_111")==1,"Identify #111");
  check(!RemainsRules.floor(1)&&RemainsRules.wall(1),"#111 requires wall");
  for(int family=1;family<=10;family++)for(int cuts=0;cuts<3;cuts++)check(RemainsRules.family(RemainsRules.variant(family,cuts))==family,"Stage preserves pose family");
  for(int family:RemainsRules.FLOOR)check(!RemainsRules.wall(family),"Floor variants never seated");
  for(int family:RemainsRules.WALL)check(!RemainsRules.floor(family),"Wall variants never floor");
  for(int excluded:new int[]{6,7,10})check(!RemainsRules.floor(excluded)&&!RemainsRules.wall(excluded),"Exclude hanging/impaled model");
  check(!RemainsRules.decayed(100,24099,24000),"Still flesh immediately before 20 minutes");
  check(RemainsRules.decayed(100,24100,24000),"Skeleton at 20 minutes");
  check(RemainsRules.decayed(100,100000,24000),"Unloaded corpse ages with game clock");
  check(!RemainsRules.decayed(-1,100000,24000),"Old saves get migration timestamp");
  check(!RemainsRules.decayed(1000,500,24000),"Clock reversal does not cause instant rot");
  check(RemainsRules.harvestReady(-1,0),"First skinning works at world tick zero");
  check(!RemainsRules.harvestReady(500,500),"Duplicate hand/event does not harvest twice");
  check(!RemainsRules.harvestReady(500,509)&&RemainsRules.harvestReady(500,510),"Half-second skinning cooldown");
  for(String knife:new String[]{"minecraft:diamond_sword","lookinsharp:combat_knife","lrtactical:dagger","lrtactical:karambit","custom:cuchillo","custom:machete"})check(RemainsRules.bladeName(knife),"Blade supported: "+knife);
  for(String tool:new String[]{"minecraft:stick","lrtactical:baseball_bat","minecraft:iron_shovel"})check(!RemainsRules.bladeName(tool),"Non-blade never skins");
  System.out.println(count+" corpse placement/lifecycle/tool checks passed");
 }
 static void check(boolean result,String message){count++;if(!result)throw new AssertionError(message);}
}
