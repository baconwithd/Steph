import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class ReleaseContractsTest {
 static ClassNode read(String jar,String name)throws Exception{try(ZipFile z=new ZipFile(jar)){ClassNode n=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class")).readAllBytes()).accept(n,0);return n;}}
 public static void main(String[] a)throws Exception{
  ClassNode c=read(a[0],"dev/zomboid/hordes/ZombieCombat");boolean reach=false;
  for(MethodNode m:c.methods){for(var i:m.instructions.toArray()){if(m.name.equals("allowAttack")&&i instanceof MethodInsnNode call&&call.owner.endsWith("WoundRules")&&call.name.equals("ready"))throw new AssertionError("Contact timer retained");if(m.name.equals("reach")&&i instanceof LdcInsnNode l&&Double.valueOf(2).equals(l.cst))reach=true;}}
  if(!reach)throw new AssertionError("Missing +2 reach");
  c=read(a[0],"dev/zomboid/hordes/mixin/ZombieAttackCooldownMixin");boolean zero=false,scoped=false;
  for(var m:c.methods)for(var i:m.instructions.toArray()){if(i instanceof FieldInsnNode f&&f.name.equals("ticksUntilNextAttack")&&f.getOpcode()==Opcodes.PUTFIELD&&i.getPrevious().getOpcode()==Opcodes.ICONST_0)zero=true;if(i instanceof TypeInsnNode t&&t.getOpcode()==Opcodes.INSTANCEOF&&t.desc.endsWith("/Zombie"))scoped=true;}
  if(!zero||!scoped)throw new AssertionError("Cooldown change not scoped to zombies");
  c=read(a[1],"dev/zomboid/remains/ZombieRemainsLoot$CorpseData");boolean saves=false,loads=false;
  for(var m:c.methods)for(var i:m.instructions.toArray())if(i instanceof LdcInsnNode l&&"Quality".equals(l.cst)){if(m.name.equals("save"))saves=true;if(m.name.equals("load"))loads=true;}
  if(!saves||!loads)throw new AssertionError("Rarity not persisted");
  System.out.println("PASS: +2 reach, no contact timer, zombie-only cooldown removal and persistent corpse quality");
 }
}
