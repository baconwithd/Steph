import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class MutantReleaseTest{
 static ClassNode read(ZipFile z,String name)throws Exception{ClassNode n=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class")).readAllBytes()).accept(n,0);return n;}
 public static void main(String[] a)throws Exception{try(ZipFile z=new ZipFile(a[0])){
  ClassNode c=read(z,"dev/zomboid/remains/ZombieRemainsLoot$CorpseData");boolean save=false,load=false,limit=false;
  for(var m:c.methods)for(var i:m.instructions.toArray()){if(i instanceof LdcInsnNode l&&"Mutant".equals(l.cst)){if(m.name.equals("save"))save=true;if(m.name.equals("load"))load=true;}if(m.name.equals("load")&&i instanceof MethodInsnNode call&&call.name.equals("getContainerSize"))limit=true;}
  if(!save||!load||!limit)throw new AssertionError("Mutant size not persisted/restored");
  c=read(z,"dev/zomboid/remains/ZombieRemainsLoot$Corpse");boolean expanded=false;for(var m:c.methods)for(var i:m.instructions.toArray())if(i instanceof IntInsnNode v&&v.operand==54)expanded=true;if(!expanded)throw new AssertionError("No expanded inventory");
  c=read(z,"dev/zomboid/remains/MutantIntegration");int permanent=0,guard=0;for(var m:c.methods)if(m.name.equals("join"))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call){if(call.name.equals("addPermanentModifier"))permanent++;if(call.name.equals("hasModifier"))guard++;}if(permanent!=2||guard!=2)throw new AssertionError("Repeat application or health persistence risk");
  System.out.println("PASS: 54 slots, persistent mutant flag, full-slot loading and guarded permanent attribute boosts");
 }}
}
