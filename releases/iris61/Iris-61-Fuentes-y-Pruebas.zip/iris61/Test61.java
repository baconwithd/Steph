package dev.zomboid.iriskeys;
import net.minecraft.client.*;import com.mojang.blaze3d.platform.InputConstants;
public class Test61{
 static void check(boolean v,String reason){if(!v)throw new AssertionError(reason);}
 static void reset(){Reload61.checked=Reload61.pending=Reload61.latched=false;Reload61.lastKey=Reload61.heldKey=-1;Minecraft.INSTANCE.screen=null;Minecraft.INSTANCE.player=new net.minecraft.client.player.LocalPlayer();Minecraft.INSTANCE.level=new net.minecraft.client.multiplayer.ClientLevel();}
 static void type(int key,int point,int mods){Reload61.key(7,key,0,1,mods);Reload61.character(7,point,mods);}
 public static void main(String[]a){reset();KeyMapping b=new KeyMapping(82);b.clicks=1;check(!Reload61.consume(b),"old R still reloads");check(b.getKey().getValue()==93&&KeyMapping.resets==1,"saved R not migrated");
 type(93,125,1);b.clicks=1;check(Reload61.consume(b),"US shift brace");check(!Reload61.consume(b),"double reload");Reload61.key(7,93,0,2,1);Reload61.character(7,125,1);check(!Reload61.consume(b),"autorepeat");Reload61.key(7,93,0,0,0);type(93,125,1);check(Reload61.consume(b),"second physical press");Reload61.key(7,93,0,0,0);
 type(93,93,0);b.clicks=1;check(!Reload61.consume(b),"right bracket mistaken for brace");type(92,125,6);check(Reload61.consume(b),"Spanish AltGr brace");Reload61.key(7,92,0,0,0);
 Minecraft.INSTANCE.screen=new net.minecraft.client.gui.screens.Screen();type(92,125,6);check(!Reload61.consume(b),"chat/menu typing reload");Minecraft.INSTANCE.screen=null;check(!Reload61.consume(b),"menu leaked reload");
 Reload61.key(8,92,0,1,6);Reload61.character(8,125,6);check(!Reload61.consume(b),"foreign window");Minecraft.INSTANCE.player=null;type(92,125,6);check(!Reload61.consume(b),"no player");Minecraft.INSTANCE.player=new net.minecraft.client.player.LocalPlayer();Minecraft.INSTANCE.level=null;type(92,125,6);check(!Reload61.consume(b),"no world");
 reset();KeyMapping custom=new KeyMapping(80);custom.clicks=1;check(Reload61.consume(custom),"custom controls binding broken");check(custom.getKey().getValue()==80,"custom mapping overwritten");custom.setKey(InputConstants.Type.KEYSYM.getOrCreate(82));custom.clicks=1;check(Reload61.consume(custom),"intentional later R rebind broken");
 System.out.println("PASS: literal } on US and Spanish-style layouts; no ], old R, chat/menu, foreign window or autorepeat; one reload per press; saved-R migration and custom bindings preserved");
 }
}
