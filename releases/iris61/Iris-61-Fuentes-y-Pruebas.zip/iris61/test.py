from pathlib import Path
import subprocess,zipfile,json
r=Path(__file__).resolve().parent;jar=next((r/'output').glob('*.jar'));st=r/'build/stubs';t=r/'build/test';t.mkdir(exist_ok=True);results=[]
def run(args):
 p=subprocess.run(args,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();return p.stdout.strip()
run(['java','com.sun.tools.javac.Main','-cp',str(jar)+':'+str(st),'-d',str(t),str(r/'Test61.java')]);results.append(run(['java','-Xverify:all','-cp',str(t)+':'+str(jar)+':'+str(st),'dev.zomboid.iriskeys.Test61']))
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree']];run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(t),str(r/'Contract61.java')]);results.append(run(['java',*f,'-cp',str(t),'Contract61',str(jar)]))
base=r.parents[1]/'attachments/ef796b64-4ca1-40d3-9766-f0f20204d781/iris-neoforge-1.8.14-beta.1+mc1.21.1.jar'
with zipfile.ZipFile(base)as a,zipfile.ZipFile(jar)as b:
 changed=sorted(n for n in a.namelist()if a.read(n)!=b.read(n));added=sorted(set(b.namelist())-set(a.namelist()));assert changed==['mixins.iris.json','net/irisshaders/iris/Iris.class'];assert added==['dev/zomboid/iriskeys/Reload61.class','net/irisshaders/iris/mixin/MixinReloadBrace61.class'];assert not any(n.startswith('net/minecraft/')or n.startswith('com/mojang/')for n in added);assert 'MixinReloadBrace61'in json.loads(b.read('mixins.iris.json'))['client']
(r/'output/test-results.json').write_text(json.dumps({'results':results,'changed':changed,'added':added,'full_minecraft_runtime':False},indent=2))
