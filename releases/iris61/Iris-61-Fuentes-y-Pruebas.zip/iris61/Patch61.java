import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;import java.util.*;
public class Patch61 extends Patch52{
 static final String H="dev/zomboid/iriskeys/Reload61";
 static void handler(ClassNode c,String name,String target,String desc,boolean key){var m=new MethodNode(ACC_PRIVATE,name,desc,null,null);var inject=new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/Inject;");var at=new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/At;");at.values=List.of("value","HEAD");inject.values=List.of("method",List.of(target),"at",List.of(at),"require",1,"remap",false);m.visibleAnnotations=List.of(inject);m.instructions.add(new VarInsnNode(LLOAD,1));for(int i=3;i<=(key?6:4);i++)m.instructions.add(new VarInsnNode(ILOAD,i));m.instructions.add(call(H,key?"key":"character",key?"(JIIII)V":"(JII)V"));m.instructions.add(new InsnNode(RETURN));c.methods.add(m);}
 public static void main(String[]a)throws Exception{load(a[0]);overlay(a[1]);var c=read("net/irisshaders/iris/Iris");int defaultKey=0,consume=0;
 for(var m:c.methods){boolean reload=false;for(var n:m.instructions.toArray()){if(n instanceof LdcInsnNode l&&l.cst.equals("iris.keybind.reload"))reload=true;if(reload&&n instanceof IntInsnNode i&&i.operand==82){i.operand=93;defaultKey++;reload=false;}
 if(m.name.equals("handleKeybinds")&&n instanceof MethodInsnNode i&&i.owner.equals("net/minecraft/client/KeyMapping")&&i.name.equals("consumeClick")&&n.getPrevious() instanceof FieldInsnNode f&&f.name.equals("reloadKeybind")){i.setOpcode(INVOKESTATIC);i.owner=H;i.name="consume";i.desc="(Lnet/minecraft/client/KeyMapping;)Z";i.itf=false;consume++;}}}
 if(defaultKey!=1||consume!=1)throw new AssertionError("reload hooks "+defaultKey+" "+consume);write(c);
 var mix=new ClassNode();mix.version=V21;mix.access=ACC_PUBLIC|ACC_ABSTRACT;mix.name="net/irisshaders/iris/mixin/MixinReloadBrace61";mix.superName="java/lang/Object";var annotation=new AnnotationNode("Lorg/spongepowered/asm/mixin/Mixin;");annotation.values=List.of("targets",List.of("net.minecraft.client.KeyboardHandler"),"remap",false);mix.invisibleAnnotations=List.of(annotation);
 handler(mix,"iris61$character","charTyped(JII)V","(JIILorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V",false);
 handler(mix,"iris61$key","keyPress(JIIII)V","(JIIIILorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V",true);write(mix);
 String config=new String(data.get("mixins.iris.json"),java.nio.charset.StandardCharsets.UTF_8);config=config.replace("\"DimensionTypeAccessor\"","\"MixinReloadBrace61\",\"DimensionTypeAccessor\"");if(!config.contains("MixinReloadBrace61"))throw new AssertionError("mixin config");data.put("mixins.iris.json",config.getBytes(java.nio.charset.StandardCharsets.UTF_8));save(a[2]);
 }
}
