package com.mojang.blaze3d.platform;public class Window{public long getWindow(){return 7;}}
