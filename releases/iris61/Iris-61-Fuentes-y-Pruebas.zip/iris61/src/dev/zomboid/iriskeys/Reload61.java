package dev.zomboid.iriskeys;
import net.minecraft.client.Minecraft;import net.minecraft.client.KeyMapping;import com.mojang.blaze3d.platform.InputConstants;
/** A layout-independent brace shortcut, routed through Iris' original reload/error handling. */
public final class Reload61 {
 static boolean checked,pending,latched;static int lastKey=-1,heldKey=-1;
 static boolean ready(Minecraft mc){return mc!=null&&mc.player!=null&&mc.level!=null&&mc.screen==null;}
 static boolean window(Minecraft mc,long handle){return mc!=null&&mc.getWindow().getWindow()==handle;}
 public static void key(long handle,int key,int scan,int action,int mods){Minecraft mc=Minecraft.getInstance();if(!window(mc,handle))return;if(action==1){lastKey=key;if(key==heldKey)latched=false;}else if(action==0&&key==heldKey){latched=false;heldKey=-1;}}
 public static void character(long handle,int point,int mods){Minecraft mc=Minecraft.getInstance();if(point!=125||!window(mc,handle)||!ready(mc)||latched)return;pending=true;latched=true;heldKey=lastKey;}
 public static boolean consume(KeyMapping binding){
  // Migrate the old R binding once, after Options has read options.txt. Other custom bindings stay configurable.
  if(!checked){checked=true;if(binding.getKey().getType()==InputConstants.Type.KEYSYM&&binding.getKey().getValue()==82){binding.setKey(InputConstants.Type.KEYSYM.getOrCreate(93));KeyMapping.resetMapping();}}
  boolean click=false;while(binding.consumeClick())click=true;Minecraft mc=Minecraft.getInstance();boolean brace=pending;pending=false;if(!ready(mc))return false;
  boolean literalDefault=binding.getKey().getType()==InputConstants.Type.KEYSYM&&binding.getKey().getValue()==93;
  return brace||(!literalDefault&&click);
 }
}
