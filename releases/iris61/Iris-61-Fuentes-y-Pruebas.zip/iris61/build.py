from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;o=r/'output';o.mkdir(exist_ok=True);st=r/'build/stubs';st.mkdir(parents=True,exist_ok=True);cl=r/'build/helper';cl.mkdir(exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-d',str(st),*map(str,(r/'stubs').rglob('*.java'))],check=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(st),'-d',str(cl),*map(str,(r/'src').rglob('*.java'))],check=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']];t=r/'build/tools';t.mkdir(exist_ok=True)
subprocess.run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(t),str(r.parent/'medical52/Patch52.java'),str(r/'Patch61.java')],check=True)
base=r.parents[1]/'attachments/ef796b64-4ca1-40d3-9766-f0f20204d781/iris-neoforge-1.8.14-beta.1+mc1.21.1.jar'
subprocess.run(['java',*f,'-cp',str(t),'Patch61',str(base),str(cl),str(o/'iris-neoforge-1.8.14-beta.1+mc1.21.1-reload-brace.1.jar')],check=True)
