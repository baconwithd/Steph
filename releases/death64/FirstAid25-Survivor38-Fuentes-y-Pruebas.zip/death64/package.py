from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).resolve().parent;o=r/'output';d=r/'dist';d.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[r.parents[1]/'attachments/55182a59-077a-4aa8-a5dc-c506b79e2c9c/firstaid-1.21.1-ZOMBOID-v3.6.24-unified-health-splint-game.jar',r.parents[1]/'attachments/251699a4-0273-48f9-892b-924645faf2de/survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v37-package-conflict-fix.jar']
manifest={'release':'death64','minecraft':'1.21.1','loader':'NeoForge','inputs':[{'file':p.name,'sha256':digest(p)}for p in inputs],'outputs':[{'file':p.name,'bytes':p.stat().st_size,'sha256':digest(p)}for p in sorted(o.glob('*.jar'))],'full_modpack_runtime_tested':False,'replace_both_client_and_server':True}
(o/'manifest.json').write_text(json.dumps(manifest,indent=2));(o/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n'for p in sorted(o.iterdir())if p.name!='SHA256SUMS.txt'))
with zipfile.ZipFile(d/'FirstAid25-Survivor38-Muerte-PZ.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.iterdir()):z.write(p,p.name)
with zipfile.ZipFile(d/'FirstAid25-Survivor38-Fuentes-y-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','survivor-src','tests','compile-stubs','assets']:
  for p in sorted((r/folder).rglob('*')):
   if p.is_file():z.write(p,'death64/'+str(p.relative_to(r)))
 for name in ['Patch64.java','Contract64.java','build.py','test.py','package.py']:z.write(r/name,'death64/'+name)
 z.write(r.parent/'medical52/Patch52.java','medical52/Patch52.java')
 for name in ['LEEME.md','manifest.json','test-results.json']:z.write(o/name,'death64/'+name)
 z.writestr('death64/BUILD.md','Requires JDK 21+. Set FIRSTAID_BASE and SURVIVOR_BASE to the absolute paths of the input JARs listed in manifest.json. Run python build.py. Tests use minimal fixtures under tests and execute new production code against the built JARs. Run python test.py with the same input environment variables. Annotation stubs are compile-only. The font license is bundled under assets. No full Minecraft visual runtime validation is claimed.\n')
for p in d.glob('*.zip'):
 with zipfile.ZipFile(p)as z:assert z.testzip()is None
 print(p.name,p.stat().st_size,digest(p))
