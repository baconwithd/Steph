from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;t=r/'frame-tests';t.mkdir(exist_ok=True)
f={
'net/flashlight/battery/Capture53.java':'package net.flashlight.battery;public class Capture53{public static boolean enabled=true;public static boolean active(){return enabled;}}',
'net/flashlight/battery/Engine6.java':'package net.flashlight.battery;public class Engine6{public static String trace="";public static void render(Object e){trace+="F";}}',
'net/flashlight/battery/Light6.java':'package net.flashlight.battery;public class Light6{public static class Target{public void bindWrite(boolean b){}}public static class MC{public Object level=new Object();public Target getMainRenderTarget(){return new Target();}}public static MC instance=new MC();public static Object mc(){return instance;}}',
'org/joml/Matrix4f.java':'package org.joml;public class Matrix4f{public int value;public Matrix4f(){}public Matrix4f(Matrix4f a){value=a.value;}}',
'com/hyrrx/hardcoretruedarkness/client/FinalDarknessPostProcessor.java':'package com.hyrrx.hardcoretruedarkness.client;public class FinalDarknessPostProcessor{public static void nativeApply53(float p){net.flashlight.battery.Engine6.trace+="D";}}',
'net/flashlight/battery/FrameTest.java':'''package net.flashlight.battery;public class FrameTest{public static class Tracker{public float getGameTimeDeltaPartialTick(boolean b){return .3f;}}public static class Camera{public Object getPosition(){return new Object();}public boolean isDetached(){return false;}}public static class Event{public org.joml.Matrix4f m=new org.joml.Matrix4f();public Object getStage(){return "AFTER_LEVEL";}public Object getModelViewMatrix(){return m;}public Object getProjectionMatrix(){return m;}public Tracker getPartialTick(){return new Tracker();}public Camera getCamera(){return new Camera();}}static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError(n);}public static void main(String[]a){Event e=new Event();e.m.value=4;Frame53.stage(e);ok(Engine6.trace.isEmpty());e.m.value=9;ok(((org.joml.Matrix4f)Frame53.pending.getModelViewMatrix()).value==4);ok(Frame53.deferDarkness(.3f));Frame53.flush();ok(Engine6.trace.equals("FD"));Frame53.flush();ok(Engine6.trace.equals("FD"));Frame53.stage(e);Frame53.deferDarkness(.4f);Light6.instance.level=new Object();Frame53.flush();ok(Engine6.trace.equals("FD"));Capture53.enabled=false;Frame53.stage(e);ok(Engine6.trace.equals("FDF"));ok(!Frame53.deferDarkness(.4f));System.out.println("DEFERRED_FRAME_ORDER_SNAPSHOT_WORLD_CHANGE_CHECKS="+n);}}'''
}
for name,s in f.items():p=t/name;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(s)
j=next((r/'output').glob('flashlight*.jar'));c=t/'classes';c.mkdir(exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(j),'-d',str(c),*[str(t/n) for n in f]],check=True)
subprocess.run(['java','-cp',str(c)+':'+str(j),'net.flashlight.battery.FrameTest'],check=True)
