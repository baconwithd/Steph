package net.flashlight.battery;
import java.util.List;
public final class Capture53 {
 static boolean shaderFrame,warned,blocked;static Object world;static int badWidth,badHeight;
 static boolean active(){try{return Boolean.TRUE.equals(R.call(R.call(R.type("net.irisshaders.iris.api.v0.IrisApi"),"getInstance"),"isShaderPackInUse"));}catch(IllegalStateException e){if(e.getCause() instanceof ClassNotFoundException)return false;throw e;}}
 public static boolean capture(Object event){shaderFrame=active();if(!shaderFrame)return false;Engine6.ready=false;Object mc=Light6.mc(),current=R.get(mc,"level");if(current!=world){world=current;blocked=false;}if(current==null||R.get(mc,"player")==null)return true;Object target=R.call(mc,"getMainRenderTarget");int w=G6.i(R.get(target,"width")),h=G6.i(R.get(target,"height"));if(blocked&&w==badWidth&&h==badHeight)return true;if(Engine6.busy)return true;float partial=((Number)R.call(R.call(event,"getPartialTick"),"getGameTimeDeltaPartialTick",false)).floatValue();List<Light6.Lamp> lamps=Light6.render(partial);if(lamps.isEmpty())return true;Engine6.busy=true;Errors18.incoming("scene copy",()->G6.i(G6.gl(11,"glGetError")));
 try(G6.State saved=new G6.State()){
  int source=saved.draw;int color=G6.i(G6.gl(11,"glGetInteger",34853)); // GL_DRAW_BUFFER0
  G6.gl(15,"glBindBuffer",35052,0);Engine6.divisor=1;Engine6.init();Engine6.resize(w,h);
  G6.gl(30,"glBindFramebuffer",36008,source);int oldRead=G6.i(G6.gl(11,"glGetInteger",3074));
  try{G6.gl(11,"glReadBuffer",color);G6.bind(0,Engine6.albedo);G6.gl(11,"glCopyTexSubImage2D",3553,0,0,0,0,0,w,h);G6.bind(0,Engine6.depthBuffer);G6.gl(11,"glCopyTexSubImage2D",3553,0,0,0,0,0,w,h);}finally{G6.gl(11,"glReadBuffer",oldRead);}
  Errors18.check("single scene copy",()->G6.i(G6.gl(11,"glGetError")));Engine6.ready=true;
 }catch(RuntimeException e){blocked=true;badWidth=w;badHeight=h;Engine6.ready=false;if(!warned){warned=true;System.err.println("[Flashlight53] Scene copy stopped to avoid retry flashes; change world/resolution after fixing the error: "+e);}}finally{Engine6.busy=false;}return true;
 }
 public static int depth(int nativeTexture){return nativeTexture;}
 public static void integer(int program,String name,int value){G6.integer(program,name,value);if(name.equals("Count"))G6.scalar(program,"CapturedLit",shaderFrame?1f:0f);}
}
