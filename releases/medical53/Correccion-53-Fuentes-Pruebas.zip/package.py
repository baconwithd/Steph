from pathlib import Path
import zipfile,hashlib,json
r=Path(__file__).resolve().parent;o=r/'output';d=r/'dist';d.mkdir(exist_ok=True)
files=[dict(name=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in sorted(o.glob('*.jar'))]
(o/'manifest.json').write_text(json.dumps({'release':53,'files':files},indent=2))
(o/'SHA256SUMS.txt').write_text(''.join(x['sha256']+'  '+x['name']+'\n'for x in files))
(o/'test-results.json').write_text(json.dumps({'shader_compile_link':'Mesa llvmpipe PASS','framebuffer_copy_formats':['D24','D32F','D24S8'],'armor_helper_fixture_checks':11,'deferred_frame_fixture_checks':8,'prior_regressions':json.loads((o/'regressions.json').read_text()),'full_minecraft_modpack_run':False,'bytecode_verification_log':(r/'verification.log').read_text()},indent=2))
with zipfile.ZipFile(d/'Correccion-53-Iris-Armadura-Pose.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.glob('*.jar')):z.write(p,'mods/'+p.name)
 for n in ['LEEME.md','manifest.json','SHA256SUMS.txt','test-results.json']:z.write(o/n,n)
with zipfile.ZipFile(d/'Correccion-53-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','flash-src','dark-src','armor-tests','frame-tests']:
  for p in (r/folder).rglob('*.java'):z.write(p,str(p.relative_to(r)))
 for n in ['build.py','Patch53.java','portable6.frag','test_armor.py','test_frame.py','copy_test.py','shader_test.py','regressions.py','package.py','verification.log']:z.write(r/n,n)
 z.write(r.parent/'medical52/Patch52.java','base-tools/Patch52.java')
 for n in ['LEEME.md','test-results.json']:z.write(o/n,n)
for p in d.glob('*.zip'):
 with zipfile.ZipFile(p)as z:assert z.testzip() is None
print('DELIVERY_ZIP_CRC=PASS')
