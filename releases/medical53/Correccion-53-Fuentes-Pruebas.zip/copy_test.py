from pathlib import Path
exec(Path('work/medical52/shader_test.py').read_text().split('shaders=[]')[0])
# Actual OpenGL copy used by Capture53, including conversion of source depth formats.
bind=fn(g,'glBindTexture',None,[U,U]);gen=fn(g,'glGenTextures',None,[I,C.POINTER(U)]);image=fn(g,'glTexImage2D',None,[U,I,I,I,I,I,U,U,P]);copy=fn(g,'glCopyTexSubImage2D',None,[U,I,I,I,I,I,I,I]);error=fn(g,'glGetError',U,[])
fbo=U();fn(g,'glGenFramebuffers',None,[I,C.POINTER(U)])(1,C.byref(fbo));fn(g,'glBindFramebuffer',None,[U,U])(0x8D40,fbo)
def texture(fmt,external,ty):
 n=U();gen(1,C.byref(n));bind(0xDE1,n);image(0xDE1,0,fmt,4,4,0,external,ty,None);return n
attach=fn(g,'glFramebufferTexture2D',None,[U,U,U,U,I]);color=texture(0x8058,0x1908,0x1401);attach(0x8D40,0x8CE0,0xDE1,color,0)
for fmt,external,ty in [(0x81A6,0x1902,0x1406),(0x8CAC,0x1902,0x1406),(0x88F0,0x84F9,0x84FA)]:
 src=texture(fmt,external,ty);attach(0x8D40,0x8D00,0xDE1,src,0);assert fn(g,'glCheckFramebufferStatus',U,[U])(0x8D40)==0x8CD5
 fn(g,'glClearColor',None,[C.c_float]*4)(.25,.5,.75,1);fn(g,'glClearDepth',None,[C.c_double])(.4);fn(g,'glClear',None,[U])(0x4100)
 dest=texture(0x81A6,0x1902,0x1406);copy(0xDE1,0,0,0,0,0,4,4);assert error()==0,hex(fmt)
 pixels=(C.c_float*16)();fn(g,'glGetTexImage',None,[U,I,U,U,P])(0xDE1,0,0x1902,0x1406,pixels);assert all(abs(x-.4)<1e-4 for x in pixels)
 destColor=texture(0x8058,0x1908,0x1401);copy(0xDE1,0,0,0,0,0,4,4);assert error()==0
 pixelsColor=(C.c_ubyte*64)();fn(g,'glGetTexImage',None,[U,I,U,U,P])(0xDE1,0,0x1908,0x1401,pixelsColor);assert abs(pixelsColor[0]-64)<=1 and abs(pixelsColor[1]-128)<=1
 print('FRAMEBUFFER_COLOR_DEPTH_COPY_FORMAT',hex(fmt),'PASS')
