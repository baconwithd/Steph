package dev.zomboid.gore;
import java.util.*;
public final class Armor53 {
 static final ThreadLocal<Deque<Object>> BASE=ThreadLocal.withInitial(ArrayDeque::new);
 public static Object provider(Object stack){return stack;}
 public static Object resolve(Object ignored,Object wearer,Object stack,Object slot,Object base){Object extension=R.call(R.type("net.neoforged.neoforge.client.extensions.common.IClientItemExtensions"),"of",stack);Object model=R.call(extension,"getHumanoidArmorModel",wearer,stack,slot,base);if(model!=null&&model!=base)return model;return R.call(R.call(R.type("software.bernie.geckolib.animatable.client.GeoRenderProvider"),"of",stack),"getGeoArmorRenderer",wearer,stack,slot,base);}
 public static void begin(Object base){BASE.get().push(base);}public static void end(){Deque<Object>d=BASE.get();if(!d.isEmpty())d.pop();if(d.isEmpty())BASE.remove();}
 static Object field(Object o,String name){try{return R.get(o,name);}catch(IllegalStateException e){return null;}}
 public static void mask(Object renderer){Deque<Object>d=BASE.get();if(d.isEmpty())return;Object model=d.peek();String[]geo={"head","body","leftArm","rightArm","leftLeg","rightLeg","leftBoot","rightBoot"};String[]parts={"head","body","leftArm","rightArm","leftLeg","rightLeg","leftLeg","rightLeg"};int[]regions={0,6,2,3,4,5,4,5};Skin12.Context ctx=Skin12.CURRENT.get();for(int i=0;i<geo.length;i++){Object bone=field(renderer,geo[i]),part=field(model,parts[i]);if(bone==null||part==null)continue;boolean hidden=!R.yes(R.get(part,"visible"));if(ctx!=null&&(Damage25.destroyed(Cuts24.CURRENT.get(),regions[i])||(regions[i]<6&&(ctx.state&(1<<regions[i]))!=0)))hidden=true;R.call(bone,"setHidden",hidden);R.call(bone,"setChildrenHidden",hidden);}}
}
