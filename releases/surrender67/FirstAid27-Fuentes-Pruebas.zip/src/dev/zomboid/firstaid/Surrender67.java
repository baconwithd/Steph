package dev.zomboid.firstaid;
/** Explicit surrender must bypass the injury-to-downed conversion, on the server only. */
public final class Surrender67{
 public static void finish(Object model,Object player){
  if(player==null||R.yes(R.call(R.call(player,"level"),"isClientSide"))||!R.yes(R.call(player,"isAlive")))return;
  if(!R.yes(R.call(model,"isUnconscious"))&&!Revival.active(model))return;
  Object source=R.call(R.call(player,"damageSources"),"genericKill");
  R.set(model,"criticalConditionActive",false);R.call(model,"clearUnconsciousState");R.call(model,"clearUnconsciousPenalties",player);
  R.call(R.call(player,"getPersistentData"),"putLong","FADownDeadline",0L);R.call(model,"scheduleResync");
  R.call(R.type("ichttt.mods.firstaid.common.util.CommonUtils"),"killPlayerDirectly",player,source);
 }
 public static void choose(Object screen,int index){
  if(R.yes(R.get(screen,"surrendered")))return;String[] buttons=(String[])R.call(screen,"buttons");if(index<0||index>=buttons.length)return;
  if(buttons.length==2&&index==0){if(R.yes(R.get(screen,"requested"))||!Cinematic63.usable(R.call(screen,"player")))return;Cinematic63.send("ATTEMPT_SELF_DEFIB");R.set(screen,"requested",true);R.set(screen,"requestTicks",0);}
  else{if(R.yes(R.get(screen,"requested")))return;Cinematic63.send("GIVE_UP");R.set(screen,"surrendered",true);R.set(screen,"requestTicks",0);}
 }
 public static void tick(Object screen){if(R.yes(R.get(screen,"surrendered"))){int n=((Number)R.get(screen,"requestTicks")).intValue()+1;R.set(screen,"requestTicks",n);if(n>=40){R.set(screen,"surrendered",false);R.set(screen,"requestTicks",0);}}}
}
