from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;base=next((r.parent/'death65/output').glob('firstaid*.jar'));b=r/'build';b.mkdir(exist_ok=True);o=r/'output';o.mkdir(exist_ok=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+x+'=ALL-UNNAMED' for x in ['', '.tree','.tree.analysis']]
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(base),'-d',str(b/'classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(b/'tools'),str(r.parent/'medical52/Patch52.java'),str(r/'Patch67.java')],check=True)
subprocess.run(['java',*f,'-cp',str(b/'tools'),'Patch67',str(base),str(b/'classes'),str(o/'firstaid-1.21.1-ZOMBOID-v3.6.27-surrender-final-death.jar')],check=True)
