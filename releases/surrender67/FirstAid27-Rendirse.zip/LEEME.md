# FirstAid 3.6.27 — Rendirse

Reemplaza FirstAid 3.6.26 (o la versión anterior de FirstAid) por este JAR; no conserves dos versiones. Reinicia el juego. En multijugador actualiza cliente y servidor. Conserva Survivor Creator v38 y los demás mods actuales.

Causa: PlayerDamageModel.giveUp limpiaba el estado y llamaba CommonUtils.killPlayer con origen nulo. Esa función invoca Revival.preventDeath, que convierte otra vez la muerte en estado derribado. El botón quedaba además bloqueado tras el primer envío.

Cambio: la solicitud existente GIVE_UP ejecuta una ruta de servidor que comprueba jugador vivo y estado inconsciente/crítico; limpia dicho estado y su plazo; y llama a la muerte directa existente con damageSources.genericKill(), que la lógica Revival reconoce como muerte definitiva. No ejecuta respawn. La pantalla conserva el comportamiento de cámara/cadáver de v26. Las solicitudes repetidas tras morir o recuperarse no matan otra vez. En cliente, el bloqueo se establece solo tras enviar correctamente y caduca a los 40 ticks para permitir reintentar si no llega la muerte. Se conserva el bloqueo mientras está pendiente una solicitud del desfibrilador.

Validación: 13 comprobaciones con jugadores/modelos/red simulados y R/Revival/Surrender67 del JAR; BasicVerifier revisó 308 clases. Comparación de archivos: exactamente dos clases modificadas y un auxiliar añadido. Recursos, fuente, chat, cámara, protocolo y el resto del código permanecen idénticos al JAR 3.6.26. No se ejecutó Minecraft con el conjunto completo de mods.
