package dev.zomboid.gore;
import java.util.*;
/** Server-authoritative weapon power. Damage is read from the projectile before zombie health resistance. */
public final class Power62{
 public record Profile(double damage,double speed,double distance,int pellets,Rules.Weapon weapon,boolean explosive,long born,String owner,String gun){}
 record Key(long born,String owner,String gun){}
 static final class Cluster{double headDamage;int heads;final Set<Integer> seen=new HashSet<>();}
 static final class Target{long tick,deathTick;Profile death;double dx,dz;final LinkedHashMap<Key,Cluster> shots=new LinkedHashMap<>();}
 static final Map<Object,LinkedHashMap<Integer,Target>> WORLDS=Collections.synchronizedMap(new WeakHashMap<>());
 record Dead(Object level,int id,int region,Profile profile,int bulletId){}
 static final ThreadLocal<Dead> DEAD=new ThreadLocal<>();
 static final Map<Object,Set<Integer>> USED=Collections.synchronizedMap(new WeakHashMap<>());
 static double clamp(double v,double lo,double hi){return Double.isFinite(v)?Math.max(lo,Math.min(hi,v)):lo;}
 static int id(Object o){return ((Number)R.call(o,"getId")).intValue();}
 static long tick(Object level){return ((Number)R.call(level,"getGameTime")).longValue();}
 static Target target(Object level,int id){synchronized(WORLDS){var map=WORLDS.computeIfAbsent(level,k->new LinkedHashMap<>());long now=tick(level);if(map.size()>512)map.entrySet().removeIf(e->now-e.getValue().tick>20);while(map.size()>=1024){var it=map.keySet().iterator();it.next();it.remove();}Target t=map.computeIfAbsent(id,k->new Target());if(now<t.tick||now-t.tick>10){t.shots.clear();t.death=null;}t.tick=now;return t;}}
 static Object get(Object o,String field,Object fallback){try{return R.get(o,field);}catch(RuntimeException absent){return fallback;}}
 public static Profile profile(Object bullet,Object point,Rules.Weapon weapon){
  double damage=clamp(R.num(R.call(bullet,"getDamage",point)),0,1000),speed=clamp(R.num(R.call(R.call(bullet,"getDeltaMovement"),"length")),0,200),distance=128;
  Object start=get(bullet,"startPos",null);if(start!=null)distance=clamp(R.num(R.call(start,"distanceTo",point)),0,10000);
  double modifier=clamp(R.num(get(bullet,"damageModifier",1f)),1d/64,1);int pellets=(int)Math.round(1/modifier);Object owner=R.call(bullet,"getOwner");String ownerId=owner==null?"none":String.valueOf(R.call(owner,"getUUID")),gun=String.valueOf(get(bullet,"gunId","unknown"));Object level=R.call(bullet,"level");long born=tick(level)-((Number)get(bullet,"tickCount",0)).longValue();
  return new Profile(damage,speed,distance,pellets,weapon,R.yes(get(bullet,"explosion",false)),born,ownerId,gun);
 }
 static double close(Profile p){return clamp(1-p.distance/8,0,1);}
 public static double radius(Profile p,int region){
  if(p.explosive||p.damage<=0)return 0;double caliber=p.weapon==Rules.Weapon.SNIPER?1.24:p.weapon==Rules.Weapon.PISTOL?1:1.06;
  double size=(.45+.34*Math.sqrt(p.damage)*caliber)*(.9+.1*clamp(Math.sqrt(p.speed/20),.6,1.6));
  if(p.weapon==Rules.Weapon.SHOTGUN&&p.pellets>1)size*=1+.75*close(p);return clamp(size,.45,region==0?6.6:region>=6?5:3.8);
 }
 public static double force(Profile p){if(p.explosive||p.damage<=0)return 0;double grouped=p.damage;if(p.weapon==Rules.Weapon.SHOTGUN)grouped*=1+.9*close(p)*close(p)*(p.pellets-1);double speed=clamp(Math.sqrt(p.speed/20),.6,1.6),kind=p.weapon==Rules.Weapon.SHOTGUN?1.25:p.weapon==Rules.Weapon.SNIPER?1.1:1;return clamp((.07+Math.sqrt(grouped)*.07)*speed*kind,.06,1.4);}
 public static void capture(Object event){Object entity=R.call(event,"getEntity");if(!Gore.zombie(entity))return;Object source=R.call(event,"getSource"),bullet=R.call(source,"getDirectEntity");if(!Bullet13.tacz(bullet))return;Gore.Shot shot=Gore.shots.get();Object point=shot!=null&&shot.entity()==entity?shot.point():R.call(bullet,"position");Profile p=profile(bullet,point,Gore.weapon(bullet));if(p.explosive||p.damage<=0)return;Object level=R.call(entity,"level");Target t=target(level,id(entity));Object v=R.call(bullet,"getDeltaMovement");double x=R.num(R.get(v,"x")),z=R.num(R.get(v,"z")),n=Math.hypot(x,z);if(n<1e-7)return;t.death=p;t.deathTick=tick(level);t.dx=x/n;t.dz=z/n;}
 public static boolean allowDamage(Object entity,Gore.Shot shot,float damage){return !Float.isFinite(damage)||damage<=0||allow(entity,shot);}
 public static boolean allow(Object entity,Gore.Shot shot){if(shot.bullet()==null)return true;synchronized(USED){Set<Integer> s=USED.computeIfAbsent(shot.bullet(),k->new HashSet<>());if(s.size()>=128)return false;return s.add(id(entity));}}
 public static double liveRadius(float amount,int kind,Rules.Weapon weapon,Gore.Shot shot){if(shot.bullet()==null)return Cuts24.radius(amount,kind,weapon);Profile p=profile(shot.bullet(),shot.point(),weapon);return p.explosive?Cuts24.radius(amount,kind,weapon):radius(p,Hit28.locate(shot).region());}
 public static double deadRadius(float amount,int kind,Rules.Weapon weapon){Dead d=DEAD.get();return d==null||d.profile.explosive?Cuts24.radius(amount,kind,weapon):radius(d.profile,d.region);}
 static int[] expand(int[] cuts,Object level,int entity,int region,Profile p,int projectile){
  if(p.explosive||p.damage<=0)return cuts;Target t=target(level,entity);Key key=new Key(p.born,p.owner,p.gun);while(t.shots.size()>=8&&!t.shots.containsKey(key)){var it=t.shots.keySet().iterator();it.next();it.remove();}Cluster c=t.shots.computeIfAbsent(key,k->new Cluster());if(c.seen.size()>=128||!c.seen.add(projectile))return cuts;
  if(region==0){c.headDamage+=p.damage;c.heads++;boolean closeBlast=p.weapon==Rules.Weapon.SHOTGUN&&p.pellets>=4&&p.distance<=3.5&&c.heads>=3&&c.headDamage>=Math.max(12,p.damage*p.pellets*.45);boolean heavy=p.weapon==Rules.Weapon.SNIPER&&p.damage>=75;if(closeBlast||heavy){int[] rest=new int[cuts.length];int n=0;for(int i=0;i<cuts.length;i+=2)if((cuts[i]&7)!=0){rest[n++]=cuts[i];rest[n++]=cuts[i+1];}return Cuts24.add(Arrays.copyOf(rest,n),new Cuts24.Cut(0,.5,.5,.5,15.9375));}}return cuts;
 }
 public static int[] expandLive(int[] cuts,Gore.Shot shot){if(shot.bullet()==null)return cuts;return expand(cuts,R.call(shot.entity(),"level"),id(shot.entity()),Hit28.locate(shot).region(),profile(shot.bullet(),shot.point(),shot.gun()),id(shot.bullet()));}
 public static int[] expandDead(int[] cuts){Dead d=DEAD.get();return d==null?cuts:expand(cuts,d.level,d.id,d.region,d.profile,d.bulletId);}
 public static Object corpseReflect(Object receiver,String method,Object[]args,Object bullet){Dead old=DEAD.get();try{Object level=args[0],point=args[5];int entity=((Number)args[2]).intValue(),part=((Number)args[3]).intValue();DEAD.set(new Dead(level,entity,Damage13.region(part),profile(bullet,point,Gore.weapon(bullet)),id(bullet)));return R.call(receiver,method,args);}finally{if(old==null)DEAD.remove();else DEAD.set(old);}}

 public static void packet(Object entity,Object packet){
  if(!Gore.zombie(entity)||R.yes(R.call(entity,"isAlive")))return;Object level=R.call(entity,"level");Target t; synchronized(WORLDS){var map=WORLDS.get(level);t=map==null?null:map.get(id(entity));}if(t==null||t.death==null||tick(level)-t.deathTick>2||tick(level)<t.deathTick)return;
  double f=force(t.death);if(f<=0)return;R.set(packet,"velX",t.dx*f);R.set(packet,"velY",Math.min(0,R.num(R.get(packet,"velY"))));R.set(packet,"velZ",t.dz*f);
  // Native centered impulse with zero vector: all initial shot movement is in velocity, once.
  R.set(packet,"hitPartIndex",(byte)-2);R.set(packet,"hitImpulseX",0f);R.set(packet,"hitImpulseY",0f);R.set(packet,"hitImpulseZ",0f);
 }
 public static boolean initial(Object data,Object vector){
  String type=String.valueOf(R.get(data,"mobType"));if(!type.contains("zombie")&&!type.equals("minecraft:husk")&&!type.equals("minecraft:drowned"))return false;
  if(((Number)R.get(data,"hitPartIndex")).intValue()!=-2)return false;Object impulse=R.get(data,"hitImpulse");if(impulse==null||R.num(R.call(impulse,"lengthSqr"))>1e-10)return false;Object v=R.get(data,"velocity");double x=R.num(R.get(v,"x")),y=R.num(R.get(v,"y")),z=R.num(R.get(v,"z")),n=Math.hypot(x,z);if(!Double.isFinite(n)||n<=.025)return false;double s=n>1.4?1.4/n:1;R.set(vector,"x",(float)(x*s));R.set(vector,"y",(float)Math.min(0,y));R.set(vector,"z",(float)(z*s));return true;
 }
}
