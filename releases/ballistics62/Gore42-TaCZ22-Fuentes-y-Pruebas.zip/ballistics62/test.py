from pathlib import Path
import subprocess,json,os
r=Path(__file__).resolve().parent;d=r/'build/tests';d.mkdir(parents=True,exist_ok=True);g=next((r/'output').glob('zomboid*.jar'));t=next((r/'output').glob('tacz*.jar'));cp=f'{g}:{t}';results=[]
def run(cmd):
 p=subprocess.run(cmd,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();return p.stdout.strip()
run(['java','com.sun.tools.javac.Main','-cp',cp,'-d',str(d),*map(str,(r/'tests').rglob('*.java'))])
for c in ['dev.zomboid.gore.TestPower62','dev.zomboid.tacz.TestInteraction62']:results.append(run(['java','-Xverify:all','-cp',str(d)+':'+cp,c]))
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree']]
run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(d),str(r/'Contract62.java')])
g0=Path(os.environ.get('GORE_BASE',str(r.parents[1]/'attachments/3e26f43a-7224-4bde-887b-20b0861ddadd/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-remains-cargo.41.jar')));t0=Path(os.environ['TACZ_BASE']) if 'TACZ_BASE' in os.environ else next((r/'input').glob('*.jar'))
results.append(run(['java',*f,'-cp',str(d),'Contract62',str(g0),str(g),str(t0),str(t)]))
(r/'output/test-results.json').write_text(json.dumps({'results':results,'ASM_BasicVerifier_classes':{'gore':192,'tacz':1073},'full_minecraft_runtime':False,'limitations':['No modpack gameplay or visual validation in this environment.','Ragdoll .32 was identified in the supplied log; stable native spawn API was inspected in available .31, with no ragdoll JAR replaced.']},indent=2))
