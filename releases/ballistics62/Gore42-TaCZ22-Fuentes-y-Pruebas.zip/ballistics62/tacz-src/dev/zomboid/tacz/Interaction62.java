package dev.zomboid.tacz;
/** Cosmetic local interaction; does not send extra use, attack or ammunition actions. */
public final class Interaction62 {
 static Object owner,level;static long start=-1;static boolean warned;
 static Object mc(){return R.call(R.type("net.minecraft.client.Minecraft"),"getInstance");}
 public static void trigger(){Object m=mc();owner=R.get(m,"player");level=R.get(m,"level");start=System.nanoTime();}
 public static float curve(float p){if(!Float.isFinite(p)||p<=0||p>=1)return 0;float x=p<.42f?p/.42f:p<.62f?1:(1-p)/.38f;return x*x*(3-2*x);}
 public static float weight(){Object m=mc();if(start<0||owner==null||R.get(m,"player")!=owner||R.get(m,"level")!=level)return 0;float p=(System.nanoTime()-start)/760000000f;if(p>=1){start=-1;return 0;}return curve(p);}
 public static float[] motion(float p){float[]times={0,.24f,.46f,.67f,.84f,1};float[][]v={{0,0,0,0,0,0},{-.08f,.02f,-.30f,-12,8,-6},{-.12f,.04f,-.47f,-22,12,-12},{-.14f,-.015f,-.45f,-18,24,-34},{-.06f,-.04f,-.22f,-8,30,-15},{0,0,0,0,0,0}};p=Math.max(0,Math.min(1,p));int i=0;while(i<4&&p>times[i+1])i++;float t=(p-times[i])/(times[i+1]-times[i]);t=t*t*(3-2*t);float[]o=new float[6];for(int j=0;j<6;j++)o[j]=v[i][j]+(v[i+1][j]-v[i][j])*t;return o;}
 static float progress(){weight();return start<0?1:Math.max(0,Math.min(1,(System.nanoTime()-start)/760000000f));}
 public static void first(Object pose){try{float w=weight();if(w==0)return;float[]v=motion(progress());R.call(pose,"translate",(double)v[0],(double)v[1],(double)v[2]);String[] axes={"XP","YP","ZP"};for(int i=0;i<3;i++)R.call(pose,"mulPose",R.call(R.get(R.type("com.mojang.math.Axis"),axes[i]),"rotationDegrees",v[i+3]));}catch(RuntimeException e){warn(e);}}
 public static void doorSwing(Object player,Object hand){if(!R.yes(R.call(R.type("com.locknar.taczammocheck.tactical.TaczGunCompat"),"isTaczGun",R.call(player,"getMainHandItem"))))R.call(player,"swing",hand);}
 public static void render(Object player,Object arm,Object pose,int light){first(pose);R.call(R.type("com.tacz.guns.util.RenderHelper"),"renderFirstPersonArm",player,arm,pose,light);}
 public static void third(Object player,Object model){if(player==null||model==null)return;try{float w=weight();if(w==0||player!=owner)return;Object a=R.get(model,"leftArm"),s=R.get(model,"leftSleeve");String[] axes={"xRot","yRot","zRot"};float[]pose=motion(progress());float[] target={-1.38f-pose[1]*2,-.24f-pose[4]*.01f,-.10f+pose[5]*.008f};for(int i=0;i<3;i++){float old=((Number)R.get(a,axes[i])).floatValue();float v=old+(target[i]-old)*w;R.set(a,axes[i],v);R.set(s,axes[i],v);}}catch(RuntimeException e){warn(e);}}
 static void warn(RuntimeException e){if(!warned){warned=true;System.err.println("[TaCZ] Left interaction: "+e);}}
}
