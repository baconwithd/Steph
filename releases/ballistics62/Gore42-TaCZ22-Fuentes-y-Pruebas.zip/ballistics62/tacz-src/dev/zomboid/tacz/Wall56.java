package dev.zomboid.tacz;
public final class Wall56{
 static final ThreadLocal<Boolean> WALL=ThreadLocal.withInitial(()->false);
 static float smooth(float x){x=Float.isFinite(x)?Math.max(0,Math.min(1,x)):0;return x*x*(3-2*x);}
 public static float pitch(float wall,float kick,float alt){float w=smooth(wall),r=smooth(Math.max(kick,alt));return -32*Math.max(w,r);}
 public static double vertical(float wall,float kick,float alt){float w=smooth(wall),r=smooth(Math.max(kick,alt));return -.18*Math.max(w,r);}
 public static void apply(Object pose,float wall,float kick,float alt,Object kind){float p=smooth(Math.max(wall,Math.max(kick,alt)));R.call(pose,"translate",.065*p,vertical(wall,kick,alt),.10*p);String[] axes={"XP","YP","ZP"};float[] angles={pitch(wall,kick,alt),3*p,-4*p};for(int i=0;i<3;i++)R.call(pose,"mulPose",R.call(R.get(R.type("com.mojang.math.Axis"),axes[i]),"rotationDegrees",angles[i]));}
 public static void begin(Object player,Object info){boolean enabled=R.yes(R.call(R.get(R.type("com.locknar.taczammocheck.LocknarConfig"),"TACZ_WALL_OBSTRUCTION_ENABLED"),"get"));WALL.set(enabled&&R.yes(R.call(R.type("com.locknar.taczammocheck.tactical.client.TaczWallObstructionThirdPersonClient"),"isMuzzleObstructedCached",player,((Number)R.call(info,"length")).doubleValue())));}
 public static float arm(float original){return Math.abs(original)*.70f;}
}
