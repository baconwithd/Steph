from pathlib import Path
import subprocess,os
r=Path(__file__).resolve().parent;o=r/'output';o.mkdir(exist_ok=True);g=Path(os.environ.get('GORE_BASE',str(r.parents[1]/'attachments/3e26f43a-7224-4bde-887b-20b0861ddadd/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-remains-cargo.41.jar')));t=Path(os.environ['TACZ_BASE']) if 'TACZ_BASE' in os.environ else next((r/'input').rglob('*.jar'))
for src,base,dst in [('src',g,'gore'),('tacz-src',t,'tacz')]:
 d=r/'build'/dst;d.mkdir(parents=True,exist_ok=True);subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(base),'-d',str(d),*map(str,(r/src).rglob('*.java'))],check=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']];d=r/'build/tools';d.mkdir(exist_ok=True)
subprocess.run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(d),str(r.parent/'medical52/Patch52.java'),str(r/'Patch62.java')],check=True)
subprocess.run(['java',*f,'-cp',str(d),'Patch62',str(g),str(r/'build/gore'),str(o/'zomboid-zombie-gore-1.0.20-neoforge-1.21.1-weapon-power.42.jar'),str(t),str(r/'build/tacz'),str(o/'tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.22-low-ready-door.jar')],check=True)
