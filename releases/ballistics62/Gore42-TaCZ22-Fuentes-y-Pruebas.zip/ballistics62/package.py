from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent;o=r/'output';d=r/'dist';d.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
g0=r.parents[1]/'attachments/3e26f43a-7224-4bde-887b-20b0861ddadd/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-remains-cargo.41.jar';t0=next((r/'input').glob('*.jar'))
manifest={'release':'ballistics62','minecraft':'1.21.1','loader':'NeoForge','inputs':[{ 'file':p.name,'sha256':digest(p)}for p in [g0,t0]],'outputs':[{ 'file':p.name,'bytes':p.stat().st_size,'sha256':digest(p)}for p in sorted(o.glob('*.jar'))],'ragdoll_replacement':False,'full_modpack_runtime_tested':False}
(o/'manifest.json').write_text(json.dumps(manifest,indent=2));(o/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n'for p in sorted(o.iterdir())if p.is_file() and p.name!='SHA256SUMS.txt'))
with zipfile.ZipFile(d/'Gore42-TaCZ22-Potencia-y-Puertas.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in sorted(o.iterdir()):z.write(p,p.name)
with zipfile.ZipFile(d/'Gore42-TaCZ22-Fuentes-y-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for path in ['src','tacz-src','tests']:
  for p in sorted((r/path).rglob('*.java')):z.write(p,'ballistics62/'+str(p.relative_to(r)))
 for path in ['build.py','test.py','Patch62.java','Contract62.java','package.py']:
  z.write(r/path,'ballistics62/'+path)
 z.write(r.parent/'medical52/Patch52.java','medical52/Patch52.java')
 z.writestr('ballistics62/BUILD.md','Requires JDK 21+ and the two exact input JARs in manifest.json. Set GORE_BASE and TACZ_BASE to their absolute paths. Run python build.py and python test.py from this directory. ASM uses JDK internal packages with explicit exports. Tests use API fixtures, not a running Minecraft instance. Source additions and ASM patch are provided; original mod source is not bundled.\n')
 for path in ['LEEME.md','manifest.json','test-results.json']:z.write(o/path,'ballistics62/'+path)
for p in d.iterdir():
 with zipfile.ZipFile(p)as z:assert z.testzip()is None
 print(p.name,p.stat().st_size,digest(p))
