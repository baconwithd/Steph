package net.minecraft.client;public class Minecraft{static final Minecraft M=new Minecraft();public Object player,level;public static Minecraft getInstance(){return M;}}
