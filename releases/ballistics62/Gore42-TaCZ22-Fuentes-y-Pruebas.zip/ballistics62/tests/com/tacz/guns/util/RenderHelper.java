package com.tacz.guns.util;public class RenderHelper{public static int calls;public static void renderFirstPersonArm(Object player,Object arm,Object pose,int light){calls++;}}
