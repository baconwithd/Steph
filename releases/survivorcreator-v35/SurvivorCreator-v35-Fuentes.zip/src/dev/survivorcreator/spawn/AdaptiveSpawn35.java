package dev.survivorcreator.spawn;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
/** Bounded, loaded-terrain-only spawn selection. Never generates chunks while confirming a character. */
public final class AdaptiveSpawn35 {
 static final Map<Object,Plan> PLANS=Collections.synchronizedMap(new WeakHashMap<>());
 record Plan(Object level,int[] point,String mode){}
 static final List<int[]> HOMES=readHomes();
 static Object c(Object o,String name,Object...args){return R.call(o,name,args);}static boolean yes(Object o){return Boolean.TRUE.equals(o);}static int n(Object o){return ((Number)o).intValue();}
 static Object pos(int x,int y,int z){return R.make("net.minecraft.core.BlockPos",x,y,z);}
 static List<int[]> readHomes(){try(var in=AdaptiveSpawn35.class.getResourceAsStream("/survivor-spawn-homes.csv")){List<int[]> rows=new ArrayList<>();if(in!=null)for(String line:new String(in.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8).split("\\R")){if(line.isBlank())continue;String[] cols=line.split(",");int[] row=new int[7];for(int i=0;i<7;i++)row[i]=Integer.parseInt(cols[i]);rows.add(row);}return List.copyOf(rows);}catch(Exception e){System.err.println("[SurvivorCreator] Spawn catalog unavailable: "+e);return List.of();}}
 static boolean loaded(Object level,int x,int z){return yes(c(level,"hasChunk",Math.floorDiv(x,16),Math.floorDiv(z,16)));}
 public static boolean dangerous(String id){return List.of("lava","magma","fire","cactus","berry_bush","powder_snow","wither_rose","portal").stream().anyMatch(id::contains);}
 static boolean terrain(Object level,int x,int y,int z){if(!loaded(level,x,z)||y<=n(c(level,"getMinBuildHeight"))||y+1>=n(c(level,"getMaxBuildHeight")))return false;Object feet=pos(x,y,z);if(!yes(c(c(level,"getWorldBorder"),"isWithinBounds",feet)))return false;
  for(int dy=-1;dy<=1;dy++){Object p=pos(x,y+dy,z),state=c(level,"getBlockState",p);if(!yes(c(c(state,"getFluidState"),"isEmpty"))||dangerous(String.valueOf(c(c(state,"getBlock"),"getDescriptionId"))))return false;
   if(dy<0){if(!yes(c(state,"isFaceSturdy",level,p,R.field(R.type("net.minecraft.core.Direction"),"UP"))))return false;}
   else if(!yes(c(c(state,"getCollisionShape",level,p),"isEmpty")))return false;
  }return true;
 }
 static boolean quiet(Object level,int[] p){Object box=R.make("net.minecraft.world.phys.AABB",p[0]-12d,p[1]-6d,p[2]-12d,p[0]+12d,p[1]+6d,p[2]+12d);return ((List<?>)c(level,"getEntitiesOfClass",R.type("net.minecraft.world.entity.monster.Monster"),box)).isEmpty();}
 static int[] surface(Object level,int x,int z,int nearY){if(!loaded(level,x,z))return null;int y=n(c(level,"getHeight",R.field(R.type("net.minecraft.world.level.levelgen.Heightmap$Types"),"MOTION_BLOCKING_NO_LEAVES"),x,z));boolean ceiling=yes(c(c(level,"dimensionType"),"hasCeiling"));if(!ceiling&&terrain(level,x,y,z))return new int[]{x,y,z};
  // Nearby interiors/caves are allowed; never search the whole build height.
  for(int d=0;d<=8;d++){if(terrain(level,x,nearY+d,z))return new int[]{x,nearY+d,z};if(d>0&&terrain(level,x,nearY-d,z))return new int[]{x,nearY-d,z};}return null;
 }
 static int[] catalog(Object level,int zone,long deadline){List<int[]> pool=new ArrayList<>();for(int[] row:HOMES){if(System.nanoTime()>deadline)break;if((zone==9||row[0]==zone)&&loaded(level,row[1],row[3])&&loaded(level,row[4],row[6]))pool.add(row);}Collections.shuffle(pool);int tested=0;
  for(int[] r:pool){if(tested++>=48||System.nanoTime()>deadline)break;Object be=c(level,"getBlockEntity",pos(r[4],r[5],r[6]));if(be==null||!R.type("net.minecraft.world.Container").isInstance(be))continue;int[] p={r[1],r[2],r[3]};if(terrain(level,p[0],p[1],p[2])&&quiet(level,p))return p;}return null;
 }
 public static int[] offset(int i,int rotation){double angle=(i*2.399963229728653+rotation*.017453292519943);double radius=8+Math.sqrt((i+1)/192d)*112;return new int[]{(int)Math.round(Math.cos(angle)*radius),(int)Math.round(Math.sin(angle)*radius)};}
 static Plan find(Object player,int zone){long deadline=System.nanoTime()+40_000_000L;Object level=c(player,"serverLevel");int[] fixed=catalog(level,zone,deadline);if(fixed!=null)return new Plan(level,fixed,"validated catalog home");deadline=System.nanoTime()+40_000_000L;
  Object spawn=c(level,"getSharedSpawnPos");int px=(int)Math.floor(((Number)c(player,"getX")).doubleValue()),py=(int)Math.floor(((Number)c(player,"getY")).doubleValue()),pz=(int)Math.floor(((Number)c(player,"getZ")).doubleValue());int sx=n(c(spawn,"getX")),sy=n(c(spawn,"getY")),sz=n(c(spawn,"getZ"));int rotation=ThreadLocalRandom.current().nextInt(360);int[] fallback=null;
  for(int i=0;i<192&&System.nanoTime()<deadline;i++){int[] delta=offset(i,rotation);boolean atSpawn=(i&1)==0;int[] p=surface(level,(atSpawn?sx:px)+delta[0],(atSpawn?sz:pz)+delta[1],atSpawn?sy:py);if(p==null)continue;if(fallback==null)fallback=p;if(quiet(level,p))return new Plan(level,p,"random safe terrain");}
  // Dense local pass finds small islands and enclosed starts missed by the outer samples.
  for(int i=0;i<81&&System.nanoTime()<deadline;i++){int dx=i%9-4,dz=i/9-4;int[] p=surface(level,px+dx,pz+dz,py);if(p==null)continue;if(fallback==null)fallback=p;if(quiet(level,p))return new Plan(level,p,"local safe terrain");}
  return new Plan(level,fallback,fallback==null?"keep vanilla position (no safe terrain)":"terrain safe; grace protection");
 }
 public static Object filter(Object player,Object confirm){PLANS.remove(player);List<Object> clean=new ArrayList<>();int zone=-1;for(Object perk:(List<?>)c(confirm,"perks")){String id=perk.toString();if(id.startsWith("survivorcreator:spawn_")){try{int parsed=Integer.parseInt(id.substring("survivorcreator:spawn_".length()));if(zone>=0||parsed<0||parsed>9)throw new IllegalArgumentException();zone=parsed;}catch(Exception e){reject(player,"Zona de aparición inválida.");return null;}}else clean.add(perk);}
  Object stripped=R.make("dev.survivorcreator.net.Net$Confirm",c(confirm,"profession"),List.copyOf(clean));Object data=c(player,"getData",R.field(R.type("dev.survivorcreator.SurvivorCreator"),"CHARACTER"));if(yes(c(data,"completed")))return stripped;
  Object valid=c(R.type("dev.survivorcreator.data.Validator"),"validate",c(stripped,"profession"),List.copyOf(clean),true);if(!yes(c(valid,"ok")))return stripped;
  try{Plan p=find(player,zone<0?9:zone);PLANS.put(player,p);System.out.println("[SurvivorCreator] Adaptive spawn: "+p.mode+" "+Arrays.toString(p.point));}
  catch(RuntimeException e){System.err.println("[SurvivorCreator] Adaptive spawn failed; retaining vanilla spawn: "+e);PLANS.put(player,new Plan(c(player,"serverLevel"),null,"validation fallback"));}
  return stripped;
 }
 static void reject(Object player,String message){try{var method=R.type("dev.survivorcreator.spawn.Spawns").getDeclaredMethod("reject",Object.class,String.class);method.setAccessible(true);method.invoke(null,player,message);}catch(Exception e){throw new IllegalStateException(e);}}
 public static void place(Object player){Plan p=PLANS.remove(player);if(p==null)return;
  if(p.point!=null&&c(player,"serverLevel")==p.level&&terrain(p.level,p.point[0],p.point[1],p.point[2])){try{c(player,"teleportTo",p.level,p.point[0]+.5,p.point[1]+0d,p.point[2]+.5,0f,0f);}catch(IllegalStateException e){c(player,"teleportTo",p.level,p.point[0]+.5,p.point[1]+0d,p.point[2]+.5,Set.of(),0f,0f);}}
  c(R.type("dev.survivorcreator.GraceProtection"),"give",player);c(R.type("dev.survivorcreator.spawn.Flashlight"),"equip",player);
  for(String item:new String[]{"BREAD","APPLE","TORCH"}){Object stack=R.make("net.minecraft.world.item.ItemStack",R.field(R.type("net.minecraft.world.item.Items"),item),item.equals("TORCH")?4:2);if(!yes(c(c(player,"getInventory"),"add",stack)))c(player,"drop",stack,false);}
 }
}
