/*
 * Decompiled with CFR 0.152.
 */
package dev.survivorcreator.spawn;

public final class Zones {
    public static final String[] NAMES = new String[]{"Residencial noroeste", "Residencial noreste", "Ciudad suroeste", "Ciudad sureste", "Periferia de la central", "Extremo noreste", "Franja residencial oeste", "Esquina suroeste", "Extremo sureste", "Automático: mundo actual"};
    public static final String[] DANGER = new String[]{"Bajo", "Bajo\u2013medio", "Alto", "Alto", "Extremo", "Alto", "Medio", "Alto", "Alto", "Se comprueba al aparecer"};
    public static final String[] LOOT = new String[]{"B\u00e1sico", "B\u00e1sico\u2013variado", "Variado", "Variado", "Valioso cerca de la planta", "Variado", "Dom\u00e9stico y materiales", "Variado", "Variado", "Según el mundo"};
    public static final String[] INFO = new String[]{"Casas e interiores: comida, agua y provisiones dom\u00e9sticas. Puntos aleatorios en distintas plantas.", "Viviendas del este: alimentos, ropa y herramientas b\u00e1sicas. Interiores aleatorios cerca de contenedores.", "Edificios urbanos: provisiones, herramientas y material de oficina; mayor exposici\u00f3n a zombis al salir.", "Edificios y oficinas: suministros variados y medicamentos seg\u00fan el contenedor. Plantas elegidas al azar.", "Refugios al borde de la central nuclear del noroeste. Zona muy peligrosa; materiales y herramientas valiosos en el sector nuclear.", "Interiores m\u00e1s alejados al noreste, pr\u00f3ximos al sector de la pir\u00e1mide. Provisiones y materiales; explorar grandes estructuras aumenta el riesgo.", "Edificios del borde occidental, entre ambos sectores. Comida, ropa y herramientas seg\u00fan el contenedor; rutas alternativas hacia el centro.", "Interiores del extremo suroeste, lejos del norte residencial. Provisiones dom\u00e9sticas y de oficina; salida urbana peligrosa.", "Edificios del extremo sureste. Comida, materiales y suministros de oficina; las recompensas dependen de las tablas de cada contenedor.", "Busca terreno seguro del mundo actual. Si hay casas verificadas de Mosslorn, puede usarlas. No requiere el mapa original."};
    public static final int[][] MARKERS = new int[][]{{31, 31}, {81, 42}, {30, 69}, {87, 74}, {13, 13}, {91, 15}, {18, 49}, {20, 92}, {92, 92}, new int[]{50,50}};
}
