from pathlib import Path
import subprocess,io,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parent;out=r/'preview';out.mkdir(exist_ok=True)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
cases=[('Cabeza · vendar',0,1),('Torso · vendar',4,1),('Brazo · vendar',1,1),('Pierna · tablilla',2,2),('Pie · vendar',7,1),('Extraer bala',4,3),('Inyección',1,4),('Tomar medicina',0,5),('Desinfectar',1,6),('Retirar venda',6,7),('Reanimación',4,8),('Flexiones',4,10)]
jar=next((r/'output').glob('firstaid*.jar'));data=[]
for name,part,kind in cases:
 text=subprocess.check_output(['java','-cp',str(jar),'dev.zomboid.firstaid.Motion57',str(part),str(kind)],text=True);data.append(np.array([[float(x)for x in line.split(',')]for line in text.splitlines()]))
views=[x[:,25:]for x in data]
def rot(a):
 x,y,z=a;sx,cx=math.sin(x),math.cos(x);sy,cy=math.sin(y),math.cos(y);sz,cz=math.sin(z),math.cos(z)
 return np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])@np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])@np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
verts=np.array([[x,y,z]for x,y,z in [(0,0,0),(1,0,0),(1,1,0),(0,1,0),(0,0,1),(1,0,1),(1,1,1),(0,1,1)]],float)
faces=[([0,3,2,1],.98),([4,5,6,7],.55),([0,1,5,4],.86),([3,7,6,2],.48),([0,4,7,3],.72),([1,2,6,5],.85)]
def draw_model(draw,p,cx,cy):
 pieces=[]
 def box(bounds,pivot,angles,color):
  low=np.array(bounds[:3]);high=np.array(bounds[3:]);v=(verts*(high-low)+low)@rot(angles).T+np.array(pivot)
  for ids,shade in faces:
   points=v[ids];depth=np.mean(points[:,0]*.5+points[:,1]*.2-points[:,2]*.85)
   xy=[(cx+(q[0]*.88+q[2]*.46)*5.8,cy+(q[1]*.91-q[2]*.28+q[0]*.12)*5.8)for q in points]
   pieces.append((depth,xy,tuple(int(c*shade)for c in color)))
 skin=(172,128,93);shirt=(45,122,109);pants=(58,69,99)
 box((-4,0,-2,4,12,2),(0,p[18],p[19]),p[6:9],shirt)
 box((-4,-8,-4,4,0,4),(0,p[22],p[23]),p[9:12],skin)
 # Hair and eyes are aligned with the animated head, not separate screen decals.
 box((-4,-8.1,-4,4,-6,4),(0,p[22],p[23]),p[9:12],(57,40,31))
 for x in [-2.3,1.4]:box((x,-4.3,-4.03,x+.9,-3.45,-4.08),(0,p[22],p[23]),p[9:12],(210,218,224))
 box((-3,-2,-2,1,1,2),(-5,2+p[20],p[21]),p[0:3],shirt);box((-3,1,-2,1,10,2),(-5,2+p[20],p[21]),p[0:3],skin)
 box((-1,-2,-2,3,1,2),(5,2+p[20],p[21]),p[3:6],shirt);box((-1,1,-2,3,10,2),(5,2+p[20],p[21]),p[3:6],skin)
 drop=max(0,p[18]-(12-math.cos(p[6])*12))
 box((-2,0,-2,2,12,2),(-1.9,12+drop,0),p[12:15],pants);box((-2,0,-2,2,12,2),(1.9,12+drop,0),p[15:18],pants)
 for _,xy,color in sorted(pieces,key=lambda x:x[0]):draw.polygon(xy,fill=color,outline=tuple(max(0,c-10)for c in color))
frames=[]
for frame in range(64):
 im=Image.new('RGB',(1200,1030),(15,20,25));draw=ImageDraw.Draw(im);draw.text((20,10),'FIRST AID · PREVIEW TÉCNICO DE ANIMACIONES',font=font,fill=(230,232,226));draw.text((20,36),'Maniquí fuera de Minecraft · curvas del JAR · no representa el shaderpack ni la skin final',font=small,fill=(161,177,184))
 for idx,((name,part,kind),samples)in enumerate(zip(cases,data)):
  x=idx%4*300;y=idx//4*320+65;draw.rounded_rectangle((x+7,y,x+293,y+308),radius=10,fill=(23,31,38),outline=(47,63,68));draw.text((x+18,y+10),name,font=font,fill=(222,227,211));draw.text((x+18,y+34),'3ª persona',font=small,fill=(126,157,160));p=samples[frame,1:25];draw.ellipse((x+103,y+218,x+197,y+234),fill=(13,19,24));draw_model(draw,p,x+150,y+91)
  # Reference first-person hands use the exact public view-space curves from FirstPerson57.
  # Read separately below; these are stand-ins, not a render of LR's asset skeleton.
  draw.rectangle((x+16,y+242,x+284,y+296),fill=(12,18,22));draw.text((x+22,y+245),'1ª · trayectoria de manos',font=small,fill=(139,162,167))
  v=views[idx][frame] if 'views'in globals()else None
  if v is not None:
   dx,dy,dz,rx,ry,rz=v;center=(x+150+dx*100,y+278-dy*45);w=6+math.sin(frame*.32)*1.5
   for side in [-1,1]:
    cx=center[0]+side*25;cy=center[1];draw.line((x+150+side*65,y+298,cx,cy),fill=(53,115,104),width=12);draw.rounded_rectangle((cx-7,cy-5,cx+7,cy+5),radius=2,fill=(171,127,92))
 frames.append(im)
 if frame==25:im.save(out/'portada.png')
# Encoding is lossless source frames -> shareable MP4 and an animated GIF.
for i,im in enumerate(frames):im.save(out/f'frame{i:03}.png')
subprocess.run(['ffmpeg','-v','error','-y','-framerate','10','-i',str(out/'frame%03d.png'),'-c:v','libx264','-pix_fmt','yuv420p','-crf','21',str(out/'FirstAid-animaciones-preview.mp4')],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(out/'FirstAid-animaciones-preview.mp4'),'-vf','fps=8,scale=840:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=128[p];[s1][p]paletteuse',str(out/'FirstAid-animaciones-preview.gif')],check=True)
for p in out.glob('frame*.png'):p.unlink()
print('PREVIEW_FROM_PRODUCTION_CURVES=PASS')
