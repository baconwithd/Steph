from pathlib import Path
import subprocess,json,zipfile
r=Path(__file__).resolve().parent;fa=next((r/'output').glob('firstaid*.jar'));lr=next((r/'output').glob('Les*.jar'));c=r/'build/tests';c.mkdir(exist_ok=True);results=[]
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(fa),'-d',str(c),*map(str,(r/'tests').rglob('*.java'))],check=True)
p=subprocess.run(['java','-Xverify:all','-cp',str(c)+':'+str(fa),'dev.zomboid.firstaid.MotionChecks57'],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
with zipfile.ZipFile(fa)as z:
 config=json.loads(z.read('firstaid.mixins.json'));assert 'client.MedicalView57'in config['client'];d=json.loads(z.read('assets/firstaid/animations/consumable/carfak_bandage.animation.json'));assert d['animations']['use']['animation_length']==3.3
 for animation in d['animations'].values():
  for bone in animation['bones'].values():
   for channel in bone.values():
    if isinstance(channel,dict):assert all(float(k)>=0 for k in channel)
results.append('NATIVE_LR_ASSET_DURATION_AND_MIXIN_REGISTRATION=PASS')
flags=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+x+'=ALL-UNNAMED'for x in ['','.tree']]
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(c),str(r/'Contract57.java')],check=True)
p=subprocess.run(['java',*flags,'-cp',str(c),'Contract57',str(fa),str(lr)],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
(r/'output/test-results.json').write_text(json.dumps({'results':results,'full_minecraft_run':False},indent=2))
