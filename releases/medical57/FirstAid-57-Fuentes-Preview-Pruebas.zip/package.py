from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).resolve().parent;o=r/'output';d=r/'dist';d.mkdir(exist_ok=True)
files=[{'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in sorted(o.glob('*.jar'))];assert len(files)==2
manifest={'release':57,'firstaid':'3.6.20','reference_commit':'18f20af4faca6802599564fa044b1faad0c981c8','files':files};(o/'manifest.json').write_text(json.dumps(manifest,indent=2));(o/'SHA256SUMS.txt').write_text(''.join(p['sha256']+'  '+p['name']+'\n'for p in files))
tests=json.loads((o/'test-results.json').read_text());tests['additional_runtime_fixtures']=['PRODUCTION_FIRST_PERSON_APPLY_LR_BRIDGE_METADATA_PARTS_CUES_EXPIRY=PASS','LR_OPTIONAL_FIRSTAID_ABSENT=PASS'];tests['bytecode']=(r/'build.log').read_text();(o/'test-results.json').write_text(json.dumps(tests,indent=2))
with zipfile.ZipFile(d/'FirstAid-57-Animaciones-Primera-Tercera.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.glob('*.jar')):z.write(p,'mods/'+p.name)
 for name in ['LEEME.md','manifest.json','SHA256SUMS.txt','test-results.json']:z.write(o/name,name)
 z.write(r/'preview/FirstAid-animaciones-preview.mp4','preview/FirstAid-animaciones-preview.mp4')
with zipfile.ZipFile(d/'FirstAid-57-Fuentes-Preview-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','lr-src','tests','runtime-tests']:
  for p in (r/folder).rglob('*.java'):z.write(p,str(p.relative_to(r)))
 for name in ['build.py','Patch57.java','Contract57.java','test.py','test_runtime.py','preview.py','bandage57.animation.json','build.log','package.py']:z.write(r/name,name)
 z.write(r.parent/'medical52/Patch52.java','base-tools/Patch52.java')
 for name in ['LEEME.md','manifest.json','test-results.json']:z.write(o/name,name)
for p in d.glob('*.zip'):
 with zipfile.ZipFile(p)as z:assert z.testzip()is None
print('TWO_JAR_PREVIEW_MANIFEST_ZIP_CRC=PASS')
