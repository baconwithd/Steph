from pathlib import Path
import subprocess,json,zipfile
r=Path(__file__).resolve().parent;root=r.parents[1];base=root/'attachments/27e84bf6-1455-400b-8385-90ff53151214/firstaid-1.21.1-ZOMBOID-v3.6.19-isometric-survival-decisions.jar';o=r/'output';o.mkdir(exist_ok=True);classes=r/'build/classes';classes.mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(base),'-d',str(classes),*map(str,(r/'src').rglob('*.java'))],check=True)
with zipfile.ZipFile(base)as z:d=json.loads(z.read('assets/firstaid/animations/consumable/carfak_bandage.animation.json'))
# Keep native LR model/bone coordinates and action length; smooth the existing hand paths.
for name,anim in d['animations'].items():
 for bone,values in anim.get('bones',{}).items():
  if bone=='camera':
   for channel,track in values.items():
    if not isinstance(track,dict):continue
    for time,key in track.items():
     if isinstance(key,list):track[time]=[v*.35 if isinstance(v,(int,float)) else v for v in key]
     elif isinstance(key,dict):
      for mode in ['pre','post']:
       if mode in key:key[mode]=[v*.35 if isinstance(v,(int,float)) else v for v in key[mode]]
  if name=='use' and bone in ['gun_and_righthand','mag_and_lefthand']:
   for channel in ['rotation','position']:
    track=values.get(channel)
    if not isinstance(track,dict)or len(track)<3:continue
    keys=sorted(track,key=float)
    def vec(x):return x.get('post',x.get('pre'))if isinstance(x,dict)else x
    original=[vec(track[k])for k in keys]
    for i in range(1,len(keys)-1):
     if not all(isinstance(v,list)and len(v)==3 and all(isinstance(x,(int,float))for x in v)for v in original[i-1:i+2]):continue
     value=[.2*original[i-1][j]+.6*original[i][j]+.2*original[i+1][j]for j in range(3)]
     track[keys[i]]={'post':value,'lerp_mode':'catmullrom'}
(r/'bandage57.animation.json').write_text(json.dumps(d,indent=2))
lr=root/'attachments/43748403-8f87-4362-a030-f69fbee5c5dc/LesRaisins-Tactical-Equipements-1.21.1-0.4.3-zomboid-isometric-melee.4-click-combat-hold-mining.jar';lc=r/'build/lr';lc.mkdir(exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-d',str(lc),*map(str,(r/'lr-src').rglob('*.java'))],check=True)
flags=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+x+'=ALL-UNNAMED'for x in ['','.tree','.tree.analysis']];t=r/'build/tools';t.mkdir(exist_ok=True)
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(t),str(r.parent/'medical52/Patch52.java'),str(r/'Patch57.java')],check=True)
subprocess.run(['java',*flags,'-cp',str(t),'Patch57',str(base),str(classes),str(r/'bandage57.animation.json'),str(o/'firstaid-1.21.1-ZOMBOID-v3.6.20-anatomical-treatment-motion.jar'),str(lr),str(lc),str(o/'LesRaisins-Tactical-Equipements-1.21.1-0.4.3-medical-view.5.jar')],check=True)
