package dev.zomboid.firstaid;
import org.joml.Matrix4f;import org.joml.Quaternionf;import org.joml.Quaternionfc;import org.joml.Vector3f;
import java.util.*;
/** A hand endpoint must lie on the selected leg, not merely point downwards. Units: model pixels. */
public final class Contact60 {
 static boolean lower(int part){return part==2||part==3||part==6||part==7;}
 static boolean foot(int part){return part==3||part==7;}
 static float side(int part){return part==2||part==3?1:-1;}
 static boolean worker(int part,boolean left){return left==(side(part)<0);}
 static float f(Object o,String n){return ((Number)R.get(o,n)).floatValue();}
 static float bound(float x,float a,float b){return Math.max(a,Math.min(b,x));}
 public static Vector3f euler(Quaternionf q){double x=q.x,y=q.y,z=q.z,w=q.w,n=x*x+y*y+z*z+w*w;return new Vector3f((float)Math.atan2(2*(y*z+w*x),n-2*(x*x+y*y)),(float)Math.asin(Math.max(-1,Math.min(1,2*(w*y-x*z)/n))),(float)Math.atan2(2*(x*y+w*z),n-2*(y*y+z*z)));}
 static float[] posture(int part,int kind,float t){
  float[]p=Motion59.third(part,kind,t);if(!lower(part)||kind>7)return p;
  float reach=Motion59.ease(t/10),bend=(foot(part)?1.2f:.95f)*reach,selected=-1.1f*reach,standing=-.4f*reach,drop=12*(1-(float)Math.cos(standing));
  p[6]=bend;p[7]=p[8]=0;p[9]=.5f*reach;p[10]=p[11]=0;
  // p[12] is RIGHT leg; p[15] is LEFT leg. The previous clip bent the opposite one.
  p[12]=side(part)>0?standing:selected;p[15]=side(part)>0?selected:standing;p[13]=p[14]=p[16]=p[17]=0;
  p[18]=12-12*(float)Math.cos(bend)+drop;p[19]=-12*(float)Math.sin(bend);p[20]=p[18]+2*((float)Math.cos(bend)-1);p[21]=p[19]+2*(float)Math.sin(bend);p[22]=p[18];p[23]=p[19];return p;
 }
 static Vector3f hip(int part,float[]p){float drop=p[18]-(12-12*(float)Math.cos(p[6]));return new Vector3f(side(part)*1.9f,12+drop,0);}
 static Vector3f shoulder(boolean left,float[]p){return new Vector3f(left?5:-5,2+p[20],p[21]);}
 static float pitch(int part,float[]p){return p[side(part)>0?15:12];}
 static Vector3f world(int part,float[]p,Vector3f local){return new Vector3f(local).rotateX(pitch(part,p)).add(hip(part,p));}
 // Restrict the palm to an actual outer face of the selected shin or ankle.
 static float candidate(int part,float[]p,boolean left,boolean working,float tangent,float desiredX,float desiredY,float desiredZ,Vector3f out){
  Vector3f h=hip(part,p),s=shoulder(left,p);float x=working?tangent:Math.copySign(2.05f,s.x-h.x),z=working?-2.05f:tangent,theta=pitch(part,p),c=(float)Math.cos(theta),sn=(float)Math.sin(theta);
  float ax=h.x+x-s.x,ay=h.y-z*sn-s.y,az=z*c-s.z,b=ay*c+az*sn,disc=b*b-(ax*ax+ay*ay+az*az-91.25f),best=Float.POSITIVE_INFINITY;if(disc<0)return best;
  float root=(float)Math.sqrt(disc),min=foot(part)?9:3,max=foot(part)?11.8f:8;
  for(float y:new float[]{-b-root,-b+root})if(y>=min&&y<=max){float cost=(x-desiredX)*(x-desiredX)+(y-desiredY)*(y-desiredY)*.8f+(z-desiredZ)*(z-desiredZ);if(cost<best){best=cost;out.set(x,y,z);}}
  return best;
 }
 public static Vector3f localGoal(int part,int kind,float t,boolean left){return localGoal(part,kind,t,left,posture(part,kind,t));}
 static Vector3f localGoal(int part,int kind,float t,boolean left,float[]p){
  boolean work=worker(part,left);float[]g=Motion59.gesture(part,kind,t,left);float desiredX=work?bound(g[0]*.6f,-1.8f,1.8f):side(part)*2.05f,desiredY=(foot(part)?10.3f:6)+bound(g[1]*.3f,-.7f,.7f),desiredZ=work?-2.05f:.7f;
  Vector3f bestPoint=new Vector3f(desiredX,desiredY,desiredZ),tryPoint=new Vector3f();float best=Float.POSITIVE_INFINITY,bestT=0;
  for(int i=0;i<=40;i++){float tangent=-2.05f+i*.1025f,cost=candidate(part,p,left,work,tangent,desiredX,desiredY,desiredZ,tryPoint);if(cost<best){best=cost;bestT=tangent;bestPoint.set(tryPoint);}}
  float step=.1025f;for(int i=0;i<8;i++){step*=.5f;float center=bestT;for(float v:new float[]{center-step,center+step}){v=bound(v,-2.05f,2.05f);float cost=candidate(part,p,left,work,v,desiredX,desiredY,desiredZ,tryPoint);if(cost<best){best=cost;bestT=v;bestPoint.set(tryPoint);}}}
  return bestPoint;
 }
 public static Vector3f thirdPalm(float[]p,boolean left){int i=left?3:0;return new Vector3f(left?1:-1,9.5f,0).rotate(new Quaternionf().rotationZYX(p[i+2],p[i+1],p[i])).add(shoulder(left,p));}
 public static Vector3f thirdGoal(int part,int kind,float t,boolean left){float[]p=posture(part,kind,t);return world(part,p,localGoal(part,kind,t,left,p));}
 public static float[] third(int part,int kind,float t){
  float[]p=posture(part,kind,t);if(!lower(part)||kind>7)return p;float blend=Motion59.ease((t-8)/8);
  for(boolean left:new boolean[]{false,true}){Vector3f target=world(part,p,localGoal(part,kind,t,left,p)),d=target.sub(shoulder(left,p));Quaternionf q=new Quaternionf().rotationTo(left?1:-1,9.5f,0,d.x,d.y,d.z);float[] grip=Motion59.gesture(part,kind,t,left);float length=(float)Math.sqrt(91.25);q.rotateAxis(grip[5]*.017f+grip[4]*.008f,(left?1:-1)/length,9.5f/length,0);Vector3f angles=euler(q);int i=left?3:0;for(int a=0;a<3;a++){float goal=angles.get(a),old=p[i+a];p[i+a]=old+(float)Math.atan2(Math.sin(goal-old),Math.cos(goal-old))*blend;}}
  return p;
 }
 public static float[] thirdFor(int part,int kind,float fallback,Object player,float age){return third(part,kind,kind>=8?fallback:Motion59.elapsedFor(player,part,kind,age,fallback,1));}
 /** Raised selected leg in the same first-person model space as the native consumable rig. */
 public static Matrix4f firstLimb(int part){return new Matrix4f().translate(side(part)*2.6f,42,13).rotateZ((float)Math.PI).rotateX(foot(part)?-.95f:-.65f);}
 public static Vector3f firstGoal(int part,int kind,float t,boolean left){
  float[]g=Motion59.gesture(part,kind,t,left);boolean work=worker(part,left);Vector3f local=new Vector3f(work?bound(g[0]*.45f,-1.75f,1.75f):side(part)*2.05f,(foot(part)?10.5f:6)+bound(g[1]*.22f,-.6f,.6f),work?-2.05f:bound(g[2]*.3f,-1.5f,1.5f));return firstLimb(part).transformPosition(local);
 }
 static Matrix4f matrix(Object node){
  List<Object> path=new ArrayList<>();for(Object n=node;n!=null&&path.size()<32;n=R.call(n,"getParent"))path.add(n);Matrix4f m=new Matrix4f();for(int i=path.size()-1;i>=0;i--){Object n=path.get(i);m.translate(f(n,"offsetX")+f(n,"x")/16,f(n,"offsetY")+f(n,"y")/16,f(n,"offsetZ")+f(n,"z")/16).rotateZYX(f(n,"zRot"),f(n,"yRot"),f(n,"xRot")).rotate((Quaternionfc)R.get(n,"additionalQuaternion")).scale(f(n,"xScale"),f(n,"yScale"),f(n,"zScale"));}return m;
 }
 public static Vector3f firstPalm(Object rig,boolean left){Object hand=R.call(rig,"getNode",left?"lefthand_pos":"righthand_pos");return matrix(hand).transformPosition(new Vector3f(left?-6:6,-11.5f,0).div(16)).mul(16);}
 public static void firstBones(Object rig,int part,int kind,float t,float weight){
  if(!lower(part)||kind>7)return;float blend=weight*Motion59.ease((t-6)/8);
  for(boolean left:new boolean[]{true,false}){Object ctrl=R.call(rig,"getNode",left?"mag_and_lefthand":"gun_and_righthand"),hand=R.call(rig,"getNode",left?"lefthand_pos":"righthand_pos");if(ctrl==null||hand==null)return;Vector3f delta=firstGoal(part,kind,t,left).sub(firstPalm(rig,left)).div(16);Object parent=R.call(ctrl,"getParent");if(parent!=null)matrix(parent).invert().transformDirection(delta);R.set(ctrl,"offsetX",f(ctrl,"offsetX")+delta.x*blend);R.set(ctrl,"offsetY",f(ctrl,"offsetY")+delta.y*blend);R.set(ctrl,"offsetZ",f(ctrl,"offsetZ")+delta.z*blend);}
 }
 static void renderPart(Object part,Object pose,Object vertex,int light,int alpha){
  String[]fields={"x","y","z","xRot","yRot","zRot","xScale","yScale","zScale"};float[] saved=new float[fields.length];Object visible=R.get(part,"visible");for(int i=0;i<fields.length;i++)saved[i]=f(part,fields[i]);try{for(int i=0;i<fields.length;i++)R.set(part,fields[i],i<6?0f:1f);R.set(part,"visible",true);R.call(part,"render",pose,vertex,light,655360,alpha<<24|0xffffff);}finally{for(int i=0;i<fields.length;i++)R.set(part,fields[i],saved[i]);R.set(part,"visible",visible);}
 }
 public static void drawLimb(Object rig,Object pose,Object player,Object stack,Object buffer,int light,float partial){try{
  float[]c=FirstPerson57.CLOCK.get(player);if(c==null||!lower((int)c[1])||c[2]>7||c[3]<.05f||R.call(rig,"getNode","bandage")==null)return;int part=(int)c[1];float age=f(player,"tickCount")+partial,t=Motion59.elapsed(player,part,(int)c[2],age,age-c[0]),weight=c[3]*Motion59.ease(t/8);if(weight<.01f)return;
  Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance"),renderer=R.call(R.call(mc,"getEntityRenderDispatcher"),"getRenderer",player),model=R.call(renderer,"getModel"),skin=R.call(R.call(player,"getSkin"),"texture"),type=R.call(R.type("net.minecraft.client.renderer.RenderType"),"entityTranslucent",skin),vertex=R.call(buffer,"getBuffer",type);
  R.call(pose,"pushPose");try{R.call(pose,"translate",(double)(side(part)*2.6f/16),42d/16,13d/16);R.call(pose,"mulPose",new Quaternionf().rotationZ((float)Math.PI).rotateX(foot(part)?-.95f:-.65f));int alpha=Math.max(1,Math.min(255,(int)(weight*255)));String name=side(part)>0?"left":"right";renderPart(R.get(model,name+"Leg"),pose,vertex,light,alpha);Object pants=R.get(model,name+"Pants");if(R.yes(R.get(pants,"visible")))renderPart(pants,pose,vertex,light,alpha);}finally{R.call(pose,"popPose");}
 }catch(RuntimeException e){MedicalMotion.warn(e);}}
}
