package dev.zomboid.firstaid;
import java.util.*;import org.joml.Quaternionf;
public class Rig60{
 public static class Node{public float x,y,z,xRot,yRot,zRot,offsetX,offsetY,offsetZ,xScale=1,yScale=1,zScale=1;public Quaternionf additionalQuaternion=new Quaternionf();public Node parent;public Node getParent(){return parent;}}
 public Map<String,Node> nodes=new HashMap<>();public Node getNode(String name){return nodes.get(name);}public Rig60(){
nodes.put("root",new Node());
nodes.put("mag_and_lefthand",new Node());
nodes.put("lefthand",new Node());
nodes.put("lefthand_pos",new Node());
nodes.put("medic",new Node());
nodes.put("bag_front",new Node());
nodes.put("zipper",new Node());
nodes.put("chain",new Node());
nodes.put("bag_back",new Node());
nodes.put("gun_and_righthand",new Node());
nodes.put("righthand",new Node());
nodes.put("righthand_pos",new Node());
nodes.put("bandage",new Node());
nodes.put("bone",new Node());
nodes.put("camera",new Node());
nodes.put("views",new Node());
nodes.put("idle_view",new Node());
{Node n=nodes.get("root");n.x=-6.0f;n.y=13.0f;n.z=8.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);}
{Node n=nodes.get("mag_and_lefthand");n.x=0.0f;n.y=0.0f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("root");}
{Node n=nodes.get("lefthand");n.x=0.0f;n.y=0.0f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("mag_and_lefthand");n.yScale=1.5f;}
{Node n=nodes.get("lefthand_pos");n.x=6.0f;n.y=11.0f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("lefthand");}
{Node n=nodes.get("medic");n.x=6.0f;n.y=11.0f;n.z=-7.5f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("mag_and_lefthand");}
{Node n=nodes.get("bag_front");n.x=0.0f;n.y=-2.0f;n.z=-0.5f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("medic");}
{Node n=nodes.get("zipper");n.x=-3.23438f;n.y=-2.09375f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("bag_front");}
{Node n=nodes.get("chain");n.x=-0.2031200000000002f;n.y=-0.03125f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("zipper");}
{Node n=nodes.get("bag_back");n.x=0.0f;n.y=-2.0f;n.z=-0.5f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("medic");}
{Node n=nodes.get("gun_and_righthand");n.x=12.0f;n.y=0.0f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("root");}
{Node n=nodes.get("righthand");n.x=0.0f;n.y=0.0f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("gun_and_righthand");n.yScale=1.5f;}
{Node n=nodes.get("righthand_pos");n.x=-6.0f;n.y=11.0f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("righthand");}
{Node n=nodes.get("bandage");n.x=-6.0f;n.y=8.75f;n.z=-8.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(-90);n.parent=nodes.get("gun_and_righthand");}
{Node n=nodes.get("bone");n.x=-0.23599f;n.y=0.0f;n.z=0.44715f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("bandage");}
{Node n=nodes.get("camera");n.x=0.0f;n.y=13.425f;n.z=14.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);}
{Node n=nodes.get("views");n.x=0.0f;n.y=24.0f;n.z=0.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);}
{Node n=nodes.get("idle_view");n.x=0.0f;n.y=-10.575f;n.z=14.0f;n.xRot=(float)Math.toRadians(0);n.yRot=(float)Math.toRadians(0);n.zRot=(float)Math.toRadians(0);n.parent=nodes.get("views");}
}}