package dev.zomboid.firstaid;
import org.joml.*;import java.util.*;
public class TestDraw60{
 public static class Player{public int tickCount=30;public Skin getSkin(){return new Skin();}public int getUseItemRemainingTicks(){return 36;}public boolean isUsingItem(){return true;}}
 public static class Skin{public Object texture(){return "actual-player-skin";}}
 public static class Pose{public Matrix4f matrix=new Matrix4f();public Deque<Matrix4f> stack=new ArrayDeque<>();public void pushPose(){stack.push(new Matrix4f(matrix));}public void popPose(){matrix=stack.pop();}public void translate(double x,double y,double z){matrix.translate((float)x,(float)y,(float)z);}public void mulPose(Quaternionf q){matrix.rotate(q);}}
 public static class Buffer{public Object getBuffer(Object type){return type;}}
 public static class Part{public float x=1,y=12,z=0,xRot=.4f,yRot=.2f,zRot=.1f,xScale=.9f,yScale=.8f,zScale=1.2f;public boolean visible=true,fail;public int renders;public Matrix4f last;public void render(Object pose,Object vertex,int light,int overlay,int color){renders++;last=new Matrix4f(((Pose)pose).matrix);if(fail)throw new IllegalStateException("simulated render failure");if(x!=0||y!=0||z!=0||xRot!=0||yRot!=0||zRot!=0||xScale!=1||yScale!=1||zScale!=1)throw new AssertionError("unreset limb");}}
 public static class Model{public Part leftLeg=new Part(),rightLeg=new Part(),leftPants=new Part(),rightPants=new Part();}
 public static class Renderer{public Model model=new Model();public Object getModel(){return model;}}
 public static class Dispatcher{public Renderer renderer=new Renderer();public Object getRenderer(Object player){return renderer;}}
 static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
 public static void main(String[]a){Player p=new Player();Pose pose=new Pose();Dispatcher dispatcher=new Dispatcher();net.minecraft.client.Minecraft.INSTANCE.dispatcher=dispatcher;Model m=dispatcher.renderer.model;Rig60 rig=new Rig60();
  FirstPerson57.CLOCK.put(p,new float[]{0,2,1,1,0});MedicalMotion.warned=false;
  me.xjqsh.lrtactical.compat.firstaid.MedicalLimb60.draw(rig,pose,p,null,new Buffer(),170,0);
  check(!MedicalMotion.warned,"reflective draw failed");check(m.leftLeg.renders==1&&m.leftPants.renders==1&&m.rightLeg.renders==0,"wrong leg drawn");check(m.leftLeg.x==1&&m.leftLeg.y==12&&m.leftLeg.xRot==.4f&&m.leftLeg.xScale==.9f&&m.leftLeg.visible,"shared model leaked");check(pose.stack.isEmpty()&&pose.matrix.equals(new Matrix4f()),"pose scope leaked");
  Vector3f local=new Vector3f(0,6,-2.05f),rendered=m.leftLeg.last.transformPosition(new Vector3f(local).div(16)).mul(16),target=Contact60.firstLimb(2).transformPosition(new Vector3f(local));check(rendered.distance(target)<.0001f,"first limb and hand use different model spaces");check("actual-player-skin".equals(net.minecraft.client.renderer.RenderType.skin),"wrong texture");
  FirstPerson57.CLOCK.put(p,new float[]{0,6,1,1,0});me.xjqsh.lrtactical.compat.firstaid.MedicalLimb60.draw(rig,pose,p,null,new Buffer(),170,0);check(m.rightLeg.renders==1&&m.leftLeg.renders==1,"right leg selection");
  FirstPerson57.CLOCK.remove(p);me.xjqsh.lrtactical.compat.firstaid.MedicalLimb60.draw(rig,pose,p,null,new Buffer(),170,0);check(m.rightLeg.renders==1,"idle draw");
  Part part=new Part();part.fail=true;try{Contact60.renderPart(part,pose,new Object(),170,255);throw new AssertionError();}catch(IllegalStateException expected){}check(part.x==1&&part.xRot==.4f&&part.xScale==.9f,"failed render restoration");
  System.out.println("PASS: real optional LR bridge -> reflective leg draw, selected side, player skin, model-space alignment, idle, shared-model restoration and render failure cleanup");
 }
}
