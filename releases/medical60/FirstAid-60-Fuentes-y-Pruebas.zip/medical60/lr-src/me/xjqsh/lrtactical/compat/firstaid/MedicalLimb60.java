package me.xjqsh.lrtactical.compat.firstaid;
import java.lang.reflect.Method;
public final class MedicalLimb60{
 static Method draw;static boolean absent,warned;
 public static void draw(Object rig,Object pose,Object player,Object stack,Object buffer,int light,float partial){if(absent)return;try{if(draw==null)draw=Class.forName("dev.zomboid.firstaid.Contact60").getMethod("drawLimb",Object.class,Object.class,Object.class,Object.class,Object.class,int.class,float.class);draw.invoke(null,rig,pose,player,stack,buffer,light,partial);}catch(ClassNotFoundException|NoSuchMethodException e){absent=true;}catch(ReflectiveOperationException e){if(!warned){warned=true;System.err.println("[LR] Medical limb preview: "+e);}}}
}
