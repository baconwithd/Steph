package net.minecraft.client;
public class Minecraft{public static final Minecraft INSTANCE=new Minecraft();public Object dispatcher;public static Minecraft getInstance(){return INSTANCE;}public Object getEntityRenderDispatcher(){return dispatcher;}}
