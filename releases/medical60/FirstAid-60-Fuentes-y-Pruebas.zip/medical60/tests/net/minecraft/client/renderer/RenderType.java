package net.minecraft.client.renderer;
public class RenderType{public static Object skin;public static Object entityTranslucent(Object texture){skin=texture;return texture;}}
