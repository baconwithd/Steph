package dev.zomboid.firstaid;
import org.joml.Vector3f;
public class TestContact60{
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 public static void main(String[]args){float maxThird=0,maxFirst=0;int checked=0;
  for(int part:new int[]{2,3,6,7})for(int kind=1;kind<=7;kind++)for(float t=16;t<=60;t+=.5f){float[]p=Contact60.third(part,kind,t);for(float v:p)check(Float.isFinite(v),"NaN");
   for(boolean left:new boolean[]{true,false}){Vector3f goal=Contact60.thirdGoal(part,kind,t,left),palm=Contact60.thirdPalm(p,left),local=Contact60.localGoal(part,kind,t,left);float error=goal.distance(palm);maxThird=Math.max(maxThird,error);check(error<.015f,"missed third contact part="+part+" kind="+kind+" t="+t+" error="+error);check(Math.abs(local.x)>=2.049f||Math.abs(local.z)>=2.049f,"hand inside skin");check(local.y>=(Contact60.foot(part)?9:3)&&local.y<=(Contact60.foot(part)?11.8f:8),"wrong region");}
   boolean selectedLeft=part==2||part==3;check(p[selectedLeft?15:12]<p[selectedLeft?12:15],"wrong leg lifted");
   float drop=p[18]-(12-12*(float)java.lang.Math.cos(p[6]));float standing=p[selectedLeft?12:15];check(java.lang.Math.abs((12+drop+12*java.lang.Math.cos(standing))-24)<.001,"standing foot floats");
   var rig=new Rig60();for(boolean left:new boolean[]{true,false})FirstPerson58.set(rig.getNode(left?"mag_and_lefthand":"gun_and_righthand"),Motion59.first(part,kind,t,left),1);
   Contact60.firstBones(rig,part,kind,t,1);for(boolean left:new boolean[]{true,false}){float error=Contact60.firstPalm(rig,left).distance(Contact60.firstGoal(part,kind,t,left));maxFirst=Math.max(maxFirst,error);check(error<.015,"missed first contact "+error);}
   checked++;
  }
  // The previous free path must not satisfy the contact test.
  float[]old=Motion59.third(2,1,30);check(Contact60.thirdPalm(old,false).distance(Contact60.thirdGoal(2,1,30,false))>1,"regression does not reject old free path");
  var rig=new Rig60();float before=rig.getNode("root").offsetX;Contact60.firstBones(rig,0,1,30,1);check(before==rig.getNode("root").offsetX,"non-leg modified");
  for(int frame=0;frame<30;frame++){float[] actual=MedicalMotion.angles(2,1,frame),expected=Contact60.third(2,1,frame);for(int i=0;i<12;i++)check(actual[i]==expected[i],"dispatch not connected");}
  System.out.println("PASS "+checked+" leg/action/frame cases; maximum palm contact error in pixels: third="+maxThird+", first="+maxFirst+"; correct side, outer surface, grounded standing foot and old-patch rejection");
 }
}
