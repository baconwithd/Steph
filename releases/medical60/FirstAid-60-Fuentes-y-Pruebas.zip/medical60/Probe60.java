package dev.zomboid.firstaid;
import org.joml.*;
public class Probe60{
 public static void main(String[]a){for(int part:new int[]{2,3,6,7})for(int kind=1;kind<=7;kind++)for(int frame=0;frame<=100;frame++){float t=frame*.66f;Rig60 rig=new Rig60();for(boolean left:new boolean[]{true,false})FirstPerson58.set(rig.getNode(left?"mag_and_lefthand":"gun_and_righthand"),Motion59.first(part,kind,t,left),1);FirstPerson58.set(rig.getNode("bandage"),new float[]{10.605f,-6.901f,53.399f,4.432f,8.802f,7.019f},1);Contact60.firstBones(rig,part,kind,t,1);System.out.print(part+","+kind+","+frame);
  for(boolean left:new boolean[]{true,false}){var n=rig.getNode(left?"mag_and_lefthand":"gun_and_righthand");Vector3f e=Contact60.euler(n.additionalQuaternion);for(float v:new float[]{(float)java.lang.Math.toDegrees(e.x),(float)java.lang.Math.toDegrees(e.y),(float)java.lang.Math.toDegrees(e.z),n.offsetX*16,-n.offsetY*16,n.offsetZ*16})System.out.print(","+v);}
  for(float v:Contact60.third(part,kind,t))System.out.print(","+v);for(float v:Contact60.firstLimb(part).get(new float[16]))System.out.print(","+v);System.out.println();
 }}
}
