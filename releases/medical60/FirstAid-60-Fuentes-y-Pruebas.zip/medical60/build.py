from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;o=r/'output';o.mkdir(exist_ok=True);fa=next((r.parent/'medical59/output').glob('firstaid*.jar'));lr=next((r.parent/'medical59/output').glob('Les*.jar'));joml=r.parent/'medical58/joml.jar'
for src,cp,dst in [('src',str(fa)+':'+str(joml),'classes'),('lr-src',str(lr),'lr')]:
 d=r/'build'/dst;d.mkdir(parents=True,exist_ok=True);subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(d),*map(str,(r/src).rglob('*.java'))],check=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']];d=r/'build/tools';d.mkdir(exist_ok=True)
subprocess.run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(d),str(r.parent/'medical52/Patch52.java'),str(r/'Patch60.java')],check=True)
subprocess.run(['java',*f,'-cp',str(d),'Patch60',str(fa),str(r/'build/classes'),str(o/'firstaid-1.21.1-ZOMBOID-v3.6.23-leg-contact-ik.jar'),str(lr),str(r/'build/lr'),str(o/'LesRaisins-Tactical-Equipements-1.21.1-0.4.3-medical-leg-view.7.jar')],check=True)
