from pathlib import Path
import subprocess,json,zipfile
r=Path(__file__).resolve().parent;prev=r.parent/'medical58';fa=next((r/'output').glob('firstaid*.jar'));lr=next((r/'output').glob('Les*.jar'));ta=next((prev/'output').glob('tacz*.jar'));cp=':'.join(map(str,[fa,lr,ta,prev/'joml.jar']));d=r/'build/test';d.mkdir(parents=True,exist_ok=True);results=[]
def run(cmd):
 p=subprocess.run(cmd,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();return p.stdout.strip()
run(['java','com.sun.tools.javac.Main','-cp',cp,'-d',str(d),str(r/'Rig60.java'),str(r/'TestContact60.java'),str(r/'TestDraw60.java'),str(r/'Probe60.java'),*map(str,(r/'tests').rglob('*.java'))])
for test in ['TestContact60','TestDraw60']:results.append(run(['java','-Xverify:all','-cp',str(d)+':'+cp,'dev.zomboid.firstaid.'+test]))
with open(r/'poses.csv','w')as f:subprocess.run(['java','-Xverify:all','-cp',str(d)+':'+cp,'dev.zomboid.firstaid.Probe60'],stdout=f,check=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree']]
run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(d),str(r/'Contract60.java'),str(prev/'Contract58.java'),str(r.parent/'medical57/Contract57.java')])
for test,args in [('Contract60',[lr,fa]),('Contract58',[lr,ta]),('Contract57',[fa,lr])]:results.append(run(['java',*f,'-cp',str(d),test,*map(str,args)]))
audit={}
for new,pattern in [(fa,'firstaid*.jar'),(lr,'Les*.jar')]:
 with zipfile.ZipFile(new)as z,zipfile.ZipFile(next((r.parent/'medical59/output').glob(pattern)))as b:
  audit[new.name]={'changed':[n for n in b.namelist()if b.read(n)!=z.read(n)],'added':sorted(set(z.namelist())-set(b.namelist()))}
(r/'output/test-results.json').write_text(json.dumps({'results':results,'audit':audit,'full_minecraft_runtime':False,'preview':'Offline native first-person rig and pure third-person contact poses; no gameplay recording'},indent=2))
