package net.minecraft.client.gui.screens;public class ChatScreen extends Screen{public String initial;public ChatScreen(String s){super(net.minecraft.network.chat.Component.empty());initial=s;}}
