package dev.survivorcreator.data;public record CharacterData(boolean completed){public static final CharacterData EMPTY=new CharacterData(false);}
