package dev.survivorcreator.data;public class ClientState{public static CharacterData character=new CharacterData(true);}
