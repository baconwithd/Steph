package dev.zomboid.autopsy.death64;
import dev.zomboid.autopsy.R;import java.util.*;
/** Respawn only after a valid character submission, never while displaying the death summary. */
public final class Server64{
 static final Map<Object,Boolean> REPORTED=Collections.synchronizedMap(new WeakHashMap<>());static final ThreadLocal<Boolean> CREATING=ThreadLocal.withInitial(()->false);
 static Object cls(String s){return R.type(s);}static Object call(Object o,String m,Object...a){return R.call(o,m,a);}
 public static boolean tick(Object event){Object p=call(event,"getEntity");if(!R.type("net.minecraft.server.level.ServerPlayer").isInstance(p)||R.yes(call(p,"isAlive")))return false;if(!R.yes(call(p,"isRemoved"))&&REPORTED.put(p,true)==null)call(cls("dev.survivorcreator.DeathHooks"),"sendDeath",p);return true;}
 public static void notice(Object player){if(!CREATING.get())call(cls("dev.survivorcreator.DeathHooks"),"sendDeath",player);}
 static void reject(Object player,String message){Object payload=R.make("dev.survivorcreator.net.Net$Result",false,"survivorcreator.spawn.error",message);Object empty=java.lang.reflect.Array.newInstance(R.type("net.minecraft.network.protocol.common.custom.CustomPacketPayload"),0);call(cls("net.neoforged.neoforge.network.PacketDistributor"),"sendToPlayer",player,payload,empty);}
 public static boolean confirm(Object old,Object confirm){if(R.yes(call(old,"isAlive")))return false;if(CREATING.get()||R.yes(call(old,"isRemoved")))return true;Object server=call(old,"getServer");if(server==null)return true;if(R.yes(call(server,"isHardcore"))){reject(old,"Este mundo extremo no permite reaparecer.");return true;}
 // Validate the same fields before replacing the dead ServerPlayer. Strip only the native spawn selector.
 List<Object> perks=new ArrayList<>();int zone=-1;for(Object perk:(List<?>)call(confirm,"perks")){String s=perk.toString();if(s.startsWith("survivorcreator:spawn_")){try{int n=Integer.parseInt(s.substring("survivorcreator:spawn_".length()));if(zone>=0||n<0||n>9)throw new IllegalArgumentException();zone=n;}catch(IllegalArgumentException e){reject(old,"Zona de aparición inválida.");return true;}}else perks.add(perk);}
 Object checked=call(cls("dev.survivorcreator.data.Validator"),"validate",call(confirm,"profession"),List.copyOf(perks),true);if(!R.yes(call(checked,"ok"))){Object payload=R.make("dev.survivorcreator.net.Net$Result",false,call(checked,"key"),call(checked,"arg"));Object empty=java.lang.reflect.Array.newInstance(R.type("net.minecraft.network.protocol.common.custom.CustomPacketPayload"),0);call(cls("net.neoforged.neoforge.network.PacketDistributor"),"sendToPlayer",old,payload,empty);return true;}
 CREATING.set(true);try{Object next=call(call(server,"getPlayerList"),"respawn",old,false,R.get(R.type("net.minecraft.world.entity.Entity$RemovalReason"),"KILLED"));R.set(R.get(next,"connection"),"player",next);call(cls("dev.survivorcreator.Events"),"handleConfirm",next,confirm);}finally{CREATING.remove();}return true;
 }
}
