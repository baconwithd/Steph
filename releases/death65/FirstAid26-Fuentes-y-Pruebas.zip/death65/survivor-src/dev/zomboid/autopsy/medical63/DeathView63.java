package dev.zomboid.autopsy.medical63;
import dev.zomboid.autopsy.R;
/** Bridge to the pre-respawn death screen. Never reopen a post-respawn summary. */
public final class DeathView63{
 static Object current,area;static int focus=-1;
 static Class<?> view(){return R.type("dev.zomboid.firstaid.Cinematic63");}static Class<?> flow(){return R.type("dev.zomboid.firstaid.Death64");}
 public static boolean render(Object screen,Object g,int x,int y,float dt){if(!R.yes(R.get(screen,"deathMode")))return false;try{view();flow();}catch(IllegalStateException absent){return false;}if(current!=screen){current=screen;focus=-1;R.call(R.type("dev.survivorcreator.client.DeathAudio"),"beginDeath");}Object m=R.call(view(),"mc");if(!R.yes(R.get(flow(),"pending")))R.call(flow(),"hold",R.get(m,"player"));R.call(view(),"enter");area=R.call(view(),"draw",g,R.get(screen,"font"),R.get(screen,"width"),R.get(screen,"height"),x,y,true,false,new String[]{"Nuevo personaje","Menú principal","Salir al escritorio"},focus,R.get(view(),"lifeTicks"),R.get(view(),"kills"),0);return true;}
 public static boolean click(Object screen,double x,double y,int button){x=((Number)R.call(R.type("dev.survivorcreator.hudscale.ScreenScale"),"input",x)).doubleValue();y=((Number)R.call(R.type("dev.survivorcreator.hudscale.ScreenScale"),"input",y)).doubleValue();if(button==0&&area!=null)for(int i=0;i<3;i++)if(R.yes(R.call(area,"hit",x,y,i))){R.call(flow(),"choose",i);break;}return true;}
 public static boolean key(Object screen,int key){if(key==258||key==264||key==265)focus=focus<0?(key==265?2:0):(focus+(key==265?-1:1)+3)%3;else if(focus>=0&&(key==257||key==32))R.call(flow(),"choose",focus);return true;}
 static void finish(Object screen){R.call(flow(),"beginCreation");}
 public static boolean redirect(Object result){try{flow();view();}catch(IllegalStateException absent){return false;}boolean death=R.yes(R.call(result,"ok"))&&"__death__".equals(R.call(result,"arg"));if(death){Object m=R.call(view(),"mc"),p=R.get(m,"player");if(p==null||R.get(m,"level")==null)return true;if(!R.yes(R.get(flow(),"pending")))R.call(flow(),"hold",p);
 try{Object report=R.get(R.type("dev.survivorcreator.hearing.DeathPanel"),"report"),detail=R.get(R.type("dev.survivorcreator.hearing.DeathPanel"),"detail");long ticks=((Number)R.call(report,"ticks")).longValue();if(ticks>=0)R.set(view(),"lifeTicks",ticks);if(R.yes(R.call(detail,"has","zombies24")))R.set(view(),"kills",((Number)R.call(R.call(detail,"get","zombies24"),"getAsInt")).intValue());}catch(IllegalStateException absent){}
 if(!R.yes(R.get(flow(),"creating"))){R.call(m,"setScreen",R.make("dev.zomboid.firstaid.FinalScreen63"));R.call(R.type("dev.survivorcreator.client.DeathAudio"),"beginDeath");}return true;}
 if(R.yes(R.get(flow(),"creating"))&&R.yes(R.call(result,"ok")))R.call(flow(),"completed");return false;}
}
