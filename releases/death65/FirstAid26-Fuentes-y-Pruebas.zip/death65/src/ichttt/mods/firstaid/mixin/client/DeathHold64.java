package ichttt.mods.firstaid.mixin.client;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.At;import org.spongepowered.asm.mixin.injection.Inject;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="net.minecraft.client.player.LocalPlayer",remap=false)
public abstract class DeathHold64{
 @Inject(method="respawn()V",at=@At("HEAD"),cancellable=true,require=1)
 private void firstaid$holdDeathView64(CallbackInfo ci){if(dev.zomboid.firstaid.Death64.blockRespawn())ci.cancel();}
}
