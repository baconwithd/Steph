package dev.zomboid.firstaid;
public final class UnconsciousClient{
 static boolean is(Object o,String name){return o!=null&&o.getClass().getName().equals("dev.zomboid.firstaid."+name);}
 static Object lastPlayer;static boolean wasDown;
 public static void tick(){Object m=Cinematic63.mc(),p=R.get(m,"player"),w=R.get(m,"level"),s=R.get(m,"screen");if(p==null||w==null){wasDown=false;lastPlayer=null;Cinematic63.disconnected();if(is(s,"UnconsciousScreen")||is(s,"FinalScreen63"))R.call(m,"setScreen",new Object[]{null});return;}Cinematic63.observe();boolean down=DownedSupport.down(p),alive=R.yes(R.call(p,"isAlive"));boolean fresh=down&&(!wasDown||lastPlayer!=p);wasDown=down;lastPlayer=p;
 if(Death64.pending){if(Death64.standaloneRespawn&&alive){Death64.completed();if(is(s,"FinalScreen63")||is(s,"UnconsciousScreen"))R.call(m,"setScreen",new Object[]{null});return;}Cinematic63.enter();if(Death64.creating&&s==null&&!alive)Death64.creating=false;if(!Death64.creating&&(s==null||s.getClass().getName().equals("net.minecraft.client.gui.screens.DeathScreen")||is(s,"UnconsciousScreen")))R.call(m,"setScreen",R.make("dev.zomboid.firstaid.FinalScreen63"));return;}
 if(down){Cinematic63.enter();if(fresh||s==null)R.call(m,"setScreen",R.make("dev.zomboid.firstaid.UnconsciousScreen"));}
 else if(!alive){Death64.hold(p);Cinematic63.enter();if(s==null||s.getClass().getName().equals("net.minecraft.client.gui.screens.DeathScreen")||is(s,"UnconsciousScreen"))R.call(m,"setScreen",R.make("dev.zomboid.firstaid.FinalScreen63"));}
 else if(Cinematic63.ending(s)){Cinematic63.enter();}else{Cinematic63.release();Cinematic63.requestedRespawn=false;if(is(s,"UnconsciousScreen")||is(s,"FinalScreen63"))R.call(m,"setScreen",new Object[]{null});}
 }
}
