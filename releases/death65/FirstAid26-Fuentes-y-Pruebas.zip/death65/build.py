from pathlib import Path
import subprocess,json,os,zipfile
r=Path(__file__).resolve().parent;root=r.parents[1];o=r/'output';o.mkdir(exist_ok=True);b=r/'build';b.mkdir(exist_ok=True)
f=Path(os.environ.get('FIRSTAID_BASE',str(root/'attachments/55182a59-077a-4aa8-a5dc-c506b79e2c9c/firstaid-1.21.1-ZOMBOID-v3.6.24-unified-health-splint-game.jar')));s=Path(os.environ.get('SURVIVOR_BASE',str(root/'attachments/251699a4-0273-48f9-892b-924645faf2de/survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v37-package-conflict-fix.jar')))
stubs=b/'stubs';stubs.mkdir(exist_ok=True)
paths=['org/spongepowered/asm/mixin/Mixin.java','org/spongepowered/asm/mixin/injection/At.java','org/spongepowered/asm/mixin/injection/Inject.java','org/spongepowered/asm/mixin/injection/callback/CallbackInfo.java']
subprocess.run(['java','com.sun.tools.javac.Main','-d',str(stubs),*map(lambda p:str(r/'compile-stubs'/p),paths)],check=True)
for src,base,kind in [('src',f,'firstaid'),('survivor-src',s,'survivor')]:
 dst=b/kind;dst.mkdir(exist_ok=True);subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(base)+':'+str(stubs),'-d',str(dst),*map(str,(r/src).rglob('*.java'))],check=True)
flags=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+x+'=ALL-UNNAMED'for x in ['', '.tree','.tree.analysis']];d=b/'tools';d.mkdir(exist_ok=True)
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(d),str(r.parent/'medical52/Patch52.java'),str(r/'Patch64.java')],check=True)
fa=o/'firstaid-1.21.1-ZOMBOID-v3.6.26-death-font-chat.jar';su=o/'survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v38-deferred-character-respawn.jar'
subprocess.run(['java',*flags,'-cp',str(d),'Patch64',str(f),str(b/'firstaid'),str(fa),str(s),str(b/'survivor'),str(su)],check=True)
with zipfile.ZipFile(fa)as z:data={n:z.read(n)for n in z.namelist()}
cfg=json.loads(data['firstaid.mixins.json']);cfg['client'].append('client.DeathHold64');data['firstaid.mixins.json']=json.dumps(cfg,indent=2).encode()
data['assets/firstaid/font/pz64.json']=json.dumps({'providers':[{'type':'ttf','file':'firstaid:pz64.ttf','shift':[0,0],'size':11,'oversample':2},{'type':'reference','id':'minecraft:default'}]}).encode();data['assets/firstaid/font/pz64.ttf']=(r/'assets/pz64.ttf').read_bytes();data['assets/firstaid/font/LICENSE-DejaVu.txt']=(r/'assets/LICENSE-DejaVu.txt').read_bytes()
with zipfile.ZipFile(fa,'w',zipfile.ZIP_DEFLATED)as z:
 for n,v in data.items():z.writestr(n,v)
print('Font and required respawn mixin installed; annotation stubs are compile-only.')
