from pathlib import Path
import subprocess,json,os,zipfile,io
r=Path(__file__).resolve().parent;o=r/'output';d=r/'build/tests';d.mkdir(exist_ok=True);cp=':'.join(map(str,o.glob('*.jar')));results=[]
def run(cmd):
 p=subprocess.run(cmd,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();return p.stdout.strip()
run(['java','com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(d),*map(str,(r/'tests').rglob('*.java'))])
for name in ['dev.zomboid.autopsy.death64.TestServer64','dev.zomboid.firstaid.TestDeath64']:results.append(run(['java','-Xverify:all','-cp',str(d)+':'+cp,name,str(r/'build/ui.tsv')]))
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+x+'=ALL-UNNAMED'for x in ['', '.tree']]
run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(d),str(r/'Contract64.java')])
fa=next(o.glob('firstaid*.jar'));su=next(o.glob('survivor*.jar'))
results.append(run(['java',*f,'-cp',str(d),'Contract64',os.environ.get('FIRSTAID_BASE',str(r.parents[1]/'attachments/55182a59-077a-4aa8-a5dc-c506b79e2c9c/firstaid-1.21.1-ZOMBOID-v3.6.24-unified-health-splint-game.jar')),str(fa),os.environ.get('SURVIVOR_BASE',str(r.parents[1]/'attachments/251699a4-0273-48f9-892b-924645faf2de/survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v37-package-conflict-fix.jar')),str(su)]))
with zipfile.ZipFile(fa)as z:
 font=json.loads(z.read('assets/firstaid/font/pz64.json'));ttf=next(p for p in font['providers']if p['type']=='ttf');ns,path=ttf['file'].split(':',1);resolved='assets/'+ns+'/font/'+path
 assert resolved in z.namelist(),resolved
 assert any(p.get('type')=='reference'and p.get('id')=='minecraft:default'for p in font['providers'])
 from PIL import ImageFont
 ft=ImageFont.truetype(io.BytesIO(z.read(resolved)),11)
 assert all(ft.getmask(c).getbbox() is not None for c in 'ABCxyz019áéíóúñ¿¡')
 results.append('PASS font provider: native font/ prefix resolves to '+resolved+'; TTF opens and Spanish glyphs rasterize; vanilla fallback present.')
with zipfile.ZipFile(r.parent/'death64/output/firstaid-1.21.1-ZOMBOID-v3.6.25-pz-death-camera.jar')as z:
 font=json.loads(z.read('assets/firstaid/font/pz64.json'));ns,path=font['providers'][0]['file'].split(':',1)
 assert 'assets/'+ns+'/font/'+path not in z.namelist()
 results.append('PASS regression: old .25 font path reproduces missing font/font resource.')
print(results[-2:])
(o/'test-results.json').write_text(json.dumps({'runtime_tests':results,'full_minecraft_runtime':False,'fixture_note':'Game APIs and old medical helpers are test doubles. New renderer, client hold, native patched FinalScreen and server helper are production code.'},indent=2))
