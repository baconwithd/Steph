from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).resolve().parent;o=r/'output';d=r/'dist';d.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
fa=next(o.glob('firstaid*.jar'));original=r.parent/'death64/output'/next((r.parent/'death64/output').glob('firstaid*.jar')).name
with zipfile.ZipFile(next(o.glob('survivor*.jar')))as a,zipfile.ZipFile(next((r.parent/'death64/output').glob('survivor*.jar')))as b:assert {n:a.read(n)for n in a.namelist()}=={n:b.read(n)for n in b.namelist()}
manifest={'release':'death65','minecraft':'1.21.1','loader':'NeoForge','replace_only':'First Aid .25','keep':'Survivor Creator v38','previous_firstaid_sha256':sha(original),'output':{'file':fa.name,'bytes':fa.stat().st_size,'sha256':sha(fa)},'full_modpack_runtime_tested':False,'survivor38_content_unchanged':True};(o/'manifest.json').write_text(json.dumps(manifest,indent=2));files=[fa,o/'LEEME.md',o/'test-results.json',o/'manifest.json'];(o/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n'for p in files));files.append(o/'SHA256SUMS.txt')
with zipfile.ZipFile(d/'FirstAid26-Fuente-Camara-Chat.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in files:z.write(p,p.name)
with zipfile.ZipFile(d/'FirstAid26-Fuentes-y-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','survivor-src','tests','compile-stubs','assets']:
  for p in sorted((r/folder).rglob('*')):
   if p.is_file():z.write(p,'death65/'+str(p.relative_to(r)))
 for n in ['build.py','test.py','Patch64.java','Contract64.java','package.py']:z.write(r/n,'death65/'+n)
 z.write(r.parent/'medical52/Patch52.java','medical52/Patch52.java')
 for n in ['LEEME.md','manifest.json','test-results.json']:z.write(o/n,'death65/'+n)
 z.writestr('death65/BUILD.md','JDK 21+. Set FIRSTAID_BASE to the .24 JAR and SURVIVOR_BASE to v37, as in build.py, then run python build.py and python test.py. The test reproducing the .25 font error additionally reads ../death64/output/firstaid*.jar; adjust that local path to your previous .25 JAR. Survivor v38 is rebuilt only as a regression reference; its contents are unchanged and it is not included in the installation ZIP. No game or annotation fixtures are shipped in production.\n')
for p in d.glob('*.zip'):
 with zipfile.ZipFile(p)as z:assert z.testzip()is None
 print(p.name,p.stat().st_size,sha(p))
