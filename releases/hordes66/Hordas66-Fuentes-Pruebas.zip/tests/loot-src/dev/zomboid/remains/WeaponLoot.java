package dev.zomboid.remains;public class WeaponLoot{public record Ammo(String id,int count){}public static Ammo ammo(String id,int count){return new Ammo(id,count);}}
