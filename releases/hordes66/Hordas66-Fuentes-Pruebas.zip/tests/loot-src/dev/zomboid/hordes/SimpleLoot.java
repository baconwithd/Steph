package dev.zomboid.hordes;import java.util.*;public class SimpleLoot{public static Object single(String k,Object p,Object l,List<Object>r){return k;}}
