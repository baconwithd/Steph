package dev.zomboid.hordes;
import java.util.*;import java.nio.file.*;import java.lang.reflect.*;
public class Test66{
 static int tests;static void ok(boolean b,String m){if(!b)throw new AssertionError(m);tests++;}
 static void fails(Runnable r,String m){try{r.run();}catch(IllegalArgumentException e){tests++;return;}throw new AssertionError(m);}
 public static void main(String[]a)throws Exception{
 var snapshot=WorldTuning.snapshot();ok(snapshot.containsKey(Spawn66.SECONDS),"new settings installed");
 Path file=Path.of(a[0],"world.properties");Field f=WorldTuning.class.getDeclaredField("file");f.setAccessible(true);f.set(null,file);
 var settings=new HashMap<>(snapshot);settings.put("ambiente_limite_total",12d);settings.put("ambiente_limite_grupo",50d);settings.put("limite_zona",18d);settings.put(Spawn66.SECONDS,40d);settings.put(Spawn66.BURST,3d);settings.put("cadaveres_municion",90d);
 int rev=WorldTuning.revision();WorldTuning.batch(settings,rev);
 ok(WorldTuning.get("ambiente_limite_grupo")==12,"hidden group clamped instead of rejecting all changes");ok(ZoneReserve.limit==18,"zone cap is not overwritten with 256");ok(WorldTuning.get("cadaveres_municion")==90,"loot percentage applied");ok(WorldTuning.revision()==rev+1,"revision incremented");
 Properties p=new Properties();try(var in=Files.newInputStream(file)){p.load(in);}ok(p.getProperty("limite_zona").equals("18.0"),"atomic save contains cap");ok(p.getProperty(Spawn66.SECONDS).equals("40.0"),"cadence persisted");
 fails(()->{try{WorldTuning.batch(new HashMap<>(WorldTuning.snapshot()),rev);}catch(java.io.IOException e){throw new RuntimeException(e);}},"stale save refused");
 fails(()->WorldTuning.checked(Spawn66.BURST,2.5),"fractional burst rejected");fails(()->WorldTuning.checked(Spawn66.SECONDS,0),"zero interval refused");fails(()->WorldTuning.checked("cadaveres_municion",101),"invalid loot percentage");
 ok(Spawn66.period(30,1)==600,"normal cadence");ok(Spawn66.period(30,.5)==1200,"frequency scales cadence");ok(Spawn66.period(30,2)==300,"fast cadence");
 Object world=new Object(),other=new Object();ok(Spawn66.admit(world,0,600,2),"first admission");ok(Spawn66.admit(world,1,600,2),"second admission");ok(!Spawn66.admit(world,599,600,2),"shared burst capped");ok(Spawn66.admit(world,600,600,2),"new window");ok(Spawn66.admit(other,600,600,2),"world isolation");ok(Spawn66.admit(world,0,600,2),"clock reset");
 ok(AmbientSettings47.desired(0,24,100)==0,"heat cannot override zero density");ok(AmbientSettings47.desired(.2,24,100)<AmbientSettings47.desired(1,24,100),"density effective at max heat");ok(AmbientSettings47.desired(10,24,100)<=24,"local cap");
 Map<String,Double> preset=new HashMap<>();AmbientSettings47.preset(preset,2);ok(preset.get(Spawn66.SECONDS)==30&&preset.get(Spawn66.BURST)==2,"normal preset paced");ok(preset.get("ambiente_limite_total")==24&&preset.get("ambiente_limite_grupo")==4,"normal population reduced");
 System.out.println("PASS "+tests+" actual-JAR configuration and admission checks");
 }
}
