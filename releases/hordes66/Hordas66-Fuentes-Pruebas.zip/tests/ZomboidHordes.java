package dev.zomboid.hordes;
/** Fixture replacing only the unavailable NeoForge registration entrypoint. */
public final class ZomboidHordes{public static final Config CONFIG=new Config();public static class Config{public int daySpawnIntervalTicks=600,noiseCooldownTicks=600,nightWaveIntervalTicks=1200,helicopterWaveIntervalTicks=2400;}}
