from pathlib import Path
import subprocess,json,zipfile
r=Path(__file__).resolve().parent;root=r.parents[1];inputs=json.loads((r/'inputs.json').read_text());inputs={k:root/v for k,v in inputs.items()};b=r/'build';b.mkdir(exist_ok=True);o=r/'output';o.mkdir(exist_ok=True)
d=b/'classes';d.mkdir(exist_ok=True);subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(inputs['zomboid']),'-d',str(d),*map(str,(r/'src').rglob('*.java'))],check=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+x+'=ALL-UNNAMED'for x in ['', '.tree','.tree.analysis']];t=b/'tools';t.mkdir(exist_ok=True)
subprocess.run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(t),str(r.parent/'medical52/Patch52.java'),str(r/'Patch66.java')],check=True)
z=o/'zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.51-spawn-loot-authority.jar';m=o/'zombie-remains-loot-1.6.1-neoforge-1.21.1-useful-loot.27.jar';q=o/'quietly-1_0_0-cooldown-v21-preserve-loot.jar'
subprocess.run(['java',*f,'-cp',str(t),'Patch66',str(inputs['zomboid']),str(d),str(z),str(inputs['remains']),str(m),str(inputs['quietly']),str(q)],check=True)
# Improve survival materials without inventing optional item identifiers.
with zipfile.ZipFile(z)as f:data={n:f.read(n)for n in f.namelist()}
weights={'iron_ingot':10,'copper_ingot':10,'leather':8,'coal':8,'gunpowder':8,'string':6,'redstone':6,'paper':3,'flint':3,'iron_nugget':2,'slime_ball':1}
entries=[{'type':'minecraft:item','name':'minecraft:'+name,'weight':weight,'functions':[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':1,'max':3}}]}for name,weight in weights.items()]
data['data/zomboid_hordes/loot_table/profiles/materiales.json']=json.dumps({'type':'minecraft:chest','pools':[{'rolls':1,'entries':entries}]}).encode()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED)as f:
 for n,v in data.items():f.writestr(n,v)
