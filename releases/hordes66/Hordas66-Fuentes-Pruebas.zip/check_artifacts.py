from pathlib import Path
import zipfile,json
r=Path(__file__).resolve().parent;root=r.parents[1];inputs=json.loads((r/'inputs.json').read_text())
expected={'zomboid':{'dev/zomboid/hordes/ZoneReserve.class','dev/zomboid/hordes/Population47.class','dev/zomboid/hordes/SimplePanel.class','dev/zomboid/hordes/client/AdminScreen.class','dev/zomboid/hordes/SimpleLoot.class','dev/zomboid/hordes/AmbientSettings47.class','data/zomboid_hordes/loot_table/profiles/materiales.json'},'remains':{'dev/zomboid/remains/LootFinish15.class'},'quietly':{'dev/zomboid/scavenging/FinalLoot17.class'}}
for kind,prefix in [('zomboid','zomboid-hordes'),('remains','zombie-remains'),('quietly','quietly')]:
 out=next((r/'output').glob(prefix+'*.jar'))
 with zipfile.ZipFile(root/inputs[kind])as f:old={n:f.read(n)for n in f.namelist()}
 with zipfile.ZipFile(out)as f:
  assert f.testzip() is None
  new={n:f.read(n)for n in f.namelist()}
 changed={n for n in old if old[n]!=new.get(n)};added=set(new)-set(old)
 assert changed==expected[kind],(kind,changed)
 assert not(set(old)-set(new))
 assert all(n.startswith('dev/zomboid/hordes/Spawn66')or n=='dev/zomboid/hordes/Loot66.class'for n in added),(kind,added)
 print(kind,'PASS exact patch surface:',len(changed),'modified,',len(added),'added; remaining resources and cooldown code identical')
print('PASS ZIP integrity and original-file preservation')
