package dev.zomboid.hordes;
import java.util.*;
/** One live admission budget across ambient, vanilla, horde events and reserve wakeups. */
public final class Spawn66{
 public static final String SECONDS="ambiente_reposicion_segundos",BURST="ambiente_tanda";
 static final Map<Object,Window> WINDOWS=Collections.synchronizedMap(new WeakHashMap<>());static final Map<Object,Long> NEXT=new WeakHashMap<>();
 static final class Window{long start;int count;Window(long s){start=s;}}
 static Object c(Object o,String m,Object...a){return ZoneReflection.call(o,m,a);}static boolean yes(Object o){return Boolean.TRUE.equals(o);}
 static long time(Object level){return((Number)c(level,"getGameTime")).longValue();}
 public static long period(double seconds,double frequency){return Math.max(20,Math.min(120000,Math.round(seconds*20/Math.max(.1,frequency))));}
 static long period(){return period(WorldTuning.get(SECONDS),WorldTuning.get("frecuencia"));}
 public static void install(Map<String,Double>d,Map<String,Double>lo,Map<String,Double>hi,Map<String,Double>v){add(d,lo,hi,v,SECONDS,30,5,600);add(d,lo,hi,v,BURST,2,1,8);}
 static void add(Map<String,Double>d,Map<String,Double>lo,Map<String,Double>hi,Map<String,Double>v,String k,double value,double min,double max){d.put(k,value);lo.put(k,min);hi.put(k,max);v.putIfAbsent(k,value);}
 public static int batch(){return (int)WorldTuning.get(BURST);}
 public static void validate(String key,double v){if((key.equals(SECONDS)||key.equals(BURST))&&(!Double.isFinite(v)||v!=Math.rint(v)))throw new IllegalArgumentException("La tanda y el intervalo deben ser enteros.");}
 static boolean admit(Object level,long now,long interval,int batch){synchronized(WINDOWS){Window w=WINDOWS.get(level);if(w==null||now<w.start||now-w.start>=interval){w=new Window(now);WINDOWS.put(level,w);}if(w.count>=batch)return false;w.count++;return true;}}
 public static boolean join(Object event){Object level=c(event,"getLevel");if(yes(c(level,"isClientSide"))||yes(c(event,"loadedFromDisk")))return true;Object entity=c(event,"getEntity");if(!yes(c(ZoneReserve.class,"zombie",entity)))return true;
  // Player-zombie conversion owns a real player's belongings and is not ambient population.
  for(Class<?> k=entity.getClass();k!=null;k=k.getSuperclass())if(k.getSimpleName().equals("ZombiePlayer")||k.getSimpleName().equals("HuskPlayer")||k.getSimpleName().equals("DrownedPlayer"))return true;
  if(yes(c(event,"isCanceled")))return false;if(ZoneReserve.paused(level)){c(event,"setCanceled",true);return false;}
  if(!admit(level,time(level),period(),(int)WorldTuning.get(BURST))){c(event,"setCanceled",true);return false;}return true;
 }
 public static boolean due(Object level,long now){if(ZoneReserve.paused(level)||Budget49.full())return false;Long last=NEXT.get(level);long p=period();if(last!=null&&now>=last&&now-last<p)return false;NEXT.put(level,now);return true;}
 public static void applied(){ZoneReserve.limit=(int)WorldTuning.get("limite_zona");Population47.CACHE.clear();}
 public static String[] keys(String[] a){return append(Budget49.keys(a),"frecuencia",SECONDS,BURST,"limite_zona");}
 public static String[] labels(String[] a){return append(Budget49.labels(a),"Frecuencia (menor = mas lento)","Reposicion base (segundos)","Maximo de nuevos por intervalo","Maximo activo por zona (6x6 chunks)");}
 public static String[] icons(String[] a){return append(Budget49.icons(a),"minecraft:clock","minecraft:clock","minecraft:zombie_head","minecraft:filled_map");}
 static String[]append(String[]a,String...b){String[]o=Arrays.copyOf(a,a.length+b.length);System.arraycopy(b,0,o,a.length,b.length);return o;}
}
