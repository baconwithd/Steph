package dev.zomboid.hordes;
import java.util.Map;
public final class AmbientSettings47{
 public static final String TOTAL="ambiente_limite_total",GROUP="ambiente_limite_grupo",HEAT="ambiente_ruido_todos";
 public static void install(Map<String,Double>d,Map<String,Double>lo,Map<String,Double>hi,Map<String,Double>v){add(d,lo,hi,v,TOTAL,24,1,80);add(d,lo,hi,v,GROUP,4,1,80);add(d,lo,hi,v,HEAT,1,0,1);Budget49.install(d,lo,hi,v);Spawn66.install(d,lo,hi,v);}
 static void add(Map<String,Double>d,Map<String,Double>lo,Map<String,Double>hi,Map<String,Double>v,String k,double x,double a,double b){d.put(k,x);lo.put(k,a);hi.put(k,b);v.putIfAbsent(k,x);}
 public static void validate(String k,double v){Budget49.validate(k,v);Spawn66.validate(k,v);if((k.equals(TOTAL)||k.equals(GROUP)||k.equals(HEAT))&&(!Double.isFinite(v)||v!=Math.rint(v)))throw new IllegalArgumentException("El limite debe ser un numero entero.");}
 public static void validateBatch(Map<String,Double> m){if(m.containsKey(TOTAL)&&m.containsKey(GROUP))m.put(GROUP,Math.min(m.get(TOTAL),m.get(GROUP)));}
 public static void applied(){Spawn66.applied();}
 public static boolean enabled(){return WorldTuning.snapshot().containsKey(TOTAL);}
 public static int total(){return(int)WorldTuning.get(TOTAL);}public static int group(){return Math.min(total(),(int)WorldTuning.get(GROUP));}
 public static int desired(double density,int cap,double heat){if(!Double.isFinite(density)||!Double.isFinite(heat))return 0;double base=Math.min(1,Math.max(0,density)*.65),bonus=1+.35*Math.max(0,Math.min(100,heat))/100;return Math.max(0,Math.min(cap,(int)Math.round(cap*base*bonus)));}
 public static void preset(Map<String,Double>m,int n){m.put("poblacion_pausada_todos",0d);m.put("limite_zona",new double[]{64,48,32,24,16}[n]);m.put(TOTAL,new double[]{48,36,24,16,8}[n]);m.put(GROUP,new double[]{8,6,4,3,2}[n]);m.put(Spawn66.SECONDS,new double[]{20,25,30,45,60}[n]);m.put(Spawn66.BURST,new double[]{4,3,2,2,1}[n]);m.put(HEAT,1d);}
 public static boolean window(int x,int z,int px,int pz){return Math.abs((long)x-px)<=1&&Math.abs((long)z-pz)<=1;}
}
