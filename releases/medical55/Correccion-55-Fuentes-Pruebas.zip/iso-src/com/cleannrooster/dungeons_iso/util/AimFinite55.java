package com.cleannrooster.dungeons_iso.util;
/** Reject invalid/zero-length aim samples before they enter rotation interpolation. */
public final class AimFinite55 {
 static double coordinate(Object value,String name)throws ReflectiveOperationException{return ((Number)value.getClass().getField(name).get(value)).doubleValue();}
 public static boolean valid(Object entity,Object target){if(entity==null||target==null)return false;try{Object eye=entity.getClass().getMethod("getEyePosition").invoke(entity);double dx=coordinate(target,"x")-coordinate(eye,"x"),dy=coordinate(target,"y")-coordinate(eye,"y"),dz=coordinate(target,"z")-coordinate(eye,"z");double length=dx*dx+dy*dy+dz*dz;return Double.isFinite(length)&&length>1e-10;}catch(ReflectiveOperationException e){throw new IllegalStateException("isometric aim coordinate contract",e);}}
}
