import ctypes as C,os
from pathlib import Path
os.environ['EGL_PLATFORM']='surfaceless';e=C.CDLL('libEGL.so.1');g=C.CDLL('libGL.so.1')
def fn(lib,n,ret,args):
 f=getattr(lib,n);f.restype=ret;f.argtypes=args;return f
P=C.c_void_p;I=C.c_int;U=C.c_uint
D=fn(e,'eglGetDisplay',P,[P])(None);a=I();b=I();assert fn(e,'eglInitialize',U,[P,C.POINTER(I),C.POINTER(I)])(D,C.byref(a),C.byref(b));assert fn(e,'eglBindAPI',U,[U])(0x30A2)
attrs=(I*13)(0x3033,1,0x3040,8,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038);cfg=P();num=I();assert fn(e,'eglChooseConfig',U,[P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I)])(D,attrs,C.byref(cfg),1,C.byref(num)) and num.value
ctx=fn(e,'eglCreateContext',P,[P,P,P,C.POINTER(I)])(D,cfg,None,(I*1)(0x3038));surf=fn(e,'eglCreatePbufferSurface',P,[P,P,C.POINTER(I)])(D,cfg,(I*5)(0x3057,1,0x3056,1,0x3038));assert fn(e,'eglMakeCurrent',U,[P,P,P,P])(D,surf,surf,ctx)
getstr=fn(g,'glGetString',C.c_char_p,[U]);print('OFFSCREEN_RENDERER',getstr(0x1F01).decode())
create=fn(g,'glCreateShader',U,[U]);source=fn(g,'glShaderSource',None,[U,I,C.POINTER(C.c_char_p),C.POINTER(I)]);compile=fn(g,'glCompileShader',None,[U]);get=fn(g,'glGetShaderiv',None,[U,U,C.POINTER(I)]);log=fn(g,'glGetShaderInfoLog',None,[U,I,C.POINTER(I),C.c_char_p])
r=Path(__file__).parent
shaders=[]
for kind,text in [(0x8B31,'#version 150\nout vec2 texCoord;void main(){vec2 p[3]=vec2[3](vec2(-1,-1),vec2(3,-1),vec2(-1,3));gl_Position=vec4(p[gl_VertexID],0,1);texCoord=p[gl_VertexID]*.5+.5;}'),(0x8B30,(r/'portable6.frag').read_text())]:
 shader=create(kind);v=C.c_char_p(text.encode());source(shader,1,C.byref(v),None);compile(shader);ok=I();get(shader,0x8B81,C.byref(ok));buf=C.create_string_buffer(8192);log(shader,8192,None,buf);assert ok.value,buf.value;shaders.append(shader)
program=fn(g,'glCreateProgram',U,[])();attach=fn(g,'glAttachShader',None,[U,U]);[attach(program,s) for s in shaders];fn(g,'glLinkProgram',None,[U])(program);ok=I();fn(g,'glGetProgramiv',None,[U,U,C.POINTER(I)])(program,0x8B82,C.byref(ok));assert ok.value;print('PORTABLE_FLASHLIGHT_GLSL150_COMPILE_AND_LINK=PASS')
fn(e,'eglMakeCurrent',U,[P,P,P,P])(D,None,None,None);fn(e,'eglDestroySurface',U,[P,P])(D,surf);fn(e,'eglDestroyContext',U,[P,P])(D,ctx);fn(e,'eglTerminate',U,[P])(D)
