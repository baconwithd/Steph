#version 150

uniform sampler2D DiffuseSampler;
uniform float DarknessFloor;
uniform float KeepStart;
uniform float KeepEnd;
uniform float DarknessStrength;
uniform float DaylightPreserve;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 color = texture(DiffuseSampler, texCoord);
    // Preserve explicitly stamped laser emission, including faint distant pixels.
    if(abs(color.a-251.0/255.0)<0.0015){fragColor=color;return;}

    float strength = clamp(DarknessStrength, 0.0, 1.0);
    float daylightPreserve = clamp(DaylightPreserve, 0.0, 1.0);
    if (strength <= 0.001) {
        fragColor = color;
        return;
    }

    float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
    float maxChannel = max(max(color.r, color.g), color.b);
    float minChannel = min(min(color.r, color.g), color.b);
    float saturationProxy = maxChannel - minChannel;

    // Preserve genuinely bright/emissive pixels and torch-lit surfaces while crushing shader
    // moonlight and dim ambience. Bright, low-saturation fog and sky gradients are also
    // protected so fog mods do not turn into black speckles or bands.
    float keepByLuma = smoothstep(KeepStart, KeepEnd, luma) * mix(0.28, 1.0, daylightPreserve);
    float keepByPeak = smoothstep(0.14, 0.56, maxChannel);
    float warmLight = smoothstep(0.09, 0.28, maxChannel) * smoothstep(0.02, 0.16, color.r - color.b);
    float skyFogKeep = daylightPreserve * smoothstep(0.42, 0.78, maxChannel) * smoothstep(0.18, 0.55, luma);
    float fogLike = daylightPreserve * smoothstep(0.35, 0.75, luma) * (1.0 - smoothstep(0.08, 0.22, saturationProxy));
    float daylightSurface = daylightPreserve * smoothstep(0.15, 0.34, luma) * smoothstep(0.16, 0.38, maxChannel);
    float keep = max(max(max(keepByLuma, keepByPeak), warmLight), max(max(skyFogKeep, fogLike), daylightSurface));

    float deepDark = 1.0 - smoothstep(0.02, 0.12, luma);
    float floor = mix(max(DarknessFloor, 0.22), 0.10, deepDark);

    vec3 crushed = color.rgb * floor;
    vec3 enforced = mix(crushed, color.rgb, keep);
    vec3 result = mix(color.rgb, enforced, strength);

    fragColor = vec4(result, color.a);
}
