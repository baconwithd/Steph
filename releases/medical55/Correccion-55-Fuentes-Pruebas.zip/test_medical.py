from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;t=r/'medical-tests';t.mkdir(exist_ok=True)
f={
'dev/zomboid/firstaid/Wounds45.java':'''package dev.zomboid.firstaid;public class Wounds45{public static class Wound{public boolean bandaged,dirty;}public static Wound[] w=new Wound[8];public static int[] old=new int[0];static{for(int i=0;i<8;i++)w[i]=new Wound();}public static Object model(Object e){return e;}public static Object[] wounds(Object m){return w;}static boolean flag(Object w,String n){return R.yes(R.get(w,n));}public static int[] nativeSnapshot55(Object e){return old;}}''',
'dev/zomboid/firstaid/SnapshotTest55.java':'''package dev.zomboid.firstaid;public class SnapshotTest55{static void ok(boolean b){if(!b)throw new AssertionError();}public static void main(String[]a){Object e=new Object();ok(Snapshot55.snapshot(e).length==0);Wounds45.w[1].bandaged=true;int[] s=Snapshot55.snapshot(e);ok(s.length==7&&s[0]==1&&s[6]==1);Wounds45.w[1].dirty=true;ok(Snapshot55.snapshot(e)[6]==3);Wounds45.old=new int[]{1,0,0,0,2,12000,3};ok(Snapshot55.snapshot(e).length==7);Wounds45.w[4].bandaged=true;ok(Snapshot55.snapshot(e).length==14);Wounds45.w[4].bandaged=false;ok(Snapshot55.snapshot(e).length==7);ok(Wounds45.old.length==7);System.out.println("BANDAGE_SNAPSHOT_NO_MARKS_DIRTY_DEDUP_REMOVAL=PASS");}}''',
'dev/zomboid/gore/BiteTest55.java':'''package dev.zomboid.gore;public class BiteTest55{public static void main(String[]a){int count=0;for(int x=0;x<256;x++){int[]m={0,x,128,0,2,12000,0};if(Bite48.torn(m,0)){count++;m[6]=1;if(Bite48.torn(m,0))throw new AssertionError("bandaged bite removes model skin");m[6]=3;if(Bite48.torn(m,0))throw new AssertionError();}}if(count==0)throw new AssertionError();System.out.println("BANDED_BITES_PRESERVE_SKIN_CHECKS="+count);}}'''
}
for n,s in f.items():p=t/n;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(s)
g=next((r/'output').glob('zomboid*.jar'));fa=next((r/'output').glob('firstaid*.jar'));c=t/'classes';c.mkdir(exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(g)+':'+str(fa),'-d',str(c),*[str(t/n)for n in f]],check=True)
for main in ['dev.zomboid.firstaid.SnapshotTest55','dev.zomboid.gore.BiteTest55']:subprocess.run(['java','-Xverify:all','-cp',str(c)+':'+str(g)+':'+str(fa),main],check=True)
flags=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['','.tree']]
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(c),str(r/'Check55.java')],check=True)
subprocess.run(['java',*flags,'-Xverify:all','-cp',str(c)+':'+str(g),'Check55',str(next((r/'output').glob('ragdoll*.jar')))],check=True)
