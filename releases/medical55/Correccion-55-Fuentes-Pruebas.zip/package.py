from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent;o=r/'output';d=r/'dist';d.mkdir(exist_ok=True)
files=[dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sorted(o.glob('*.jar'))];assert len(files)==6
(o/'manifest.json').write_text(json.dumps({'release':55,'files':files},indent=2));(o/'SHA256SUMS.txt').write_text(''.join(p['sha256']+'  '+p['name']+'\n'for p in files))
(o/'test-results.json').write_text(json.dumps({'java21_asm':(r/'build.log').read_text(),'prior_regressions':json.loads((o/'regressions.json').read_text()),'bandage_snapshot_fixture':'PASS','bandaged_bite_geometry_checks':64,'native_armor_instruction_jvm':'PASS','native_tacz_live_damage_dispatch_fixture':'PASS','own_npc_collider_priority_fixture':'PASS','isometric_finite_nonzero_aim_fixture':'PASS','flashlight_darkness_glsl150_compile_link':'PASS Mesa llvmpipe','controlled_plane_real_gl_soft_falloff':'PASS','full_modpack_run':False},indent=2))
with zipfile.ZipFile(d/'Correccion-55-Luz-Impactos-Vendas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.glob('*.jar')):z.write(p,'mods/'+p.name)
 for n in ['LEEME.md','manifest.json','SHA256SUMS.txt','test-results.json']:z.write(o/n,n)
with zipfile.ZipFile(d/'Correccion-55-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','fa-src','flash-src','iso-src','medical-tests','live-tests']:
  for p in (r/folder).rglob('*.java'):z.write(p,str(p.relative_to(r)))
 for n in ['build.py','Patch55.java','Check55.java','AimTest55.java','test_medical.py','test_live.py','regressions.py','shader_test.py','dark_shader_test.py','render_test.py','portable6.frag','dark55.fsh','controlled-light-plane.png','build.log','package.py']:z.write(r/n,n)
 z.write(r.parent/'medical52/Patch52.java','base-tools/Patch52.java')
 z.write(r.parent/'medical49/src/medical46/tests/com/raiiiden/ragdollified/server/ServerRagdollSyncManager.java','fixture-update/ServerRagdollSyncManager.java')
 for n in ['LEEME.md','manifest.json','test-results.json']:z.write(o/n,n)
for p in d.glob('*.zip'):
 with zipfile.ZipFile(p)as z:assert z.testzip()is None
print('SIX_JAR_MANIFEST_AND_DELIVERY_CRC=PASS')
