package dev.zomboid.gore;
/** Route physical hits on a living incapacitated NPC through the original TaCZ damage path. */
public final class Damage55{
 public static Object nearer(Object hit,int physicalId){Object result=Targets49.nearer(hit);if(result==null)return null;Object actor=R.call(result,"getEntity");if(Npc29.npc(actor)&&((Number)R.call(actor,"getId")).intValue()==physicalId){Object retained=Corpse13.retained(physicalId);if(retained!=null&&R.yes(R.get(retained,"live")))return null;}return result;}
 public static boolean live(Object bullet,int id,int part,Object point,Object start,Object end){Object retained=Corpse13.retained(id);if(retained==null||!R.yes(R.get(retained,"live")))return false;Object level=R.call(bullet,"level"),actor=R.call(level,"getEntity",id);if(actor==null||!Npc29.npc(actor)||!R.yes(R.call(actor,"isAlive")))return true;Object result=R.make("com.tacz.guns.entity.EntityKineticBullet$EntityResult",actor,point,part==1);Object hit=R.make("com.tacz.guns.util.TacHitResult",result);R.call(bullet,"onHitEntity",hit,start,end);return true;}
}
