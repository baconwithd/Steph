from pathlib import Path
import subprocess,shutil,json
r=Path(__file__).resolve().parent;prev=r.parent/'medical49';g=next((r/'output').glob('zomboid*.jar'));rag=next((r/'output').glob('ragdoll*.jar'));results=[]
# Re-run the prior 49 behavioral/geometry/impact suites on the new jars, without rebuilding their old output.
for name in ['bullet_test.py','hit_test.py','regressions.py']:
 s=(prev/name).read_text().replace('r=Path(__file__).resolve().parent;',"r=Path('"+str(prev)+"');").replace("g=next((r/'output').glob('zomboid*.jar'))",'g=Path('+repr(str(g))+')')
 path=r/('prev_'+name);path.write_text(s);p=subprocess.run(['python',str(path)],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
(r/'output/regressions.json').write_text(json.dumps(results,indent=2))
