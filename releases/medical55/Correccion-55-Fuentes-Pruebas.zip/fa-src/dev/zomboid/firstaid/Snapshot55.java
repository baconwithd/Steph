package dev.zomboid.firstaid;
import java.util.*;
public final class Snapshot55 {
 public static int[] snapshot(Object entity){int[] original=(int[])R.call(R.type("dev.zomboid.firstaid.Wounds45"),"nativeSnapshot55",entity);Object model=Wounds45.model(entity);if(model==null)return original;Object[] wounds=Wounds45.wounds(model);List<Integer> all=new ArrayList<>();for(int x:original)all.add(x);for(int part=0;part<Math.min(8,wounds.length);part++){if(!Wounds45.flag(wounds[part],"bandaged"))continue;boolean represented=false;for(int i=0;i+6<original.length;i+=7)if(original[i]==part){represented=true;break;}if(!represented){int[] mark={part,128,128,0,1,12000,1|(Wounds45.flag(wounds[part],"dirty")?2:0)};for(int x:mark)all.add(x);}}return all.stream().mapToInt(Integer::intValue).toArray();}
}
