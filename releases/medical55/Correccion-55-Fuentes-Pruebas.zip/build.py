from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;root=r.parents[1];b=r.parent/'medical53/output';o=r/'output';o.mkdir(exist_ok=True)
g=next(b.glob('zomboid*.jar'));rag=next(b.glob('ragdoll*.jar'));flash=next((r.parent/'medical54/output').glob('flashlight*.jar'));fa=root/'attachments/470ca71e-d59c-4fc6-8f56-9d4d5a65223f/firstaid-1.21.1-ZOMBOID-v3.6.17-revive-rearm.jar';dark=next(b.glob('hardcore*.jar'))
for src,jar,name in [('src',g,'gore'),('fa-src',fa,'fa'),('flash-src',flash,'flash'),('iso-src',g,'iso')]:
 out=r/'build'/name;out.mkdir(parents=True,exist_ok=True);subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(jar),'-d',str(out),*map(str,(r/src).rglob('*.java'))],check=True)
flags=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['','.tree','.tree.analysis']];t=r/'build/tools';t.mkdir(exist_ok=True)
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(t),str(r.parent/'medical52/Patch52.java'),str(r/'Patch55.java')],check=True)
args=[g,r/'build/gore',o/'zomboid-zombie-gore-1.0.20-neoforge-1.21.1-live-body-hits-bandages.38.jar',rag,o/'ragdollified-1.21.1-1.1.5-armor-provider-ref.31.jar',flash,r/'build/flash',r/'portable6.frag',o/'flashlight-5.1-neoforge-1.21.1-soft-map-occlusion.22.jar',fa,r/'build/fa',o/'firstaid-1.21.1-ZOMBOID-v3.6.18-visible-bandage-marks.jar',dark,o/'hardcore_true_darkness-6.1-night-visibility.6-soft-ambient.jar']
args += [root/'attachments/5ba4b2b4-197b-42ec-9865-2f2650a91d09/dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.33-black-void.jar',r/'build/iso',o/'dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.34-finite-aim.jar']
subprocess.run(['java',*flags,'-cp',str(t),'Patch55',*map(str,args)],check=True)
