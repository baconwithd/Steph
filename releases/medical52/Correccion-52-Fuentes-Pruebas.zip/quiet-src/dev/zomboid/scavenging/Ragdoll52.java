package dev.zomboid.scavenging;
import java.util.*;
/** Server-side search for the retained zombie inventory; native Corpses reuse Search. */
public final class Ragdoll52 {
 static final Map<UUID,Pending> JOBS=new HashMap<>();
 static final Map<Object,Boolean> SEARCHED=new WeakHashMap<>();
 static final ThreadLocal<Boolean> REPLAY=ThreadLocal.withInitial(()->false);
 public static boolean corpse(Object player,Object corpse){if(Search.replaying())return false;Search.Target t=Search.entityTarget(corpse);if(t==null||!Search.fresh(t))return false;Search.start(player,t,null);return true;}
 static Object lookup(int id){return ((Map<?,?>)R.get(Search.type("dev.zomboid.remains.BodyLoot16"),"BODIES")).get(id);}
 public static boolean body(Object player,int id){if(REPLAY.get()||Search.replaying())return false;if(!Search.eligible(player))return true;Object b=lookup(id);if(b==null||!R.yes(R.call(Search.type("dev.zomboid.remains.BodyLoot16"),"valid",R.get(b,"corpse"),player)))return true;if(SEARCHED.containsKey(b))return false;UUID uuid=Search.uuid(player);Pending old=JOBS.get(uuid);if(old==null||old.body!=b){if(R.get(player,"containerMenu")!=R.get(player,"inventoryMenu"))return true;JOBS.put(uuid,new Pending(player,b,id));Search.message(player,"Buscando 0% · Scavenging "+Search.skill(player));}return true;}
 public static void tick(){for(Pending p:List.copyOf(JOBS.values())){UUID id=Search.uuid(p.player);try{long elapsed=Search.now(p.level)-p.start;boolean valid=lookup(p.id)==p.body&&Search.eligible(p.player)&&Search.level(p.player)==p.level&&R.get(p.player,"containerMenu")==R.get(p.player,"inventoryMenu")&&((Number)R.get(p.player,"hurtTime")).intValue()==0&&R.num(R.call(p.player,"distanceToSqr",p.x,p.y,p.z))<=.64&&R.yes(R.call(Search.type("dev.zomboid.remains.BodyLoot16"),"valid",R.get(p.body,"corpse"),p.player));if(!valid||elapsed<0){JOBS.remove(id);Search.message(p.player,"Búsqueda interrumpida");continue;}if(elapsed>=p.ticks){JOBS.remove(id);REPLAY.set(true);try{R.call(Search.type("dev.zomboid.remains.BodyLoot16"),"open",p.player,p.id);if(R.get(p.player,"containerMenu")!=R.get(p.player,"inventoryMenu"))SEARCHED.put(p.body,true);}finally{REPLAY.remove();}}else if(elapsed%4==0)Search.message(p.player,"Buscando "+Math.min(100,elapsed*100/p.ticks)+"% · Scavenging "+p.skill);}catch(Throwable e){JOBS.remove(id);Search.warn("ragdoll search",e);}}}
 public static void logout(Object event){JOBS.remove(Search.uuid(R.call(event,"getEntity")));}
 public static void clear(){JOBS.clear();SEARCHED.clear();REPLAY.remove();}
 static final class Pending {final Object player,body,level;final int id,skill,ticks;final long start;final double x,y,z;Pending(Object p,Object b,int i){player=p;body=b;id=i;level=Search.level(p);skill=Search.skill(p);ticks=Rules.ticks(skill);start=Search.now(level);x=R.coord(p,"X");y=R.coord(p,"Y");z=R.coord(p,"Z");}}
}
