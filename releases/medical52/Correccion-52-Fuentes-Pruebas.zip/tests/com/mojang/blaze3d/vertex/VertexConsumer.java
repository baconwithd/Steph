package com.mojang.blaze3d.vertex;
import java.util.*;
public interface VertexConsumer{VertexConsumer addVertex(PoseStack.Pose p,float x,float y,float z);VertexConsumer setColor(int c);VertexConsumer setUv(float u,float v);VertexConsumer setOverlay(int i);VertexConsumer setLight(int i);VertexConsumer setNormal(PoseStack.Pose p,float x,float y,float z);
}