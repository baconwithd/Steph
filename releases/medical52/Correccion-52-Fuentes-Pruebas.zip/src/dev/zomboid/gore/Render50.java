package dev.zomboid.gore;
import java.lang.ref.*;import java.util.*;
/** Weak identity keys: no model hash/equals callbacks, no unbounded reference-queue sweep in a frame. */
public final class Render50<K,V> extends AbstractMap<K,V>{
 static final class Key<T>extends WeakReference<T>{final int hash;Key(T v,ReferenceQueue<T>q){super(v,q);hash=System.identityHashCode(v);}public int hashCode(){return hash;}public boolean equals(Object other){return this==other||other instanceof Key<?>k&&get()!=null&&get()==k.get();}}
 static final class Probe{Object value;public int hashCode(){return System.identityHashCode(value);}public boolean equals(Object k){return k instanceof Key<?>key&&value==key.get();}}
 final HashMap<Key<K>,V>values=new HashMap<>();final ReferenceQueue<K>queue=new ReferenceQueue<>();final Probe probe=new Probe();V nullValue;boolean hasNull;
 void sweep(){for(int i=0;i<8;i++){Object k=queue.poll();if(k==null)break;values.remove(k);}}
 public V get(Object k){sweep();if(k==null)return nullValue;probe.value=k;try{return values.get(probe);}finally{probe.value=null;}}
 public boolean containsKey(Object k){sweep();if(k==null)return hasNull;probe.value=k;try{return values.containsKey(probe);}finally{probe.value=null;}}
 public V put(K k,V v){sweep();if(k==null){V old=nullValue;nullValue=v;hasNull=true;return old;}return values.put(new Key<>(k,queue),v);}
 public V remove(Object k){sweep();if(k==null){V old=nullValue;nullValue=null;hasNull=false;return old;}probe.value=k;try{return values.remove(probe);}finally{probe.value=null;}}
 public void clear(){values.clear();hasNull=false;nullValue=null;while(queue.poll()!=null){}}
 public int size(){sweep();return values.size()+(hasNull?1:0);}public Set<Entry<K,V>>entrySet(){sweep();Set<Entry<K,V>>out=Collections.newSetFromMap(new IdentityHashMap<>());for(var e:values.entrySet()){K k=e.getKey().get();if(k!=null)out.add(new SimpleImmutableEntry<>(k,e.getValue()));}if(hasNull)out.add(new SimpleImmutableEntry<>(null,nullValue));return out;}
}
