package dev.zomboid.gore;
import java.util.*;
/** Remove only exactly coincident opaque internal faces; preserve skin, marks and exposed surfaces. */
public final class MeshMerge52 {
 record Point(int x,int y,int z) implements Comparable<Point>{public int compareTo(Point p){int n=Integer.compare(x,p.x);if(n==0)n=Integer.compare(y,p.y);return n==0?Integer.compare(z,p.z):n;}}
 record Key(int material,List<Point> points){}
 static int bits(float f){return Float.floatToIntBits(f==0?0:f);}
 public static List<Mesh12.Quad> prune(List<Mesh12.Quad> input){Map<Key,List<Mesh12.Quad>> groups=new LinkedHashMap<>();List<Mesh12.Quad> out=new ArrayList<>();for(var q:input){if(q.material()<1||q.material()>7){out.add(q);continue;}List<Point> p=new ArrayList<>(4);for(var v:q.vertices())p.add(new Point(bits(v.x()),bits(v.y()),bits(v.z())));Collections.sort(p);groups.computeIfAbsent(new Key(q.material(),List.copyOf(p)),k->new ArrayList<>()).add(q);}for(var faces:groups.values()){var first=faces.getFirst();boolean opposite=false;for(var q:faces)if(first.nx()*q.nx()+first.ny()*q.ny()+first.nz()*q.nz()<-.999f){opposite=true;break;}if(!opposite)out.add(first);}return out.size()==input.size()?input:List.copyOf(out);}
}
