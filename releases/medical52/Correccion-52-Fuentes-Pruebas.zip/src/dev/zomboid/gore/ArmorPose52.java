package dev.zomboid.gore;
public final class ArmorPose52 {
 public static boolean prepare(Object part){Integer region=Armor48.PARTS.get(part);if(region==null)return false;Skin12.Context ctx=Skin12.CURRENT.get();return ctx!=null&&(Damage25.destroyed(Cuts24.CURRENT.get(),region)||(region<6&&(ctx.state&(1<<region))!=0));}
 public static void align(Object part){Mesh12.Box b=Model25.bounds(part);if(b!=null)R.call(part,"setPos",-(b.x0()+b.x1())*.5f,-(b.y0()+b.y1())*.5f,-(b.z0()+b.z1())*.5f);}
}
