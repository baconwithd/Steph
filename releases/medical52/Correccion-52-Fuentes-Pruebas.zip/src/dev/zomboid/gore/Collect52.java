package dev.zomboid.gore;
import java.util.*;import dev.zomboid.gore.fast.FastReflection;
public final class Collect52 {
 public static Object call(Object owner,String method,Object[]args){Object value=FastReflection.call(owner,method,args);if(!method.equals("getAllEntities")||!(value instanceof Iterable<?> items))return value;List<Object> ready=new ArrayList<>();for(Object e:items){if(e==null)continue;if(e.getClass().getName().equals("de.maxhenkel.corpse.entities.CorpseEntity")&&FastReflection.call(e,"getDeath")==null)continue;ready.add(e);}return ready;}
}
