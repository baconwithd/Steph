package dev.zomboid.gore;
import java.util.*;
public final class Transfer52 {
 static final Map<Object,Saved> POSES=new WeakHashMap<>();
 record Saved(Object pose,boolean settled){}
 static final Map<Object,Boolean> GRAVITY=new WeakHashMap<>();
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);}
 public static void down(Object source){if(!Npc29.npc(source)||Linked45.client(source))return;boolean active=R.yes(c(c(source,"getPersistentData"),"getBoolean","soc_down20"));if(active){GRAVITY.putIfAbsent(source,R.yes(c(source,"isNoGravity")));c(source,"setNoGravity",true);c(source,"setDeltaMovement",0d,0d,0d);}else wake(source);}
 public static void wake(Object source){Boolean old=GRAVITY.remove(source);if(old!=null)c(source,"setNoGravity",old);}
 public static void capture(Object corpse,Object source){if(source==null||!Npc29.npc(source)||Linked45.client(corpse))return;Object r=Corpse13.retained(Linked45.id(source));if(r!=null){Object pose=R.get(r,"settledTransforms");if(pose==null)pose=R.get(r,"latestStreamTransforms");if(pose!=null)POSES.put(corpse,new Saved(pose,R.get(r,"settledTransforms")!=null));}wake(source);}
 public static void install(Object corpse,Object retained){Saved saved=POSES.remove(corpse);if(saved==null)return;R.set(retained,"settledTransforms",saved.settled()?saved.pose():null);R.set(retained,"latestStreamTransforms",saved.pose());Object p=R.get(retained,"spawnPacket");R.set(p,"isSwimming",false);R.set(p,"velX",0d);R.set(p,"velY",0d);R.set(p,"velZ",0d);}
 public static void follow(Object corpse){if(Linked45.client(corpse))return;Object r=Corpse13.retained(Linked45.id(corpse));if(r==null)return;Object pose=Corpse13.pose(r,0);if(pose==null)return;Object p=R.get(pose,"position");double x=R.num(R.get(p,"x")),y=R.num(R.get(p,"y"))-.2,z=R.num(R.get(p,"z"));if(!Double.isFinite(x+y+z))return;c(corpse,"setNoGravity",true);c(corpse,"setPos",x,y,z);c(corpse,"setDeltaMovement",0d,0d,0d);}
}
