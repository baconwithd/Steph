package dev.zomboid.gore;
public final class Loot52 {
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);}
 public static void open(Object player,int id){Object world=c(player,"level"),body=c(world,"getEntity",id);if(body!=null&&body.getClass().getName().equals("de.maxhenkel.corpse.entities.CorpseEntity")){if(!R.yes(c(player,"isAlive"))||R.yes(c(player,"isSpectator"))||R.num(c(player,"distanceToSqr",body))>25||!R.yes(c(player,"hasLineOfSight",body)))return;try{if(R.yes(c(R.type("dev.zomboid.scavenging.Ragdoll52"),"corpse",player,body)))return;}catch(IllegalStateException e){if(!(e.getCause() instanceof ClassNotFoundException))throw e;}c(player,"interactOn",body,R.get(R.type("net.minecraft.world.InteractionHand"),"MAIN_HAND"));return;}c(R.type("dev.zomboid.remains.BodyLoot16"),"open",player,id);}
 public static boolean delay(Object player,int id){try{return R.yes(c(R.type("dev.zomboid.scavenging.Ragdoll52"),"body",player,id));}catch(IllegalStateException e){if(e.getCause() instanceof ClassNotFoundException)return false;throw e;}}
}
