package dev.zomboid.gore;
import java.util.List;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;
public final class Emit52 {
 public static void emit(List<Mesh12.Quad> mesh,Object consumer,Object pose,int light,int overlay,int color){VertexConsumer vc=(VertexConsumer)consumer;PoseStack.Pose p=(PoseStack.Pose)pose;for(var q:mesh)for(var v:q.vertices())vc.addVertex(p,v.x(),v.y(),v.z()).setColor(color).setUv(v.u(),v.v()).setOverlay(overlay).setLight(light).setNormal(p,q.nx(),q.ny(),q.nz());}
}
