package net.flashlight.battery;
import java.util.*;
public final class Steady52 {
 static final List<State> ACTIVE=new ArrayList<>();static Object world;static long last;
 static final class State{Light6.Lamp lamp;float gain;State(Light6.Lamp l){lamp=l;}}
 static float step(float gain,boolean on,double dt){float d=(float)(Math.max(0,Math.min(.05,dt))/.30);return on?Math.min(1,gain+d):Math.max(0,gain-d);}
 public static double distance(Object candidate,Object player){double d=Light6.distance(candidate,player);return Light6.cache.containsKey(candidate)?d*.72:d;}
 public static List<Light6.Lamp> render(float partial){List<Light6.Lamp> wanted=Light6.nativeRender52(partial);long now=System.nanoTime();if(world!=Light6.world){world=Light6.world;ACTIVE.clear();last=now;}double dt=last==0?0:(now-last)/1e9;last=now;for(State s:List.copyOf(ACTIVE)){Light6.Lamp chosen=null;for(var l:wanted)if(l.owner==s.lamp.owner){chosen=l;break;}if(chosen!=null)s.lamp=chosen;s.gain=step(s.gain,chosen!=null,dt);if(chosen==null&&s.gain<=0){ACTIVE.remove(s);continue;}if(chosen==null)Light6.pose(s.lamp,partial);}for(var l:wanted){boolean exists=ACTIVE.stream().anyMatch(s->s.lamp.owner==l.owner);if(!exists&&ACTIVE.size()<2)ACTIVE.add(new State(l));}return ACTIVE.stream().map(s->s.lamp).toList();}
 public static void scalar(int program,String uniform,float value){G6.scalar(program,uniform,value);if(uniform.startsWith("Range[")){int n=uniform.charAt(6)-'0';G6.scalar(program,"Gain["+n+"]",n>=0&&n<ACTIVE.size()?ACTIVE.get(n).gain:0f);}}
}
