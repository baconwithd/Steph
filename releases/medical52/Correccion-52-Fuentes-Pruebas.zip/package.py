from pathlib import Path
import zipfile,hashlib,json
r=Path(__file__).resolve().parent;o=r/'output';dist=r/'dist';dist.mkdir(exist_ok=True)
manifest=json.loads((o/'manifest.json').read_text())
for row in manifest['files']:assert hashlib.sha256((o/row['name']).read_bytes()).hexdigest()==row['sha256']
with zipfile.ZipFile(dist/'Correccion-52-Cadaveres-Armadura-Luces.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.glob('*.jar')):z.write(p,'mods/'+p.name)
 for name in ['LEEME.md','manifest.json','SHA256SUMS.txt','test-results.json']:z.write(o/name,name)
with zipfile.ZipFile(dist/'Correccion-52-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','quiet-src','flash-src','flash-api','tests','bridge-tests','iris-tests']:
  for p in (r/folder).rglob('*.java'):z.write(p,str(p.relative_to(r)))
 for name in ['build.py','Patch52.java','FlashPatch52.java','test_bridge.py','shader_test.py','verify.py','regressions.py','portable6.frag','tissue52.png','package.py']:z.write(r/name,name)
 for name in ['LEEME.md','test-results.json','manifest.json']:z.write(o/name,name)
 z.write(r/'verification.log','verification.log')
 z.write(r.parent/'medical49/src/medical45/tests/com/raiiiden/ragdollified/server/ServerRagdollSyncManager.java','regression-fixture-update/com/raiiiden/ragdollified/server/ServerRagdollSyncManager.java')
for p in dist.glob('*.zip'):
 with zipfile.ZipFile(p)as z:assert z.testzip() is None
print('DELIVERY_ZIP_CRC_AND_MANIFEST=PASS')
