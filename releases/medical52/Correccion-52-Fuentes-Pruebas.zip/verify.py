from pathlib import Path
import subprocess,json,zipfile,io
from PIL import Image
r=Path(__file__).resolve().parent;logs=[]
def run(args):
 p=subprocess.run(list(map(str,args)),capture_output=True,text=True);print(p.stdout,p.stderr,end='');logs.append(p.stdout+p.stderr);p.check_returncode()
run(['python',r/'build.py'])
g=next((r/'output').glob('zomboid-zombie-gore*.jar'));flash=next((r/'output').glob('flashlight*.jar'))
run(['java','com.sun.tools.javac.Main','-proc:none','-cp',g,'-d',r/'build/tests',*list((r/'tests').rglob('*.java'))])
for name in ['RenderCheck51','ArmorCheck52']:run(['java','-Xverify:all','-cp',str(r/'build/tests')+':'+str(g),'dev.zomboid.gore.'+name])
run(['python',r/'test_bridge.py'])
run(['java','com.sun.tools.javac.Main','-proc:none','-cp',flash,'-d',r/'build/iris-tests',*list((r/'iris-tests').rglob('*.java'))])
for name in ['IrisCheck52','SteadyCheck52']:run(['java','-Xverify:all','-cp',str(r/'build/iris-tests')+':'+str(flash),'net.flashlight.battery.'+name])
run(['python',r/'shader_test.py']);run(['python',r/'regressions.py'])
for jar in (r/'output').glob('*.jar'):
 with zipfile.ZipFile(jar) as z:assert z.testzip() is None
with zipfile.ZipFile(g) as z:
 im=Image.open(io.BytesIO(z.read('assets/zomboid_gore/textures/entity/tissue52.png'))).convert('RGBA');assert all(p[3]==255 for p in im.getdata())
 assert not any(n.startswith(('net/minecraft/','com/mojang/')) for n in z.namelist())
with zipfile.ZipFile(flash) as z:
 assert len(z.read('net/flashlight/battery/Light6.class'))>5000
 assert b'nativeRender52' in z.read('net/flashlight/battery/Light6.class')
 assert b'Ljava/util/LinkedHashMap;' in z.read('net/flashlight/battery/Steady52.class')
(r/'output/test-results.json').write_text(json.dumps({'minecraft_tested':False,'shader_driver':'Mesa llvmpipe EGL, GLSL 150 compile/link only','behavioral_boundary':'Production helpers with simulated Minecraft/NeoForge/Iris APIs. No full modpack or visual flicker validation.','results':logs,'jar_integrity':'CRC and no Minecraft compilation stubs bundled: PASS'},indent=2))
print('ALL_MEDICAL52_VERIFICATION=PASS')
