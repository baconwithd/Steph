package net.irisshaders.iris.pipeline;public interface WorldRenderingPipeline{Object getSodiumPrograms();void setPhase(Object phase);void setOverridePhase(Object phase);void onSetShaderTexture();}
