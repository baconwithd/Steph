from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;root=r.parents[1]
g=root/'attachments/ca60c67c-b444-4153-b3b5-70f7ee034d92/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-medical-buffer-torso.35.jar';rag=root/'attachments/16830a15-04dc-4a9b-ba8c-afb796c7eb0f/ragdollified-1.21.1-1.1.5-single-player-zombie-corpse.28.jar';loot=root/'attachments/4cbb1e9b-485d-4f6c-a015-e846bf620760/zombie-remains-loot-1.6.1-neoforge-1.21.1-loot-recovery.24.jar';q=root/'attachments/ef92059f-ba9e-4ff6-9403-dd804c446bdf/quietly-1_0_0-cooldown-v18-environment-loot.jar'
for d in ['build/gore','build/quiet','build/tools','output']:(r/d).mkdir(parents=True,exist_ok=True)
for src,cp,dst in [('src',str(g)+':'+str(root/'work/procedural29/build/test'),'gore'),('quiet-src',str(q),'quiet')]:subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(r/'build'/dst),*map(str,(r/src).rglob('*.java'))],check=True)
flags=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED' for s in ['','.tree','.tree.analysis']]
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(r/'build/tools'),str(r/'Patch52.java')],check=True)
subprocess.run(['java',*flags,'-cp',str(r/'build/tools'),'Patch52',str(g),str(r/'build/gore'),str(r/'tissue52.png'),str(r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-filled-wounds-search.36.jar'),str(rag),str(r/'output/ragdollified-1.21.1-1.1.5-continuous-corpse-pose.29.jar'),str(loot),str(r/'output/zombie-remains-loot-1.6.1-neoforge-1.21.1-quietly-search.25.jar'),str(q),str(r/'build/quiet'),str(r/'output/quietly-1_0_0-cooldown-v19-ragdoll-search.jar')],check=True)

subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(root/'attachments/1b24d94d-7c6a-4af6-ad6e-735cd4238ec5/flashlight-5.1-neoforge-1.21.1-gl-error-isolation.18.jar'),'-d',str(r/'build/flash'),*map(str,(r/'flash-src').rglob('*.java')),*map(str,(r/'flash-api').rglob('*.java'))],check=True)
(r/'build/flash/net/flashlight/battery/Light6.class').unlink();(r/'build/flash/net/flashlight/battery/Light6$Lamp.class').unlink()
subprocess.run(["java",*flags,"com.sun.tools.javac.Main",*flags,"-cp",str(r/"build/tools"),"-d",str(r/"build/tools"),str(r/"FlashPatch52.java")],check=True)
subprocess.run(["java",*flags,"-cp",str(r/"build/tools"),"FlashPatch52",str(root/"attachments/1b24d94d-7c6a-4af6-ad6e-735cd4238ec5/flashlight-5.1-neoforge-1.21.1-gl-error-isolation.18.jar"),str(r/"output/flashlight-5.1-neoforge-1.21.1-iris-terrain-programs.19.jar"),str(r/"portable6.frag"),str(r/"build/flash")],check=True)
