package dev.zomboid.firstaid;
/** Deterministic model-space animation curves; ticks at 20 Hz, angles in radians. */
public final class Motion57 {
 static float smooth(float x){x=Math.max(0,Math.min(1,x));return x*x*x*(x*(x*6-15)+10);}
 static float sin(double x){return (float)Math.sin(x);}
 public static float[] sample(int part,int kind,float ticks){if(!Float.isFinite(ticks))ticks=0;part=Math.max(0,Math.min(7,part));kind=Math.max(1,Math.min(11,kind));float t=Math.max(0,ticks),reach=smooth(t/(kind==10?16:10)),cycle=(t%48)/48f,w=sin(cycle*Math.PI*2),detail=sin(cycle*Math.PI*4+.6),press=smooth((cycle-.35f)/.18f)*(1-smooth((cycle-.72f)/.20f));float[] p=new float[24];p[0]=-.60f;p[1]=-1.15f;p[2]=.10f;p[3]=-.60f;p[4]=1.15f;p[5]=-.10f;p[9]=.18f;
 if(part==0){p[0]=-2.40f;p[1]=-.85f;p[3]=-2.40f;p[4]=.85f;p[9]=.08f;}
 else if(part==1){p[0]=-1.05f;p[1]=-1.35f;p[3]=-.20f;p[4]=.08f;p[9]=.26f;p[7]=-.08f;}
 else if(part==5){p[3]=-1.05f;p[4]=1.35f;p[0]=-.20f;p[1]=-.08f;p[9]=.26f;p[7]=.08f;}
 else if(part==2||part==3||part==6||part==7){float side=part<4?1:-1;boolean foot=part==3||part==7;p[6]=foot?.95f:.60f;p[18]=foot?5.5f:2f;p[12]=p[15]=foot?-.95f:-.55f;p[9]=.42f;p[0]=-.28f;p[3]=-.30f;p[1]=-.18f+.18f*side;p[4]=.18f+.18f*side;p[7]=side*.08f;}
 float action=smooth((t-5)/7);
 switch(kind){
 case 1 -> {p[0]+=(.13f*w+.04f*detail)*action;p[3]+=-.07f*w*action;p[1]+=.13f*detail*action;p[4]+=.045f*w*action;p[2]+=.05f*w*action;}
 case 2 -> {p[0]+=.08f*press*action;p[3]-=.06f*press*action;p[1]+=.08f*w*action;p[4]-=.035f*w*action;p[6]+=.025f*press;}
 case 3 -> {p[0]-=(.12f*press+.035f*w)*action;p[1]+=.035f*detail*action;p[3]+=.035f*press*action;p[9]+=.045f*press;}
 case 4 -> {p[0]=-1.13f-.10f*press*action;p[1]=-1.02f;p[3]=-.48f;p[4]=.06f;p[9]=.32f;p[7]=-.10f;}
 case 5 -> {p[0]=-1.95f+.07f*w*action;p[1]=-.20f;p[3]=-.70f;p[4]=.18f;p[9]=-.10f+.03f*w;p[6]=0;}
 case 6 -> {p[0]+=.10f*w*action;p[1]+=.12f*detail*action;p[3]+=.025f*w*action;p[9]+=.03f*press;}
 case 7 -> {p[0]-=.17f*press*action;p[1]-=.11f*press*action;p[3]+=.07f*press*action;}
 case 8 -> {float compression=.045f*(1-sin(t*.72));p[6]=.58f+compression;p[0]=-.72f-compression;p[3]=-.72f-compression;p[1]=-.10f;p[4]=.10f;p[9]=.42f;}
 case 9 -> {p[0]=-1.02f;p[1]=-.48f;p[3]=-1.02f;p[4]=.48f;p[9]=.35f;p[6]=.10f;}
 case 10 -> {float push=(1-sin(t*.13))* .5f;p[6]=1.30f;p[9]=.35f;p[0]=-.88f-.12f*push;p[3]=p[0];p[1]=-.14f;p[4]=.14f;p[12]=1.30f;p[15]=1.30f;p[18]=8+push*.6f;}
 case 11 -> {float squat=(1-sin(t*.11))*.5f;p[6]=.14f+.16f*squat;p[0]=-.65f-.28f*squat;p[3]=p[0];p[1]=-.12f;p[4]=.12f;p[12]=-.62f*squat;p[15]=-.62f*squat;p[18]=2.8f*squat;}
 }
 // Body pivots hinge around the hips; shoulders/head follow the torso instead of floating.
 float drop=p[18],bend=p[6];p[18]=12-(float)Math.cos(bend)*12+drop;p[19]=-(float)Math.sin(bend)*12;p[20]=p[18]+2*((float)Math.cos(bend)-1);p[21]=p[19]+2*(float)Math.sin(bend);p[22]=p[18];p[23]=p[19];
 for(int i=0;i<p.length;i++)p[i]*=reach;return p;}
 public static void main(String[]args){int part=Integer.parseInt(args[0]),kind=Integer.parseInt(args[1]);for(int i=0;i<96;i++){float t=i*2f;float[] p=sample(part,kind,t);System.out.print(t);for(float v:p)System.out.print(","+v);for(float v:FirstPerson57.view(part,kind,t))System.out.print(","+v);System.out.println();}}
}
