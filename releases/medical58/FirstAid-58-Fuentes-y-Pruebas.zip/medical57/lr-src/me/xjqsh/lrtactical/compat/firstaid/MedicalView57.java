package me.xjqsh.lrtactical.compat.firstaid;
import java.lang.reflect.*;
public final class MedicalView57{
 static Method hook;static boolean absent,warned;
 public static void apply(Object pose,Object player,Object stack,float partial){if(absent)return;try{if(hook==null)hook=Class.forName("dev.zomboid.firstaid.FirstPerson57").getMethod("apply",Object.class,Object.class,Object.class,float.class);hook.invoke(null,pose,player,stack,partial);}catch(ClassNotFoundException|NoSuchMethodException e){absent=true;}catch(ReflectiveOperationException e){if(!warned){warned=true;System.err.println("[LR] First Aid view animation: "+e);}}}
}
