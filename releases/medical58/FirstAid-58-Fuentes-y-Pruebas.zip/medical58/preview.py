from pathlib import Path
import json,math,io,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parent;o=r/'preview';o.mkdir(exist_ok=True)
bones=json.loads((r/'geometry.json').read_text())['minecraft:geometry'][0]['bones'];index={b['name']:b for b in bones}
rows=np.loadtxt(r/'poses.csv',delimiter=',',skiprows=1);poses={(int(x[0]),int(x[1]),int(x[2])):x[3:]for x in rows}
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
def T(v):
 m=np.eye(4);m[:3,3]=v;return m
def S(v):return np.diag([*v,1])
def R(v):
 x,y,z=np.radians(v);cx,sx=np.cos(x),np.sin(x);cy,sy=np.cos(y),np.sin(y);cz,sz=np.cos(z),np.sin(z)
 return np.array([[cz,-sz,0,0],[sz,cz,0,0],[0,0,1,0],[0,0,0,1]])@np.array([[cy,0,sy,0],[0,1,0,0],[-sy,0,cy,0],[0,0,0,1]])@np.array([[1,0,0,0],[0,cx,-sx,0],[0,sx,cx,0],[0,0,0,1]])
faces=[[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]]
def geometry(part,kind,frame):
 ctrl=poses[part,kind,frame];mats={};quads=[]
 for b in bones:
  n=b['name'];p=np.array(b['pivot'],float);parent=b.get('parent');parentp=np.array(index[parent]['pivot'])if parent else np.array([0,24,0]);pivot=(p-parentp)*[1,-1,1]
  v=ctrl[:6]if n=='mag_and_lefthand'else ctrl[6:]if n=='gun_and_righthand'else np.array([10.605,-6.901,53.399,4.432,8.802,7.019])if n=='bandage'else np.zeros(6)
  scale=[1,1.5,1]if n in ['lefthand','righthand']else [1,1,6.68]if n=='bone'else [1,1,1]
  mats[n]=(mats[parent]if parent else T([0,24,0])@R([0,0,180]))@T(v[3:]*[1,-1,1])@T(pivot)@R(b.get('rotation',[0,0,0]))@R(v[:3])@S(scale)
  if n not in ['lefthand_pos','righthand_pos','bandage','bone']:continue
  for cube in b.get('cubes',[]):
   origin=np.array(cube['origin']);size=np.array(cube['size']);local=(origin-p)*[1,-1,1];local[1]-=size[1]
   points=np.array([[local[0]+i*size[0],local[1]+j*size[1],local[2]+k*size[2],1]for i in [0,1]for j in [0,1]for k in [0,1]])
   # Render fallback Bedrock arm cubes; the game replaces these with the player's skin.
   world=(mats[n]@points.T).T[:,:3]
   for fi,f in enumerate(faces):quads.append((world[f],n,fi))
 return quads
# Fixed reference projection: inspect rig in camera space; same scale for every treatment.
def render(part,kind,frame):
 im=Image.new('RGB',(400,235),(26,33,40));d=ImageDraw.Draw(im)
 for y in range(80,235,22):d.line((0,y,400,y),fill=(31,40,48))
 quads=geometry(part,kind,frame)
 # Camera looks down -Z; model uses Bedrock native units.
 q=[]
 for pts,n,f in quads:
  z=-pts[:,2]+35;z=np.maximum(z,8);xy=np.c_[200+pts[:,0]*180/z,85-pts[:,1]*180/z]
  q.append((float(z.mean()),xy,n,f))
 for depth,xy,n,f in sorted(q,reverse=True,key=lambda x:x[0]):
  base=(181,137,111)if n.endswith('_pos')else (210,205,177);factor=.65+.06*f;c=tuple(int(x*factor)for x in base)
  d.polygon([tuple(p)for p in xy],fill=c,outline=tuple(max(0,x-24)for x in c))
 return im
panels=[(0,1,'Cabeza · vendar'),(1,1,'Brazo izquierdo · vendar'),(2,1,'Pierna izquierda · vendar'),(3,1,'Pie izquierdo · vendar'),(4,3,'Torso · extracción'),(5,6,'Brazo derecho · desinfectar')]
frames=[]
proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1200x560','-r','30','-i','-','-an','-c:v','libx264','-crf','21','-pix_fmt','yuv420p',str(o/'FirstAid-58-preview.mp4')],stdin=subprocess.PIPE)
for f in range(90):
 im=Image.new('RGB',(1200,560),(15,20,26));d=ImageDraw.Draw(im);d.text((16,9),'PREVIEW TÉCNICO · rig Bedrock de First Aid · curvas del código Java',font=font,fill='white')
 d.text((16,33),'Render fuera de Minecraft. Cubos de referencia; sin shaders, skin ni interpolación del juego.',font=small,fill=(180,190,200))
 for i,(part,kind,title)in enumerate(panels):
  x=(i%3)*400;y=58+(i//3)*250;im.paste(render(part,kind,f),(x,y));ImageDraw.Draw(im).text((x+12,y+8),title,font=font,fill=(235,217,153))
 proc.stdin.write(im.tobytes())
 if f%3==0:frames.append(im.resize((900,420)))
 if f==35:im.save(o/'FirstAid-58-preview.png')
proc.stdin.close();assert proc.wait()==0
frames[0].save(o/'FirstAid-58-preview.gif',save_all=True,append_images=frames[1:],duration=100,loop=0)
