package dev.zomboid.firstaid;
/** Late skeletal replacement: native consumption clock and sounds remain intact. */
public final class FirstPerson58 {
 static float smooth(float x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}
 /** Independent control-bone targets, degrees and Bedrock pixels. */
 public static float[] pose(int part,int kind,float ticks,boolean left){
  float phase=(ticks%22)/22f,w=(float)Math.sin(phase*Math.PI*2),press=smooth(phase/.35f)*(1-smooth((phase-.65f)/.35f));
  float[] v=left?new float[]{-164.943f,15.396f,-246.78f,6.97f,-9.979f,-3.313f}:new float[]{160.037f,1.528f,-105.11f,-3.706f,-6.941f,-9.753f};
  float side=part==1?1:part==5?-1:(part==2||part==3)?.45f:(part==6||part==7)?-.45f:0,low=(part==3||part==7)?1.25f:(part==2||part==6)?1:0,head=part==0?1:0;
  v[0]+=head*(left?-28:22)+low*(left?26:-24);v[1]+=side*(left?22:16);v[2]+=side*(left?18:-20);
  v[3]+=side*2.3f;v[4]+=head*3.2f-low*3.8f;v[5]+=head*1.7f-low*1.4f;
  if(kind==7)w=-w;
  if(kind==1||kind==7){v[0]+=(left?-9:15)*w;v[2]+=(left?12:-23)*w;v[3]+=(left?.7f:1.7f)*w;v[4]+=(left?.3f:.8f)*press;}
  else if(kind==2){v[0]+=(left?-3:12)*press;v[2]+=(left?4:-13)*press;v[5]+=(left?.1f:1.3f)*press;}
  else if(kind==3){v[0]+=(left?-2:7)*press;v[1]+=(left?1:8)*w;v[5]+=(left?.08f:-1.4f)*press;}
  else if(kind==4){v[1]+=(left?22:-15);v[3]+=(left?2:-1.4f);v[5]+=(left?.1f:.9f)*press;}
  else if(kind==5){v[4]+=3;v[0]+=left?-35:38;v[5]+=1+press*.4f;}
  else if(kind==6){v[2]+=(left?3:17)*w;v[3]+=(left?.1f:.9f)*w;}
  else{v[0]+=(left?9:-9)*press;v[4]+=press*.8f;}
  return v;
 }
 static void set(Object node,float[]v,float weight){
  String[]a={"offsetX","offsetY","offsetZ"};for(int i=0;i<3;i++){float old=((Number)R.get(node,a[i])).floatValue(),value=v[i+3]/16*(i==1?-1:1);R.set(node,a[i],old+(value-old)*weight);}
  Object q=R.get(node,"additionalQuaternion"),target=R.make("org.joml.Quaternionf");R.call(target,"rotationZYX",(float)Math.toRadians(v[2]),(float)Math.toRadians(v[1]),(float)Math.toRadians(v[0]));R.call(q,"slerp",target,weight);
 }
 public static void bones(Object rig,Object player,Object stack,float partial){try{
  float[]c=FirstPerson57.CLOCK.get(player);if(c==null||c[3]<.001f)return;
  // Only this rig has calibrated pivots. Never force another consumable's skeleton.
  Object bandage=R.call(rig,"getNode","bandage"),left=R.call(rig,"getNode","mag_and_lefthand"),right=R.call(rig,"getNode","gun_and_righthand");if(bandage==null||left==null||right==null)return;
  float t=((Number)R.get(player,"tickCount")).floatValue()+partial-c[0],weight=c[3]*smooth(t/5);
  set(left,pose((int)c[1],(int)c[2],t,true),weight);set(right,pose((int)c[1],(int)c[2],t,false),weight);
  // Keep the dressing in the working hand rather than the original universal use path.
  set(bandage,new float[]{10.605f,-6.901f,53.399f,4.432f,8.802f,7.019f},weight);
 }catch(RuntimeException e){MedicalMotion.warn(e);}}
}
