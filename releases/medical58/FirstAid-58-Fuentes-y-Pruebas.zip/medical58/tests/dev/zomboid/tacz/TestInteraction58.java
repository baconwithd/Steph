package dev.zomboid.tacz;
public class TestInteraction58{
 public static class Part{public float xRot=.1f,yRot=.2f,zRot=.3f;}
 public static class Model{public Part leftArm=new Part(),leftSleeve=new Part(),rightArm=new Part();}
 public static class Pose{public int moves,rotations;public void translate(double x,double y,double z){moves++;}public void mulPose(Object q){rotations++;}}
 public static void main(String[]a){var m=net.minecraft.client.Minecraft.getInstance();m.player=new Object();m.level=new Object();Interaction58.trigger();Interaction58.start=System.nanoTime()-310000000;var model=new Model();Interaction58.third(m.player,model);if(model.leftArm.xRot>-.9f||model.rightArm.xRot!=.1f||model.leftSleeve.xRot!=model.leftArm.xRot)throw new AssertionError("arm scope");var foreign=new Model();Interaction58.third(new Object(),foreign);if(foreign.leftArm.xRot!=.1f)throw new AssertionError("other player");Pose pose=new Pose();Interaction58.render(m.player,new Object(),pose,100);if(pose.moves!=1||pose.rotations!=3||com.tacz.guns.util.RenderHelper.calls!=1)throw new AssertionError("native render forwarding");m.level=new Object();if(Interaction58.weight()!=0)throw new AssertionError("world reset");System.out.println("PASS: interaction first/third, sleeve sync, right arm unchanged, native render forwarded once, other player/world isolation");}
}
