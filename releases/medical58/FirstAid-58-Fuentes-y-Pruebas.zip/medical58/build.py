from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent; root=r.parents[1];o=r/'output';o.mkdir(exist_ok=True)
fa=next((r.parent/'medical57/output').glob('firstaid*.jar'));lr=next((r.parent/'medical57/output').glob('LesRaisins*.jar'));tacz=next((r.parent/'medical56/output').glob('tacz*.jar'))
for src,base,dst in [('src',fa,'classes'),('lr-src',lr,'lr'),('src-tacz',tacz,'tacz')]:
 d=r/'build'/dst;d.mkdir(parents=True,exist_ok=True);subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(base),'-d',str(d),*map(str,(r/src).rglob('*.java'))],check=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']];d=r/'build/tools';d.mkdir(exist_ok=True)
subprocess.run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(d),str(r.parent/'medical52/Patch52.java'),str(r/'Patch58.java')],check=True)
subprocess.run(['java',*f,'-cp',str(d),'Patch58',str(fa),str(r/'build/classes'),str(o/'firstaid-1.21.1-ZOMBOID-v3.6.21-independent-treatment-hands.jar'),str(lr),str(r/'build/lr'),str(o/'LesRaisins-Tactical-Equipements-1.21.1-0.4.3-medical-bones.6.jar'),str(tacz),str(r/'build/tacz'),str(o/'tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.21-left-interaction.jar')],check=True)
