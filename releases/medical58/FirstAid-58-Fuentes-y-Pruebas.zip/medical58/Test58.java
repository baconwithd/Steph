package dev.zomboid.firstaid;
import java.util.*;import org.joml.Quaternionf;
public class Test58 {
 public static class Node {public float offsetX,offsetY,offsetZ;public Quaternionf additionalQuaternion=new Quaternionf();}
 public static class Rig {public Map<String,Node> nodes=new HashMap<>();public Object getNode(String name){return nodes.get(name);}Rig(){for(String s:List.of("bandage","mag_and_lefthand","gun_and_righthand"))nodes.put(s,new Node());}}
 public static class Player {public int tickCount=12;}
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[]args){
  for(int p=0;p<8;p++)for(int k=1;k<=11;k++)for(boolean l:new boolean[]{false,true})for(float t=0;t<200;t+=.25f){float[]v=FirstPerson58.pose(p,k,t,l);for(float x:v)check(Float.isFinite(x),"NaN");float[]n=FirstPerson58.pose(p,k,t+.01f,l);for(int i=0;i<6;i++)check(Math.abs(v[i]-n[i])<.2,"discontinuity");}
  Player p=new Player();Rig rig=new Rig();FirstPerson58.bones(rig,p,null,0);check(rig.nodes.get("mag_and_lefthand").offsetX==0,"idle modified");
  Set<String> poses=new HashSet<>();for(int part=0;part<8;part++)for(int kind=1;kind<=7;kind++){
   FirstPerson57.CLOCK.put(p,new float[]{0,part,kind,1,12});FirstPerson58.bones(rig,p,null,0);Node l=rig.nodes.get("mag_and_lefthand"),r=rig.nodes.get("gun_and_righthand");check(l.offsetX!=0&&r.offsetX!=0,"bone hook did not execute");check(!l.additionalQuaternion.equals(r.additionalQuaternion),"arms identical");poses.add(l.offsetX+","+l.offsetY+","+l.additionalQuaternion+","+r.additionalQuaternion);
  }check(poses.size()>=40,"body part/action distinction "+poses.size());
  FirstPerson57.CLOCK.remove(p);float old=rig.nodes.get("bandage").offsetY;FirstPerson58.bones(rig,p,null,0);check(old==rig.nodes.get("bandage").offsetY,"idle not untouched");
  FirstPerson57.CLOCK.put(p,new float[]{0,0,1,1,12});rig.nodes.remove("bandage");FirstPerson58.bones(rig,p,null,0);
  for(float t=0;t<1;t+=.001f){float w=dev.zomboid.tacz.Interaction58.curve(t);check(w>=0&&w<=1,"interaction curve");}check(dev.zomboid.tacz.Interaction58.curve(0)==0&&dev.zomboid.tacz.Interaction58.curve(1)==0,"interaction rest");
  System.out.println("PASS: actual reflective bone replacement, 56 combinations, independent hands, idle, foreign rig, finite continuous targets and interaction envelope");
  if(args.length>0)for(int part:new int[]{0,1,2,3,4,5,6,7})for(int kind:new int[]{1,2,3,4,5,6,7})for(int frame=0;frame<90;frame++){float t=frame*20f/30;System.out.print(part+","+kind+","+frame);for(boolean left:new boolean[]{true,false})for(float v:FirstPerson58.pose(part,kind,t,left))System.out.print(","+v);System.out.println();}
 }
}
