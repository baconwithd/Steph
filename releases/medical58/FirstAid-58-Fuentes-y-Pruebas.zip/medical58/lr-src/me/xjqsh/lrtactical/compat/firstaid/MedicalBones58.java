package me.xjqsh.lrtactical.compat.firstaid;
import java.lang.reflect.*;
public final class MedicalBones58 {
 static Method hook;static boolean absent,warned;
 public static void apply(Object model,Object player,Object stack,float partial){if(absent)return;try{if(hook==null)hook=Class.forName("dev.zomboid.firstaid.FirstPerson58").getMethod("bones",Object.class,Object.class,Object.class,float.class);hook.invoke(null,model,player,stack,partial);}catch(ClassNotFoundException|NoSuchMethodException e){absent=true;}catch(ReflectiveOperationException e){if(!warned){warned=true;System.err.println("[LR] medical bones: "+e);}}}
}
