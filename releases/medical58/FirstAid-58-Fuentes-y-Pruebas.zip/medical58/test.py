from pathlib import Path
import subprocess,json,zipfile
r=Path(__file__).resolve().parent;d=r/'build/test';d.mkdir(parents=True,exist_ok=True);fa=next((r/'output').glob('firstaid*.jar'));lr=next((r/'output').glob('Les*.jar'));ta=next((r/'output').glob('tacz*.jar'));cp=':'.join(map(str,[fa,lr,ta,r/'joml.jar']));results=[]
def run(cmd):
 p=subprocess.run(cmd,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();return p.stdout.strip()
run(['java','com.sun.tools.javac.Main','-cp',cp,'-d',str(d),str(r/'Test58.java'),*map(str,(r/'tests').rglob('*.java'))])
for c in ['dev.zomboid.firstaid.Test58','dev.zomboid.tacz.TestInteraction58']:results.append(run(['java','-Xverify:all','-cp',str(d)+':'+cp,c]))
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree']]
run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(d),str(r/'Contract58.java'),str(r.parent/'medical57/Contract57.java')])
results.append(run(['java',*f,'-cp',str(d),'Contract58',str(lr),str(ta)]))
results.append(run(['java',*f,'-cp',str(d),'Contract57',str(fa),str(lr)]))
(r/'output/test-results.json').write_text(json.dumps({'results':results,'full_minecraft_runtime':False,'preview':'Offline Bedrock fallback-arm geometry driven by Java-exported control-bone targets; not a gameplay recording.'},indent=2))
