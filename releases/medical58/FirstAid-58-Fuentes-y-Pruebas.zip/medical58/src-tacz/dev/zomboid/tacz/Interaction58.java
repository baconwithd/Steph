package dev.zomboid.tacz;
/** Cosmetic local interaction; does not send extra use, attack or ammunition actions. */
public final class Interaction58 {
 static Object owner,level;static long start=-1;static boolean warned;
 static Object mc(){return R.call(R.type("net.minecraft.client.Minecraft"),"getInstance");}
 public static void trigger(){Object m=mc();owner=R.get(m,"player");level=R.get(m,"level");start=System.nanoTime();}
 public static float curve(float p){if(!Float.isFinite(p)||p<=0||p>=1)return 0;float x=p<.42f?p/.42f:p<.62f?1:(1-p)/.38f;return x*x*(3-2*x);}
 public static float weight(){Object m=mc();if(start<0||owner==null||R.get(m,"player")!=owner||R.get(m,"level")!=level)return 0;float p=(System.nanoTime()-start)/620000000f;if(p>=1){start=-1;return 0;}return curve(p);}
 public static void first(Object pose){try{float w=weight();if(w==0)return;R.call(pose,"translate",-.09d*w,.055d*w,-.24d*w);String[] axes={"XP","YP","ZP"};float[] angles={-22,12,-9};for(int i=0;i<3;i++)R.call(pose,"mulPose",R.call(R.get(R.type("com.mojang.math.Axis"),axes[i]),"rotationDegrees",angles[i]*w));}catch(RuntimeException e){warn(e);}}
 public static void render(Object player,Object arm,Object pose,int light){first(pose);R.call(R.type("com.tacz.guns.util.RenderHelper"),"renderFirstPersonArm",player,arm,pose,light);}
 public static void third(Object player,Object model){try{float w=weight();if(w==0||player!=owner)return;Object a=R.get(model,"leftArm"),s=R.get(model,"leftSleeve");String[] axes={"xRot","yRot","zRot"};float[] target={-1.38f,-.28f,-.13f};for(int i=0;i<3;i++){float old=((Number)R.get(a,axes[i])).floatValue();float v=old+(target[i]-old)*w;R.set(a,axes[i],v);R.set(s,axes[i],v);}}catch(RuntimeException e){warn(e);}}
 static void warn(RuntimeException e){if(!warned){warned=true;System.err.println("[TaCZ] Left interaction: "+e);}}
}
