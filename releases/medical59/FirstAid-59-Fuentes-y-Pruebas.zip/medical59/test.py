from pathlib import Path
import subprocess,json,itertools,zipfile
import numpy as np
r=Path(__file__).resolve().parent;prev=r.parent/'medical58';fa=next((r/'output').glob('firstaid*.jar'));lr=next((r/'output').glob('Les*.jar'));ta=next((prev/'output').glob('tacz*.jar'));cp=':'.join(map(str,[fa,lr,ta,prev/'joml.jar']));d=r/'build/test';d.mkdir(parents=True,exist_ok=True);results=[]
def run(args):
 p=subprocess.run(args,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();return p.stdout.strip()
run(['java','com.sun.tools.javac.Main','-cp',cp,'-d',str(d),str(prev/'Test58.java'),str(r/'Probe59.java'),str(r/'Playhead59.java')])
results.append(run(['java','-Xverify:all','-cp',str(d)+':'+cp,'dev.zomboid.firstaid.Test58']))
results.append(run(['java','-Xverify:all','-cp',str(d)+':'+cp,'dev.zomboid.firstaid.Playhead59']))
with open(r/'poses.csv','w')as f:subprocess.run(['java','-Xverify:all','-cp',str(d)+':'+cp,'dev.zomboid.firstaid.Probe59'],check=True,stdout=f)
a=np.loadtxt(r/'poses.csv',delimiter=',');assert np.isfinite(a).all()
# Compare movement only, stripping posture/placement. An offset-only variant must fail.
metrics={}
for view,cols in [('first',slice(3,15)),('third',slice(15,33))]:
 signatures=[]
 for part in range(8):
  for kind in range(1,8):
   x=a[(a[:,0]==part)&(a[:,1]==kind),cols].copy();x=x[16:96];x-=x.mean(axis=0)
   # Balance angle/translation scales; pairwise test ignores static destination offsets.
   if view=='first':x[:,[0,1,2,6,7,8]]*=.04
   norm=np.linalg.norm(x);assert norm>.01;signatures.append(((part,kind),(x/norm).ravel()))
 nearest=min((float(np.linalg.norm(x-y)),p,q)for (p,x),(q,y)in itertools.combinations(signatures,2));assert nearest[0]>.08,(view,nearest)
 metrics[view]={'distinct_movement_sequences':56,'minimum_normalized_distance':nearest[0],'closest_pair':nearest[1:]}
 # The old common 22-tick sinusoid cannot pass this non-periodicity test.
 for part in range(8):
  for kind in range(1,8):
   x=a[(a[:,0]==part)&(a[:,1]==kind),cols];assert np.linalg.norm(x[25]-x[58])>.1
results.append('PASS: 56 distinct temporal paths per view after removal of static offsets; no common 22-tick loop')
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree']]
run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(d),str(prev/'Contract58.java'),str(r.parent/'medical57/Contract57.java')])
results.append(run(['java',*f,'-cp',str(d),'Contract58',str(lr),str(ta)]));results.append(run(['java',*f,'-cp',str(d),'Contract57',str(fa),str(lr)]))
with zipfile.ZipFile(fa)as z,zipfile.ZipFile(next((prev/'output').glob('firstaid*.jar')))as b:
 changed=[n for n in b.namelist()if b.read(n)!=z.read(n)];added=sorted(set(z.namelist())-set(b.namelist()));assert sorted(changed)==['dev/zomboid/firstaid/FirstPerson58.class','dev/zomboid/firstaid/MedicalMotion.class'];assert added==['dev/zomboid/firstaid/Motion59.class']
(r/'output/test-results.json').write_text(json.dumps({'results':results,'motion_comparison':metrics,'changed':changed,'added':added,'full_minecraft_runtime':False},indent=2));print(json.dumps(metrics,indent=2))
