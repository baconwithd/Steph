package dev.zomboid.firstaid;
public class Probe59{
 public static void main(String[]a){for(int p=0;p<8;p++)for(int k=1;k<=7;k++)for(int frame=0;frame<=100;frame++){float t=frame*.66f;System.out.print(p+","+k+","+frame);for(boolean left:new boolean[]{true,false})for(float v:Motion59.first(p,k,t,left))System.out.print(","+v);for(float v:Motion59.third(p,k,t))System.out.print(","+v);System.out.println();}}
}
