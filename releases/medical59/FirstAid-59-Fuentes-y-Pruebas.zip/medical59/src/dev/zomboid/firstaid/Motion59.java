package dev.zomboid.firstaid;
/** Authored non-periodic choreography. Each row is a gesture, never random jitter. */
public final class Motion59 {
 static float clamp(float x){return Float.isFinite(x)?Math.max(0,Math.min(1,x)):0;}
 static float ease(float x){x=clamp(x);return x*x*x*(x*(x*6-15)+10);}
 static float[] key(float t,float[] times,float[][] values){int i=0;while(i<times.length-2&&t>times[i+1])i++;float a=ease((t-times[i])/(times[i+1]-times[i]));float[] out=new float[values[0].length];for(int j=0;j<out.length;j++)out[j]=values[i][j]+(values[i+1][j]-values[i][j])*a;return out;}
 static final float[] STAGE={0,.14f,.30f,.47f,.64f,.82f,1};
 // Right/left control-bone delta conventions: XYZ pixels followed by pitch/yaw/roll degrees.
 // Different routes: crown, forearm-to-biceps, knee side, heel-to-instep, chest,
 // crossed right forearm, under right knee, right sole-to-laces.
 static final float[][][] ROUTES={
  {{0,0,0,0,0,0},{-1,1,1,-8,-5,8},{-2.5f,2.5f,0,-18,-10,18},{0,3,1,-8,4,-12},{2,1.5f,.5f,12,12,-24},{.5f,0,-1,4,3,-8},{0,0,0,0,0,0}},
  {{0,0,0,0,0,0},{-1,0,1,-2,-16,22},{-2,-.5f,1,8,-25,32},{-1,1.4f,.3f,-10,-6,14},{.5f,2,-.8f,-20,8,-12},{-1,.5f,0,5,-12,18},{0,0,0,0,0,0}},
  {{0,0,0,0,0,0},{1,-1,0,15,0,-15},{1.6f,-2.5f,.6f,24,14,-6},{-1,-1.5f,1.5f,3,-12,18},{-2,-.7f,.5f,-8,-16,28},{0,-2,-.5f,18,5,2},{0,0,0,0,0,0}},
  {{0,0,0,0,0,0},{-.8f,-.5f,-1.7f,15,-12,8},{-1.6f,-1.2f,-2.5f,24,-4,22},{1,-2,.3f,4,18,-16},{2,0,1.6f,-18,24,-28},{-.5f,.5f,-1,-5,-8,6},{0,0,0,0,0,0}},
  {{0,0,0,0,0,0},{1,0,1,2,14,-14},{2.7f,.8f,.5f,-10,26,-25},{1,-1.4f,1.3f,12,8,-8},{-2,-.6f,-.7f,18,-18,20},{-1.5f,1.2f,0,-8,-12,12},{0,0,0,0,0,0}},
  {{0,0,0,0,0,0},{1.8f,.7f,0,-8,18,-10},{2.5f,1.5f,-.8f,-22,26,-28},{.5f,2.3f,1,-16,8,8},{-.8f,.2f,1.6f,14,-18,30},{1.3f,-.5f,.4f,5,14,-18},{0,0,0,0,0,0}},
  {{0,0,0,0,0,0},{-1.5f,-.4f,1,6,-12,12},{-2.2f,-1.8f,1.8f,18,-26,24},{0,-2.7f,.2f,26,4,-10},{1.8f,-1,-1,-8,16,-24},{.6f,-.4f,.5f,-2,8,-8},{0,0,0,0,0,0}},
  {{0,0,0,0,0,0},{1,-1,1.8f,-8,14,-14},{2,-2,-.5f,8,26,-30},{.5f,-.2f,-2,24,8,-6},{-1.8f,.8f,-1,-14,-18,22},{-1,-1.3f,1,6,-10,10},{0,0,0,0,0,0}}
 };
 static final float[][][] ACTIONS={
  // Bandage: draw strip, cross wound, pass around, tension, palm pressure.
  {{0,0,0,0,0,0},{1.5f,0,-1,0,8,-20},{-1.5f,.6f,0,-8,-12,26},{.8f,1,1,12,14,-18},{1.8f,-.5f,-1.2f,-14,22,-30},{-.5f,0,.6f,5,-8,12},{0,0,0,0,0,0}},
  // Splint: place lengthwise, support ends, tighten lower strap, upper strap, test support.
  {{0,0,0,0,0,0},{0,-1,1,18,0,0},{0,1.5f,.8f,-20,0,4},{1,-1,0,12,18,-18},{-1,1,0,-12,-18,18},{0,.4f,1.1f,6,0,-4},{0,0,0,0,0,0}},
  // Extraction: inspect, align probe, hold steady, draw straight out, discard sideways.
  {{0,0,0,0,0,0},{-.8f,.8f,-.7f,-6,-18,6},{0,0,1.4f,4,3,-2},{.1f,-.1f,1.5f,4,3,-2},{0,.2f,-2.3f,-10,0,8},{2,-.7f,-1.7f,20,30,-32},{0,0,0,0,0,0}},
  // Injection: brace, perpendicular insertion, held plunger press, remove, cap away.
  {{0,0,0,0,0,0},{.6f,-.8f,-1,0,22,10},{.3f,0,1.2f,2,12,0},{.3f,0,1.2f,2,12,0},{.3f,.3f,1.3f,7,12,0},{1.8f,-.7f,-1.4f,-12,28,-18},{0,0,0,0,0,0}},
  // Oral medicine: open container, palm dose, lift to mouth, head tilt, lower hand.
  {{0,0,0,0,0,0},{-.7f,-.7f,0,14,-20,24},{1.4f,-.3f,-.8f,-6,18,-28},{0,3.5f,1.8f,-38,-4,4},{0,3.7f,2,-44,0,0},{-.7f,1,-.5f,-10,-6,12},{0,0,0,0,0,0}},
  // Antiseptic: tip bottle, wipe outwards, lift pad, second stroke on a new axis, dab.
  {{0,0,0,0,0,0},{.8f,.6f,.4f,10,0,-32},{-1.8f,.3f,1,-4,-18,16},{-.7f,1.8f,-.8f,-16,-6,6},{1.5f,-1,1,14,16,-12},{0,.1f,1.4f,6,0,0},{0,0,0,0,0,0}},
  // Removal: find edge, pinch, slow peel diagonally, pull loose tail, discard down.
  {{0,0,0,0,0,0},{-.4f,.2f,1.2f,4,-8,12},{-.5f,.3f,1.2f,4,-8,12},{1,.8f,-1,-12,16,-24},{2.5f,1.5f,-2.4f,-24,30,-40},{2,-2.5f,-1,32,12,-16},{0,0,0,0,0,0}}
 };
 // The support hand braces in a different way at each site, not a copy of the worker.
 static final float[][][] SUPPORT={
  {{0,0,0},{.3f,.5f,.8f},{-.6f,1.4f,1},{-1.6f,.7f,.4f},{-.2f,1.6f,.3f},{.5f,.5f,.8f},{0,0,0}},
  {{0,0,0},{1.5f,.4f,-.2f},{1.5f,.4f,-.2f},{.5f,1,.6f},{.2f,.8f,1},{1,.2f,.4f},{0,0,0}},
  {{0,0,0},{-.5f,-1,1},{-1.2f,-.7f,1},{-1.2f,-.7f,1},{.8f,-1.5f,.2f},{.4f,-.4f,.6f},{0,0,0}},
  {{0,0,0},{-1,-1,-.5f},{-1.3f,-1.2f,-1},{-.3f,-.4f,1.3f},{.7f,-.8f,1.2f},{-.4f,-.5f,0},{0,0,0}},
  {{0,0,0},{.4f,1,.3f},{-.5f,.5f,.8f},{.5f,-.8f,.8f},{1.3f,-.2f,.4f},{.2f,.6f,1},{0,0,0}},
  {{0,0,0},{-1.1f,-.5f,.5f},{-.5f,-1,1},{-.5f,-1,1},{-1.3f,.7f,.3f},{-.8f,1.2f,0},{0,0,0}},
  {{0,0,0},{1.1f,-1,.3f},{1.3f,-1.4f,-.5f},{-.4f,-.6f,1.1f},{-.4f,-.6f,1.1f},{.8f,-.3f,.4f},{0,0,0}},
  {{0,0,0},{.8f,-.6f,1.2f},{1.2f,-1.5f,.4f},{-.7f,-1.2f,-.8f},{-1.1f,.3f,-1},{.4f,-.8f,.5f},{0,0,0}}
 };
 static boolean workerLeft(int part){return part==5||part==6||part==7;}
 static float progress(float ticks){return clamp((ticks-6)/60);}
 public static float[] gesture(int part,int kind,float ticks,boolean left){
  part=Math.max(0,Math.min(7,part));kind=Math.max(1,Math.min(7,kind));float t=progress(ticks),gate=ease((ticks-3)/7);boolean worker=left==workerLeft(part);
  float[] route=key(t,STAGE,ROUTES[part]),a=key(t,STAGE,ACTIONS[kind-1]),support=key(t,STAGE,SUPPORT[part]),out=new float[6];
  if(worker){
   // Site-specific axes make an arm wrap, knee wrap and ankle figure-eight different routes.
   float ax=a[0],ay=a[1],az=a[2];if(part==1){ax=a[1];ay=-a[0];az=a[2];}else if(part==5){ax=-a[2];ay=a[0];az=a[1];}else if(part==2){ax=a[0];ay=a[2];az=-a[1];}else if(part==6){ax=-a[1];ay=-a[2];az=a[0];}else if(part==3){ax=a[2];ay=a[1];az=-a[0];}else if(part==7){ax=-a[1];ay=a[0];az=a[2];}
   out[0]=route[0]+ax;out[1]=route[1]+ay;out[2]=route[2]+az;for(int i=3;i<6;i++)out[i]=route[i]+a[i]*(part==0?.65f:1);
  }else{
   for(int i=0;i<3;i++)out[i]=support[i];out[3]=support[1]*9;out[4]=support[2]*8;out[5]=-support[0]*12;
   // Distinct supporting jobs: pin splint; expose probe site; brace injector; catch pill; hold peel edge.
   float hold=key(t,new float[]{0,.22f,.72f,1},new float[][]{{0},{1},{1},{0}})[0];
   if(kind==2){out[1]-=.9f*hold;out[3]+=12*hold;}else if(kind==3){out[0]-=.8f*hold;out[5]+=16*hold;}else if(kind==4){out[2]+=.8f*hold;out[4]-=18*hold;}else if(kind==5){out[1]-=1.1f*hold;out[5]-=24*hold;}else if(kind==6){out[0]+=.7f*hold;out[3]-=8*hold;}else if(kind==7){out[2]-=.6f*hold;out[5]+=20*hold;}
  }
  for(int i=0;i<6;i++)out[i]*=gate;return out;
 }
 public static float[] first(int part,int kind,float ticks,boolean left){
  if(!Float.isFinite(ticks))ticks=0;part=Math.max(0,Math.min(7,part));kind=Math.max(1,Math.min(11,kind));
  float[]v=left?new float[]{-164.943f,15.396f,-246.78f,6.97f,-9.979f,-3.313f}:new float[]{160.037f,1.528f,-105.11f,-3.706f,-6.941f,-9.753f};
  float side=part==1?1:part==5?-1:part==2||part==3?.45f:part==6||part==7?-.45f:0,low=part==3||part==7?1.25f:part==2||part==6?1:0,head=part==0?1:0;
  v[0]+=head*(left?-28:22)+low*(left?26:-24);v[1]+=side*(left?22:16);v[2]+=side*(left?18:-20);v[3]+=side*2.3f;v[4]+=head*3.2f-low*3.8f;v[5]+=head*1.7f-low*1.4f;
  if(kind<=7){float[]g=gesture(part,kind,ticks,left);for(int i=0;i<3;i++){v[i]+=g[i+3];v[i+3]+=g[i];}}
  else if(kind==8){float p=(float)Math.pow(Math.sin(Math.max(0,ticks)*.72),2);v[0]+=(left?-12:12)*p;v[4]-=p*1.5f;}
  else if(kind==9){float p=ease(ticks/14)*(1-ease((ticks-45)/20));v[1]+=(left?18:-18)*p;v[4]-=p;}
  else{float p=(float)Math.cos(ticks*(kind==10?.13:.11));v[0]+=(left?8:-8)*p;v[4]+=p;}
  return v;
 }
 static final java.util.Map<Object,float[]> PLAYHEAD=java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());
 static float elapsed(Object player,int part,int kind,float age,float fallback){return elapsedFor(player,part,kind,age,fallback,0);}
 static float elapsedFor(Object player,int part,int kind,float age,float fallback,int channel){
  int remaining;boolean using;try{remaining=((Number)R.call(player,"getUseItemRemainingTicks")).intValue();using=R.yes(R.call(player,"isUsingItem"));}catch(RuntimeException missing){return fallback;}
  float[]s=PLAYHEAD.get(player);if(s==null||s[3]!=part||s[4]!=kind||age<s[0]||age-s[0]>20||(Float.isFinite(s[6+channel])&&fallback<s[6+channel]-.5f)){s=new float[]{age,age-fallback,remaining,part,kind,using?1:0,Float.NaN,Float.NaN};PLAYHEAD.put(player,s);}
  else if(using&&(s[5]==0||remaining>s[2]+1)){s[1]=age;}
  s[0]=age;s[2]=remaining;s[5]=using?1:0;s[6+channel]=fallback;return Math.max(0,age-s[1]);
 }
 public static float[] thirdFor(int part,int kind,float fallback,Object player,float age){return third(part,kind,kind>=8?fallback:elapsedFor(player,part,kind,age,fallback,1));}
 public static float[] third(int part,int kind,float ticks){
  if(!Float.isFinite(ticks))ticks=0;part=Math.max(0,Math.min(7,part));kind=Math.max(1,Math.min(11,kind));if(kind>=8)return Motion57.sample(part,kind,ticks);
  float[]p=new float[24];float reach=ease(ticks/10);
  // Unshared postures: inspect crown; present forearm; half-kneel per knee; squat/toe lift; hold chest.
  switch(part){
   case 0->{p[0]=-2.35f;p[1]=-.6f;p[2]=.22f;p[3]=-2.12f;p[4]=.9f;p[5]=-.12f;p[9]=-.1f;}
   case 1->{p[0]=-1.08f;p[1]=-1.26f;p[2]=-.17f;p[3]=-.55f;p[4]=.15f;p[5]=-.35f;p[6]=.12f;p[7]=-.12f;p[9]=.35f;}
   case 2->{p[0]=-.58f;p[1]=-.42f;p[3]=-.35f;p[4]=.1f;p[6]=.62f;p[7]=-.18f;p[9]=.48f;p[12]=-.95f;p[15]=-.3f;p[18]=3.4f;}
   case 3->{p[0]=-.18f;p[1]=-.5f;p[3]=-.4f;p[4]=-.12f;p[6]=1.03f;p[7]=-.18f;p[9]=.38f;p[12]=-1.15f;p[15]=-.65f;p[18]=6.6f;}
   case 4->{p[0]=-.78f;p[1]=-.95f;p[2]=.25f;p[3]=-.85f;p[4]=.85f;p[5]=-.15f;p[6]=.16f;p[9]=.3f;}
   case 5->{p[0]=-.65f;p[1]=-.1f;p[2]=.42f;p[3]=-1.16f;p[4]=1.3f;p[5]=.16f;p[6]=.19f;p[7]=.16f;p[9]=.32f;}
   case 6->{p[0]=-.25f;p[1]=-.15f;p[3]=-.7f;p[4]=.3f;p[6]=.72f;p[7]=.22f;p[9]=.4f;p[12]=-.25f;p[15]=-1.03f;p[18]=3.9f;}
   case 7->{p[0]=-.42f;p[1]=.1f;p[3]=-.12f;p[4]=.48f;p[6]=.96f;p[7]=.25f;p[9]=.5f;p[12]=-.8f;p[15]=-1.25f;p[18]=6.1f;}
  }
  if(kind==5&&part==0){p[0]=-1.55f;p[1]=-.26f;p[2]=.08f;p[3]=-.78f;p[4]=.7f;p[5]=-.14f;p[6]=0;p[9]=-.08f;}
  for(boolean left:new boolean[]{false,true}){float[]g=gesture(part,kind,ticks,left);int i=left?3:0;float side=left?-1:1;p[i]+=g[3]*.012f-g[2]*.045f;p[i+1]+=g[4]*.014f+g[0]*.065f;p[i+2]+=g[5]*.014f+side*g[1]*.035f;}
  float[]work=gesture(part,kind,ticks,workerLeft(part));p[9]+=work[2]*.025f;p[10]+=work[0]*.035f;p[8]+=work[1]*.018f;
  float drop=p[18],bend=p[6];p[18]=12-(float)Math.cos(bend)*12+drop;p[19]=-(float)Math.sin(bend)*12;p[20]=p[18]+2*((float)Math.cos(bend)-1);p[21]=p[19]+2*(float)Math.sin(bend);p[22]=p[18];p[23]=p[19];for(int i=0;i<24;i++)p[i]*=reach;return p;
 }
}
