package dev.zomboid.firstaid;
/** Late skeletal replacement: native consumption clock and sounds remain intact. */
public final class FirstPerson58 {
 static float smooth(float x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}
 /** Independent control-bone targets, degrees and Bedrock pixels. */
 public static float[] pose(int part,int kind,float ticks,boolean left){return Motion59.first(part,kind,ticks,left);}

 static void set(Object node,float[]v,float weight){
  String[]a={"offsetX","offsetY","offsetZ"};for(int i=0;i<3;i++){float old=((Number)R.get(node,a[i])).floatValue(),value=v[i+3]/16*(i==1?-1:1);R.set(node,a[i],old+(value-old)*weight);}
  Object q=R.get(node,"additionalQuaternion"),target=R.make("org.joml.Quaternionf");R.call(target,"rotationZYX",(float)Math.toRadians(v[2]),(float)Math.toRadians(v[1]),(float)Math.toRadians(v[0]));R.call(q,"slerp",target,weight);
 }
 public static void bones(Object rig,Object player,Object stack,float partial){try{
  float[]c=FirstPerson57.CLOCK.get(player);if(c==null||c[3]<.001f)return;
  // Only this rig has calibrated pivots. Never force another consumable's skeleton.
  Object bandage=R.call(rig,"getNode","bandage"),left=R.call(rig,"getNode","mag_and_lefthand"),right=R.call(rig,"getNode","gun_and_righthand");if(bandage==null||left==null||right==null)return;
  float age=((Number)R.get(player,"tickCount")).floatValue()+partial;float t=Motion59.elapsed(player,(int)c[1],(int)c[2],age,age-c[0]),weight=c[3]*smooth(t/5);
  set(left,pose((int)c[1],(int)c[2],t,true),weight);set(right,pose((int)c[1],(int)c[2],t,false),weight);
  // Keep the dressing in the working hand rather than the original universal use path.
  set(bandage,new float[]{10.605f,-6.901f,53.399f,4.432f,8.802f,7.019f},weight);
 }catch(RuntimeException e){MedicalMotion.warn(e);}}
}
