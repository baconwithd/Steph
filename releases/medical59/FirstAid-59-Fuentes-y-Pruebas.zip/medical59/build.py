from pathlib import Path
import subprocess,shutil
r=Path(__file__).resolve().parent;o=r/'output';o.mkdir(exist_ok=True);base=next((r.parent/'medical58/output').glob('firstaid*.jar'));d=r/'build/classes';d.mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(base),'-d',str(d),*map(str,(r/'src').rglob('*.java'))],check=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']];t=r/'build/tools';t.mkdir(exist_ok=True)
subprocess.run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(t),str(r.parent/'medical52/Patch52.java'),str(r/'Patch59.java')],check=True)
subprocess.run(['java',*f,'-cp',str(t),'Patch59',str(base),str(d),str(o/'firstaid-1.21.1-ZOMBOID-v3.6.22-distinct-medical-choreography.jar')],check=True)
shutil.copy2(next((r.parent/'medical58/output').glob('Les*.jar')),o)
