from pathlib import Path
import json,math,io,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parent;o=r/'preview';o.mkdir(exist_ok=True)
bones=json.loads((r.parent/'medical58/geometry.json').read_text())['minecraft:geometry'][0]['bones'];index={b['name']:b for b in bones}
rows=np.loadtxt(r/'poses.csv',delimiter=',',skiprows=0);poses={(int(x[0]),int(x[1]),int(x[2])):x[3:15]for x in rows}
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
def T(v):
 m=np.eye(4);m[:3,3]=v;return m
def S(v):return np.diag([*v,1])
def R(v):
 x,y,z=np.radians(v);cx,sx=np.cos(x),np.sin(x);cy,sy=np.cos(y),np.sin(y);cz,sz=np.cos(z),np.sin(z)
 return np.array([[cz,-sz,0,0],[sz,cz,0,0],[0,0,1,0],[0,0,0,1]])@np.array([[cy,0,sy,0],[0,1,0,0],[-sy,0,cy,0],[0,0,0,1]])@np.array([[1,0,0,0],[0,cx,-sx,0],[0,sx,cx,0],[0,0,0,1]])
faces=[[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]]
def geometry(part,kind,frame):
 ctrl=poses[part,kind,frame];mats={};quads=[]
 for b in bones:
  n=b['name'];p=np.array(b['pivot'],float);parent=b.get('parent');parentp=np.array(index[parent]['pivot'])if parent else np.array([0,24,0]);pivot=(p-parentp)*[1,-1,1]
  v=ctrl[:6]if n=='mag_and_lefthand'else ctrl[6:12]if n=='gun_and_righthand'else np.array([10.605,-6.901,53.399,4.432,8.802,7.019])if n=='bandage'else np.zeros(6)
  scale=[1,1.5,1]if n in ['lefthand','righthand']else [1,1,6.68]if n=='bone'else [1,1,1]
  mats[n]=(mats[parent]if parent else T([0,24,0])@R([0,0,180]))@T(v[3:]*[1,-1,1])@T(pivot)@R(b.get('rotation',[0,0,0]))@R(v[:3])@S(scale)
  if n not in ['lefthand_pos','righthand_pos','bandage','bone']:continue
  for cube in b.get('cubes',[]):
   origin=np.array(cube['origin']);size=np.array(cube['size']);local=(origin-p)*[1,-1,1];local[1]-=size[1]
   points=np.array([[local[0]+i*size[0],local[1]+j*size[1],local[2]+k*size[2],1]for i in [0,1]for j in [0,1]for k in [0,1]])
   # Render fallback Bedrock arm cubes; the game replaces these with the player's skin.
   world=(mats[n]@points.T).T[:,:3]
   for fi,f in enumerate(faces):quads.append((world[f],n,fi))
 return quads
# Fixed reference projection: inspect rig in camera space; same scale for every treatment.
def render(part,kind,frame):
 im=Image.new('RGB',(400,235),(26,33,40));d=ImageDraw.Draw(im)
 for y in range(80,235,22):d.line((0,y,400,y),fill=(31,40,48))
 quads=geometry(part,kind,frame)
 # Camera looks down -Z; model uses Bedrock native units.
 q=[]
 for pts,n,f in quads:
  z=-pts[:,2]+35;z=np.maximum(z,8);xy=np.c_[200+pts[:,0]*180/z,85-pts[:,1]*180/z]
  q.append((float(z.mean()),xy,n,f))
 for depth,xy,n,f in sorted(q,reverse=True,key=lambda x:x[0]):
  base=(181,137,111)if n.endswith('_pos')else (210,205,177);factor=.65+.06*f;c=tuple(int(x*factor)for x in base)
  d.polygon([tuple(p)for p in xy],fill=c,outline=tuple(max(0,x-24)for x in c))
 return im
full=np.loadtxt(r/'poses.csv',delimiter=',');thirdposes={(int(x[0]),int(x[1]),int(x[2])):x[15:]for x in full}
def box(mat,origin,size):
 return (mat@np.array([[origin[0]+i*size[0],origin[1]+j*size[1],origin[2]+k*size[2],1]for i in [0,1]for j in [0,1]for k in [0,1]]).T).T[:,:3]
def renderthird(part,kind,frame):
 im=Image.new('RGB',(320,235),(29,37,44));d=ImageDraw.Draw(im);d.line((25,220,300,220),fill=(66,77,86));p=thirdposes[part,kind,frame];drop=p[18]-(12-math.cos(p[6])*12);q=[]
 parts=[('body',0,(0,p[18],p[19]),p[6:9],(-4,0,-2),(8,12,4),(53,105,113)),('head',0,(0,p[22],p[23]),p[9:12],(-4,-8,-4),(8,8,8),(176,138,109)),('rightArm',5,(-5,2+p[20],p[21]),p[0:3],(-3,-2,-2),(4,12,4),(183,143,111)),('leftArm',1,(5,2+p[20],p[21]),p[3:6],(-1,-2,-2),(4,12,4),(183,143,111)),('rightLeg',6,(-1.9,12+drop,0),p[12:15],(-2,0,-2),(4,12,4),(57,70,88)),('leftLeg',2,(1.9,12+drop,0),p[15:18],(-2,0,-2),(4,12,4),(57,70,88))]
 view=R([-8,32,0])
 for name,ident,xyz,angles,origin,size,color in parts:
  matrix=view@T(xyz)@R(np.degrees(angles));pts=box(matrix,origin,size)
  for fi,face in enumerate(faces):q.append((pts[face],color,fi))
  selected=(part==4 and name=='body')or(part==0 and name=='head')or(part in [1,5]and ident==part and name.endswith('Arm'))or(part in [2,3,6,7]and ident==(2 if part in [2,3]else 6)and name.endswith('Leg'))
  if selected:
   center=[0,3,-2.08]if name.endswith('Arm')else [0,10,-2.08]if part in [3,7]else [0,5,-2.08]if name.endswith('Leg')else [0,-4,-4.08]if part==0 else [0,5,-2.08]
   patch=box(matrix,center,(1.4,1.4,.1))
   for fi,face in enumerate(faces):q.append((patch[face],(195,64,52),fi))
 for pts,color,f in sorted(q,key=lambda a:float(a[0][:,2].mean()),reverse=True):
  xy=np.c_[160+pts[:,0]*4.6,52+pts[:,1]*4.6];shade=.66+.06*f;c=tuple(int(x*shade)for x in color);d.polygon([tuple(x)for x in xy],fill=c,outline=tuple(max(0,x-17)for x in c))
 return im
sites=[(0,1,'Cabeza: coronilla y sien'),(1,1,'Brazo izq.: antebrazo a bíceps'),(2,1,'Pierna izq.: apoyo de rodilla'),(3,1,'Pie izq.: talón y empeine'),(4,1,'Torso: cruce sobre el pecho'),(5,1,'Brazo der.: mano izquierda trabaja'),(6,1,'Pierna der.: apoyo contrario'),(7,1,'Pie der.: planta y cordones')]
actions=[(0,1,'Vendar: rodear, tensar, presionar'),(2,2,'Tablilla: colocar y fijar dos puntos'),(4,3,'Extraer: alinear, tirar y apartar'),(1,4,'Inyectar: apoyar, insertar, presionar'),(0,5,'Medicar: preparar y llevar a la boca'),(7,6,'Desinfectar: verter, limpiar y secar'),(5,7,'Retirar: pinzar, despegar y apartar')]
for name,panels in [('Zonas',sites),('Tratamientos',actions)]:
 proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x1120','-r','30','-i','-','-an','-c:v','libx264','-crf','21','-pix_fmt','yuv420p',str(o/('FirstAid-59-'+name+'.mp4'))],stdin=subprocess.PIPE);frames=[]
 for f in range(101):
  im=Image.new('RGB',(1280,1120),(14,20,26));d=ImageDraw.Draw(im);d.text((14,10),'59 · '+name.upper()+' · Primera y tercera persona',font=font,fill='white');d.text((14,36),'Preview técnico fuera de Minecraft: rig Bedrock y poses Java. Sin skin, shaders ni captura de gameplay.',font=small,fill=(182,194,205))
  for i,(part,kind,title)in enumerate(panels):
   x=(i%2)*640;y=68+(i//2)*260
   im.paste(render(part,kind,f).resize((320,220)),(x,y+27));im.paste(renderthird(part,kind,f).resize((320,220)),(x+320,y+27));d=ImageDraw.Draw(im);d.text((x+10,y+4),title,font=font,fill=(235,218,157));d.text((x+10,y+232),'1.ª',font=small,fill=(157,176,189));d.text((x+332,y+232),'3.ª',font=small,fill=(157,176,189));d.line((x+8,y+254,x+8+f/100*620,y+254),fill=(109,181,170),width=2)
  proc.stdin.write(im.tobytes())
  if f%3==0:frames.append(im.resize((960,840)))
  if f==47:im.save(o/('FirstAid-59-'+name+'.png'))
 proc.stdin.close();assert proc.wait()==0;frames[0].save(o/('FirstAid-59-'+name+'.gif'),save_all=True,append_images=frames[1:],duration=100,loop=0)
