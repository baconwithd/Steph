import jdk.internal.org.objectweb.asm.tree.*;
public class Patch59 extends Patch52{
 public static void main(String[]a)throws Exception{load(a[0]);overlay(a[1]);var c=read("dev/zomboid/firstaid/MedicalMotion");int calls=0;for(var m:c.methods)for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode i&&i.owner.equals("dev/zomboid/firstaid/Motion57")&&i.name.equals("sample")){i.owner="dev/zomboid/firstaid/Motion59";i.name="third";if(m.name.equals("pose")){var l=new jdk.internal.org.objectweb.asm.tree.InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(FLOAD,2));m.instructions.insertBefore(i,l);i.name="thirdFor";i.desc="(IIFLjava/lang/Object;F)[F";}calls++;}if(calls!=2)throw new AssertionError("third-person dispatch "+calls);write(c);save(a[2]);}
}
