#!/usr/bin/env bash
set -euo pipefail
# Uso: bash build.sh /ruta/al/tacznpcs-original.jar /ruta/al/directorio-de-salida
src_dir=$(cd -- "$(dirname -- "$0")" && pwd)
build_dir="$src_dir/build"
output_dir="$2"
mkdir -p "$build_dir" "$output_dir"
exports=(--add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED)
java -m jdk.compiler/com.sun.tools.javac.Main "${exports[@]}" -d "$build_dir" "$src_dir/Patch.java" "$src_dir/mod/cdv/tnpc/tactical/BanditBrain.java"
java "${exports[@]}" -cp "$build_dir" Patch "$1" "$output_dir/tacznpcs-2.1.0-1.21.1-tactical.1.jar" "$build_dir"
