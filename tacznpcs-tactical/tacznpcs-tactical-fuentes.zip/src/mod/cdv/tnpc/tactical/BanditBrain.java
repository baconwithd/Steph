package mod.cdv.tnpc.tactical;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.nio.file.*;
import java.io.*;

public final class BanditBrain {
 private static final Map<String,Method> METHODS=new ConcurrentHashMap<>();
 private static final Map<Object,State> STATES=Collections.synchronizedMap(new WeakHashMap<>());
 private static final Map<Object,Regions> REGIONS=Collections.synchronizedMap(new WeakHashMap<>());
 private static final Set<String> ERRORS=ConcurrentHashMap.newKeySet();
 private static class State {int shot;long retreatUntil,decision;double rx,ry,rz;}
 private static class Regions {final Properties used=new Properties();Path file;long lastTick=-1;boolean ready;}
 private static State state(Object mob){return STATES.computeIfAbsent(mob,k->new State());}
 private static Class<?> type(String n)throws Exception{return Class.forName(n);}
 private static boolean accepts(Class<?> p,Object a){if(a==null)return !p.isPrimitive();if(!p.isPrimitive())return p.isInstance(a);return p==int.class&&a instanceof Integer||p==long.class&&a instanceof Long||p==float.class&&a instanceof Float||p==double.class&&a instanceof Double||p==boolean.class&&a instanceof Boolean;}
 private static Object call(Object obj,String name,Object...args)throws Exception{
  Class<?> c=obj instanceof Class<?>?(Class<?>)obj:obj.getClass();StringBuilder k=new StringBuilder(c.getName()).append('#').append(name);for(Object a:args)k.append('/').append(a==null?"null":a.getClass().getName());
  Method m=METHODS.get(k.toString());if(m==null){List<Method> choices=new ArrayList<>(Arrays.asList(c.getMethods()));for(Class<?> q=c;q!=null;q=q.getSuperclass())choices.addAll(Arrays.asList(q.getDeclaredMethods()));outer:for(Method candidate:choices){if(!candidate.getName().equals(name)||candidate.getParameterCount()!=args.length)continue;Class<?>[] p=candidate.getParameterTypes();
   boolean ok=true;for(int i=0;i<p.length;i++)if(!accepts(p[i],args[i])){ok=false;break;}if(!ok)continue;candidate.setAccessible(true);m=candidate;break outer;}
   if(m==null)throw new NoSuchMethodException(c.getName()+"."+name+"/"+args.length);METHODS.put(k.toString(),m);}
  return m.invoke(obj instanceof Class<?>?null:obj,args);
 }
 private static Object field(Object obj,String name)throws Exception{Class<?> c=obj instanceof Class<?>?(Class<?>)obj:obj.getClass();for(Class<?> q=c;q!=null;q=q.getSuperclass())try{Field f=q.getDeclaredField(name);f.setAccessible(true);return f.get(obj instanceof Class<?>?null:obj);}catch(NoSuchFieldException e){}throw new NoSuchFieldException(name);}
 private static double num(Object o){return ((Number)o).doubleValue();}
 private static double coord(Object o,String axis)throws Exception{return num(call(o,"get"+axis));}
 private static boolean yes(Object o){return Boolean.TRUE.equals(o);}
 private static void error(String feature,Exception e){if(ERRORS.add(feature))System.err.println("[TacZ NPCs Tactical] "+feature+" disabled for this operation: "+e);}
 private static boolean bandit(Object mob)throws Exception{String id=String.valueOf(field(mob,"templateId")).toLowerCase(Locale.ROOT);if(id.contains("bandit")||id.contains("illager"))return true;Object t=call(mob,"getTemplate");return t!=null&&((Set<?>)call(t,"opposed")).contains("players");}
 private static List<?> nearby(Object level,Object mob,String clazz,double range)throws Exception{return (List<?>)call(level,"getEntitiesOfClass",type(clazz),call(call(mob,"getBoundingBox"),"inflate",range));}
 private static boolean allied(Object mob,Object other)throws Exception{return mob==other||yes(call(mob,"isAlliedTo",other))||bandit(mob)&&bandit(other);}
 public static void tick(Object mob){try{
  Object level=call(mob,"level");if(yes(call(level,"isClientSide")))return;long time=((Number)call(level,"getGameTime")).longValue();State s=state(mob);if(time<s.decision){if(time<s.retreatUntil){call(call(mob,"getNavigation"),"moveTo",s.rx,s.ry,s.rz,1.35);call(mob,"setSprinting",true);call(mob,"setTarget",(Object)null);}return;}s.decision=time+5;
  if(!bandit(mob))return;if(s.retreatUntil>0&&time>=s.retreatUntil){s.retreatUntil=0;call(mob,"setSprinting",false);}
  List<?> zombies=nearby(level,mob,"net.minecraft.world.entity.monster.Zombie",24.0);
  List<?> npcs=nearby(level,mob,"mod.cdv.tnpc.entity.AutoGunOperator",24.0);int allies=0,threats=0;Object nearest=null;double closest=Double.MAX_VALUE;
  for(Object n:npcs)if(yes(call(n,"isAlive"))&&allied(mob,n))allies++;
  for(Object z:zombies)if(yes(call(z,"isAlive"))){double d=num(call(mob,"distanceToSqr",z));if(d<closest){closest=d;nearest=z;}if(d<144||yes(call(call(mob,"getSensing"),"hasLineOfSight",z)))threats++;}
  Object target=call(mob,"getTarget");boolean danger=threats>=Math.max(4,Math.max(1,allies)*3)||threats>=2&&num(call(mob,"getHealth"))<num(call(mob,"getMaxHealth"))*0.3;
  if(danger&&nearest!=null){Object away=call(type("net.minecraft.world.entity.ai.util.LandRandomPos"),"getPosAway",mob,18,7,call(nearest,"position"));if(away!=null){s.retreatUntil=time+60;s.rx=num(field(away,"x"));s.ry=num(field(away,"y"));s.rz=num(field(away,"z"));}}
  if(time<s.retreatUntil){call(call(mob,"getNavigation"),"moveTo",s.rx,s.ry,s.rz,1.35);call(mob,"setSprinting",true);if(nearest!=null&&closest>64&&time%20>=15)call(mob,"setTarget",nearest);else call(mob,"setTarget",(Object)null);return;}
  if(target==null){double pd=48*48;Object pt=null;for(Object p:nearby(level,mob,"net.minecraft.world.entity.player.Player",48.0)){if(yes(call(p,"isSpectator"))||yes(call(p,"isCreative")))continue;double d=num(call(mob,"distanceToSqr",p));if(d<pd&&yes(call(call(mob,"getSensing"),"hasLineOfSight",p))){pd=d;pt=p;}}if(pt!=null){call(mob,"setTarget",pt);target=pt;}}
  if(nearest!=null&&(closest<100||target==null)&&yes(call(call(mob,"getSensing"),"hasLineOfSight",nearest))){call(mob,"setTarget",nearest);target=nearest;}
  if(target!=null&&yes(call(target,"isAlive")))return;
  Object loot=null;double best=256;
  for(Object item:nearby(level,mob,"net.minecraft.world.entity.item.ItemEntity",16.0)){Object stack=call(item,"getItem");if(!yes(call(mob,"wantsToPickUp",stack))||!upgrade(mob,stack))continue;double d=num(call(mob,"distanceToSqr",item));if(d<best){best=d;loot=item;}}
  if(loot!=null)call(call(mob,"getNavigation"),"moveTo",loot,1.1);
 }catch(Exception e){error("AI",e);}}
 public static void committed(Object mob){state(mob).shot++;try{Object level=call(mob,"level");Object flame=field(type("net.minecraft.core.particles.ParticleTypes"),"FLAME");call(level,"sendParticles",flame,coord(mob,"X"),num(call(mob,"getEyeY"))-0.12,coord(mob,"Z"),2,0.04,0.04,0.04,0.0);}catch(Exception e){error("muzzle particles",e);}}
 private static double[] aim(Object mob)throws Exception{Object t=call(mob,"getTarget");if(t==null)return new double[]{num(call(mob,"getViewXRot",1.0f)),num(call(mob,"getViewYRot",1.0f))};double dx=coord(t,"X")-coord(mob,"X"),dz=coord(t,"Z")-coord(mob,"Z");double dist=Math.sqrt(dx*dx+dz*dz);double y=coord(t,"Y")+num(call(t,"getBbHeight"))*(type("net.minecraft.world.entity.player.Player").isInstance(t)?0.28:0.5);double pitch=-Math.toDegrees(Math.atan2(y-num(call(mob,"getEyeY")),Math.max(0.1,dist)));double yaw=Math.toDegrees(Math.atan2(dz,dx))-90;
  int n=state(mob).shot%10;if(type("net.minecraft.world.entity.player.Player").isInstance(t)&&n!=0&&n!=3&&n!=6){double width=num(call(t,"getBbWidth"));double offset=Math.toDegrees(Math.atan2(width+0.9,Math.max(dist,1)));yaw+=n%2==0?offset:-offset;}
  return new double[]{pitch,yaw};}
 public static Float pitch(Object mob){try{return (float)aim(mob)[0];}catch(Exception e){error("aim",e);try{return ((Number)call(mob,"getViewXRot",1.0f)).floatValue();}catch(Exception x){return 0f;}}}
 public static Float yaw(Object mob){try{return (float)aim(mob)[1];}catch(Exception e){error("aim",e);try{return ((Number)call(mob,"getViewYRot",1.0f)).floatValue();}catch(Exception x){return 0f;}}}
 private static boolean upgrade(Object mob,Object stack){try{Object item=call(stack,"getItem");if(type("com.tacz.guns.api.item.IGun").isInstance(item))return betterGun(stack,call(mob,"getMainHandItem"));Object slot=call(item,"getEquipmentSlot");return yes(call(mob,"canReplaceCurrentItem",stack,call(mob,"getItemBySlot",slot)));}catch(Exception e){error("loot selection",e);return false;}}
 public static boolean betterGun(Object candidate,Object current){try{Object a=call(candidate,"getItem"),b=call(current,"getItem");Class<?> gun=type("com.tacz.guns.api.item.IGun");if(!gun.isInstance(a))return false;if(!gun.isInstance(b))return true;return gunScore(a,candidate)>gunScore(b,current);}catch(Exception e){error("gun upgrades",e);return false;}}
 private static int gunScore(Object gun,Object stack)throws Exception{Object id=call(gun,"getGunId",stack);Optional<?> index=(Optional<?>)call(type("com.tacz.guns.api.TimelessAPI"),"getCommonGunIndex",id);if(index.isEmpty())return 0;String kind=String.valueOf(call(index.get(),"getType")).toLowerCase(Locale.ROOT);return switch(kind){case "pistol"->1;case "smg"->2;case "shotgun"->3;case "rifle","sniper"->4;case "mg"->5;default->2;};}
 public static void levelTick(Object event){try{Object level=call(event,"getLevel");if(!type("net.minecraft.server.level.ServerLevel").isInstance(level))return;long tick=((Number)call(level,"getGameTime")).longValue();if(tick%100!=0)return;
  Regions r=REGIONS.computeIfAbsent(level,k->new Regions());if(r.lastTick==tick)return;r.lastTick=tick;
  if(!r.ready){Object server=call(level,"getServer");Object root=field(type("net.minecraft.world.level.storage.LevelResource"),"ROOT");Path world=(Path)call(server,"getWorldPath",root);String dimension=String.valueOf(call(call(level,"dimension"),"location"));r.file=world.resolve("data/tacznpcs-bandits-"+dimension.replaceAll("[^a-zA-Z0-9_.-]","_")+".properties");if(Files.exists(r.file))try(InputStream in=Files.newInputStream(r.file)){r.used.load(in);}r.ready=true;}
  List<?> players=(List<?>)call(level,"players");Map<?,?> templates=(Map<?,?>)field(type("mod.cdv.tnpc.data.TemplateDataManager"),"TEMPLATES");String template=templates.containsKey("bandits")?"bandits":templates.containsKey("illagers")?"illagers":null;if(template==null)return;
  for(Object player:players){if(yes(call(player,"isSpectator")))continue;int px=((int)Math.floor(coord(player,"X")))>>4,pz=((int)Math.floor(coord(player,"Z")))>>4;
   if(nearby(level,player,"mod.cdv.tnpc.entity.AutoGunOperator",80.0).size()>=12)continue;
   for(int attempt=0;attempt<8;attempt++){int cx=px+(int)(Math.random()*9)-4,cz=pz+(int)(Math.random()*9)-4;int regionX=Math.floorDiv(cx,5);String key=regionX+":"+cz;if(r.used.containsKey(key))continue;int selected=regionX*5+Math.floorMod(Objects.hash(regionX,cz),5);if(cx!=selected)continue;if(!yes(call(call(level,"getChunkSource"),"hasChunk",cx,cz)))continue;
    int x=cx*16+8,z=cz*16+8;Object heightmap=Enum.valueOf((Class)type("net.minecraft.world.level.levelgen.Heightmap$Types"),"MOTION_BLOCKING_NO_LEAVES");int y=((Number)call(level,"getHeight",heightmap,x,z)).intValue();boolean close=false;for(Object p:players){double dx=coord(p,"X")-x,dz=coord(p,"Z")-z;if(dx*dx+dz*dz<1024){close=true;break;}}if(close)continue;
    Object block=type("net.minecraft.core.BlockPos").getConstructor(int.class,int.class,int.class).newInstance(x,y-1,z);if(!yes(call(call(level,"getFluidState",block),"isEmpty")))continue;
    int count=Math.random()<0.55?1:2+(int)(Math.random()*3),added=0;
    for(int i=0;i<count;i++){Object mob=call(type("mod.cdv.tnpc.entity.AutoGunOperator"),"create",level,template);call(mob,"moveTo",x+0.5+(i%2)*1.5,(double)y,z+0.5+(i/2)*1.5,(float)(Math.random()*360),0f);if(!yes(call(level,"noCollision",mob)))continue;call(mob,"setPersistenceRequired");if(yes(call(level,"addFreshEntity",mob)))added++;}
    if(added>0){r.used.setProperty(key,String.valueOf(tick));Files.createDirectories(r.file.getParent());Path temp=r.file.resolveSibling(r.file.getFileName()+".tmp");try(OutputStream out=Files.newOutputStream(temp)){r.used.store(out,"One encounter per five contiguous chunks; persistent world ledger");}Files.move(temp,r.file,StandardCopyOption.REPLACE_EXISTING);return;}
   }
  }
 }catch(Exception e){error("regional spawning",e);}}
}
