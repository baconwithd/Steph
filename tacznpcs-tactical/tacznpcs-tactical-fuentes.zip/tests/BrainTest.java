import mod.cdv.tnpc.tactical.BanditBrain;
public class BrainTest {
 public static class Mob {
  final net.minecraft.world.entity.player.Player player=new net.minecraft.world.entity.player.Player();
  public Object getTarget(){return player;}public double getX(){return 0;}public double getZ(){return 0;}public double getEyeY(){return 1.62;}public float getViewXRot(float f){return 7;}public float getViewYRot(float f){return 12;}public Object level(){return new World();}
 }
 public static class World {}
 public static void main(String[] args)throws Exception{
  Mob m=new Mob();int accurate=0;float pitch=BanditBrain.pitch(m);
  if(pitch<3||pitch>4)throw new AssertionError("Aim does not point at lower body: "+pitch);
  for(int i=0;i<10;i++){float yaw=BanditBrain.yaw(m);if(Math.abs(yaw)<.001)accurate++;else if(Math.abs(yaw)<4)throw new AssertionError("Miss offset too small");if(BanditBrain.yaw(m)!=yaw)throw new AssertionError("Cooldown retries changed accuracy cycle");BanditBrain.committed(m);}
  if(accurate!=3)throw new AssertionError("Expected 3 precise trajectories, got "+accurate);
  if(Math.abs(BanditBrain.yaw(m))>.001)throw new AssertionError("Cycle does not reset after ten shots");
  if(BanditBrain.pitch(new Object())!=0f)throw new AssertionError("Missing target API fallback failed");
  System.out.println("PASS: 3/10 precise trajectories, lower-body angle, stable cooldown retries, ten-shot cycle, safe reflection fallback.");
 }
}
