package mod.cdv.tnpc.entity;
public class AutoGunOperator {public String templateId="bandits";public boolean isAlive(){return true;}public boolean isAlliedTo(Object o){return false;}}
