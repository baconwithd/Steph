package net.minecraft.world.entity.player;
public class Player {
 public double getX(){return 0;}public double getY(){return 0;}public double getZ(){return 20;}public float getBbHeight(){return 1.8f;}public float getBbWidth(){return .6f;}
}
