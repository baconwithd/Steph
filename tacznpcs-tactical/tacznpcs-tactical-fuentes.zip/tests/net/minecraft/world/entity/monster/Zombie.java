package net.minecraft.world.entity.monster;
public class Zombie {public boolean isAlive(){return true;}public Object position(){return new Object();}}
