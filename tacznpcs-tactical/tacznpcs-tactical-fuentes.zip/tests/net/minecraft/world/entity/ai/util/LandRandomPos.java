package net.minecraft.world.entity.ai.util;
public class LandRandomPos {public static class Vec {public double x=10,y=64,z=10;}public static Vec getPosAway(Object m,int h,int v,Object p){return new Vec();}}
