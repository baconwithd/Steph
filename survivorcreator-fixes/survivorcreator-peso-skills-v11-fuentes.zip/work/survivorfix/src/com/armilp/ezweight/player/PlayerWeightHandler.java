package com.armilp.ezweight.player;
import java.util.*;
import java.lang.reflect.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.*;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.capabilities.Capabilities;
import com.armilp.ezweight.data.ItemWeightRegistry;
import com.armilp.ezweight.util.BackpackIdUtils;
public class PlayerWeightHandler {
 private static final Method CAPABILITY=capabilityGetter();
 private static Method capabilityGetter(){
  for(Method m:ItemStack.class.getMethods())if(m.getName().equals("getCapability")&&m.getParameterCount()==1&&m.getParameterTypes()[0].isInstance(Capabilities.ItemHandler.ITEM))return m;
  return null;
 }
 public static double backpackReduction(ItemStack stack){return BackpackIdUtils.isBackpackItem(stack)?.90:0;}
 public static double backpackContents(ItemStack stack,double contents){return BackpackIdUtils.isBackpackItem(stack)?CarryRules.contents(contents):contents;}
 public static double getMaxWeight(Player p){return DynamicMaxWeightCalculator.calculate(p);}
 public static double getExtendedStackWeightWithContents(ItemStack stack,Player p){return getStackWeight(stack,p,new HashSet<>(),p==null?null:p.level().registryAccess());}
 public static double getPickupUnitWeight(ItemStack stack,Player p){return getExtendedStackWeightWithContents(stack,p)/Math.max(1,stack.getCount());}
 public static double getTotalWeight(Player p){
  Set<Object> visited=new HashSet<>();HolderLookup.Provider registries=p.level().registryAccess();double total=0;
  for(ItemStack stack:p.getInventory().items)total+=getStackWeight(stack,p,visited,registries);
  for(ItemStack stack:p.getInventory().armor)total+=getStackWeight(stack,p,visited,registries);
  for(ItemStack stack:p.getInventory().offhand)total+=getStackWeight(stack,p,visited,registries);
  try{
   Class<?> api=Class.forName("top.theillusivec4.curios.api.CuriosApi");
   Object optional=api.getMethod("getCuriosInventory",LivingEntity.class).invoke(null,p);
   if(optional instanceof Optional<?> opt&&opt.isPresent()){
    Object inventory=opt.get();Object slots=inventory.getClass().getMethod("getCurios").invoke(inventory);
    for(Object slot:((Map<?,?>)slots).values()){
     Object handler=slot.getClass().getMethod("getStacks").invoke(slot);
     if(handler instanceof IItemHandler items&&visited.add(handler))total+=handlerWeight(items,p,visited,registries,0);
    }
   }
  }catch(ClassNotFoundException ignored){}catch(ReflectiveOperationException|RuntimeException e){warn("Curios",e);}
  return total;
 }
 public static double getStackWeight(ItemStack stack,Player p,Set<Object> visited,HolderLookup.Provider registries){return stackWeight(stack,p,visited,registries,0);}
 private static double stackWeight(ItemStack stack,Player p,Set<Object> visited,HolderLookup.Provider registries,int depth){
  if(stack.isEmpty()||!visited.add(stack))return 0;
  double base=ItemWeightRegistry.getWeight(stack)*stack.getCount();if(depth>24)return base;
  double contents=0;boolean backpack=BackpackIdUtils.isBackpackItem(stack);boolean resolved=false;
  try{
   if(BuiltInRegistries.ITEM.getKey(stack.getItem()).getNamespace().equals("sophisticatedbackpacks")){
    Class<?> wrapper=Class.forName("net.p3pp3rf1y.sophisticatedbackpacks.backpack.wrapper.BackpackWrapper");
    Object w=wrapper.getMethod("fromStack",ItemStack.class).invoke(null,stack);
    Object uuid=w.getClass().getMethod("getContentsUuid").invoke(w);
    if(uuid instanceof Optional<?> id&&id.isPresent()&&!visited.add(new StorageId(id.get())))return base;
    Object inventory=w.getClass().getMethod("getInventoryHandler").invoke(w);
    if(inventory instanceof IItemHandler h){resolved=true;if(visited.add(h))contents=handlerWeight(h,p,visited,registries,depth+1);}
   }
   if(!resolved){
    Object handler=null;
    if(CAPABILITY!=null)handler=CAPABILITY.invoke(stack,Capabilities.ItemHandler.ITEM);
    if(handler instanceof IItemHandler h){resolved=true;if(visited.add(h))contents=handlerWeight(h,p,visited,registries,depth+1);}
   }
  }catch(ReflectiveOperationException|RuntimeException e){warn("container",e);}
  if(!resolved){
   ItemContainerContents container=stack.get(DataComponents.CONTAINER);
   BundleContents bundle=stack.get(DataComponents.BUNDLE_CONTENTS);
   if(container!=null){for(ItemStack child:container.nonEmptyItems())contents+=stackWeight(child,p,visited,registries,depth+1);}
   else if(bundle!=null){for(ItemStack child:bundle.items())contents+=stackWeight(child,p,visited,registries,depth+1);}
   else{CustomData tag=stack.get(DataComponents.CUSTOM_DATA);if(tag!=null)contents=tagWeight(tag.copyTag(),p,visited,registries,depth+1);}
  }
  return base+(backpack?CarryRules.contents(contents):contents);
 }
 private static double handlerWeight(IItemHandler handler,Player p,Set<Object> visited,HolderLookup.Provider registries,int depth){
  double total=0;for(int i=0;i<handler.getSlots();i++)total+=stackWeight(handler.getStackInSlot(i),p,visited,registries,depth);return total;
 }
 public static double extractWeightFromTag(CompoundTag tag,Set<Object> visited,HolderLookup.Provider registries){return tagWeight(tag,null,visited,registries,0);}
 private static double tagWeight(CompoundTag tag,Player p,Set<Object> visited,HolderLookup.Provider registries,int depth){
  if(tag==null||registries==null||depth>24)return 0;double total=0;
  for(String key:tag.getAllKeys()){
   if(tag.contains(key,9)){ListTag list=tag.getList(key,10);for(int i=0;i<list.size();i++){CompoundTag child=list.getCompound(i);
    if(child.contains("id",8))total+=stackWeight(ItemStack.parseOptional(registries,child),p,visited,registries,depth+1);
    else total+=tagWeight(child,p,visited,registries,depth+1);
   }}else if(tag.contains(key,10))total+=tagWeight(tag.getCompound(key),p,visited,registries,depth+1);
  }return total;
 }
 private record StorageId(Object id){}
 private static final Set<String> warnings=new HashSet<>();
 private static void warn(String section,Exception e){if(warnings.add(section))org.slf4j.LoggerFactory.getLogger("ezweight").warn("Weight container integration: "+section,e);}
}
