package com.armilp.ezweight.player;
public final class CarryRules {
 public static double item(double raw){return Double.isFinite(raw)?Math.max(0,raw)/3:0;}
 public static double contents(double weight){return Math.max(0,weight)*.10;}
 public static double capacity(int strength,int fitness,int sprinting){return 50+2*bounded(strength)+1.5*bounded(fitness)+.5*bounded(sprinting);}
 private static int bounded(int n){return Math.max(0,Math.min(10,n));}
 public static double effectWeight(double actual,double capacity,double originalMax){return Math.max(0,actual)/Math.max(1,capacity)*originalMax;}
}
