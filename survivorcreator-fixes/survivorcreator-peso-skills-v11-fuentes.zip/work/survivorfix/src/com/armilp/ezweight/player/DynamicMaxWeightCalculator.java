package com.armilp.ezweight.player;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
public class DynamicMaxWeightCalculator {
 public static double calculate(Player player){
  if(player==null)return 50;
  AttributeInstance attribute=BuiltInRegistries.ATTRIBUTE.getHolder(ResourceLocation.parse("ezweight:weight")).map(player::getAttribute).orElse(null);
  if(player.level().isClientSide())return attribute==null?50:Math.max(50,attribute.getValue());
  double base=CarryRules.capacity(skill(player,"strength"),skill(player,"fitness"),skill(player,"sprinting"));
  if(attribute!=null){if(attribute.getBaseValue()!=base)attribute.setBaseValue(base);return Math.max(50,attribute.getValue());}
  return base;
 }
 private static int skill(Player player,String id){
  if(!(player instanceof ServerPlayer))return 0;
  try{Class<?> skills=Class.forName("dev.survivorcreator.skills.Skills");Object skill=skills.getMethod("get",String.class).invoke(null,id);if(skill==null)return 0;
   return ((Number)skills.getMethod("level",ServerPlayer.class,Class.forName("dev.survivorcreator.skills.Skill")).invoke(null,player,skill)).intValue();
  }catch(ReflectiveOperationException|LinkageError e){return 0;}
 }
}
