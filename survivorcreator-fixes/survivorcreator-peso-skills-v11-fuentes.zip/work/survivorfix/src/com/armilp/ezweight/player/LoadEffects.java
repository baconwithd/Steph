package com.armilp.ezweight.player;
import java.util.List;
import com.armilp.ezweight.levels.WeightLevel;
import com.armilp.ezweight.registry.ModEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
public final class LoadEffects {
 public static WeightLevel forNullablePlayer(Player p){return p==null?null:forPlayer(PlayerWeightHandler.getTotalWeight(p),p);}
 public static WeightLevel forPlayer(double weight,Player p){
  double capacity=DynamicMaxWeightCalculator.calculate(p),ratio=weight/capacity;
  if(ratio<.8)return new WeightLevel("Unburdened",0,capacity*.8,List.of());
  if(ratio<.95)return new WeightLevel("Light Load",capacity*.8,capacity*.95,List.of(new MobEffectInstance(ModEffects.LIGHT_ENCUMBERED,6000,0,false,false,true)));
  if(ratio<1.05)return new WeightLevel("Moderate Load",capacity*.95,capacity*1.05,List.of(new MobEffectInstance(ModEffects.ENCUMBERED,6000,0,false,false,true)));
  if(ratio<1.15)return new WeightLevel("Heavy Load",capacity*1.05,capacity*1.15,List.of(new MobEffectInstance(ModEffects.HEAVILY_ENCUMBERED,6000,0,false,false,true)));
  if(ratio<1.3)return new WeightLevel("Very Heavy Load",capacity*1.15,capacity*1.3,List.of(new MobEffectInstance(ModEffects.OVERBURDENED,6000,0,false,false,true)));
  return new WeightLevel("Overburdened",capacity*1.3,Double.MAX_VALUE,List.of(new MobEffectInstance(ModEffects.CRUSHED,6000,0,false,false,true)));
 }
}
