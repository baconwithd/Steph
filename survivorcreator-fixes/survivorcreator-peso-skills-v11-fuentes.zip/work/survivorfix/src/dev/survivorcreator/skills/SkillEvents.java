/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.damagesource.DamageTypes
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.neoforged.neoforge.event.entity.EntityJoinLevelEvent
 *  net.neoforged.neoforge.event.entity.living.LivingDamageEvent$Post
 *  net.neoforged.neoforge.event.entity.living.LivingEvent$LivingJumpEvent
 *  net.neoforged.neoforge.event.entity.player.PlayerEvent$PlayerLoggedOutEvent
 *  net.neoforged.neoforge.event.server.ServerStoppingEvent
 *  net.neoforged.neoforge.event.tick.PlayerTickEvent$Post
 *  net.neoforged.neoforge.event.tick.ServerTickEvent$Post
 */
package dev.survivorcreator.skills;

import dev.survivorcreator.skills.Skill;
import dev.survivorcreator.skills.SkillPopups;
import dev.survivorcreator.skills.Skills;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@net.neoforged.fml.common.EventBusSubscriber(modid="survivorcreator")
public final class SkillEvents {
    private static final java.util.Map<ServerPlayer,net.minecraft.world.phys.Vec3> MOVEMENT=new java.util.WeakHashMap<>();
    private SkillEvents() {
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post post) {
        if(!(post.getEntity() instanceof ServerPlayer p)||!p.isAlive()||p.isCreative()||p.isSpectator())return;
        net.minecraft.world.phys.Vec3 previous=MOVEMENT.put(p,p.position());
        if(previous==null)return;
        double distance=p.position().subtract(previous).horizontalDistanceSqr();
        if(distance<.0004||distance>1||p.isPassenger())return;
        if(p.isSprinting()&&p.onGround()&&!p.isInWater()){
            Skills.addXp(p,Skills.FITNESS,.10);WorkEvents.xp(p,"sprinting",.10);
        }else if(p.isCrouching()){
            WorkEvents.xp(p,"sneaking",.05);WorkEvents.xp(p,"nimble",.025);
        }else if(p.onGround())WorkEvents.xp(p,"lightfooted",.025);
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent livingJumpEvent) {
        LivingEntity livingEntity = livingJumpEvent.getEntity();
        if (livingEntity instanceof ServerPlayer) {
            ServerPlayer serverPlayer = (ServerPlayer)livingEntity;
            if(serverPlayer.isCreative()||serverPlayer.isSpectator())return;
            Skills.addXp(serverPlayer, Skills.FITNESS, 1.0);
        }
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onHit(LivingDamageEvent.Post post) {
        if (post.getEntity() instanceof Player) {
            return;
        }
        Entity entity = post.getSource().getEntity();
        if (!(entity instanceof ServerPlayer)) {
            return;
        }
        ServerPlayer serverPlayer = (ServerPlayer)entity;
        if (post.getSource().getDirectEntity() != serverPlayer) {
            return;
        }
        if (!post.getSource().is(DamageTypes.PLAYER_ATTACK)) {
            return;
        }
        if (post.getNewDamage() <= 0.0f) {
            return;
        }
        ItemStack itemStack = serverPlayer.getMainHandItem();
        if (itemStack == null || itemStack.isEmpty()) {
            return;
        }
        Skill skill = SkillEvents.classifyWeapon(itemStack);
        if (skill == null) {
            return;
        }
        Skills.addXp(serverPlayer, Skills.STRENGTH, 1.0);
        Skills.addXp(serverPlayer, skill, 5.0);
    }

    private static Skill classifyWeapon(ItemStack itemStack) {
        String string = String.valueOf(itemStack.getItem()).toLowerCase();
        if (SkillEvents.has(string, "karambit") || SkillEvents.has(string, "dagger") || SkillEvents.has(string, "knife") || SkillEvents.has(string, "cutter") || SkillEvents.has(string, "scalpel")) {
            return Skills.get("short_blade");
        }
        if (SkillEvents.has(string, "katana") || SkillEvents.has(string, "machete") || SkillEvents.has(string, "sword") || SkillEvents.has(string, "long_blade") || SkillEvents.has(string, "blade")) {
            return Skills.get("long_blade");
        }
        if (SkillEvents.has(string, "axe") || SkillEvents.has(string, "hatchet")) {
            return Skills.get("axe");
        }
        if (SkillEvents.has(string, "spear") || SkillEvents.has(string, "trident") || SkillEvents.has(string, "pike") || SkillEvents.has(string, "halberd")) {
            return Skills.get("spear");
        }
        if (SkillEvents.has(string, "bat") || SkillEvents.has(string, "club") || SkillEvents.has(string, "crowbar") || SkillEvents.has(string, "pipe") || SkillEvents.has(string, "staff") || SkillEvents.has(string, "stick") || SkillEvents.has(string, "long_blunt")) {
            return Skills.get("long_blunt");
        }
        if (SkillEvents.has(string, "skillet") || SkillEvents.has(string, "pan") || SkillEvents.has(string, "hammer") || SkillEvents.has(string, "wrench") || SkillEvents.has(string, "mace") || SkillEvents.has(string, "short_blunt")) {
            return Skills.get("short_blunt");
        }
        return null;
    }

    private static boolean has(String string, String string2) {
        return string.contains(string2);
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post post) {
        SkillPopups.tick(post.getServer());
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent playerLoggedOutEvent) {
        SkillPopups.removeFor(playerLoggedOutEvent.getEntity().getUUID());
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onStopping(ServerStoppingEvent serverStoppingEvent) {
        SkillPopups.clearAll();
        MOVEMENT.clear();
    }

    @net.neoforged.bus.api.SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent entityJoinLevelEvent) {
        if (entityJoinLevelEvent.loadedFromDisk() && entityJoinLevelEvent.getEntity().getTags().contains("survivorcreator_popup")) {
            entityJoinLevelEvent.setCanceled(true);
        }
    }
}

