package dev.survivorcreator.skills;
public final class WorkRules {
 public static double craftXp(int count){return Math.max(1,Math.min(16,count))*2.0;}
 public static boolean metal(String id){return id.contains("iron")||id.contains("copper")||id.contains("gold")||id.contains("netherite")||id.contains("ingot")||id.contains("nugget")||id.contains("steel")||id.contains("metal")||id.contains("alloy");}
 public static boolean electric(String id){return id.contains("wire")||id.contains("circuit")||id.contains("battery")||id.contains("electronic")||id.contains("redstone");}
 public static boolean wood(String id){return id.contains("plank")||id.contains("wood")||id.contains("fence")||id.contains("trapdoor")||id.contains("stairs")||id.contains("slab")||id.contains("door")||id.contains("chest")||id.contains("barrel");}
 public static float workSpeed(float speed,int level){return speed*(1+Math.max(0,Math.min(10,level))*.03f);}
}
