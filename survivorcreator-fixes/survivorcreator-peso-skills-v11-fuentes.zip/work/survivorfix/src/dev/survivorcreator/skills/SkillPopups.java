/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.ChatFormatting
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.network.chat.Component
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.decoration.ArmorStand
 *  net.minecraft.world.level.Level
 */
package dev.survivorcreator.skills;

import dev.survivorcreator.skills.Skill;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.Level;

public final class SkillPopups {
    public static final String TAG = "survivorcreator_popup";
    private static final int LIFETIME_TICKS = 70;
    private static final List<Popup> ACTIVE = new ArrayList<Popup>();

    private SkillPopups() {
    }

    public static void show(ServerPlayer p, Skill s, int level) {
        SkillPopups.removeFor(p.getUUID());
        ServerLevel level0 = p.serverLevel();
        ArmorStand title = SkillPopups.spawn(level0, p, (Component)Component.translatable((String)"popup.survivorcreator.levelup").withStyle(new ChatFormatting[]{ChatFormatting.GOLD, ChatFormatting.BOLD}));
        ArmorStand detail = SkillPopups.spawn(level0, p, (Component)Component.translatable((String)"popup.survivorcreator.skill", (Object[])new Object[]{s.name(), level}).withStyle(ChatFormatting.YELLOW));
        if (title == null || detail == null) {
            if (title != null) {
                title.discard();
            }
            if (detail != null) {
                detail.discard();
            }
            return;
        }
        Popup popup = new Popup(p.getUUID(), title, detail);
        ACTIVE.add(popup);
        SkillPopups.follow(popup, p);
    }

    private static ArmorStand spawn(ServerLevel lvl, ServerPlayer p, Component text) {
        ArmorStand as = new ArmorStand((Level)lvl, p.getX(), p.getY() + 2.0, p.getZ());
        CompoundTag t = new CompoundTag();
        as.saveWithoutId(t);
        t.putBoolean("Marker", true);
        t.putBoolean("Invisible", true);
        t.putBoolean("NoGravity", true);
        as.load(t);
        as.addTag(TAG);
        as.setCustomName(text);
        as.setCustomNameVisible(true);
        as.setSilent(true);
        as.setInvulnerable(true);
        if (!lvl.addFreshEntity((Entity)as)) {
            return null;
        }
        as.addTag(TAG);
        return as;
    }

    private static void follow(Popup popup, ServerPlayer p) {
        double rise = (double)Math.min(popup.age, 40) * 0.008;
        double baseY = p.getY() + 2.0 + rise;
        popup.detail.setPos(p.getX(), baseY, p.getZ());
        popup.title.setPos(p.getX(), baseY + 0.3, p.getZ());
    }

    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) {
            return;
        }
        Iterator<Popup> it = ACTIVE.iterator();
        while (it.hasNext()) {
            boolean bad;
            Popup popup = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(popup.player);
            ++popup.age;
            boolean bl = bad = p == null || !p.isAlive() || popup.title.isRemoved() || popup.detail.isRemoved() || popup.title.level() != p.level() || popup.age >= 70;
            if (bad) {
                popup.title.discard();
                popup.detail.discard();
                it.remove();
                continue;
            }
            SkillPopups.follow(popup, p);
        }
    }

    public static void removeFor(UUID player) {
        Iterator<Popup> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Popup popup = it.next();
            if (!popup.player.equals(player)) continue;
            popup.title.discard();
            popup.detail.discard();
            it.remove();
        }
    }

    public static void clearAll() {
        for (Popup popup : ACTIVE) {
            popup.title.discard();
            popup.detail.discard();
        }
        ACTIVE.clear();
    }

    private static final class Popup {
        final UUID player;
        final ArmorStand title;
        final ArmorStand detail;
        int age;

        Popup(UUID player, ArmorStand title, ArmorStand detail) {
            this.player = player;
            this.title = title;
            this.detail = detail;
        }
    }
}

