package dev.survivorcreator;
import java.lang.reflect.Method;
import java.util.function.Supplier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.*;
public final class StarterGear {
 public static void give(ServerPlayer p){
  Item item=BuiltInRegistries.ITEM.get(ResourceLocation.parse("flashlight:flashlight_off"));if(item==Items.AIR)return;
  ItemStack stack=new ItemStack(item);if(!p.getInventory().add(stack))p.drop(stack,false);
  try{
   Class<?> vars=Class.forName("net.flashlight.network.FlashlightModVariables");Object type=((Supplier<?>)vars.getField("PLAYER_VARIABLES").get(null)).get();
   for(Method method:p.getClass().getMethods())if(method.getName().equals("getData")&&method.getParameterCount()==1&&method.getParameterTypes()[0].isInstance(type)){
    Object data=method.invoke(p,type);data.getClass().getField("BatteryFlashlight").setDouble(data,100);data.getClass().getMethod("markSyncDirty").invoke(data);break;
   }
  }catch(ReflectiveOperationException e){org.slf4j.LoggerFactory.getLogger("survivorcreator").warn("Unable to refill starter flashlight",e);}
 }
}
