/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.ChatFormatting
 *  net.minecraft.Util
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.client.resources.sounds.SimpleSoundInstance
 *  net.minecraft.client.resources.sounds.SoundInstance
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.FormattedText
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.util.Mth
 */
package dev.survivorcreator.client;

import dev.survivorcreator.ModSounds;
import dev.survivorcreator.client.ClientHooks;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;

public final class EndingScreen
extends Screen {
    private long started = -1L;
    private long phaseStarted = -1L;
    private int phase = 0;
    private final Component completionMessage;
    private SoundInstance music;
    private boolean finished;
    private long leaving=-1;
    private final boolean deathMode;

    public EndingScreen(Component component) {
        super((Component)Component.empty());
        this.completionMessage = component;
        String string = component == null ? "" : component.getString();
        this.deathMode = "__death__".equals(string);
    }

    public boolean isPauseScreen() {
        return false;
    }

    public boolean shouldCloseOnEsc() {
        return false;
    }

    public void render(GuiGraphics guiGraphics, int n, int n2, float f) {
        long l = Util.getMillis();
        if (this.started < 0L) {
            this.started = l;
            this.phaseStarted = l;
            if(this.deathMode)DeathAudio.beginDeath();else this.music=ClientHooks.playEndingMusic();
        }
        guiGraphics.fill(0, 0, this.width, this.height, -16777216);
        long l2 = l - this.phaseStarted;
        if (this.deathMode) {
            this.renderDeath(guiGraphics, l2);
        } else {
            this.renderIntro(guiGraphics, l2);
        }
        if(leaving>=0){
            float alpha=DeathTiming.fade(l-leaving);
            guiGraphics.fill(0,0,width,height,((int)(alpha*255)<<24));
            if(alpha>=1)this.finish();
        }
    }

    private void renderIntro(GuiGraphics guiGraphics, long l) {
        String string = switch (this.phase) {
            case 0 -> "screen.survivorcreator.ending.1";
            case 1 -> "screen.survivorcreator.ending.2";
            default -> "screen.survivorcreator.ending.3";
        };
        this.drawCentered(guiGraphics, (Component)Component.translatable((String)string), this.fade(l));
        this.drawPrompt(guiGraphics, (Component)Component.translatable((String)"screen.survivorcreator.ending.start"), 0.7f);
        if (l > 6800L) {
            this.nextPhase();
        }
    }

    private void renderDeath(GuiGraphics guiGraphics, long l) {
        if (l >= 850L) {
            this.drawCentered(guiGraphics, (Component)Component.translatable((String)"screen.survivorcreator.death.1"), this.fade(l - 850L));
        }
        if (DeathTiming.canSkip(l)) {
            this.drawPrompt(guiGraphics, (Component)Component.translatable((String)"screen.survivorcreator.death.start"), 0.8f);
        }
        if (l > 11500L) {
            this.leave();
        }
    }

    private void leave(){if(leaving<0){leaving=Util.getMillis();DeathAudio.click();}}

    private float fade(long l) {
        return Mth.clamp((float)((float)l / 1100.0f), (float)0.0f, (float)1.0f);
    }

    private void drawCentered(GuiGraphics guiGraphics, Component component, float f) {
        int n = (int)((f = Mth.clamp((float)f, (float)0.0f, (float)1.0f)) * 255.0f);
        if (n <= 3) {
            return;
        }
        int n2 = n << 24 | 0xE7E7D6;
        float f2 = this.deathMode ? 3.2f : 2.4f;
        guiGraphics.pose().pushPose();
        guiGraphics.pose().scale(f2, f2, 1.0f);
        int n3 = (int)(((float)this.width / f2 - (float)this.font.width((FormattedText)component)) / 2.0f);
        int n4 = (int)(((float)this.height / f2 - 9.0f) / 2.0f);
        guiGraphics.drawString(this.font, component, n3, n4, n2, false);
        guiGraphics.pose().popPose();
    }

    private void drawPrompt(GuiGraphics guiGraphics, Component component, float f) {
        int n = (int)(Mth.clamp((float)f, (float)0.0f, (float)1.0f) * 255.0f);
        if (n <= 3) {
            return;
        }
        int n2 = (this.width - this.font.width((FormattedText)component)) / 2;
        int n3 = this.height - 32;
        guiGraphics.drawString(this.font, component, n2, n3, n << 24 | 0xB8B8A6, false);
    }

    private SoundInstance playDeathAudio() {
        Minecraft minecraft = Minecraft.getInstance();
        SimpleSoundInstance simpleSoundInstance = SimpleSoundInstance.forUI((SoundEvent)ModSounds.ENDING_SIGH.get(), (float)1.0f, (float)1.0f);
        minecraft.getSoundManager().play((SoundInstance)simpleSoundInstance);
        return simpleSoundInstance;
    }

    private void nextPhase() {
        if (this.deathMode) {
            if(started>=0&&DeathTiming.canSkip(Util.getMillis()-started))this.leave();
            return;
        }
        if (this.phase < 2) {
            ++this.phase;
            this.phaseStarted = Util.getMillis();
        } else {
            this.finish();
        }
    }

    private void finish() {
        if (this.finished) {
            return;
        }
        this.finished = true;
        Minecraft minecraft = Minecraft.getInstance();
        if (this.music != null) {
            minecraft.getSoundManager().stop(this.music);
        }
        minecraft.setScreen(null);
        if (this.deathMode) {
            DeathAudio.creatorFade();
            ClientHooks.onOpen();
            return;
        }
        if (minecraft.player != null && this.completionMessage != null && !this.completionMessage.getString().isBlank()) {
            minecraft.player.displayClientMessage((Component)this.completionMessage.copy().withStyle(ChatFormatting.GREEN), false);
        }
    }

    public boolean keyPressed(int n, int n2, int n3) {
        this.nextPhase();
        return true;
    }

    public boolean mouseClicked(double d, double d2, int n) {
        this.nextPhase();
        return true;
    }
}

