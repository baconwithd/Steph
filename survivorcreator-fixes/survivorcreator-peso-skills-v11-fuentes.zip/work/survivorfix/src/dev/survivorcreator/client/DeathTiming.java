package dev.survivorcreator.client;
public final class DeathTiming {
 public static final long TEXT_AT=850,SKIP_AFTER=TEXT_AT+2000,FADE_MS=650;
 public static boolean canSkip(long elapsed){return elapsed>=SKIP_AFTER;}
 public static float fade(long elapsed){return Math.max(0,Math.min(1,elapsed/(float)FADE_MS));}
}
