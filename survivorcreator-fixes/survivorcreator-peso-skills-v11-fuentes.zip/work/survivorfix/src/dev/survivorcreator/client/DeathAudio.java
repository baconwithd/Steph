package dev.survivorcreator.client;
import dev.survivorcreator.ModSounds;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.*;
import net.minecraft.sounds.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
@EventBusSubscriber(modid="survivorcreator",value=Dist.CLIENT)
public final class DeathAudio {
 private static SoundInstance sigh;private static long began,fadeStarted=-1;private static boolean heard;
 public static void beginDeath(){
  Minecraft mc=Minecraft.getInstance();if(sigh!=null)mc.getSoundManager().stop(sigh);
  mc.getMusicManager().stopPlaying();sigh=SimpleSoundInstance.forUI(ModSounds.ENDING_SIGH.get(),1,1);began=Util.getMillis();heard=false;mc.getSoundManager().play(sigh);
 }
 public static void beginCreation(){if(sigh==null)menuMusic();}
 private static void menuMusic(){Minecraft mc=Minecraft.getInstance();mc.getMusicManager().stopPlaying();mc.getMusicManager().startPlaying(Musics.MENU);}
 @SubscribeEvent public static void tick(ClientTickEvent.Post e){
  if(sigh==null)return;
  Minecraft mc=Minecraft.getInstance();boolean active=mc.getSoundManager().isActive(sigh);heard|=active;
  if(!active&&(heard||Util.getMillis()-began>5000)){sigh=null;if(mc.screen instanceof EndingScreen||mc.screen instanceof CreatorScreen)menuMusic();}
 }
 public static void creatorFade(){fadeStarted=Util.getMillis();}
 public static void fadeIn(GuiGraphics g,int width,int height){
  if(fadeStarted<0)return;float alpha=1-DeathTiming.fade(Util.getMillis()-fadeStarted);
  if(alpha<=0){fadeStarted=-1;return;}g.fill(0,0,width,height,((int)(alpha*255)<<24));
 }
 public static boolean clickIf(boolean accepted){if(accepted)click();return accepted;}
 public static void click(){Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(),1));}
}
