import com.armilp.ezweight.player.CarryRules;
import dev.survivorcreator.skills.WorkRules;
import dev.survivorcreator.client.DeathTiming;
public final class BalanceTest{
 static int count;
 static void check(boolean value,String message){count++;if(!value)throw new AssertionError(message);}
 static boolean close(double a,double b){return Math.abs(a-b)<.000001;}
 public static void main(String[] args){
  check(CarryRules.capacity(0,0,0)==50,"New survivor carries fifty kg");
  for(int level=0;level<10;level++){
   check(CarryRules.capacity(level+1,0,0)>CarryRules.capacity(level,0,0),"Strength grows capacity gradually");
   check(CarryRules.capacity(0,level+1,0)>CarryRules.capacity(0,level,0),"Fitness grows capacity gradually");
   check(CarryRules.capacity(0,0,level+1)>CarryRules.capacity(0,0,level),"Endurance grows capacity gradually");
  }
  check(CarryRules.capacity(100,-1,100)==75,"Invalid/excess skill levels are clamped");
  check(close(CarryRules.item(3),1),"All items one third base weight");
  double ammo=CarryRules.item(.2)*96;
  check(close(ammo,6.4)&&ammo<50*.8,"Stack and a half of ammo below nuisance threshold");
  check(close(CarryRules.contents(ammo),.64),"Backpack content weighs ten percent");
  check(close(CarryRules.contents(0),0),"Empty backpack contents weigh zero");
  for(double invalid:new double[]{-1,Double.NaN,Double.POSITIVE_INFINITY})check(CarryRules.item(invalid)==0,"Invalid weights never poison total");
  check(close(CarryRules.item(3)+CarryRules.contents(CarryRules.item(30)),2),"Backpack shell counted in full, only contents reduced");
  check(WorkRules.metal("minecraft:iron_ingot")&&WorkRules.metal("fracturepoint:steel_blend"),"Vanilla and mod metal jobs recognized");
  check(WorkRules.wood("minecraft:oak_planks")&&WorkRules.wood("minecraft:oak_trapdoor"),"Wood jobs recognized");
  check(WorkRules.electric("flashlight:battery"),"Electrical crafts recognized");
  check(WorkRules.craftXp(64)==32&&WorkRules.craftXp(1)==2,"Shift-crafted XP capped per event");
  check(close(WorkRules.workSpeed(10,10),13),"Work skill bonus bounded at thirty percent");
  check(!DeathTiming.canSkip(2849)&&DeathTiming.canSkip(2850),"Exactly two seconds after first text appears");
  check(DeathTiming.fade(-1)==0&&DeathTiming.fade(0)==0&&DeathTiming.fade(650)==1&&DeathTiming.fade(9999)==1,"Fade alpha clamped");
  System.out.println(count+" weight/progression/work/death timing checks passed");
 }
}
