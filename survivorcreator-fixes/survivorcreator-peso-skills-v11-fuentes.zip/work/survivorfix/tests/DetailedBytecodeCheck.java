import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.CheckClassAdapter;
public final class DetailedBytecodeCheck{
 public static void main(String[] args)throws Exception{
  int count=0;
  try(var paths=Files.walk(Path.of(args[0]))){
   for(Path p:paths.filter(p->p.toString().endsWith(".class")).toList()){
    byte[] bytes=Files.readAllBytes(p);ClassReader reader=new ClassReader(bytes);
    reader.accept(new CheckClassAdapter(new ClassWriter(0),false),0);
    ClassNode node=new ClassNode();reader.accept(node,0);
    for(MethodNode m:node.methods)if((m.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))==0){try{new Analyzer<BasicValue>(new BasicVerifier()).analyze(node.name,m);}catch(Exception e){System.out.println(node.name+" "+m.name+m.desc);throw e;}}
    count++;
   }
  }
  System.out.println("Bytecode structure and stack verification passed: "+count+" mod classes");
 }
}
