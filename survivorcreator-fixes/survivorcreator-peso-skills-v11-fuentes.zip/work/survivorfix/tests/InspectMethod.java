import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.util.*;
public class InspectMethod{public static void main(String[]a)throws Exception{try(ZipFile z=new ZipFile(a[0])){new ClassReader(z.getInputStream(z.getEntry(a[1]))).accept(new TraceClassVisitor(new java.io.PrintWriter(System.out)),0);}}}
