import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public final class WiringTest{
 static int checks;
 static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
 static ClassNode read(ZipFile z,String name)throws Exception{ClassNode n=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(n,0);return n;}
 static MethodNode method(ClassNode n,String name){return n.methods.stream().filter(m->m.name.equals(name)).findFirst().orElseThrow();}
 static boolean annotated(MethodNode m){return m.visibleAnnotations!=null&&m.visibleAnnotations.stream().anyMatch(a->a.desc.equals("Lnet/neoforged/bus/api/SubscribeEvent;"));}
 static boolean calls(MethodNode m,String owner,String name){for(var i:m.instructions)if(i instanceof MethodInsnNode c&&c.owner.equals(owner)&&c.name.equals(name))return true;return false;}
 public static void main(String[] args)throws Exception{
  try(ZipFile z=new ZipFile(args[0])){
   ClassNode events=read(z,"dev/survivorcreator/skills/SkillEvents");
   check(events.visibleAnnotations.stream().anyMatch(a->a.desc.equals("Lnet/neoforged/fml/common/EventBusSubscriber;")),"Skill lifecycle registered as subscriber");
   for(String m:new String[]{"onPlayerTick","onJump","onHit","onServerTick","onLogout","onStopping","onEntityJoin"})check(annotated(method(events,m)),"Registered original skill event "+m);
   check(calls(method(events,"onServerTick"),"dev/survivorcreator/skills/SkillPopups","tick"),"Popup clock actually connected to server ticks");
   check(calls(method(events,"onEntityJoin"),"net/neoforged/neoforge/event/entity/EntityJoinLevelEvent","loadedFromDisk"),"Orphan cleanup does not suppress new popups");
   ClassNode work=read(z,"dev/survivorcreator/skills/WorkEvents");for(String m:new String[]{"craft","smelt","harvest","plant","hoe","breakSpeed","fish","use"})check(annotated(method(work,m)),"Work event registered "+m);
   check(calls(method(read(z,"dev/survivorcreator/effects/Effects"),"firstGrant"),"dev/survivorcreator/StarterGear","give"),"Flashlight grant attached to new-character grant");
   ClassNode creator=read(z,"dev/survivorcreator/client/CreatorScreen");check(calls(method(creator,"mouseClicked"),"dev/survivorcreator/client/DeathAudio","clickIf"),"Options click sound attached");check(calls(method(creator,"render"),"dev/survivorcreator/client/DeathAudio","fadeIn"),"Creator fade attached");
   check(annotated(method(read(z,"dev/survivorcreator/client/DeathAudio"),"tick")),"Audio transition continues after death screen closes");
   for(String wood:new String[]{"oak","spruce","birch","jungle","acacia","dark_oak","mangrove","cherry","bamboo","crimson","warped"})check(z.getEntry("data/survivorcreator/recipe/recycle_"+wood+"_trapdoor.json")!=null,"Trapdoor recipe "+wood);
  }
  try(ZipFile z=new ZipFile(args[1])){
   MethodNode tick=method(read(z,"com/armilp/ezweight/events/WeightEventHandler"),"onPlayerTick");int shared=0,playerTicks=0;
   for(var i:tick.instructions)if(i instanceof FieldInsnNode f){if(f.getOpcode()==Opcodes.GETSTATIC&&f.name.equals("tickCounter"))shared++;if(f.getOpcode()==Opcodes.GETFIELD&&f.name.equals("tickCount"))playerTicks++;}
   check(shared==1&&playerTicks==1,"Each player initializes their own twenty-tick check before counter comparison");
   check(calls(tick,"com/armilp/ezweight/player/LoadEffects","forPlayer"),"Load effects follow personal capacity");
   check(calls(method(read(z,"com/armilp/ezweight/events/ItemPickupEventHandler"),"onItemPickup"),"com/armilp/ezweight/player/PlayerWeightHandler","getPickupUnitWeight"),"Picking up full containers includes reduced contents");
   ClassNode registry=read(z,"com/armilp/ezweight/data/ItemWeightRegistry");check(calls(method(registry,"getWeight"),"com/armilp/ezweight/player/CarryRules","item"),"Unit weights divided once");check(calls(method(registry,"getStackTotalWeight"),"com/armilp/ezweight/player/CarryRules","item"),"Stack tooltip weights divided once");
  }
  System.out.println(checks+" event/packaging regression checks passed");
 }
}
