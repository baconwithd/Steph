import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public final class PatchJar implements Opcodes{
 static String helper="dev/survivorcreator/client/DeathAudio";
 static ClassNode read(byte[] bytes){ClassNode n=new ClassNode();new ClassReader(bytes).accept(n,0);return n;}
 static byte[] write(ClassNode n){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);return w.toByteArray();}
 static void replace(MethodNode m,InsnList insns){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(insns);}
 static InsnList call(String owner,String name,String desc){InsnList i=new InsnList();i.add(new MethodInsnNode(INVOKESTATIC,owner,name,desc,false));return i;}
 static byte[] patch(String path,byte[] bytes){
  if(!path.endsWith(".class"))return bytes;
  ClassNode n=read(bytes);boolean changed=false;
  for(MethodNode m:n.methods){
   if(n.name.equals("dev/survivorcreator/skills/Skills")&&m.name.equals("describe")){
    InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,0));code.add(new VarInsnNode(ILOAD,1));code.add(call("dev/survivorcreator/skills/WorkBenefits","describe","(Ldev/survivorcreator/skills/Skill;I)Lnet/minecraft/network/chat/Component;"));code.add(new InsnNode(ARETURN));replace(m,code);changed=true;
   }
   if(n.name.equals("dev/survivorcreator/effects/Effects")&&m.name.equals("firstGrant")){
    InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,0));code.add(call("dev/survivorcreator/StarterGear","give","(Lnet/minecraft/server/level/ServerPlayer;)V"));m.instructions.insert(code);changed=true;
   }
   if(n.name.equals("dev/survivorcreator/client/ClientHooks")&&m.name.equals("beginCreationAudio")){
    InsnList code=call(helper,"beginCreation","()V");code.add(new InsnNode(RETURN));replace(m,code);changed=true;
   }
   if(n.name.equals("dev/survivorcreator/client/CreatorScreen")){
    for(AbstractInsnNode ins:m.instructions.toArray()){
     if(m.name.equals("mouseClicked")&&ins.getOpcode()==IRETURN){m.instructions.insertBefore(ins,call(helper,"clickIf","(Z)Z"));changed=true;}
     if(m.name.equals("render")&&ins.getOpcode()==RETURN){
      InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,1));code.add(new VarInsnNode(ALOAD,0));code.add(new FieldInsnNode(GETFIELD,"net/minecraft/client/gui/screens/Screen","width","I"));code.add(new VarInsnNode(ALOAD,0));code.add(new FieldInsnNode(GETFIELD,"net/minecraft/client/gui/screens/Screen","height","I"));code.add(call(helper,"fadeIn","(Lnet/minecraft/client/gui/GuiGraphics;II)V"));m.instructions.insertBefore(ins,code);changed=true;
     }
    }
   }
   if(n.name.equals("com/armilp/ezweight/data/ItemWeightRegistry")&&(m.name.equals("getWeight")||m.name.equals("getStackTotalWeight"))){
    for(AbstractInsnNode ins:m.instructions.toArray())if(ins.getOpcode()==DRETURN)m.instructions.insertBefore(ins,call("com/armilp/ezweight/player/CarryRules","item","(D)D"));changed=true;
   }
   if(n.name.equals("com/armilp/ezweight/util/BackpackIdUtils")&&m.name.equals("getWeightReductionPercent")){
    // Every recognized backpack has the same effective reduction, including old per-instance overrides.
    InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,0));code.add(call("com/armilp/ezweight/player/PlayerWeightHandler","backpackReduction","(Lnet/minecraft/world/item/ItemStack;)D"));code.add(new InsnNode(DRETURN));replace(m,code);changed=true;
   }
   if(n.name.equals("com/armilp/ezweight/util/BackpackIdUtils")&&m.name.equals("calculateBackpackContentsWeight")){
    InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,0));code.add(new VarInsnNode(DLOAD,1));code.add(call("com/armilp/ezweight/player/PlayerWeightHandler","backpackContents","(Lnet/minecraft/world/item/ItemStack;D)D"));code.add(new InsnNode(DRETURN));replace(m,code);changed=true;
   }
   if(n.name.equals("com/armilp/ezweight/events/WeightEventHandler")&&m.name.equals("onPlayerTick")){
    boolean counterReplaced=false;
    for(AbstractInsnNode ins:m.instructions.toArray()){
     // Per-player schedule fixes the shared multiplayer tick counter.
     if(ins instanceof FieldInsnNode f&&f.getOpcode()==GETSTATIC&&f.name.equals("tickCounter")&&!counterReplaced){
      InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,1));code.add(new FieldInsnNode(GETFIELD,"net/minecraft/world/entity/Entity","tickCount","I"));code.add(new LdcInsnNode(20));code.add(new InsnNode(IREM));m.instructions.insertBefore(ins,code);m.instructions.remove(ins);counterReplaced=true;
     }
     if(ins instanceof MethodInsnNode mi&&mi.name.equals("getLevelForWeight")){
      InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,1));code.add(call("com/armilp/ezweight/player/LoadEffects","forPlayer","(DLnet/minecraft/world/entity/player/Player;)Lcom/armilp/ezweight/levels/WeightLevel;"));m.instructions.insertBefore(ins,code);m.instructions.remove(ins);
     }
    }changed=true;
   }
   if(n.name.equals("com/armilp/ezweight/events/ItemPickupEventHandler")&&m.name.equals("onItemPickup")){
    for(AbstractInsnNode ins:m.instructions.toArray())if(ins instanceof MethodInsnNode mi&&mi.name.equals("getWeight")&&mi.owner.equals("com/armilp/ezweight/data/ItemWeightRegistry")){
     InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,0));code.add(new MethodInsnNode(INVOKEVIRTUAL,"net/neoforged/neoforge/event/entity/player/ItemEntityPickupEvent$Pre","getPlayer","()Lnet/minecraft/world/entity/player/Player;",false));code.add(call("com/armilp/ezweight/player/PlayerWeightHandler","getPickupUnitWeight","(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/player/Player;)D"));m.instructions.insertBefore(ins,code);m.instructions.remove(ins);changed=true;
    }
   }
   if(n.name.equals("com/armilp/ezweight/events/ContainerEventHandler")&&m.name.startsWith("drop")){
    for(AbstractInsnNode ins:m.instructions.toArray())if(ins.getOpcode()==DSUB){
     InsnList code=new InsnList();code.add(new InsnNode(POP2));code.add(new VarInsnNode(ALOAD,0));code.add(call("com/armilp/ezweight/player/PlayerWeightHandler","getTotalWeight","(Lnet/minecraft/world/entity/player/Player;)D"));m.instructions.insert(ins,code);changed=true;
    }
   }
   if(n.name.equals("com/armilp/ezweight/levels/WeightLevelManager")&&m.name.equals("getLevelForPlayer")){
    InsnList code=new InsnList();code.add(new VarInsnNode(ALOAD,0));code.add(call("com/armilp/ezweight/player/LoadEffects","forNullablePlayer","(Lnet/minecraft/world/entity/player/Player;)Lcom/armilp/ezweight/levels/WeightLevel;"));code.add(new InsnNode(ARETURN));replace(m,code);changed=true;
   }
   if(n.name.equals("com/armilp/ezweight/events/WeightJumpBlocker")&&m.name.equals("isJumpDisabled")){
    // Capacity-aware overload remains in onLivingJump; obsolete absolute ranges must not immobilize trained players.
    InsnList code=new InsnList();code.add(new InsnNode(ICONST_0));code.add(new InsnNode(IRETURN));replace(m,code);changed=true;
   }
  }
  return changed?write(n):bytes;
 }
 public static void main(String[] args)throws Exception{
  String kind=args[2];Path build=Path.of("work/survivorfix/build");Set<String> replaced=new HashSet<>();
  try(ZipFile original=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[1])))){
   var entries=original.entries();while(entries.hasMoreElements()){
    ZipEntry entry=entries.nextElement();String name=entry.getName();if(entry.isDirectory())continue;
    byte[] data=original.getInputStream(entry).readAllBytes();Path compiled=build.resolve(name);
    if(Files.exists(compiled)){data=Files.readAllBytes(compiled);replaced.add(name);}else data=patch(name,data);
    Path resource=Path.of("work/survivorfix/resources",name);if(kind.equals("survivor")&&Files.isRegularFile(resource))data=Files.readAllBytes(resource);
    if(name.equals("META-INF/neoforge.mods.toml")){
     String text=new String(data,java.nio.charset.StandardCharsets.UTF_8);
     text=text.replace(kind.equals("survivor")?"version = \"1.0.5\"":"version = \"1.8.4-stamina\"",kind.equals("survivor")?"version = \"1.0.6\"":"version = \"1.8.4-stamina-v7\"");data=text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
    }
    out.putNextEntry(new ZipEntry(name));out.write(data);out.closeEntry();
   }
   try(var paths=Files.walk(build)){
    for(Path p:paths.filter(Files::isRegularFile).toList()){
     String name=build.relativize(p).toString();if(!name.endsWith(".class")||replaced.contains(name))continue;
     if(!(kind.equals("survivor")?name.startsWith("dev/survivorcreator/"):name.startsWith("com/armilp/ezweight/")))continue;
     out.putNextEntry(new ZipEntry(name));out.write(Files.readAllBytes(p));out.closeEntry();
    }
   }
   if(kind.equals("survivor"))for(String wood:new String[]{"oak","spruce","birch","jungle","acacia","dark_oak","mangrove","cherry","bamboo","crimson","warped"}){
    String json="{\"type\":\"minecraft:crafting_shapeless\",\"category\":\"building\",\"ingredients\":[{\"item\":\"minecraft:"+wood+"_trapdoor\"}],\"result\":{\"id\":\"minecraft:"+wood+"_planks\",\"count\":2}}";
    out.putNextEntry(new ZipEntry("data/survivorcreator/recipe/recycle_"+wood+"_trapdoor.json"));out.write(json.getBytes());out.closeEntry();
   }
  }
 }
}
