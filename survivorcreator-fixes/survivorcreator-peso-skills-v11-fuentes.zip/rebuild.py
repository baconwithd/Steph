# Run from the extracted source ZIP directory. Requires Python 3 and Java 21.
import argparse,pathlib,urllib.request,subprocess,glob,os
p=argparse.ArgumentParser()
for n in ('minecraft','neoforge','survivor','ezweight'):p.add_argument('--'+n,required=True)
a=p.parse_args();lib=pathlib.Path('work/lib');lib.mkdir(parents=True,exist_ok=True)
artifacts=[('org/eclipse/jdt/ecj/3.40.0/ecj-3.40.0.jar','ecj.jar'),('com/google/code/gson/gson/2.11.0/gson-2.11.0.jar','gson.jar'),('com/google/guava/guava/33.3.1-jre/guava-33.3.1-jre.jar','guava.jar'),('org/slf4j/slf4j-api/2.0.16/slf4j-api-2.0.16.jar','slf4j.jar'),('org/joml/joml/1.10.5/joml-1.10.5.jar','joml.jar')]
for artifact in ('asm','asm-tree','asm-analysis','asm-util'):artifacts.append((f'org/ow2/asm/{artifact}/9.7.1/{artifact}-9.7.1.jar',artifact+'.jar'))
for remote,name in artifacts:
 if not (lib/name).exists():urllib.request.urlretrieve('https://repo.maven.apache.org/maven2/'+remote,lib/name)
cp=os.pathsep.join(glob.glob('work/lib/*.jar')+[a.minecraft,a.neoforge,a.survivor,a.ezweight])
build='work/survivorfix/build';pathlib.Path(build).mkdir(parents=True,exist_ok=True)
files=glob.glob('work/survivorfix/src/**/*.java',recursive=True)+glob.glob('work/stubs/**/*.java',recursive=True)
subprocess.run(['java','-jar',str(lib/'ecj.jar'),'-21','-proc:none','-warn:none','-cp',cp,'-d',build]+files,check=True)
subprocess.run(['java','-jar',str(lib/'ecj.jar'),'-21','-proc:none','-cp',cp,'-d','work/survivorfix/tools','work/survivorfix/PatchJar.java'],check=True)
pathlib.Path('outputs').mkdir(exist_ok=True)
for source,name,kind in [(a.survivor,'survivorcreator-neoforge-1.21.1-1.0.6-zomboid-v11-skills-fixed.jar','survivor'),(a.ezweight,'eZWeight-neoforge-1.21.1-1.8.4-stamina-v7-balanced.jar','weight')]:
 subprocess.run(['java','-cp','work/survivorfix/tools'+os.pathsep+cp,'PatchJar',source,'outputs/'+name,kind],check=True)
print('Built two replacement JARs in outputs/. Compile-only NeoForge stubs are not shipped.')
